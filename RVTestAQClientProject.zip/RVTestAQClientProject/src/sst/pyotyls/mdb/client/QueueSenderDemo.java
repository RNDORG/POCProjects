package sst.pyotyls.mdb.client;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.NamingException;

import sst.pyotyls.mdb.bean.RequestOrder;

 
public class QueueSenderDemo {
    private static final String QUEUE_LOOKUP = "jms/queue/MyQueue";
    private static final String CONNECTION_FACTORY = "jms/ConnectionFactory";
 
    public static void main(String[] args) {
        sendMessageToQueue();
        sendObjectMessageToQueue();
    }
 
    public static void sendMessageToQueue() {
        try {
            Context context = ClientUtility.getInitialContextForClient();
            QueueConnectionFactory factory = (QueueConnectionFactory) context.lookup(CONNECTION_FACTORY);
            QueueConnection connection = factory.createQueueConnection();
            QueueSession session = connection.createQueueSession(false, QueueSession.AUTO_ACKNOWLEDGE);
            Queue queue = (Queue) context.lookup(QUEUE_LOOKUP);
 
            QueueSender sender = session.createSender(queue);
            TextMessage message = session.createTextMessage();
            message.setText("Welcome to EJB3");
            sender.send(message);
            session.close();
        } catch (NamingException e) {
            e.printStackTrace();
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
 
    public static void sendObjectMessageToQueue() {
        try {
            Context context = ClientUtility.getInitialContextForClient();
            QueueConnectionFactory factory = (QueueConnectionFactory) context.lookup(CONNECTION_FACTORY);
            QueueConnection connection = factory.createQueueConnection();
            QueueSession session = connection.createQueueSession(false, QueueSession.AUTO_ACKNOWLEDGE);
            Queue queue = (Queue) context.lookup(QUEUE_LOOKUP);
 
            QueueSender sender = session.createSender(queue);
            ObjectMessage message = session.createObjectMessage();
            RequestOrder requestOrder = new RequestOrder();
            requestOrder.setOrderId(1234);
            requestOrder.setCustomerMsisdn("981xxxx197");
            requestOrder.setItemListText("A-2,B-1,C-9");
            message.setObject(requestOrder);
            sender.send(message);
            session.close();
        } catch (NamingException e) {
            e.printStackTrace();
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}