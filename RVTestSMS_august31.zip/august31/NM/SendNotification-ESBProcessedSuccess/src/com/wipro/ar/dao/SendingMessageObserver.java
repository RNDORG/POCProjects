package com.wipro.ar.dao;

import ie.omk.smpp.Connection;
import ie.omk.smpp.event.ConnectionObserver;
import ie.omk.smpp.event.ReceiverExitEvent;
import ie.omk.smpp.event.SMPPEvent;
import ie.omk.smpp.message.SMPPPacket;
import ie.omk.smpp.message.Unbind;
import ie.omk.smpp.message.UnbindResp;

import java.io.IOException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.wipro.ar.util.Constants;
import com.wipro.ar.util.HibernateUtil;

public class SendingMessageObserver implements ConnectionObserver
{
	private static final Logger logger = Logger.getLogger(com.wipro.ar.dao.SendingMessageObserver.class);
	private static int msgCount = 0;

    // Start time (once successfully bound).
    private long start = 0;

    // End time (either send an unbind or an unbind received).
    private long end = 0;

    // Set to true to display each message received.
    private boolean showMsgs = true;
    
    private int   respStatus = 0;
    
    //private int grpNumber;
    
    SessionFactory sessionFactory =  HibernateUtil.getSessionFactoryWrite();
	 // opens a new session from the session factory	   
    Session session; 
    Transaction txUpdate;
    Query q;
    
    // This is called when the connection receives a packet from the SMSC.
    public void update(Connection r, SMPPEvent ev) {
        switch (ev.getType()) {
        case SMPPEvent.RECEIVER_EXIT:
            receiverExit(r, (ReceiverExitEvent) ev);
            break;         
        }
    }

    
    public void packetReceived(Connection myConnection, SMPPPacket pak) 
    {    	
    	
    	switch (pak.getCommandId()) 
	    {
	        // Bind transmitter response. Check it's status for success...
	        case SMPPPacket.BIND_TRANSMITTER_RESP:
	        	respStatus = pak.getCommandStatus();
	            if (respStatus != 0) 
	            {
	               logger.info("Error binding to the SMSC. Error = "+ pak.getCommandStatus());
	            }
	            else 
	            {
	                this.start = System.currentTimeMillis();
	               logger.info("Successfully bound. Waiting for message this is Sending Message delivery..");
	            }
	            break;
	
	        // Submit message response...
	        case SMPPPacket.SUBMIT_SM_RESP:
	        	respStatus = pak.getCommandStatus();
	        	logger.info("Response received from SMSC for record no:  " + pak.getSequenceNum());
	        	if (respStatus != 0) 
	        	{	
	        		//88	0x58	ESME_RTHROTTLED
	        		if(respStatus == Constants.RTHROTTLED)
	        		{
	        			logger.info("Throttling error from SMSC for record no:  " + pak.getSequenceNum());
	        		}
	        		else
	        		{
	        			logger.info("Error in getting sending message response. "  + respStatus + "and record no: " + pak.getSequenceNum());
	        		}
	        		// Update Table on Error
        		   try
                   {
        			   session  = sessionFactory.openSession();
        			   txUpdate = session.beginTransaction();
	                   q = session.createQuery("Update ARNotificationSuccess  set status=:pstatus  where recordNum=:precordNum");	                   
	                   q.setString("pstatus", "Error");
	                   q.setLong("precordNum", pak.getSequenceNum());
	                   q.executeUpdate();
	                   txUpdate.commit();	                   
                   }
                   catch(Exception ex)
                   {
                	   logger.error("Exception in observer update ::: " + ex.getMessage());
                	   txUpdate.rollback();                	   	                	   
                   }
        		   finally
        		   {
        			   session.close();
        		   }
	        		
	        	}
	            else 
	            {
	                ++msgCount;
	                 
	                if (showMsgs)
	                {
	                  
	                   logger.info("Received Send Message  response for record no: " + pak.getSequenceNum());
	                   try
	                   {
	                	   session  = sessionFactory.openSession();
	                	   txUpdate = session.beginTransaction();
		                   q = session.createQuery("Update ARNotificationSuccess set status=:pstatus  where recordNum=:precordNum");		                   
		                   q.setString("pstatus", "PUBLISHED");
		                   q.setLong("precordNum", pak.getSequenceNum());
		                   q.executeUpdate();
		                   txUpdate.commit();		                   
	                   }
	                   catch(Exception ex)
	                   {
	                	   session.getTransaction().rollback();
	                	   logger.error("Exception in observer update for success response ::: " + ex.getMessage());	                	                  	   
	                   }
	                   finally
	                   {
	                	   session.close();	
	                   }
	                    
	                }
	                else if ((msgCount % 500) == 0)
	                {
	                    System.out.print("."); // Give some feedback
	                }
	            }
	            break;
	            
	       /* case SMPPPacket.DELIVER_SM:
	            if (pak.getCommandStatus() != 0) 
	            {
	               logger.info("Deliver SM with an error! "  + pak.getCommandStatus());
	
	            } 
	            else 
	            {
	                ++msgCount;
	                if (showMsgs)
	                {
	                	logger.info("New Message Received/n");
	                   logger.info("getSequenceNum() :  " + Integer.toString(pak.getSequenceNum()));	                         
	                    
	                    // String messageText = ((DeliverSM) pak).getMessageText();
	                     byte[] bytes =((DeliverSM) pak).getMessage();
	                     String messageText = new String(bytes); 
	                     
	                     
	                    String source = pak.getSource().getAddress();
	                    String destination = pak.getDestination().getAddress();
	                   // receiveMessageService.receiveMessage(messageText, source, destination);
	                    
	                   
	                }
	                else if ((msgCount % 500) == 0)
	                {
	                    System.out.print("."); // Give some feedback
	                }
	            }
	            break;*/
	            
	
	        // Unbind request received from server..
	        case SMPPPacket.UNBIND:
	            this.end = System.currentTimeMillis();
	           logger.info("\nSMSC has requested unbind! Responding..");
	            try 
	            {
	                UnbindResp ubr = new UnbindResp((Unbind) pak);
	                myConnection.sendResponse(ubr);
	            }
	            catch (IOException x) 
	            {
	                logger.error("IO Exception" + x.getMessage());
	            	x.printStackTrace(System.err);
	            }
	            finally 
	            {
	                endReport();
	            }
	            break;	
	        // Unbind response..
	        case SMPPPacket.UNBIND_RESP:
	            this.end = System.currentTimeMillis();
	           logger.info("\nUnbound.");
	            endReport();
	            break;
	
	        case SMPPPacket.ENQUIRE_LINK_RESP:
	           logger.info("\nENQUIRE_LINK_RESP.");
	            break;   
	         
	        default:
	           logger.info(pak.getCommandId()+" \nUnexpected packet received! Id = "
	                     + Integer.toHexString(pak.getCommandId()));
	     }
    }

    private void receiverExit(Connection myConnection, ReceiverExitEvent ev) {
        if (ev.getReason() != ReceiverExitEvent.EXCEPTION) {
           logger.info("Receiver thread has exited normally.");
        } else {
            Throwable t = ev.getException();
           logger.info("Receiver thread died due to exception:");
            t.printStackTrace(System.out);
            endReport();
        }
    }

    // Print out a report
    private void endReport() {
       logger.info("deliver_sm's received: " + msgCount);
       logger.info("Start time: " + new Date(start).toString());
       logger.info("End time: " + new Date(end).toString());
       logger.info("Elapsed: " + (end - start) + " milliseconds.");
    }
    
    
    @Override
    protected void finalize() throws Throwable 
    {
        try
        {	
        	session.close();    	
        }
        catch(Throwable t)
        {
            throw t;
        }
        finally
        {
            super.finalize();
        }
      
    }


}
