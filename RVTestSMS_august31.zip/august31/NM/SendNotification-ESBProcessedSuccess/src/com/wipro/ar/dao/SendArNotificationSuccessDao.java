package com.wipro.ar.dao;


import ie.omk.smpp.util.DefaultAlphabetEncoding;

import java.util.Date;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;

import com.wipro.ar.bean.ARNotificationSuccess;
import com.wipro.ar.util.BoundedExecutor;
import com.wipro.ar.util.Constants;
import com.wipro.ar.util.HibernateUtil;

public class SendArNotificationSuccessDao implements Runnable {
	
	private static final Logger logger = Logger.getLogger(com.wipro.ar.dao.SendArNotificationSuccessDao.class);
	
	private CountDownLatch doneSignal;
	private String batchName;
	private int workerNumber;	
	private Runnable sendlongSMSobj;
	private static final int maxShortMessageLength = 160;
    private static final int maxSegmentLength      = 153;
    private DefaultAlphabetEncoding  encoding;
	byte[] msgInByte;
	private int parts;
	
	
	public SendArNotificationSuccessDao(CountDownLatch doneSignal, String batchName, int workerNumber) {
		super();
		this.doneSignal = doneSignal;
		this.batchName  = batchName;
		this.workerNumber = workerNumber;
	}


	public void run() {
		
		logger.info(Thread.currentThread().getName()+" (Start) groupNumber = " + workerNumber);  
		processPendings4SendingSms();		
		doneSignal.countDown(); 
		
		

	}
	
	 	
	 public void processPendings4SendingSms()
	 {
		 
		logger.debug(Thread.currentThread().getName()+" (processPendings4SendingSms()) groupNumber = " + workerNumber);		
		SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();
		logger.debug("Connect to database successfully");	 
					
		 // opens a new session from the session factory
		Session session 			= sessionFactory.openSession();
		Transaction tx  			= session.beginTransaction();
		Transaction txUpdate		= null;
		Session sessionUpdate		= null;
		Query q						= null;
		//SendLongSMS sendlongSMSobj 	= null;
		final int maxRows 			= Constants.MAX_RECORDS;
		
		final int prethrottledControlValue	= Constants.THROTTLED_MAX_VALUE/(Constants.NO_OF_GRP*20); //1000/20 = 50 ms division
		final int throttledControlValue	    = prethrottledControlValue;  
		final int throttledControlValueHalf	= throttledControlValue/2;
		final int throttledRecordsValueHalf	= ((Constants.THROTTLED_MAX_VALUE*60*2)/Constants.NO_OF_GRP)/2;
		BoundedExecutor boundedExecutor 	= null;
		ScrollableResults arSuccessNotificationCursor = null;
		ARNotificationSuccess arSuccessNotification   = null;
		int throttledCounter		= 0;
		int page 					= 0;
		int grp						= 0;
		long recordNum 				= 0L;
		String batchId 				= null;
		String msisdn  				= null;
		String productId			= null;
		Date createdTime			= null;
		Date startDate				= null;
		Date endDate				= null;
		String status				= null;
		String tdfName				= null;
		float tdfAmount				= 0.0f;
		String notification			= null;	
		String productType			= null;
		String template				= null;
		String result				= null;
		int count 					= 0;
		boolean metLastRow			= false;
		int recordCounter			= 0;
		encoding  = new DefaultAlphabetEncoding();
		
		try
		{	
						 
			int totalRecourdCount = ((Long)session.createQuery("select count(*) from ARNotificationSuccess NS where batchId = '"+ batchName  + "'and NS.grp = " + workerNumber  +" and ((productType = '"+ Constants.WO_SIMPLE + "' and  status = '" + Constants.STATUS_PENDING+ "') or status = '"+ Constants.STATUS_SUCCESS_ESB +"'))").uniqueResult()).intValue();			
			int pageSize   		  = 0;
			int remainder  		  = 0;
			int quotient   		  = 0;			
			quotient	   		  = totalRecourdCount/maxRows;
			remainder	   		  = totalRecourdCount%maxRows;
			
			if(remainder > 0)
			{
				pageSize		  = quotient + 1;
			}
			else
			{
				pageSize = quotient;
			}
			
			logger.info("Total Record count: " + totalRecourdCount + " for group no " + workerNumber +" and Page Size : " + pageSize);
			
			ExecutorService executor  = Executors.newFixedThreadPool(Constants.WORKERS_FOR_SEND_SMS);
			CountDownLatch doneSignal = new CountDownLatch(Constants.WORKERS_FOR_SEND_SMS);
			
			while (page < pageSize)
		    {
			
				logger.info("\n .....Statring of  Page : " + page + " and one page conatins :  " + maxRows + "reccords" );
				
				Criteria criteria 			= session.createCriteria(ARNotificationSuccess.class);
				Criterion batch 			= Restrictions.eq("batchId", batchName);
				Criterion statusPending 	= Restrictions.eq("status", Constants.STATUS_PENDING );
				Criterion productTypeCrt 	= Restrictions.eq("productType", Constants.WO_SIMPLE );
				Criterion statusESBSuccess  = Restrictions.eq("status", Constants.STATUS_SUCCESS_ESB );
				Criterion grpNumber 		= Restrictions.eq("grp", workerNumber );
				
		        LogicalExpression andExp 	= Restrictions.and(Restrictions.and(batch, grpNumber), Restrictions.or(Restrictions.and(statusPending, productTypeCrt), statusESBSuccess));	        
		        criteria.add(andExp);
								
				arSuccessNotificationCursor = criteria.setReadOnly(true).setFirstResult(page*maxRows).setMaxResults(maxRows).scroll(ScrollMode.FORWARD_ONLY);	
				
				recordNum 			= 0L;
				grp				    = 0;
				batchId 			= null;
				msisdn  			= null;
				productId			= null;
				createdTime		    = null;
				startDate			= null;
				endDate			    = null;
				status				= null;
				tdfName			    = null;
				tdfAmount			= 0.0f;
				notification		= null;	
				productType		    = null;
				template			= null;
				result				= null;
				count 				= 0;
				metLastRow			= false;
				
				
				try 
				{	
					boundedExecutor = new BoundedExecutor(executor, throttledControlValue);
					
					do
					{		
						
						for (int i =0 ; i < Constants.WORKERS_FOR_SEND_SMS && ! metLastRow;  i++)
						{
							 if (arSuccessNotificationCursor.next())
							 {
								 recordCounter++;
								 
								 arSuccessNotification = (ARNotificationSuccess) arSuccessNotificationCursor.get(0);				
								 recordNum		= arSuccessNotification.getRecordNum();
					             batchId 		= arSuccessNotification.getBatchId();
					             msisdn  		= arSuccessNotification.getMsisdn();
					             productId		= arSuccessNotification.getProductId();
					             createdTime	= arSuccessNotification.getCreatedTime();
					             startDate		= arSuccessNotification.getStartDate();
					             endDate		= arSuccessNotification.getEndDate();
					             status			= arSuccessNotification.getStatus();	            		 
					             tdfName		= arSuccessNotification.getTdfName();
					             tdfAmount	    = arSuccessNotification.getTdfAmount();
					             notification   = arSuccessNotification.getNotification();
					             productType	= arSuccessNotification.getProductType();
					             template	    = arSuccessNotification.getTemplate();
					             result			= null;
					             parts 			= 0;
								
								
					             
								// Long Message logic for throttling
					             msgInByte = encoding.encodeString(template);						             
					             parts 	   = (msgInByte.length < maxShortMessageLength ? 1 : (int)Math.ceil(((double)msgInByte.length) / maxSegmentLength));
					             
					             throttledCounter = throttledCounter +  parts;
					             
					             logger.debug("\n recordNum " + recordNum + ", batchId " + batchId + ", msisdn " + msisdn + ", template " + template);
					             
					             
					             try
				                 {
									 sessionUpdate = sessionFactory.openSession();
									 txUpdate      = sessionUpdate.beginTransaction();
					                 q = sessionUpdate.createQuery("Update ARNotificationSuccess set status=:pstatus  where recordNum=:precordNum");						                 
					                 q.setString("pstatus", Constants.STATUS_SENDING);
					                 q.setLong("precordNum", recordNum);
					                 q.executeUpdate();						                 
					                 txUpdate.commit();
					                 sessionUpdate.flush();
					                 sessionUpdate.clear();
					                 
				                 }
				                 catch(Exception ex)
				                 {
				                	   logger.error("Exception in update while sending to smsc ::: " + ex.getMessage());
				                	   throttledCounter = throttledCounter -  parts;
				                	   txUpdate.rollback();
				                	   continue;
				                 }
				        		 finally
				        		 {   
				        			  sessionUpdate.close();
				        		 }					             
														
								sendlongSMSobj = new SendLongSMSSuccess(recordNum, doneSignal, arSuccessNotification.getMsisdn(), arSuccessNotification, session, i);								
								boundedExecutor.submitTask(sendlongSMSobj);
								
								if(throttledCounter >= throttledControlValue)
								{																							
										Thread.sleep(Constants.THROTTLED_SLEEP_VALUE);
										throttledCounter    = 0;
								}
								
							 }
							 else
							 {
								 metLastRow = true;
							 } 
							 
							 metLastRow = metLastRow?metLastRow:arSuccessNotificationCursor.isLast();

						}
					}
					while(!metLastRow);	
					
				} 
				catch (Exception e) 
				{
					logger.info("Exception 1 in  processPendings4SendingSms method()  and exception is : " + e.getMessage());
					e.printStackTrace();
				}
				finally
     		   {
					boundedExecutor = null;
     		   }
			
				if (count++ % 1 == 0) 
				{
					session.flush();
					session.clear();
				}
				
				++page;	
				arSuccessNotificationCursor.close();
		    }
			logger.info("Total records for : workerNumber " + workerNumber +  " is " + recordCounter );
			executor.shutdown();
			
			while (!executor.isTerminated()) 
	 	    {	  
	 	    	   
	 	    }  
			
			// commits the transaction
			tx.commit();
		}  
		catch(Exception e)
		{		   
			logger.info("Exception 2 in  processPendings4SendingSms method()  and exception is : " + e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			arSuccessNotification 		= null;			
			arSuccessNotificationCursor = null;
			session.close();
		}
	 }
}

