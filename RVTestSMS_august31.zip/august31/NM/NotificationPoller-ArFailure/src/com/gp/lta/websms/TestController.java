package com.gp.lta.websms;

public class TestController {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		
		//:TODO

		SendLongSMS sendlongSMSobj = new SendLongSMS();
		sendlongSMSobj.sendSMS("123456789","This is Short MESSAGE");
		

	//	RecevieSMS sendlongSMSobj = new RecevieSMS();
	//	sendlongSMSobj.receiveSMS();

		
//		sendlongSMSobj.sendSMS("99","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhaaaaaaaaaaaaaaaaaaaaaaaaaa");

	}

}
