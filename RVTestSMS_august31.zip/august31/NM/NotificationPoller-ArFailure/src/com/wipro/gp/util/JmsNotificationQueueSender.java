package com.wipro.gp.util;


import java.util.Date;
import java.util.Hashtable;
import java.util.concurrent.CountDownLatch;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.wipro.gp.bean.NotificationFailure;
//import javax.naming.*;
//import javax.jms.*;

public class JmsNotificationQueueSender implements Runnable {
	
   private static final Logger logger = Logger.getLogger(com.wipro.gp.util.JmsNotificationQueueSender.class);
   private static InitialContext ctx = null;
   private static QueueConnectionFactory qcf = null;
   private static QueueConnection qc = null;
   private static QueueSession qsess = null;
   private static Queue q = null;
   private static QueueSender qsndr = null;
   private static TextMessage message = null;
   private String messageText;
   private int workerNumber;
   private CountDownLatch doneSignal;
   private Session session;
   private Transaction tx;
   private NotificationFailure notificationFailure;
   // NOTE: The next two lines set the name of the Queue Connection Factory
   //       and the Queue that we want to use.
//   private static final String QCF_NAME = "jms/MyanmarESBFactory";
//   private static final String QUEUE_NAME = "jms/SMSCGatewayQueue";
   
   private static final String QCF_NAME   = PropUtil.getInstance().getProperty("QCF_NAME");
   private static final String QUEUE_NAME = PropUtil.getInstance().getProperty("QUEUE_NAME");
   
   public JmsNotificationQueueSender() {
       super();
   }
   
   
   public JmsNotificationQueueSender(CountDownLatch doneSignal, String messageText, NotificationFailure notificationFailure, Session session)
   {
       ctx 	= null;
       qcf 	= null;
       qc 		= null;
       qsess 	= null;
       q 		= null;
       qsndr 	= null;
       message = null;
       this.doneSignal 		 	= doneSignal;
       this.messageText 		= messageText;
       this.workerNumber 		= notificationFailure.getGrpNo();
       this.notificationFailure = notificationFailure;
       this.session = session;
   }
   
   
   
   public void run()
   {
       try
       {
           System.out.println((new StringBuilder(String.valueOf(Thread.currentThread().getName()))).append(" (Start) groupNumber = ").append(workerNumber).toString());
           String result = sendMessage();
           if("Success".equals(result))
           {
        	   tx = session.beginTransaction();
               notificationFailure.setStatus(Constants.STATUS_SENT_TO_ESB);
               session.update(notificationFailure);
               tx.commit();
           }
       }
       catch(Exception ex)
       {
    	   tx.rollback();
           logger.error("Exception while doing db update " + ex.getMessage());
       }
       finally
       {
    	   session.close();
       }
       doneSignal.countDown();
   }
   
   public String  sendMessage() 
   {
	   
	   //int result = -1;
	   String result = null;
	   //t3://10.10.23.191:7001
	   String queueUrl  = "t3://" + PropUtil.getInstance().getProperty("IP") + ":" + PropUtil.getInstance().getProperty("PORT");
	   String usr  		= PropUtil.getInstance().getProperty("ESB_USR");
	   String passw     = PropUtil.getInstance().getProperty("ESB_PSW");
	   
       // create InitialContext
       Hashtable env = new Hashtable();
       env.put(Context.INITIAL_CONTEXT_FACTORY,
                      "weblogic.jndi.WLInitialContextFactory");
       // NOTE: The port number of the server is provided in the next line,
       //       followed by the userid and password on the next two lines.
       env.put(Context.PROVIDER_URL, queueUrl);
       env.put(Context.SECURITY_PRINCIPAL, usr);
       env.put(Context.SECURITY_CREDENTIALS, passw);
       try
       {
           ctx 		= new InitialContext(env);
           qcf 		= (QueueConnectionFactory)ctx.lookup(QCF_NAME);
           qc 		= qcf.createQueueConnection();
           qsess 	= qc.createQueueSession(false, 0);
           //qsess = qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
           q 		= (Queue) ctx.lookup(QUEUE_NAME);
           qsndr 	= qsess.createSender(q);
           message 	= qsess.createTextMessage();
           message.setText(messageText);
           qsndr.send(message);
           //result = 0;
           result = "Success";
       }
       catch (Exception ex) 
       {   
    	   logger.error(" error connecting to queue " + ex.getMessage());
    	   ex.printStackTrace();
       }
       
       // clean up
       try {
           message = null;
           qsndr.close();
           qsndr = null;
           q = null;
           qsess.close();
           qsess = null;
           qc.close();
           qc = null;
           qcf = null;
           ctx = null;
       }
       catch (JMSException jmse) {
    	   logger.error("JMSException Exception while sending sms to esb " + jmse.getMessage());
       }
       
       System.out.println("Cleaned up and done.");
       
       return result;
       
   }
   public static void main(String args[]) {
       
	   //JmsEsbQueueSender jmsEsbQueueSender = new JmsEsbQueueSender();
	   //jmsEsbQueueSender.sendMessage("test");
   }
}