package com.wipro.gp.bean;


public class NotificationFailure
{
	private int grpNo;
    private long recordNo;
    private String batchId;
    private String msisdn;
    private String productId;
    private String creationTime;
    private String startDate;
    private String endDate;
    private String status;
    private String tdfName;
    private String tdfAmount;
    private String productType;
    private String template;

    public NotificationFailure() 
    {
		super();
	}

	public NotificationFailure(long recordNo, String batchId, String msisdn,
			String productId, String creationTime, String startDate,
			String endDate, String status, String tdfName, String tdfAmount,
			String productType, String template) {
		super();
		this.recordNo = recordNo;
		this.batchId = batchId;
		this.msisdn = msisdn;
		this.productId = productId;
		this.creationTime = creationTime;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.tdfName = tdfName;
		this.tdfAmount = tdfAmount;
		this.productType = productType;
		this.template = template;
	}

	public NotificationFailure(int grpNo, long recordNo, String batchId,
			String msisdn, String productId, String creationTime,
			String startDate, String endDate, String status, String tdfName,
			String tdfAmount, String productType, String template) {
		super();
		this.grpNo = grpNo;
		this.recordNo = recordNo;
		this.batchId = batchId;
		this.msisdn = msisdn;
		this.productId = productId;
		this.creationTime = creationTime;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.tdfName = tdfName;
		this.tdfAmount = tdfAmount;
		this.productType = productType;
		this.template = template;
	}

	public int getGrpNo() {
		return grpNo;
	}

	public void setGrpNo(int grpNo) {
		this.grpNo = grpNo;
	}

	public long getRecordNo() {
		return recordNo;
	}

	public void setRecordNo(long recordNo) {
		this.recordNo = recordNo;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTdfName() {
		return tdfName;
	}

	public void setTdfName(String tdfName) {
		this.tdfName = tdfName;
	}

	public String getTdfAmount() {
		return tdfAmount;
	}

	public void setTdfAmount(String tdfAmount) {
		this.tdfAmount = tdfAmount;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}
    
    
	
    
    
    
}
