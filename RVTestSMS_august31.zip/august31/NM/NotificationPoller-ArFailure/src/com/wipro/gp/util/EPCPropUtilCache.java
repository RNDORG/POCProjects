package com.wipro.gp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Pattern;

import com.wipro.gp.bean.ProductInfo;
 
public class EPCPropUtilCache
{  
   
   private final Properties configProp = new Properties();   
   public static HashMap<String, ProductInfo> epcProductTemplateMap = new HashMap<String, ProductInfo>();
   
    
//   private EPCPropUtilCache()
//   {
//      //Private constructor to restrict new instances    
//	   
//      System.out.println("Read all properties from file");
//      try 
//      {
//    	  InputStream in = new FileInputStream(Constants.FILE_NAME_EPC_TEMPLATE);
//          configProp.load(in);
//      } 
//      catch (IOException e) 
//      {
//          e.printStackTrace();
//      }
//   }
   
   
   
   public static void loadEPCTemplate()
   {   
	   
	   //All property names
	   Set<String> allKeys = EPCPropUtilCache.getInstance().getAllPropertyNames();
	   String rowVal 	   = "";	   
	   
	   for(String key : allKeys) 
	   {   		     
		     rowVal   						= EPCPropUtilCache.getInstance().getProperty(key);		 
		     Pattern p 						= Pattern.compile(Constants.REGEX, -1);		      
		     String[] columns 				= p.split(rowVal);
		     int index 						= 0;
		     ProductInfo 	productInfo	    = null;
		     String tdfNameConfig			= null;
		     
		     for(String str : columns)
		     {
		    	 switch(index)
		    	 {    
			    	 case 0: 		//productInfo	    		 
			    		 productInfo =  new ProductInfo();
			    		 productInfo.setProductId(str);
			    		 break;    
			    	 case 1:
			    		productInfo.setEventId(str);
			    		break;    
			    	 case 2:
			    		 productInfo.setNotificationTemplate(str);			    		     
			    		break;
			    	 case 3:    
			    		 productInfo.setProductValidity(str);			    		     
			    		break;
			    	 case 4:
			    		 productInfo.setEventName(str);			    		     
			    		break;
			    	 case 5:
			    		 productInfo.setProductType(str);			    		     
			    		break;
			    	 case 6: 
			    		 productInfo.setTdfNameConfig(str);
			    		 tdfNameConfig = str;    
			    		break;			    	     
			    	 default:
		    	 }
		    	 index++;		    	 
		     }		     
		     epcProductTemplateMap.put(tdfNameConfig, productInfo);
		     
		}
   }
   
   public static HashMap<String, ProductInfo> getEPCMap()
   {
	   return epcProductTemplateMap;
   }
   
   private static class LazyHolder
   {
      private static final EPCPropUtilCache INSTANCE = new EPCPropUtilCache();
   }
 
   public static EPCPropUtilCache getInstance()
   {
      return LazyHolder.INSTANCE;
   }
    
   public String getProperty(String key){
      return configProp.getProperty(key);
   }
    
   public Set<String> getAllPropertyNames(){
      return configProp.stringPropertyNames();
   }
    
   public boolean containsKey(String key){
      return configProp.containsKey(key);
   }
   
   public static void main(String[] args)
   {
	   EPCPropUtilCache.loadEPCTemplate();
	   
	   ///################ Verification Test #####################
	   for(Entry<String, ProductInfo> entry : epcProductTemplateMap.entrySet())
	   {		   
	    	 System.out.print("\n\n  Map Key ::: " + entry.getKey());
	    	 ProductInfo productInfo = entry.getValue();
	    	 String notificationTemplate = productInfo.getNotificationTemplate();
	    	 System.out.print("EventId:" + productInfo.getEventId());
	    	 System.out.print("-> EventName:" + productInfo.getEventName());
	    	 System.out.print("-> NotificationTemplate:" + notificationTemplate);
	    	 String formatednotificationTemplate = String.format(notificationTemplate, productInfo.getEventId(), "7", new Date().toString(), "123.50","ddd","87787878","hghgs7777" );
	    	 System.out.println("\n ::::: formatednotificationTemplate :: " + formatednotificationTemplate);
	    	 System.out.print("-> ProductId:" + productInfo.getProductId());
	    	 System.out.print("-> ProductType:" + productInfo.getProductType());
	    	 System.out.print("-> ProductValidity:" + productInfo.getProductValidity());
	    	 // System.out.print("-> TdfNameConfig:" + productInfo.getTdfNameConfig());	    
	    	 
	    	 //#1:FACEBOOK_7_DAYS, Evt123,eventName+\"auto renew sofol hoyeche, meyad \"+productValidity+\" din 12.01am, \"+date+\". \"+tdfAmount+\" tk charge hoyeche. Internet balance jante, dial *121*1#, 7, Facebook 7 Days, SIMPLE, DATAFACEBOOK7DAYS_SUCCESS
	    }	   
	   
//	   String str = "\n Entered number = %d and string = %s";
//	   List<Object> params = new ArrayList<Object>();
//	   params.add(1);
//	   params.add("Asif");
//	   System.out.println(String.format(str, params.toArray()));
	   
//	   String s = String.format("Hello %2$s, welcome to %1$s", "GNDC", "Asif");	   
//	   System.out.println(s);
//	   
//	   String s1 = String.format("Hello welcome to", "GNDC", "Asif");	   
//	   System.out.println(s1);
//	   
//	   String s2 = String.format("Hello welcome to %2$s %2$s %1$s", "GNDC", "Asif");	   
//	   System.out.println(s2);
		
   }
}