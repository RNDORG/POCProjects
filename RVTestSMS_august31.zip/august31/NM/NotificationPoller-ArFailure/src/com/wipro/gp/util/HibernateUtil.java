package com.wipro.gp.util;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;


public class HibernateUtil 
{

	private static final Logger logger = Logger.getLogger(com.wipro.gp.util.HibernateUtil.class);
	
	private static ServiceRegistryBuilder serviceRegistryBuilder; 
	private static SessionFactory sessionFactory = null;
	
	
	public static SessionFactory getSessionFactory() 
	{
	     if(sessionFactory == null){
	          createSessionFactory();
	      }
	      return sessionFactory;
	}
	
	
//	private synchronized static void createSessionFactory()
//	{
//	    if(sessionFactory != null){return;}
//	    Configuration configuration = new Configuration();
//	    configuration.configure();    
//	    serviceRegistryBuilder = new ServiceRegistryBuilder();
//	    serviceRegistryBuilder.applySettings(configuration.getProperties());
//	    ServiceRegistry serviceRegistry = serviceRegistryBuilder.buildServiceRegistry();
//	    sessionFactory = configuration.buildSessionFactory(serviceRegistry);
//	    
//	 }  
	
	private synchronized static void createSessionFactory()
	{
		logger.info("In createSessionFactory() " );
		
	    if(sessionFactory != null){return;}
	    logger.info("createSessionFactory--- 1");
	    
	    try
	    {
		    Configuration configuration = new Configuration();
		    configuration.configure("hibernate.cfg.xml").addProperties(getConnectionProperties());    
		    serviceRegistryBuilder = new ServiceRegistryBuilder();
		    serviceRegistryBuilder.applySettings(configuration.getProperties());
		    ServiceRegistry serviceRegistry = serviceRegistryBuilder.buildServiceRegistry();
		    sessionFactory = configuration.buildSessionFactory(serviceRegistry);		    
		    logger.info("Database Connection created Successfully");
	    }
	    catch (Throwable ex)		
       {		
		  logger.error("Unable to create connection with Database, Initial SessionFactory creation failed." + ex);         		
          throw new ExceptionInInitializerError(ex);		
       } 
	    
	 }
	
	private static Properties getConnectionProperties() 
	{
		Properties connectionProps = new Properties();
		connectionProps.put("hibernate.connection.url", getConnectionUrl()); 
		connectionProps.put("hibernate.connection.username", getUserName());
		connectionProps.put("hibernate.connection.password", getPassword());
		
		return connectionProps;
	}


	private static String getPassword() 
	{
		String password   = PropUtil.getInstance().getProperty("DB_PASSWORD");
		
		return password;
	}


	private static String getUserName() 
	{
		String username   = PropUtil.getInstance().getProperty("DB_USERNAME");
		
		return username;
	}


	private static String getConnectionUrl() 
	{
		String url   = PropUtil.getInstance().getProperty("DB_CONNECTIONURL");
		
		return url;
	}

}

