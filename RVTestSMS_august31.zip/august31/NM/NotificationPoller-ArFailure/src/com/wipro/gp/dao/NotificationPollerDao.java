package com.wipro.gp.dao;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;

import com.wipro.gp.bean.NotificationFailure;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.HibernateUtil;
import com.wipro.gp.util.JmsNotificationQueueSender;
import com.wipro.gp.util.JmsNotificationQueueSender_old;
import com.wipro.gp.util.PropUtil;

public class NotificationPollerDao
{
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.dao.NotificationPollerDao.class);
    private static final int WORKERS_FOR_SEND_IN_Q = Integer.parseInt(PropUtil.getInstance().getProperty("workers.send.esb.queue"));

    public NotificationPollerDao()
    {
    }

    public void processPendings(int grpNumber, String batchName)
    {
        Session session;
        Session sessionUpdate;
        Transaction tx;
        int maxRows;
        int page;
        logger.info("Entering into getcurrentPendingList()");
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        logger.info("Connect to database successfully");
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
        List notificationList = null;
        maxRows = 500;
        page = 0;
        int count = 0;
        long recordNo = 0L;
        String batchId = null;
        String msisdn = null;
        String productId = null;
        String creationTime = null;
        String startDate = null;
        String endDate = null;
        String status = null;
        String tdfName = null;
        String tdfAmount = null;
        String productType = null;
        String template = null;
        String workorderXML = null;
        String formattedSMS = null;
        String esbFormatDate = null;
        String result = null;
        boolean metLastRow = false;
        NotificationFailure notificationSuccess = null;
        JmsNotificationQueueSender_old jmsEsbQueueSender = null;
        int pageSize  = 0;
        int remainder = 0;
        try
        {
           // int totalRecourdCount = ((Long)session.createQuery((new StringBuilder("select count(*) from NotificationSuccess NS where batchId = '")).append(batchName).append("' and status = 'PENDING' and NS.grpNo = ").append(grpNumber).toString()).uniqueResult()).intValue();
        	
        	int totalRecourdCount = ((Long)session.createQuery("select count(*) from NotificationFailure NF where batchId = '"+ batchName  + "'and NF.grpNo = " + grpNumber  +" and (productType = '"+ Constants.WO_COMPLEX + "' and  status = '" + Constants.STATUS_PENDING+ "')").uniqueResult()).intValue();
           
            if(totalRecourdCount < maxRows)
			{
				pageSize = 1;
			}
			else
			{
				pageSize		  = totalRecourdCount/maxRows;
				remainder		  = totalRecourdCount%maxRows;			
				pageSize		  = remainder > 0 ? pageSize + 1 : pageSize;				
			}
            
			System.out.println("Total Record count: " + totalRecourdCount + "and Page Size : " + pageSize);
			
            
            System.out.println((new StringBuilder("pageSize : ")).append(pageSize).toString());
            ExecutorService executor = Executors.newFixedThreadPool(WORKERS_FOR_SEND_IN_Q);
            CountDownLatch doneSignal = new CountDownLatch(WORKERS_FOR_SEND_IN_Q);
            
//            for(; page < pageSize; page++)
//            {
            
            while (page < pageSize)
		    {
			
				System.out.println("\n ................While loop and page iteration : " + page);
				Criteria criteria = session.createCriteria(com.wipro.gp.bean.NotificationFailure.class);
                Criterion productTypeCrt = Restrictions.eq("productType", "COMPLEX");
                Criterion statusPending = Restrictions.eq("status", "PENDING");
                Criterion batch = Restrictions.eq("batchId", batchName);
                Criterion grpCriterion = Restrictions.eq("grpNo", Integer.valueOf(grpNumber));
                LogicalExpression andExp = Restrictions.and(Restrictions.and(Restrictions.and(batch, productTypeCrt), grpCriterion), statusPending);
                criteria.add(andExp);
                ScrollableResults arSuccessNotificationCursor = criteria.setReadOnly(true).setFirstResult(page * maxRows).setMaxResults(maxRows).scroll(ScrollMode.FORWARD_ONLY);
                count 			= 0;
                recordNo 		= 0L;
                batchId 		= null;
                msisdn 			= null;
                productId 		= null;
                creationTime 	= null;
                startDate 		= null;
                endDate 		= null;
                status 			= null;
                tdfName 		= null;
                tdfAmount 		= null;
                workorderXML 	= null;
                formattedSMS 	= null;
                esbFormatDate 	= null;
                result 			= null;
                metLastRow 		= false;
                try
                {
                    do
                    {
                        for(int i = 0; i < maxRows && !metLastRow; i++)
                        {
                            if(arSuccessNotificationCursor.next())
                            {
                                notificationSuccess = (NotificationFailure)arSuccessNotificationCursor.get(0);
                                recordNo 			= notificationSuccess.getRecordNo();
                                batchId 			= notificationSuccess.getBatchId();
                                msisdn 				= notificationSuccess.getMsisdn();
                                productId 			= notificationSuccess.getProductId();
                                creationTime 		= notificationSuccess.getCreationTime();
                                startDate 			= notificationSuccess.getStartDate();
                                endDate 			= notificationSuccess.getEndDate();
                                status 				= notificationSuccess.getStatus();
                                tdfName 			= notificationSuccess.getTdfName();
                                tdfAmount 			= notificationSuccess.getTdfAmount();
                                productType 		= notificationSuccess.getProductType();
                                template 			= notificationSuccess.getTemplate();
                                result 				= null;
                                logger.info((new StringBuilder("\n\n\n #############------------ recordNo: ")).append(recordNo).append(", batchId  : ").append(batchId).append(",  productId : ").append(productId).append(", creationTime : ").append(creationTime).append(", startDate : ").append(startDate).append(", endDate : ").append(endDate).append(", status : ").append(status).append(", tdfName : ").append(tdfName).append(", tdfAmount : ").append(tdfAmount).toString());
                                if(tdfName != null && "COMPLEX".equalsIgnoreCase(productType))
                                {
                                	sessionUpdate = sessionFactory.openSession();
                                    workorderXML = String.format("<WorkOrderRequest><WO_ID>%s</WO_ID><Action>%s</Action><ProductId>%s</ProductId><MSISDN>%s</MSISDN><WorkOrderType>%s</WorkOrderType></WorkOrderRequest>", recordNo, Constants.ACTION_DEPROVIONING, productId, msisdn, Constants.WO_TYPE_FAILURE);
                                    System.out.println("workorderXML ::: " + workorderXML);
                                    logger.info((new StringBuilder("Routed to ESB system..... and workorderXML :: ")).append(workorderXML).toString());
                                    Runnable worker = new JmsNotificationQueueSender(doneSignal, workorderXML, notificationSuccess, sessionUpdate);
                                    System.out.println((new StringBuilder("worker: ")).append(worker).toString());
                                    executor.execute(worker);
                                }
                            } else
                            {
                                metLastRow = true;
                            }
                            metLastRow = metLastRow ? metLastRow : arSuccessNotificationCursor.isLast();
                        }

                        if(++count % WORKERS_FOR_SEND_IN_Q == 0)
                        {
                            session.flush();
                            session.clear();
                            Thread.sleep(10000);
                        }
                    } while(!metLastRow);
                    
                    
                	//ASF APR 4 executor.shutdown();
					//executor.awaitTermination(24 * 60, TimeUnit.MINUTES);
					
                  //ASF APR 4 while (!executor.isTerminated()) 
                  //ASF APR 4  {
			 	    	   /*try
			 	    	   { 	    	   
			 	    		   Thread.sleep(2000);
			 	    	   }
			 	    	   catch(Exception ex)
			 	    	   {
			 	    			   System.out.println("Exception in sleep");
			 	    	   }*/
			 	    	   
                  //ASF APR 4 }  
					
					
				} 
				catch (Exception e) 
				{
					logger.error("Exception while sending message to ESB Queue, under cursor loop area : " + e.getMessage());
					e.printStackTrace();
				}
				
//				if(metLastRow)
//				{
//					break;
//				}
			
				if ( count++ % 50 == 0 ) 
				{
					session.flush();
					session.clear();
				}
				
				++page;	
				arSuccessNotificationCursor.close();
		    }
			
			// commits the transaction and close the session
			tx.commit();
			session.close();
			
			
		}  
		catch(Exception e)
		{		   
			logger.error("Exception while sending message to ESB Queue, under page loop area : " + e.getMessage());
			e.printStackTrace();
		}
    }

//    public void updatePendingList(List notificationSuccessList)
//    {
//        Session session;
//        logger.info("Entering into updatePendingList() method");
//        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
//        logger.info("Connect to database successfully");
//        session = sessionFactory.openSession();
//        session.beginTransaction();
//        try
//        {
//            int count = 0;
//            for(Iterator iterator = notificationSuccessList.iterator(); iterator.hasNext();)
//            {
//                NotificationSuccess notificationSuccess = (NotificationSuccess)iterator.next();
//                session.update(notificationSuccess);
//                if(++count % 100 == 0)
//                {
//                    session.flush();
//                    session.clear();
//                }
//            }
//
//            break MISSING_BLOCK_LABEL_218;
//        }
//        catch(Exception e)
//        {
//            logger.error((new StringBuilder("Exception in NotificationPollerDao.class ")).append(e.getClass().getName()).append(": ").append(e.getMessage()).toString());
//            session.getTransaction().rollback();
//        }
//        session.getTransaction().commit();
//        session.flush();
//        session.close();
//        break MISSING_BLOCK_LABEL_242;
//        Exception exception;
//        exception;
//        session.getTransaction().commit();
//        session.flush();
//        session.close();
//        throw exception;
//        session.getTransaction().commit();
//        session.flush();
//        session.close();
//        logger.info("Exiting from updatePendingList() method");
//        return;
//    }
    

}
