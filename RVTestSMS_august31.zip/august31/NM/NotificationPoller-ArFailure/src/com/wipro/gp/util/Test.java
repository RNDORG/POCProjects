package com.wipro.gp.util;

import java.util.Random;

public class Test {

	
	
	 // Function for sending unique message id
    private static synchronized byte[] getNextRefNum () {
    	byte[] referenceNumber = new byte[1];
    	new Random().nextBytes(referenceNumber);
    	//byteBuffer.write((byte) referenceNumber[0]) ; 

        
        return referenceNumber;
    }
    
    
	  public static void main ( String[] args ) throws InterruptedException 
	  {
		  
//          long start, end, took;
//
//          start = System.currentTimeMillis();
//          for ( int i = 0; i < 200; i++) 
//          {
//                  try
//                  {
//                	  Thread.sleep (5);
//                  } 
//                  catch ( Exception ex ) 
//                  {
//                          ex.printStackTrace();
//                  }
//          }
//          end  = System.currentTimeMillis();
//          took = end -start;
//          System.out.println ("Took: " + took);

		  
		  
//		  List<Long> list = new ArrayList<Long>();
//
//		    int i= 0;
//		    int ctr = 0;
//		    while(i <=100)
//		    {
//		    	ctr++;
//
//		        long authStartTime = System.nanoTime();
//		        
//		        if(ctr ==10)
//		        {
//		        	Thread.sleep(10);
//		        	long elapsedTime = System.nanoTime() - authStartTime;
//		        	System.out.println("Record no." +i + " *****"+elapsedTime/1000+ " mics");
//		        	list.add(elapsedTime);
//		        	ctr = 0;
//		        }
//		        i++;
//		    }
//
//		    long sum=0;
//		    for(long l : list){
//		        sum = sum + l;
//		    }
//		    System.out.println("********* Average elapsed time = "+sum/list.size()/1000+" micro seconds");
//		    System.exit(0);
		  
		  System.out.println(getNextRefNum()[0]);
  }
}
