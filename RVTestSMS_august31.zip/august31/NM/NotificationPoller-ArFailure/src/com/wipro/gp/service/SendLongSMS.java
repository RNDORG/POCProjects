
package com.wipro.gp.service;

import ie.omk.smpp.Address;
import ie.omk.smpp.AlreadyBoundException;
import ie.omk.smpp.BadCommandIDException;
import ie.omk.smpp.Connection;
import ie.omk.smpp.UnsupportedOperationException;
import ie.omk.smpp.message.BindResp;
import ie.omk.smpp.message.InvalidParameterValueException;
import ie.omk.smpp.message.SMPPPacket;
import ie.omk.smpp.message.SMPPProtocolException;
import ie.omk.smpp.message.SMPPRequest;
import ie.omk.smpp.message.SubmitSM;
import ie.omk.smpp.message.SubmitSMResp;
import ie.omk.smpp.message.UnbindResp;
import ie.omk.smpp.message.tlv.TLVTable;
import ie.omk.smpp.message.tlv.Tag;
import ie.omk.smpp.net.TcpLink;
import ie.omk.smpp.util.ASCIIEncoding;
import ie.omk.smpp.util.AlphabetEncoding;
import ie.omk.smpp.util.DefaultAlphabetEncoding;
import ie.omk.smpp.util.EncodingFactory;
import ie.omk.smpp.util.GSMConstants;
import ie.omk.smpp.version.SMPPVersion;
import ie.omk.smpp.version.VersionException;
import java.io.ByteArrayOutputStream;
import weblogic.logging.NonCatalogLogger;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;

import org.apache.log4j.Logger; 
//import ie.omk.smpp.
/**
 *
 * @author Administrator
 */
public final class SendLongSMS {
    private static final String SMS_PROPERTY 			= "com/gp/lta/websms/WebSMSConfiguration.properties";    
    private static final Logger logger 		 			= Logger.getLogger(com.wipro.gp.service.SendLongSMS.class);    
    private static final int    maxShortMessageLength   = 160;
    private static final int    maxSegmentLength        = 153;
    final byte UDHIE_HEADER_LENGTH 						= 0x05;
    final byte UDHIE_IDENTIFIER_SAR 					= 0x00;
    final byte UDHIE_SAR_LENGTH 						= 0x03;

                        
    private static SendLongSMS    instance;
    
    private static int          portNo;
    private static String       systemId;
    private static String       systemPwd;
    private static String       systemType;
    private static int          sourceTON;
    private static int          sourceNPI;
    private static int          destinationTON;
    private static int          destinationNPI;
    private static String       shortCode;
    
    private static Properties   properties;
    ByteArrayOutputStream   byteBuffer  = new ByteArrayOutputStream();
    
    
     SendLongSMS()throws Exception{
        // Load the property file
        logger.debug(new Date()+ " : Start loading profile " + "\n");
        
//        try{
            InputStream     propsInputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(SMS_PROPERTY);
		    
            if (propsInputStream == null) 
            {
            	throw new FileNotFoundException("SMSC property file  not found in the classpath");
            }
            
            properties = new Properties();
            properties.load(propsInputStream);
//        }
//        catch(FileNotFoundException ex)
//        {
//           // ex.printStackTrace();
//            throw ex;
//        }
        
        /***************************************************************************
         * Step 1 : Load all configuration from the property file
         ***************************************************************************/
        try
        {
            portNo          =   Integer.parseInt(properties.getProperty("port"));
            systemId        =   properties.getProperty("systemID");
            systemPwd       =   properties.getProperty("password");
            systemType      =   properties.getProperty("systemType");
            sourceTON       =   Integer.parseInt(properties.getProperty("sourceTON"));
            sourceNPI       =   Integer.parseInt(properties.getProperty("sourceNPI"));

            destinationTON  =   Integer.parseInt(properties.getProperty("destinationTON"));
            destinationNPI  =   Integer.parseInt(properties.getProperty("destinationNPI"));
            shortCode		=	properties.getProperty("shortCode");
            
        }
        catch(NumberFormatException ex)
        {
            throw ex;
        }
        
        logger.debug(new Date()+ " : Completed loading profile " + "\n");
    }
    
     public synchronized static final SendLongSMS getInstance(String code)throws Exception
     {
        if(instance == null)
        {
            instance = new SendLongSMS();
        }
        
        shortCode = code;
        
      return instance;
        
    }
    
    public synchronized final String sendSMS(String destMSISDN, String msg)throws Exception
    {
        SMSSender       smsSender = new SMSSender();        
        return smsSender.sendMessage(destMSISDN, msg);
    }
    
    /***************************************************************************
     * Inner class for sending actual SMS
     ***************************************************************************/
    public final class SMSSender{
        
    	
        private int                         nextRefNum  = 0;
        private Connection                  connection  =   null;
        private DefaultAlphabetEncoding     encoding    = null;
        
        public SMSSender(){
            
        }
        
        public synchronized final String sendMessage(String destMSISDN, String msg) throws Exception{
            
            /***************************************************************
             * Step 1 : Parameter validation
             ***************************************************************/
            if(destMSISDN.isEmpty()){
                throw new Exception("Invalid MSISDN");
            }
            
            if(msg.isEmpty()){
                throw new Exception("Invalid message");
            }
            
            // Start processing for the valid message
            logger.debug(new Date()+ " : Start sending request : " + msg + " To : " + destMSISDN + "\n");
            
            int         parts       =   0;
            String      msgId       =   "";
            byte[]      msgInByte   =   null;
            SubmitSMResp response = null;
            
            try{
            	
                /***************************************************************
                 * Step 2 : Convert message into byte array
                 ***************************************************************/
                encoding = new DefaultAlphabetEncoding();
                msgInByte = encoding.encodeString(msg);
                logger.debug(new Date()+ " : Message converted into byte : " + msgInByte.toString() + "\n");
                
                if(msgInByte == null){
                    throw new Exception("Unable to convert message into byte");
                }
                
                /***************************************************************
                 * Step 3 : Calculate number of parts
                 ***************************************************************/
                logger.debug(new Date()+ " : length of byte message : " + msgInByte.length + "\n");
                
                parts = (msgInByte.length<maxShortMessageLength ? 1 : (int)Math.ceil(((double)msgInByte.length) / maxSegmentLength));
                
                logger.debug(new Date()+ " : Message parts : " + parts + "\n");
                
                /***************************************************************
                 * Step 4 : Connect with the SMSC server 
                 ***************************************************************/
                if(connectSMSC() < 0){
                    throw new Exception("Unable to connect with SMSC Server");
                }
                
                logger.debug(new Date()+ " : Successfully connected with SMSC server "  + "\n");
                
                /***************************************************************
                 * Step 5 : Send the SMS
                 ***************************************************************/
                msgId = this.sendSMS(destMSISDN, msgInByte, parts);
                
                logger.debug(new Date()+ " : Successfully sent message. : " + msgId + "\n");
            }catch(Exception ex){
                throw ex;
            }
            
            return msgId;
        }
        
         /***********************************************************************
         * List of private functions
         ***********************************************************************/
        
        // Function for connecting SMSC server
        private synchronized int connectSMSC() throws Exception{
            int             retVal      =   0;
            String          hostName    =   "";
            TcpLink         smscLink    =   null;
        
            /***************************************************************************
             * Step 1 : Establish connection with the SMSC Server
             ***************************************************************************/
            try {
                hostName = properties.getProperty("host1");

                if(hostName.isEmpty()){
                    throw new Exception("Host name not configured");
                }
                
                logger.debug(new Date()+ " : Trying to connect SMSC with host name : " + hostName + "\n");
                
                // First get the java.net.InetAddress for the SMSC:
                InetAddress     smscAddr = InetAddress.getByName(hostName);
                              
                if(smscAddr == null){
                    throw new Exception("Unable to get the address by the host name");
                }
                                
                smscLink = new TcpLink(smscAddr, portNo);

                smscLink.open();
                
                logger.debug(new Date()+ " : Connected with SMSC; host name : " + hostName + " Port No : " + portNo + "\n");
            } catch(UnknownHostException ux) {
                logger.debug(new Date()+ " : Unable to connected with SMSC Server. Error : " + ux.getMessage() + "\n");
                System.err.println("SMPPAPI: " + ux.getMessage());
                throw ux;
            }

            try{
                connection = new Connection(smscLink);

                connection.setVersion(SMPPVersion.V34);
                connection.autoAckLink(true);
                connection.autoAckMessages(true);

                // Validate whether binding successful with the host1
                BindResp    bindResp = connection.bind(Connection.TRANSMITTER, systemId, systemPwd, systemType, 
                                                        sourceTON, sourceNPI, shortCode);
                                
                if(bindResp.getCommandStatus() != 0){
                    // Take the second host and try to connect
                    hostName = properties.getProperty("host2");

                    bindResp = connection.bind(Connection.TRANSMITTER, systemId, systemPwd, systemType, 
                                                        sourceTON, sourceNPI, shortCode);

                    if(bindResp.getCommandStatus() != 0){
                        logger.debug("SMSC bind failed \n");
                        //Thread.sleep(2000L);
                        logger.debug("After Sleep \n");
                        throw new Exception("SMSC bind failed");
                    }
                }
            }
            catch(Exception ex){
                throw ex;
            }

            logger.debug(new Date()+ " : Successfully connected with SMSC; host name : " + hostName + " Port No : " + portNo + "\n");
            
            return retVal;
        }
        
        // Function for sending normal / long SMS
        private synchronized String sendSMS(String destMSISDN, byte[] msgInByte, int parts) throws Exception{
            String                  msgId       =   "";
            SMPPRequest             request     =   null;
            SubmitSMResp            response    =   null;
            byte[]                  packet      =   new byte[maxSegmentLength];
            byte[]                  msgrefnum   =   getNextRefNum();
            
            //30-Aug-16: This variable is used for long SMS
            
            
            try{
                for(int counter=0; counter<parts; counter++){
                    byteBuffer.reset();
                    
                    // Create the message
                    logger.debug(new Date()+ " : Creating request for part # : " + counter + "\n");
                    
                    request     =   (SubmitSM)connection.newInstance(SMPPPacket.SUBMIT_SM);
                                       
                    request.setDestination(new Address(destinationTON, destinationNPI, destMSISDN));
                                              
                    request.setSource(new Address(sourceTON, sourceNPI, shortCode));
                    
                    if(parts > 1){
                        // Below tags are required only for long message only
                    	request.setEsmClass(0x43);
                    	
                        request.setDataCoding(encoding.getDataCoding());
                        
                        // 30-Aug-16: Add UDH Header.
                        byteBuffer.write(UDHIE_HEADER_LENGTH); // UDH Length
                        logger.debug(new Date()+ " : Size after UDH Header : " + byteBuffer.size() + "\n");
                        
                        byteBuffer.write(UDHIE_IDENTIFIER_SAR); // IE Identifier
                        logger.debug(new Date()+ " : Size after IE Identifier : " + byteBuffer.size() + "\n");
                        
                        byteBuffer.write(UDHIE_SAR_LENGTH); // IE Data Length
                        logger.debug(new Date()+ " : Size after IE Data Length : " + byteBuffer.size() + "\n");
                        
                        
                        logger.debug(new Date()+ " : Value of msgrefnum : " + msgrefnum + "\n");
                        byteBuffer.write(msgrefnum) ; //Reference Number
                        logger.debug(new Date()+ " : Size after Reference Number : " + byteBuffer.size() + "\n");
                        
                        
                        
                        byteBuffer.write((byte) parts) ; //Number of pieces
                        logger.debug(new Date()+ " : Size after Number of pieces : " + byteBuffer.size() + "\n");
                        
                        byteBuffer.write((byte) (counter+1)) ; //Sequence number
                        logger.debug(new Date()+ " : Size after Sequence number : " + byteBuffer.size() + "\n");
                        

                    }

                    if (counter==parts-1) {
                        // Special attaintion for the last part
                        int     pos             =   counter*maxSegmentLength;
                        int     len             =   msgInByte.length - pos;
                        byte[]  finalPacket     =   new byte[len];

                        System.arraycopy(msgInByte, pos, finalPacket, 0, len);
                        logger.debug(new Date()+ " : Before setMessage (Last Part): " + finalPacket.toString() + "\n");
                        // 30-Aug-16: Start Modification
                        //request.setMessage(finalPacket, encoding);
                        byteBuffer.write(finalPacket);
                        // 30-Aug-16: End Modification
                    } else {
                        System.arraycopy(msgInByte, counter*maxSegmentLength, packet, 0, maxSegmentLength);
                        logger.debug(new Date()+ " : Before setMessage : " + packet.toString() + "\n");
                        // 30-Aug-16: Start Modification
                        byteBuffer.write(packet);
                        //request.setMessage(packet, encoding);
                        // 30-Aug-16: End Modification
                    }
                    
                    // 30-Aug-16: Start Modification
                    logger.debug(new Date()+ " : Before setMessage :: byteBuffer.size() : " + byteBuffer.size() + "\n");
                    request.setMessage(byteBuffer.toByteArray(), encoding);
                    // 30-Aug-16: end Modification
                    
                    logger.debug(new Date()+ " : Before setRequest : " + counter + "\n");
                    // Send the message
                    response = (SubmitSMResp)connection.sendRequest(request);
                    logger.debug(new Date()+ " : After setRequest : " + counter + "\n");
                      
                    
                }
            }catch(BadCommandIDException | VersionException | InvalidParameterValueException | IOException | AlreadyBoundException | SMPPProtocolException | UnsupportedOperationException ex){
                logger.debug(new Date()+ " : Unable to send request : " + ex.getMessage() + "\n");
                throw ex;
            }
            
            // Get the final response id
            if(response != null){
                msgId = response.getMessageId();
                this.unboundConnection();
            }
            
            return msgId;
        }
        
      
        // Function for sending unique message id
        private synchronized byte[] getNextRefNum () {
        	byte[] referenceNumber = new byte[1];
        	new Random().nextBytes(referenceNumber);
        	byteBuffer.write((byte) referenceNumber[0]) ; 

            
            return referenceNumber;
        }
        
        
        private synchronized void unboundConnection() throws Exception
        {
        	
        	try{
            UnbindResp ubr = this.connection.unbind();
			
			if (ubr.getCommandStatus() == 0) {
				//  System.out.println("Successfully unbound from the SMSC");
				logger.debug("Successfully unbound from the SMSC \n ");
			} else {
				// System.out.println("There was an error unbinding.");
	    	   logger.debug("There was an error unbinding. \n" );
			}
			// System.out.println("Unbinding to SMSC finished");
			logger.debug("Unbinding to SMSC finished \n" );
        	}
        	
        	catch(Exception e) {
        		e.printStackTrace();
        		
        	}
			
			
        }
    }
}