package com.wipro.gp.bean;

public class ProductInfo {
	
	String productId				= null;
    String eventId					= null;
    String notificationTemplate		= null;
    String productValidity			= null;
    String eventName				= null;
    String productType				= null;
    String tdfNameConfig 			= null;
    
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getNotificationTemplate() {
		return notificationTemplate;
	}
	public void setNotificationTemplate(String notificationTemplate) {
		this.notificationTemplate = notificationTemplate;
	}
	public String getProductValidity() {
		return productValidity;
	}
	public void setProductValidity(String productValidity) {
		this.productValidity = productValidity;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getTdfNameConfig() {
		return tdfNameConfig;
	}
	public void setTdfNameConfig(String tdfNameConfig) {
		this.tdfNameConfig = tdfNameConfig;
	}
    
    

}
