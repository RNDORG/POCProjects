package com.wipro.gp.util;


public class Constants
{
    

   // public static final String SMS_PROPERTY 			= "/PRODSMS/AR_POLLER/AR_FAILURE/ARPollerFailure/SenderSMSConfiguration.properties";    
    public static final String STATUS_PENDING 			= "PENDING";
    public static final String READY_FOR_NOTIFICATION 	= "READY_FOR_NOTIFICATION";
    public static final String STATUS_PUBLISED_SIMPLE 	= "PUBLISED_SIMPLE";
    public static final String STATUS_SENT_TO_ESB 		= "SENT_TO_ESB";
    public static final String STATUS_SUCCESS_ESB 		= "SUCCESS_ESB";
    public static final String STATUS_FAILURE_ESB 		= "FAILURE_ESB";
    public static final String STATUS_PUBLISED_COMPLEX 	= "PUBLISED_COMPLEX";
    public static final String CRM_ESB 					= "CRM-ESB";
    public static final String NOTIFICATION_APP 		= "NotificationAPP";
    public static final String NOT_FOUND 				= "NOT_FOUND";
    public static final String ACTION_PROVIONING 		= "Subscription";
    public static final String ACTION_DEPROVIONING 		= "Unsubscription";
    public static final String WO_TYPE_SUCCESS 			= "ARSUCCESS";
    public static final String WO_TYPE_FAILURE 			= "ARFAILURE";
    public static final String WO_SIMPLE 	   			= "SIMPLE";
    public static final String WO_COMPLEX 				= "COMPLEX";
    public static final String WO_TEMPLATE 				= "<WorkOrderRequest><WO_ID>%s</WO_ID><Action>%s</Action><ProductId>%s</ProductId><MSISDN>%s</MSISDN><WorkOrderType>%s</WorkOrderType></WorkOrderRequest>";
    public static final int POLLING_INTERVAL 			= 10;
    public static final String REGEX 					= "|";
    public static final String KEY_SEPARATOR 			= "\\|";
}
