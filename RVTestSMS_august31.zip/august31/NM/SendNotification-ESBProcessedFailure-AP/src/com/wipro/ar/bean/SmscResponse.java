package com.wipro.ar.bean;

public class SmscResponse {
	
	private long recordNum;
	private String status;
	private String smscMessageId;

	public SmscResponse() 
	{
		
	}

	public SmscResponse(long recordNum, String status, String smscMessageId) {
		super();
		this.recordNum = recordNum;
		this.status = status;
		this.smscMessageId = smscMessageId;
	}

	public long getRecordNum() {
		return recordNum;
	}

	public void setRecordNum(long recordNum) {
		this.recordNum = recordNum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSmscMessageId() {
		return smscMessageId;
	}

	public void setSmscMessageId(String smscMessageId) {
		this.smscMessageId = smscMessageId;
	}

}
