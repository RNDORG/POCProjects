package com.wipro.ar.util;

public class Constants {
	
	//Server
	//public static final String SMS_PROPERTY 				= "/home/AR_POLLER/AR_SUCCESS/ARSenderSuccess/SenderSMSConfiguration.properties";
	public static final String SMS_PROPERTY 				= "/PRODSMS/AR_POLLER/AR_SUCCESS_FAILURE_SMS/SenderSMSConfiguration.properties";
	

	
	//Local
	
	public static final String STATUS_PENDING				= "PENDING";
	public static final String PUBLISHED 					= "PUBLISHED";
	public static final String STATUS_FAILED				= "FAILED";	
	public static final String READY_FOR_NOTIFICATION 		= "READY_FOR_NOTIFICATION";
	public static final String STATUS_SUCCESS_ESB 			= "SUCCESS_ESB";
	public static final String STATUS_SENDING 				= "SENDING_TO_SMSC";
	
	public static final String WO_SIMPLE 					= "SIMPLE";
	
	public static final String COUNTRY_CODE					= "880";
	//public static final long POLLING_INTERVAL				= 24 * 60;
	public static final long POLLING_INTERVAL				= 10;
	public static final int WORKERS_FOR_SEND_SMS 			= Integer.parseInt(PropUtil.getInstance().getProperty("workers.for.send.sms"));		
	public static final int THROTTLED_MAX_VALUE 			= Integer.parseInt(PropUtil.getInstance().getProperty("throttled.max.value"));
	public static final int THROTTLED_SLEEP_VALUE 			= Integer.parseInt(PropUtil.getInstance().getProperty("throttled.sleep.value"));
	public static final int MAX_RECORDS			 			= Integer.parseInt(PropUtil.getInstance().getProperty("max.records"));
	public static final int NO_OF_GRP			 			= Integer.parseInt(PropUtil.getInstance().getProperty("workers.success"));
	
	public static final int RTHROTTLED 						= 88;
	 
	

}
