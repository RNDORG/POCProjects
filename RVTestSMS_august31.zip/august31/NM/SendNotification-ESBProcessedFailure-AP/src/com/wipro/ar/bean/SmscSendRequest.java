package com.wipro.ar.bean;


public class SmscSendRequest {

	private long recordNum;
	private String status;
	
	public SmscSendRequest()
	{
		
	}

	public SmscSendRequest(long recordNum, String status) {
		super();
		this.recordNum = recordNum;
		this.status = status;
	}

	public long getRecordNum() {
		return recordNum;
	}

	public void setRecordNum(long recordNum) {
		this.recordNum = recordNum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
