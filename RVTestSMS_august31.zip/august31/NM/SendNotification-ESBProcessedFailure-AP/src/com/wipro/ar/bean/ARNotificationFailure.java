package com.wipro.ar.bean;

import java.util.Date;

public class ARNotificationFailure 
{

	private int grp;
	private long recordNum;
	private String batchId;
	private String msisdn;
	private String productId;
	private Date createdTime;
	private Date startDate;
	private Date endDate;
	private String status;
	private String tdfName;
	private float tdfAmount;
	private String notification;	
	private String productType;
	private String template;	
	
	public ARNotificationFailure() {
		super();
	}

	public ARNotificationFailure(int grp, long recordNum, String batchId, String msisdn,
			String productId, Date createdTime, Date startDate, Date endDate,
			String status, String tdfName, float tdfAmount,
			String notification, String productType, String template) {
		super();
		this.grp = grp;
		this.recordNum = recordNum;
		this.batchId = batchId;
		this.msisdn = msisdn;
		this.productId = productId;
		this.createdTime = createdTime;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.tdfName = tdfName;
		this.tdfAmount = tdfAmount;
		this.notification = notification;
		this.productType = productType;
		this.template = template;
	}
	
	
	
	public ARNotificationFailure(int grp, String batchId, String msisdn, String productId,
			Date createdTime, Date startDate, Date endDate, String status,
			String tdfName, float tdfAmount, String notification,
			String productType, String template) {
		super();
		this.grp = grp;
		this.batchId = batchId;
		this.msisdn = msisdn;
		this.productId = productId;
		this.createdTime = createdTime;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.tdfName = tdfName;
		this.tdfAmount = tdfAmount;
		this.notification = notification;
		this.productType = productType;
		this.template = template;
	}

	public int getGrp() {
		return grp;
	}

	public void setGrp(int grp) {
		this.grp = grp;
	}

	public long getRecordNum() {
		return recordNum;
	}
	public void setRecordNum(long recordNum) {
		this.recordNum = recordNum;
	}
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTdfName() {
		return tdfName;
	}
	public void setTdfName(String tdfName) {
		this.tdfName = tdfName;
	}
	public float getTdfAmount() {
		return tdfAmount;
	}
	public void setTdfAmount(float tdfAmount) {
		this.tdfAmount = tdfAmount;
	}
	public String getNotification() {
		return notification;
	}
	public void setNotification(String notification) {
		this.notification = notification;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
	
	
}
