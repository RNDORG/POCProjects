package com.wipro.ar.util;

import java.math.BigInteger;
import java.nio.charset.Charset;

public class TestUtil {

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		//String udhMessage = "7D0";
		//String udhMessage = "0x1061867f";		
		String udhMessage = null;
		//long value = Long.parseLong(udhMessage, 16);

		//System.out.println("Message Id : " +value);
		
		System.out.println("Message id (hexToLong(udhMessage)): " + hexToLong(udhMessage));

	}

	
	
	public static long hexToLong(String bigHexNumber)
	{
		//String bigHexNumber = "0x6042607b1ba01d8d";
		
		if(bigHexNumber == null)
		{
			return  0;
		}
		
		if(bigHexNumber.substring(0, 2).equals("0x"))
		{
		     bigHexNumber = bigHexNumber.substring(2);
		     System.out.println("bigHexNumber : " + bigHexNumber);
		}
		
		long hexInLong = new BigInteger(bigHexNumber, 16).longValue();
		
		return hexInLong;
	}
	
	
	public static String toHex(String arg) 
    {
    	return String.format("%012x", new BigInteger(1, arg.getBytes(Charset.defaultCharset())));
    	
    }
}
