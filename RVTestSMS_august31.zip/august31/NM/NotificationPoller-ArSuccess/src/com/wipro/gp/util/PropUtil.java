// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PropUtil.java

package com.wipro.gp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;

public class PropUtil
{
    
    private PropUtil()
    {
        configProp = new Properties();
        System.out.println("Read all properties from file");
        try
        {
            InputStream in = new FileInputStream("/PRODSMS/AR_POLLER/AR_SUCCESS/ARPollerSuccess/Poller_Config.properties");
            configProp.load(in);
        }
        catch(IOException e)
        {
            System.out.println("Error while loading property file : /PRODSMS/AR_POLLER/AR_SUCCESS/ARPollerSuccess/Poller_Config.properties");
            e.printStackTrace();
        }
    }

    private static class LazyHolder
    {
       private static final PropUtil INSTANCE = new PropUtil();
    }
  
    public static PropUtil getInstance()
    {
       return LazyHolder.INSTANCE;
    }

    public String getProperty(String key)
    {
        return configProp.getProperty(key);
    }

    public Set getAllPropertyNames()
    {
        return configProp.stringPropertyNames();
    }

    public boolean containsKey(String key)
    {
        return configProp.containsKey(key);
    }

    public static void main(String args[])
    {
        String workers = getInstance().getProperty("workers.success");
        System.out.println((new StringBuilder("workers.success :: ")).append(workers).toString());
    }

    PropUtil(PropUtil proputil)
    {
        this();
    }

    private final Properties configProp;
}
