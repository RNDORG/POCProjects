package com.wipro.gp.util;

import com.wipro.gp.bean.NotificationSuccess;
import java.io.PrintStream;
import java.util.Hashtable;
import java.util.concurrent.CountDownLatch;
import javax.jms.*;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.hibernate.Session;

// Referenced classes of package com.wipro.gp.util:
//            JmsNotificationInterface

public class JmsNotificationQueueSender_Old
    implements JmsNotificationInterface, Runnable
{

    public JmsNotificationQueueSender_Old()
    {
        ctx = null;
        qcf = null;
        qc = null;
        qsess = null;
        q = null;
        qsndr = null;
        message = null;
    }

    public JmsNotificationQueueSender_Old(CountDownLatch doneSignal, String messageText, NotificationSuccess notificationSuccess, Session session)
    {
        ctx 	= null;
        qcf 	= null;
        qc 		= null;
        qsess 	= null;
        q 		= null;
        qsndr 	= null;
        message = null;
        this.doneSignal 		 = doneSignal;
        this.messageText 		 = messageText;
        workerNumber 			 = notificationSuccess.getGrpNo();
        this.notificationSuccess = notificationSuccess;
        this.session = session;
    }

    public void run()
    {
        try
        {
            System.out.println((new StringBuilder(String.valueOf(Thread.currentThread().getName()))).append(" (Start) groupNumber = ").append(workerNumber).toString());
            String result = sendMessage();
            if("Success".equals(result))
            {
                notificationSuccess.setStatus("SENT_TO_ESB");
                session.update(notificationSuccess);
            }
        }
        catch(Exception ex)
        {
            System.out.println((new StringBuilder("Exception in thread : ")).append(ex.getMessage()).toString());
        }
        doneSignal.countDown();
    }

    public String sendMessage()
        throws Exception
    {
        String result = null;
        Hashtable properties = new Hashtable();
        properties.put("java.naming.factory.initial", "weblogic.jndi.WLInitialContextFactory");
        // SIT
        //properties.put("java.naming.provider.url", "t3://10.10.23.191:7001");
        
        //Production
        properties.put("java.naming.provider.url", "t3://10.21.9.222:8001");
         
        properties.put("java.naming.security.principal", "sudipta");
        properties.put("java.naming.security.credentials", "sudipta123");
        try
        {
            ctx = new InitialContext(properties);
        }
        catch(NamingException ne)
        {
            System.out.println("Naming Exception.........");
            throw ne;
        }
        System.out.println((new StringBuilder("Got InitialContext ")).append(ctx.toString()).toString());
        try
        {
            qcf = (QueueConnectionFactory)ctx.lookup("MyanmarESBFactory");
        }
        catch(NamingException ne)
        {
            ne.printStackTrace(System.err);
            System.exit(0);
        }
        System.out.println((new StringBuilder("Got QueueConnectionFactory ")).append(qcf.toString()).toString());
        try
        {
            qc = qcf.createQueueConnection();
        }
        catch(JMSException jmse)
        {
            jmse.printStackTrace(System.err);
            System.exit(0);
        }
        System.out.println((new StringBuilder("Got QueueConnection ")).append(qc.toString()).toString());
        try
        {
            qsess = qc.createQueueSession(false, 0);
        }
        catch(JMSException jmse)
        {
            jmse.printStackTrace(System.err);
            System.exit(0);
        }
        System.out.println((new StringBuilder("Got QueueSession ")).append(qsess.toString()).toString());
        try
        {
            q = (Queue)ctx.lookup("WorkOrderRequest");
        }
        catch(NamingException ne)
        {
            ne.printStackTrace(System.err);
            System.exit(0);
        }
        System.out.println((new StringBuilder("Got Queue ")).append(q.toString()).toString());
        try
        {
            qsndr = qsess.createSender(q);
        }
        catch(JMSException jmse)
        {
            jmse.printStackTrace(System.err);
            System.exit(0);
        }
        System.out.println((new StringBuilder("Got QueueSender ")).append(qsndr.toString()).toString());
        try
        {
            message = qsess.createTextMessage();
        }
        catch(JMSException jmse)
        {
            jmse.printStackTrace();
        }
        System.out.println((new StringBuilder("Got TextMessage ")).append(message.toString()).toString());
        try
        {
            message.setText(messageText);
        }
        catch(JMSException jmse)
        {
            jmse.printStackTrace(System.err);
            System.exit(0);
        }
        System.out.println((new StringBuilder("Set text in TextMessage ")).append(message.toString()).toString());
        try
        {
            qsndr.send(message);
            result = "Success";
        }
        catch(JMSException jmse)
        {
            jmse.printStackTrace(System.err);
            System.exit(0);
        }
        System.out.println("Sent message ");
        try
        {
            message = null;
            qsndr.close();
            qsndr = null;
            q = null;
            qsess.close();
            qsess = null;
            qc.close();
            qc = null;
            qcf = null;
            ctx = null;
        }
        catch(JMSException jmse)
        {
            jmse.printStackTrace(System.err);
        }
        System.out.println("Cleaned up and done.");
        return result;
    }

    private InitialContext ctx;
    private QueueConnectionFactory qcf;
    private QueueConnection qc;
    private QueueSession qsess;
    private Queue q;
    private QueueSender qsndr;
    private TextMessage message;
    private String messageText;
    private int workerNumber;
    private CountDownLatch doneSignal;
    private Session session;
    private NotificationSuccess notificationSuccess;
    private static final String QCF_NAME = "MyanmarESBFactory";
    private static final String QUEUE_NAME = "WorkOrderRequest";
}
