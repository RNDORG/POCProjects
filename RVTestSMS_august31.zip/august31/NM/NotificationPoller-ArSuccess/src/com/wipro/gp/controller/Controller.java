
package com.wipro.gp.controller;

import java.sql.Timestamp;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.wipro.gp.service.NotificationPollerService;
import com.wipro.gp.util.PropUtil;

public class Controller
{

	 private static final Logger logger = Logger.getLogger(com.wipro.gp.controller.Controller.class);
	 private static final int WORKERS = Integer.parseInt(PropUtil.getInstance().getProperty("workers.success"));
	    
    public Controller()
    {
    }

    public void startGrpsProcessing(String batchName)
    {
        try
        {
            ExecutorService executor = Executors.newFixedThreadPool(WORKERS);
            CountDownLatch doneSignal = new CountDownLatch(WORKERS);
            for(int t = 1; t <= 4; t++)
            {
                Runnable worker = new NotificationPollerService(doneSignal, batchName, t);
                executor.execute(worker);
            }

            executor.shutdown();           
            while (!executor.isTerminated()) 
			{ 
		                  
			}
			//executor.awaitTermination(24 * 60, TimeUnit.MINUTES);
			
			logger.info(new Timestamp(System.currentTimeMillis())+" Finished all workers");
			Thread.sleep(5000);
			System.exit(0);
            
        }
        catch(Exception e)
        {
            System.out.println((new StringBuilder("Exception ")).append(e).toString());
            e.printStackTrace();
        }
    }

    public static void main(String args[])
    {
    	PropertyConfigurator.configure("/PRODSMS/AR_POLLER/AR_SUCCESS/ARPollerSuccess/log4j.properties");
    	
        if(args.length != 0)
        {
            System.out.println("........AR Notification (Success)  Poller started............");
            Controller controller = new Controller();
            controller.startGrpsProcessing(args[0]);
        } else
        {
            System.out.println("Missing argument, please provide batch No");
        }
    }   

}
