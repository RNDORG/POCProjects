
package com.wipro.gp.service;

import com.wipro.gp.dao.NotificationPollerDao;
import com.wipro.gp.util.JmsNotificationQueueSender_Old;
import java.io.PrintStream;
import java.util.concurrent.CountDownLatch;
import org.apache.log4j.Logger;

public class NotificationPollerService
    implements Runnable
{

    public NotificationPollerService()
    {
        notificationPollerDao = new NotificationPollerDao();
        jmsEsbQueueSender = null;
    }

    public NotificationPollerService(CountDownLatch doneSignal, String batchName, int worker)
    {
        notificationPollerDao = new NotificationPollerDao();
        jmsEsbQueueSender = null;
        this.doneSignal = doneSignal;
        this.worker = worker;
        this.batchName = batchName;
    }

    public void run()
    {
        System.out.println((new StringBuilder(String.valueOf(Thread.currentThread().getName()))).append(" (Start) groupNumber = ").append(worker).toString());
        processSuccessSmsList(worker);
        doneSignal.countDown();
    }

    public void processSuccessSmsList(int worker)
    {
        notificationPollerDao.processPendings(worker, batchName);
    }

    private static final Logger logger = Logger.getLogger(com.wipro.gp.service.NotificationPollerService.class);
    private NotificationPollerDao notificationPollerDao;
    private JmsNotificationQueueSender_Old jmsEsbQueueSender;
    private CountDownLatch doneSignal;
    private int worker;
    private String batchName;

}
