package com.wipro.ar.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateUtil 
{

	private static ServiceRegistryBuilder serviceRegistryBuilder; 
	private static SessionFactory sessionFactory 		= null;
	private static SessionFactory sessionFactoryWrite 	= null;
	
	
	public static SessionFactory getSessionFactory() 
	{
	     if(sessionFactory == null){
	          createSessionFactory();
	      }
	      return sessionFactory;
	}
	
	
	public static SessionFactory getSessionFactoryWrite() 
	{
	     if(sessionFactoryWrite == null){
	          createSessionFactoryWrite();
	      }
	      return sessionFactory;
	}
	
	
	private synchronized static void createSessionFactory()
	{
	    if(sessionFactory != null){return;}
	    Configuration configuration = new Configuration();
	    configuration.configure("hibernate.cfg.xml");    
	    serviceRegistryBuilder = new ServiceRegistryBuilder();
	    serviceRegistryBuilder.applySettings(configuration.getProperties());
	    ServiceRegistry serviceRegistry = serviceRegistryBuilder.buildServiceRegistry();
	    sessionFactory = configuration.buildSessionFactory(serviceRegistry);
	    
	 }
	
	
	private synchronized static void createSessionFactoryWrite()
	{
	    if(sessionFactoryWrite != null){return;}
	    Configuration configuration = new Configuration();
	    configuration.configure("hibernatewrite.cfg.xml");    
	    serviceRegistryBuilder = new ServiceRegistryBuilder();
	    serviceRegistryBuilder.applySettings(configuration.getProperties());
	    ServiceRegistry serviceRegistry = serviceRegistryBuilder.buildServiceRegistry();
	    sessionFactory = configuration.buildSessionFactory(serviceRegistry);
	    
	 }  

}

