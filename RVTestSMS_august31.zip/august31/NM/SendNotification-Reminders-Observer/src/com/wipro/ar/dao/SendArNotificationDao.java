package com.wipro.ar.dao;


import ie.omk.smpp.util.DefaultAlphabetEncoding;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.persistence.Transient;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;

import com.wipro.ar.bean.ARNotification;
import com.wipro.ar.controller.Controller;
import com.wipro.ar.util.BoundedExecutor;
import com.wipro.ar.util.Constants;
import com.wipro.ar.util.HibernateUtil;

public class SendArNotificationDao implements Runnable {
	
	private static final Logger logger = Logger.getLogger(com.wipro.ar.dao.SendArNotificationDao.class);
	
	private CountDownLatch doneSignal;
	private String batchName;
	private int workerNumber;
	private Runnable sendlongSMSobj;
	private static final int maxShortMessageLength = 160;
    private static final int maxSegmentLength      = 153;
    private DefaultAlphabetEncoding  encoding;
    byte[] msgInByte;
	private int parts;
	
	
	public SendArNotificationDao(CountDownLatch doneSignal, String batchName, int workerNumber) {
		super();
		this.doneSignal = doneSignal;
		this.batchName  = batchName;
		this.workerNumber = workerNumber;
	}


	public void run() {
		
		logger.info(Thread.currentThread().getName()+" (Start) groupNumber = " + workerNumber);  
		processPendings4SendingSms();		
		doneSignal.countDown(); 

	}
	 	
	
	 public void processPendings4SendingSms()
	 {
		 
		logger.debug(Thread.currentThread().getName()+" (processPendings4SendingSms()) groupNumber = " + workerNumber);		 
		SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();
		logger.debug("Connect to database successfully");
					
		 // opens a new session from the session factory
		Session session 			= sessionFactory.openSession();
		Transaction tx  			= session.beginTransaction();
		Session sessionUpdate		= null;
		Transaction txUpdate		= null;
		Query q						= null;
		
		final int maxRows 			= Constants.MAX_RECORDS;
		final int prethrottledControlValue	= Constants.THROTTLED_MAX_VALUE/(Controller.WORKERS*20); //1000/20 = 50 ms division		
		final int throttledControlValue	    = prethrottledControlValue;
		final int throttledControlValueHalf	= throttledControlValue/2;
		final int throttledRecordsValueHalf	= ((Constants.THROTTLED_MAX_VALUE*60*2)/Controller.WORKERS)/2;
		BoundedExecutor boundedExecutor 			  = null;
		ScrollableResults arSuccessNotificationCursor = null;
		int throttledCounter		= 0;
		int page 					= 0;
		int grp						= 0;
		long recordNum 				= 0L;
		String batchId 				= null;
		String msisdn  				= null;		
		String status				= null;
		String tdfName				= null;
		float tdfAmount				= 0.0f;
		String notification			= null;	
		String productType			= null;
		String template				= null;
		String result				= null;
		int count 					= 0;
		boolean metLastRow			= false;
		int recordCounter			= 0;
		encoding  = new DefaultAlphabetEncoding();
		
		try
		{
			
			int totalRecourdCount = ((Long)session.createQuery("select count(*) from ARNotification NS where batchId = '"+ batchName +"' and status = 'PENDING' and NS.grp = " + workerNumber  ).uniqueResult()).intValue();
			
			int pageSize   = 0;
			int remainder  = 0;
			int quotient   = 0;			
			quotient	   = totalRecourdCount/maxRows;
			remainder	   = totalRecourdCount%maxRows;
			
			if(remainder > 0)
			{
				pageSize		  = quotient+ 1;
			}
			else
			{
				pageSize = quotient;
			}
			
			
			logger.info("Total Record count: " + totalRecourdCount + " for group no " + workerNumber +" and Page Size : " + pageSize);
			ExecutorService executor  = Executors.newFixedThreadPool(Constants.WORKERS_FOR_SEND_SMS);
			CountDownLatch doneSignal = new CountDownLatch(Constants.WORKERS_FOR_SEND_SMS);
					
			while (page < pageSize)
		    {	
				
				logger.info("\n .....Statring of  Page : " + page + " for group number: " + workerNumber + " and one page conatins maximum :  " + maxRows + " reccords" );
				
				Criteria criteria 		= session.createCriteria(ARNotification.class);
				Criterion batch   		= Restrictions.eq("batchId", batchName);
				Criterion statusPending = Restrictions.eq("status", Constants.STATUS_PENDING );			
				Criterion grpNumber 	= Restrictions.eq("grp", workerNumber );
				
		        LogicalExpression andExp = Restrictions.and(Restrictions.and(batch, grpNumber), statusPending);	        
		        criteria.add(andExp);								
				
		        arSuccessNotificationCursor = criteria.setReadOnly(true).setFirstResult(page*maxRows).setMaxResults(maxRows).scroll(ScrollMode.FORWARD_ONLY);
		        
				recordNum 			= 0L;
				grp				    = 0;
				batchId 			= null;
				msisdn  			= null;
				status				= null;
				tdfName			    = null;
				tdfAmount			= 0.0f;
				notification		= null;	
				productType		    = null;
				template			= null;
				count 				= 0;				
				metLastRow			= false;
				
				try 
				{	
					
					boundedExecutor = new BoundedExecutor(executor, throttledControlValue);
					
					do
					{	
						 
						for (int i = 0; i < Constants.WORKERS_FOR_SEND_SMS && ! metLastRow;  i++)
						{
							 if (arSuccessNotificationCursor.next())
							 {
								 recordCounter++;
								 
								 ARNotification arSuccessNotification = (ARNotification) arSuccessNotificationCursor.get(0);				
								 recordNum		= arSuccessNotification.getRecordNum();
					             msisdn  		= arSuccessNotification.getMsisdn();
					             batchId		= arSuccessNotification.getBatchId();
					             template		= arSuccessNotification.getTemplate();					             
					             
					             // Long Message logic for throttling
					             parts 				= 0;
					             msgInByte 			= encoding.encodeString(template);						             
					             parts 	   			= (msgInByte.length < maxShortMessageLength ? 1 : (int)Math.ceil(((double)msgInByte.length) / maxSegmentLength));
					             throttledCounter 	= throttledCounter +  parts;
					             
	 							 logger.debug("\n recordNum " + recordNum + ", batchId " + batchId + ", msisdn " + msisdn + ", template " + template);
								
//									try
//					                  {
////		//								 sessionUpdate = sessionFactory.openSession();
////		//								 txUpdate      = sessionUpdate.beginTransaction();
//						                 q = sessionUpdate.createQuery("Update ARNotification set status=:pstatus  where recordNum=:precordNum");						                 
//						                 q.setString("pstatus", Constants.STATUS_SENDING);
//						                 q.setLong("precordNum", recordNum);
//						                 q.executeUpdate();						                 
//						                 //txUpdate.commit();
//						                 //sessionUpdate.flush();
//						                 //sessionUpdate.clear();
//						                 
//					                  }
//					                   catch(Exception ex)
//					                   {
//					                	   logger.error("Exception in update while sending to smsc ::: " + ex.getMessage());
//					                	   txUpdate.rollback();
//					                	   throttledCounter = throttledCounter -  parts;
//					                	   continue;
//					                   }
//					        		   finally
//					        		   {   
//					        			   sessionUpdate.close();
//					        		   }
								
								
	 							sendlongSMSobj = new SendLongSMS(recordNum, doneSignal, msisdn, arSuccessNotification, session, i);
								boundedExecutor.submitTask(sendlongSMSobj);
								
								if(throttledCounter >= throttledControlValue)
								{													
									Thread.sleep(Constants.THROTTLED_SLEEP_VALUE);
									throttledCounter    = 0;
								}							
							 }
							 else
							 {
								 metLastRow = true;
							 } 
								 metLastRow = metLastRow?metLastRow:arSuccessNotificationCursor.isLast();
							}
					}
					while(!metLastRow);
				} 
				catch (Exception e) 
				{
					logger.info("Exception 1 in  processPendings4SendingSms method()  and exception is : " + e.getMessage());
					e.printStackTrace();
				}
				finally
     		   {
					boundedExecutor = null;
     		   }
			
				if (count++ % 1 == 0) 
				{
					session.flush();
					session.clear();
				}
				
				++page;	
				arSuccessNotificationCursor.close();
				
		    }
			logger.info("Total records for : workerNumber " + workerNumber +  " is " + recordCounter );
			executor.shutdown();
			
			while (!executor.isTerminated()) 
	 	    {	   
	 	    	   
	 	    }
			
			// commits the transaction
			tx.commit();
			
		}  
		catch(Exception e)
		{
			logger.info("Exception 2 in  processPendings4SendingSms method()  and exception is : " + e.getMessage());
		}
		finally
		{
			arSuccessNotificationCursor = null;
			session.close();
		}
	 }
}

