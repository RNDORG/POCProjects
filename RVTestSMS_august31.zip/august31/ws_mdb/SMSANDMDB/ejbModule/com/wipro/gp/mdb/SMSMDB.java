package com.wipro.gp.mdb;

import java.util.Date;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.wipro.gp.bean.ESBValidSms;
import com.wipro.gp.db.ReceiveMessageDao;
import com.wipro.gp.util.BoundedExecutor;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.DateUtil;
import com.wipro.gp.util.SendLongSMS;




/**
 * Message-Driven Bean implementation class for: SMSMDB
 */

@MessageDriven(activationConfig = { @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
        @ActivationConfigProperty(propertyName = "maxSession", propertyValue = "200"), @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
        @ActivationConfigProperty(propertyName = "destination", propertyValue = "java:jboss/queue/SMS.SENDING.SUBMIT.QUEUE") })
@TransactionManagement(value = TransactionManagementType.BEAN)
public class SMSMDB implements MessageListener 
{
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.mdb.SMSMDB.class);
	
	String msisdn;
	String msg;
	String prodId;
	String shortCode;
	String[] parts;
	static int i = 1;
	static ExecutorService executor;
	static CountDownLatch doneSignal;
	static BoundedExecutor boundedExecutor;
	
	static
	{
		 
		executor  = Executors.newFixedThreadPool(Constants.WORKERS_FOR_SEND_SMS);
		doneSignal = new CountDownLatch(Constants.WORKERS_FOR_SEND_SMS);
		boundedExecutor = new BoundedExecutor(executor, Constants.REQ_TPS);
	}
	

    /**
     * Default constructor. 
     */
    public SMSMDB() {
        
    }
	
	/**
     * @see MessageListener#onMessage(Message)
     */
    public void onMessage(Message message) 
    {       
    	
    	System.out.println("***********Entering onMessage**************");
    	
    	String mess = null;    	
		
			try 
			{
				mess 				= ((TextMessage)message).getText();
				parts 				= mess.split("`:`");
		        msisdn		= parts[0];
		        msg			= parts[1];
		        prodId		= parts[2];
		        shortCode	= parts[3];
		        ReceiveMessageDao rmd = new ReceiveMessageDao();		        

				Date currDate 		 		= new Date();
				String creationDate 		= DateUtil.parseDate(currDate, "yyyy-MM-dd HH:mm:ss");
				
		        long uniqueId = rmd.saveMessage(msg, msisdn, shortCode, prodId, creationDate, false);
		        
		        ESBValidSms esbValidSms = new ESBValidSms();
		        esbValidSms.setSmsId(uniqueId);
		        esbValidSms.setGrpNum(1);
		        esbValidSms.setSource_msisdn(msisdn);
		        esbValidSms.setSmsText(msg);
		        esbValidSms.setProductId(prodId);
		        esbValidSms.setDest_shortCode(shortCode);
		        i ^= 1;
		        
		        
		        try
	        	{
		        	
//			        for (int i = 0; i < Constants.SMSC_THREADS; i++)
//					{
			        	SendLongSMS  sendlongSMSobj = new SendLongSMS(doneSignal, uniqueId, msisdn, esbValidSms, i);
						boundedExecutor.submitTask(sendlongSMSobj);
//					}
	        	}
		        catch (InterruptedException e) 
				{
					
					e.printStackTrace();
				}
		        
				logger.info("Message: " + mess);
			}
			catch (JMSException e) 
			{	
				logger.error("Error while Saving " + e.getMessage());
				
			}
			finally
			{
				
			}
    	    //System.out.print(mess);    
    }
    
//    public static void main(String args[])
//    {
//    	for (int j = 0; j<100; j++)
//    	{
//    		System.out.println(i ^= 1);
//    	}
//    }

}
