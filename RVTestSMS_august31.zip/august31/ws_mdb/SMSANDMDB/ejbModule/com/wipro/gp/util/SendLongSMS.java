
package com.wipro.gp.util;

import ie.omk.smpp.Address;
import ie.omk.smpp.AlreadyBoundException;
import ie.omk.smpp.BadCommandIDException;
import ie.omk.smpp.Connection;
import ie.omk.smpp.UnsupportedOperationException;
import ie.omk.smpp.message.InvalidParameterValueException;
import ie.omk.smpp.message.SMPPPacket;
import ie.omk.smpp.message.SMPPProtocolException;
import ie.omk.smpp.message.SMPPRequest;
import ie.omk.smpp.message.SubmitSM;
import ie.omk.smpp.message.SubmitSMResp;
import ie.omk.smpp.message.UnbindResp;
import ie.omk.smpp.util.DefaultAlphabetEncoding;
import ie.omk.smpp.version.VersionException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

import org.apache.log4j.Logger;

import com.wipro.gp.bean.ESBValidSms;
/**
 *
 * @author Administrator
 */
public final class SendLongSMS implements Runnable
{
	private static final Logger logger = Logger.getLogger(com.wipro.gp.util.SendLongSMS.class);
    
    private static final int maxShortMessageLength   	= 160;
    private static final int maxSegmentLength        	= 153;
    final byte UDHIE_HEADER_LENGTH 						= 0x05;
    final byte UDHIE_IDENTIFIER_SAR 					= 0x00;
    final byte UDHIE_SAR_LENGTH 						= 0x03;
    
    private Connection connection;    
    private DefaultAlphabetEncoding  encoding;
    private int worker;    
    ByteArrayOutputStream  byteBuffer = new ByteArrayOutputStream();
	private String  workDone;
	private CountDownLatch doneSignal;
	private String destMSISDN;
	private String msg;
	private ESBValidSms esbValidSms;	
	private int count;
	private int threadNo;
	private long recordNum;
	
	  
    
    /***************************************************************************
     * Step 1 : Load all configuration from the property file
     ***************************************************************************/
  
    public SendLongSMS() 
    {
    	
	}
    
    
    public SendLongSMS(CountDownLatch doneSignal, long recordNum,  String destMSISDN, ESBValidSms esbValidSms, int threadNo) 
    {
    	this.recordNum  = recordNum;
		this.doneSignal = doneSignal;	
		this.destMSISDN = destMSISDN;
		this.msg		= esbValidSms.getSmsText();
		this.worker 	= esbValidSms.getGrpNum();
		this.esbValidSms = esbValidSms;
		this.threadNo	= threadNo; 
		
		workDone = null;
		
	}
	 
    
    public String getWorkDone()
    {
    	return workDone;
    	
    }
    
    
    public void run() 
    {
    	
	    try
	    {
	    	logger.info(" Start Sending SMS for,  MSISDN = " + destMSISDN + ", Message = " +msg + " and  group Number = " + worker);	    	
	    	
	    	sendSMS();	    	
	    		
	    }
	    catch (Exception e) 
	    {
	      logger.info("Exception while sending SMS for,  MSISDN = " + destMSISDN + ", Message = " +msg + " and  group Number = " + worker);	
	      logger.error("exception in thread, while sending  sms,  sendSMS() " + e.getMessage());
		}
	    finally
	    {
	    	esbValidSms = null;
	    }
	    
	    doneSignal.countDown();
    }
    
    
    
    
    public void sendSMS() throws Exception
    {
        
    	
    	logger.debug("In  sendSMS() method and   MSISDN = " + destMSISDN + ", Message = " +msg + " and  group Number = " + worker);
    	
    	
        /***************************************************************
         * Step 1 : Parameter validation
         ***************************************************************/
        if(destMSISDN.isEmpty())
        {
        	logger.info("Exception MSISDN is Empty ......");
        	throw new Exception("Invalid MSISDN" + destMSISDN);
        }
        
        if(msg.isEmpty())
        {
        	logger.info("Exception Message is Empty ......");
        	throw new Exception("Invalid message" + msg);
        }
        
        // Start processing for the valid message
       logger.debug( "Start sending request : " + msg + " To : " + destMSISDN);
        
        int         parts       =   0;
        String      msgId       =   null;
        byte[]      msgInByte   =   null;
        SubmitSMResp response = null;
        
        try
        {
        	
            /***************************************************************
             * Step 2 : Convert message into byte array
             ***************************************************************/
            encoding  = new DefaultAlphabetEncoding();
            msgInByte = encoding.encodeString(msg);
           logger.debug("Message converted into byte : " + msgInByte.toString());
            
            if(msgInByte == null)
            {
                // throw new Exception("Unable to convert message into byte");
            	//logger.info("Unable to convert message into byte");
            	logger.info("Null, Unable to convert message into byte and msg : " + msg);
            }
            
            /***************************************************************
             * Step 3 : Calculate number of parts
             ***************************************************************/
           logger.debug( "length of byte message : " + msgInByte.length);
            
            parts = (msgInByte.length < maxShortMessageLength ? 1 : (int)Math.ceil(((double)msgInByte.length) / maxSegmentLength));
            
           logger.debug( "Message parts : " + parts);
            
            /***************************************************************
             * Step 4 : Connect with the SMSC server 
             ***************************************************************/
//            if(connectSMSC() < 0)
//            {
//               throw new Exception("Unable to connect with SMSC Server");
//            }                
            connection = Controller.getConnection(worker, threadNo);
            
            if(connection == null)
            {   
            	Thread.sleep(1000);
            	logger.info("Additional wait for connection......");
            	connection = Controller.getConnection(worker, threadNo);
            	
            	logger.info("Additional wait for connection......");
            	
            	if(connection == null)
                {   
            		logger.info("Error, Unable to get connection for  worker " +  worker);            		
            		return;            		
            		//throw new Exception("Unable to get connection for  worker " +  worker);
                }
            	
            }
            
           //logger.info(new Date()+ " : Successfully connected with SMSC server " );
            
            
            /***************************************************************
             * Step 5 : Send the SMS
             ***************************************************************/
            
            if(!destMSISDN.startsWith((Constants.COUNTRY_CODE )))
			{
            	destMSISDN = Constants.COUNTRY_CODE + destMSISDN;
			}
            
            this.sendSMS(destMSISDN, msgInByte, parts);
        	
            
        }
        catch(Exception ex)
        {
        	logger.error("Error while sending sms  sendSMS() " + ex.getMessage());
            throw ex;
        }
        finally
        {
        	
        }
        
        
    }
    
     /***********************************************************************
     * List of private functions
     ***********************************************************************/
    
    // Function for sending normal / long SMS
    private  void sendSMS(String destMSISDN, byte[] msgInByte, int parts) throws Exception
    {
        String			msgId       	= "";
        SMPPRequest     request     	= null;
        SubmitSMResp    response    	= null;
        byte[]          packet      	= new byte[maxSegmentLength];
        byte[]          msgrefnum   	= getNextRefNum();
        Address 		destAddress 	= new Address(Controller.destinationTON, Controller.destinationNPI, destMSISDN);
        //Address 		sourceAddress 	= new Address(Controller.sourceTON, Controller.sourceNPI, Controller.shortCode);
        Address 		sourceAddress 	= new Address(Controller.sourceTON, Controller.sourceNPI, esbValidSms.getDest_shortCode() );
        
        //30-Aug-16: This variable is used for long SMS
        
        try
        {
            for(int counter = 0; counter < parts; counter++)
            {
                byteBuffer.reset();
                
                // Create the message
               logger.debug( "Creating request for part # : " + counter);
                
                request = (SubmitSM)connection.newInstance(SMPPPacket.SUBMIT_SM);
                request.setDestination(destAddress);
                request.setSource(sourceAddress);
                
                if(parts > 1)
                {
                    // Below tags are required only for long message only
                	request.setEsmClass(0x43);                    	
                    request.setDataCoding(encoding.getDataCoding());
                    
                    // 30-Aug-16: Add UDH Header.
                    byteBuffer.write(UDHIE_HEADER_LENGTH); // UDH Length
                   logger.debug( "Size after UDH Header : " + byteBuffer.size());
                    
                    byteBuffer.write(UDHIE_IDENTIFIER_SAR); // IE Identifier
                   logger.debug( "Size after IE Identifier : " + byteBuffer.size());
                    
                    byteBuffer.write(UDHIE_SAR_LENGTH); // IE Data Length
                   logger.debug( "Size after IE Data Length : " + byteBuffer.size());
                    
                    
                   logger.debug("Value of msgrefnum : " + msgrefnum);
                    byteBuffer.write(msgrefnum) ; //Reference Number
                    
                   logger.debug( "Size after Reference Number : " + byteBuffer.size());
                    
                    
                    
                    byteBuffer.write((byte) parts) ; //Number of pieces
                   logger.debug("Size after Number of pieces : " + byteBuffer.size());
                    
                    byteBuffer.write((byte) (counter+1)) ; //Sequence number
                   logger.debug( "Size after Sequence number : " + byteBuffer.size());                        

                }
                

                if (counter == parts-1) 
                {
                    // Special attaintion for the last part
                    int     pos             =   counter*maxSegmentLength;
                    int     len             =   msgInByte.length - pos;
                    byte[]  finalPacket     =   new byte[len];

                    System.arraycopy(msgInByte, pos, finalPacket, 0, len);
                   logger.debug( "Before setMessage (Last Part): " + finalPacket.toString());
                    // 30-Aug-16: Start Modification
                    //request.setMessage(finalPacket, encoding);
                    byteBuffer.write(finalPacket);
                    // 30-Aug-16: End Modification
                    request.setSequenceNum((int)recordNum);
                }
                else 
                {
                    System.arraycopy(msgInByte, counter*maxSegmentLength, packet, 0, maxSegmentLength);
                   logger.debug("Before setMessage : " + packet.toString());
                    // 30-Aug-16: Start Modification
                    byteBuffer.write(packet);
                    //request.setMessage(packet, encoding);
                    // 30-Aug-16: End Modification
                    request.setSequenceNum(0);
                }
                
                // 30-Aug-16: Start Modification
               logger.debug( "Before setMessage :: byteBuffer.size() : " + byteBuffer.size());
                request.setMessage(byteBuffer.toByteArray(), encoding);
                // 30-Aug-16: end Modification
                
               logger.debug(recordNum + ": Before send request : ");
                // Send the message
                //response = (SubmitSMResp)connection.sendRequest(request);   
               //request.setSequenceNum((int)recordNum);
                //request.setMessageId("" + worker );                
                connection.sendRequest(request);                
                Controller.removeConnection(worker);
               logger.debug(recordNum + ": After send request : ");
                  
                
            }
        }
        catch(BadCommandIDException | VersionException | InvalidParameterValueException | IOException | AlreadyBoundException 
        		| SMPPProtocolException | UnsupportedOperationException ex)
        {
           logger.info( "Unable to send message to SMSC, for record number : " + recordNum + ex.getMessage());
           Controller.removeConnection(worker);
            throw ex;
        } 
       
    }  
    
    
 // Function for sending unique message id
    private  byte[] getNextRefNum ()
    {
    	byte[] referenceNumber = new byte[1];
    	new Random().nextBytes(referenceNumber);
    	byteBuffer.write((byte) referenceNumber[0]) ;
        
        return referenceNumber;
    }
    
    
    
    
    private  void unboundConnection() throws Exception
    {        	
    	try
    	{
    		UnbindResp ubr = this.connection.unbind();
		
		if (ubr.getCommandStatus() == 0) 
		{
			// logger.info("Successfully unbound from the SMSC");
			logger.info("Successfully unbound from the SMSC");
		}
		else 
		{
			//logger.info("There was an error unbinding.");
    	  logger.info("There was an error unbinding" );
		}
		//logger.info("Unbinding to SMSC finished");
		logger.info("Unbinding to SMSC finished" );
    	}        	
    	catch(Exception e) 
    	{
    		logger.error("Exception :" + e.getMessage());
    		e.printStackTrace();        		
    	}
    }
   
   
}