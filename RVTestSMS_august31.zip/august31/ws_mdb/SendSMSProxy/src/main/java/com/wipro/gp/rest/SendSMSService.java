package com.wipro.gp.rest;
 
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
 
@Path("/SendSMSService")
public class SendSMSService 
{
	private static Logger logger = LogManager.getLogger(SendSMSService.class);
	
	private static final String ConnectionFactory 	= "java:/ConnectionFactory";
	private static final String SmsQueue		   	= "java:jboss/queue/SMS.SENDING.SUBMIT.QUEUE";
	private static final String SUCCESS_RESULT 		= "<result>success</result>"; 
	private static final String FAILURE_RESULT 		= "<result>failure</result>";
	private static final String FAILURE_THROTTLING 	= "<result>failure due to throttling limit exceeded</result>";
	private static final String FAILURE_PERMISSION 	= "<result>failure:permisssion denied</result>";
	private String smsInfo;
	private boolean result;
	private static final int tps = Integer.parseInt(PropUtil.getInstance().getProperty("REQ_TPS"));
	private static final String allowedUsers = PropUtil.getInstance().getProperty("ALLOWED_USERS");
	private static String[] allowedUsersArr;
	int totalCount;
	
	static
	{
		allowedUsersArr = allowedUsers.split(",");  
	}
		
	
	//SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();
	//Session session; 
//    Transaction txUpdate;
//    Query q;   
   
   
   	@GET	
	@Path("/sendSMS")	
	@Produces(MediaType.APPLICATION_XML)
	public String getMsg(@QueryParam("msisdn") String msisdn, @QueryParam("msg") String msg, 
			@QueryParam("product") String prodID, @QueryParam("dest") String dest)
	{		
		logger.info("Obtained message, processing now");
		
		if(msg.contains("%26"))
		{
			msg = msg.replace("%26", "&");
		}
		
		if(msg.contains("%3A"))
		{
			msg = msg.replace("%3A", ":");
		}
		
		if(msg.contains("%3C"))
		{
			msg = msg.replace("%3C", "<");
		}
		
		if(msg.contains("%3E"))
		{
			msg = msg.replace("%3E", ">");
		}
		
		if(msg.contains("%28"))
		{
			msg = msg.replace("%28", "(");
		}
		
		if(msg.contains("%29"))
		{
			msg = msg.replace("%29", ")");
		}
		
		if(msg.contains("%21"))
		{
			msg = msg.replace("%21", "!");	
			
		}
		
		if(msg.contains("%3B"))
		{
			msg = msg.replace("%3B", ";");	
			
		}
		
		if(msg.contains("%3F"))
		{
			msg = msg.replace("%3F", "?");	
			
		}
		
		if(msg.contains("%22"))
		{
			msg = msg.replace("%22", "\"");
			
		}
		
		if(msg.contains("%27"))
		{
			msg = msg.replace("%27", "'");
			
		}
		
		if(msg.contains("%23"))
		{
			msg = msg.replace("%23", "#");
			
		}
		
		if(msg.contains("%2A"))
		{
			msg = msg.replace("%2A", "*");
			
		}
		
		String output = "Success: MSISDN " +  msisdn + ", SMS text  : " +   msg + "Product Id :" +  prodID + " and  Destination : " + dest;
		
		
		TextMessageQueue tms = null;
		
		boolean found = false;
		
		try 
		{
			for(String user : allowedUsersArr)
			{			
				if(user.equalsIgnoreCase(prodID))
				{
					found = true;
					break;
				}					
				
		    }
			
			if(!found)
			{
				logger.info("Failure for : " + msisdn + "`:`" + msg + "`:`" + prodID + "`:`" + dest);
				return FAILURE_PERMISSION;
			}
			
			tms 		= new TextMessageQueue(SmsQueue, ConnectionFactory);
			smsInfo 	= msisdn + "`:`" + msg + "`:`" + prodID + "`:`" + dest;			
			logger.info(smsInfo);
			
//			session  = sessionFactory.openSession();
//			totalCount = ((Integer)session.createQuery("select QCounter from ThrottledManager ").uniqueResult()).intValue();
			
//			logger.info("************* TPS Count in ThrottledManager is ************** " + totalCount);
//			
//            
//            if(totalCount > tps)
//            {
//            	logger.info("returning fail");
//            	
//            	return FAILURE_THROTTLING;
//            }
//            else
//            {
//            	txUpdate = session.beginTransaction();
//                q = session.createQuery("Update ThrottledManager set QCounter = QCounter + 1");
//                q.executeUpdate();
//                txUpdate.commit();
//                
//            	logger.info("returning success");
//            	result 		= tms.sendMessage(smsInfo);
//            }
            
            result 		= tms.sendMessage(smsInfo);
            
		    return result?SUCCESS_RESULT:FAILURE_RESULT;		    
		} 
		catch (Exception e) 
		{				
			output = "Error due to : " + e.getMessage() + " for MSISDN " + msisdn + " and SMS text is : " +   msg;			
			logger.error(output);
			
			return FAILURE_RESULT;
		}
		finally		
		{
			//session.close();
			
			if(tms != null)		
			{		
				tms.cleanUp();		
				tms = null;
			}		
		}
		
	}
 
}