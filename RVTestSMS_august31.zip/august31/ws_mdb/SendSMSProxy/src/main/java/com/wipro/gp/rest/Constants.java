package com.wipro.gp.rest;

public class Constants {
	
	//Server
	//SIT
	//public static final String SMS_PROPERTY 				= "/home/oracle/SMPPSIM/nm/AR_NOTIFICATION/ARReminders/SenderSMSConfiguration.properties";
	
	//PROD
	public static final String SMS_PROPERTY 				= "/sms/WebService/PROPS/PropertyFile.properties";
	
	

	
	//Local
	//public static final String SMS_PROPERTY 				= "d:/home/AR_POLLER/AR_SUCCESS/ARSenderSuccess/SenderSMSConfiguration.properties";
	
//	public static final String STATUS_PENDING				= "PENDING";
//	public static final String STATUS_SENDING 				= "SENDING TO SMSC";
//	public static final String PUBLISHED 					= "PUBLISHED";	
//	public static final String STATUS_FAILED 				= "FAILED";
//	public static final String READY_FOR_NOTIFICATION 		= "READY_FOR_NOTIFICATION";
//	public static final String STATUS_SUCCESS_ESB 			= "SUCCESS_ESB";
//	public static final String COUNTRY_CODE					= "880";
//	//public static final long POLLING_INTERVAL				= 24 * 60;
//	public static final long POLLING_INTERVAL				= 45;
//	//public static final int WORKERS_FOR_SEND_SMS 			= 10;
//	public static final int RTHROTTLED 						= 88;
	
//	public static final int WORKERS_FOR_SEND_SMS 			= Integer.parseInt(PropUtil.getInstance().getProperty("workers.for.send.sms"));	
//	public static final int THROTTLED_MAX_VALUE 			= Integer.parseInt(PropUtil.getInstance().getProperty("throttled.max.value"));
//	public static final int THROTTLED_SLEEP_VALUE 			= Integer.parseInt(PropUtil.getInstance().getProperty("throttled.sleep.value"));
//	public static final int MAX_RECORDS			 			= Integer.parseInt(PropUtil.getInstance().getProperty("max.records"));
//	
//	public final static String INVALID_SMS_TXT = PropUtil.getInstance().getProperty("invalid.txt");
	 
	

}
