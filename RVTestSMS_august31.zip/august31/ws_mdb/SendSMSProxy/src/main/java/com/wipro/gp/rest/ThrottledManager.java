package com.wipro.gp.rest;

import javax.persistence.Column;

public class ThrottledManager {
	
	private  long Id; 
	
	private  int QCounter;

		public ThrottledManager() {
		super();
	}

	public ThrottledManager(int Id,int QCounter) {
		super();
		
		this.Id = Id;
		this.QCounter = QCounter;
			}

	public ThrottledManager(int QCounter) {
		super();
		
		this.QCounter = QCounter;
			}
	
	public long getId() {		
		return Id;		
	}		
	public void setId(int Id) {		
		this.Id = Id;		
	}
	

	public long getQCounter() {
		return QCounter;
	}

	public void setQCounter(int QCounter) {
		this.QCounter = QCounter;
	}
		   
}
