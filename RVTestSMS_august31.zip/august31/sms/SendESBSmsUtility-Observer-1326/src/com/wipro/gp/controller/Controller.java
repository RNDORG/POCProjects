package com.wipro.gp.controller;

import ie.omk.smpp.Connection;
import ie.omk.smpp.event.ConnectionObserver;
import ie.omk.smpp.message.BindResp;
import ie.omk.smpp.net.TcpLink;
import ie.omk.smpp.version.SMPPVersion;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.wipro.gp.dao.SMSSenderDao;
import com.wipro.gp.dao.SendingMessageObserver;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.PropUtil;

public class Controller{
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.controller.Controller.class);
	
	/***Configure number of workers here***/
	public final static int WORKERS 		= Integer.parseInt(PropUtil.getInstance().getProperty("workers.success"));
	public final static int MAX_CONNECTION = Integer.parseInt(PropUtil.getInstance().getProperty("max.connection.per.ip"));
	
	static public HashMap<Integer, ArrayList<Connection>>  smscConnectionPool;
	//private final static int WORKERS = 4;	
	private static Properties properties;
	public static  int  portNo;
	public static  String systemId;
	public static String systemPwd;
	public static String systemType;
	public static int sourceTON;
	public static int sourceNPI;
	public static int destinationTON;
	public static int destinationNPI;
	public static String shortCode;
    private static int connectionCountGrp1; 
    private static int connectionCountGrp2;
    private static int connectionCountGrp3;
    private static int connectionCountGrp4;
    private static ConnectionObserver[] observerArray;
    private static int maxConnectionsPerIP;
    
	
	
	/***************************************************************************
     * Step 1 : Load all configuration from the property file
     ***************************************************************************/
    static 
    {

        // Load the property file
        logger.info("Start loading profile...");
        InputStream   propsInputStream = null;
        try
        {  
        	propsInputStream = new FileInputStream(Constants.SMS_PROPERTY);
            properties = new Properties();
            properties.load(propsInputStream);
            
            portNo          =   Integer.parseInt(properties.getProperty("port"));
            systemId        =   properties.getProperty("systemID");
            systemPwd       =   properties.getProperty("password");
            systemType      =   properties.getProperty("systemType");
            sourceTON       =   Integer.parseInt(properties.getProperty("sourceTON"));
            sourceNPI       =   Integer.parseInt(properties.getProperty("sourceNPI"));

            destinationTON  =   Integer.parseInt(properties.getProperty("destinationTON"));
            destinationNPI  =   Integer.parseInt(properties.getProperty("destinationNPI"));
            shortCode		=	properties.getProperty("shortCode");
           
        } 
        catch (Exception ex ) 
        {
        	logger.info("Exception in reading file or getting property " + ex.getMessage());
    		ex.printStackTrace();
    	} 
        finally 
        {
    		if (propsInputStream != null) 
    		{
    			try 
    			{
    				propsInputStream.close();
    			} catch (IOException e) 
    			{
    				logger.error("Exception in reading file or getting property" + e.getMessage());
    				e.printStackTrace();
    			}
    		}
    	}
        
       logger.info("Completed loading all properties" );
        
        try
        {
        	loadSMSCConnections();
        	logger.info("Loaded all connection Successfully");
        }
        catch(Exception ex)
        {
        	logger.error("Problem in loading connections......" + ex.getMessage());
        	System.exit(0);
        }
       
    
    	
    } 
    
	
	
	// Connecting Pool to connect with SMSC server
    private static void loadSMSCConnections() throws Exception
    {           
        List<String> hostList  					=   new ArrayList<String>();
        String[] hostNames						=	new String[WORKERS];
        InetAddress[] smscAddressArray			=   null;
        TcpLink[] smscLinkArray 				=   null;
        Connection[] connectionArray			=	null;
        ArrayList<Connection> connectionList	=	null;
        int hostNo								=   0;
        int instanceNo							=   0;
        observerArray							= 	new ConnectionObserver[(MAX_CONNECTION*WORKERS)];
        
        
    
        /***************************************************************************
         * Step 1 : Establish connection with the SMSC Server
         ***************************************************************************/
        try 
        {	
        	
        	for(int i = 0; i< WORKERS; i++)
        	{
        		hostNo = i + 1;
        		hostNames[i] = properties.getProperty("worker.grp." + hostNo + ".host1");
        	
        		if(!hostNames[i].isEmpty())
            	{
            		hostList.add(hostNames[i]);
            	}
            	else
            	{
            		logger.info("Host " + hostNo + " is empty");
            	}
        	}
            
        	maxConnectionsPerIP			= MAX_CONNECTION;
            connectionArray				= new Connection[maxConnectionsPerIP];
            smscConnectionPool 			= new HashMap<Integer, ArrayList<Connection>>();
            smscAddressArray			= new InetAddress[maxConnectionsPerIP];
            smscLinkArray				= new TcpLink[maxConnectionsPerIP];
            BindResp[] bindRespArray	= new BindResp[maxConnectionsPerIP];
            
            int ctr = 0;
            for(String hostName : hostList)
            {	
            	connectionList = new ArrayList<Connection>();
            	++ctr;
            	
	            for (int i = 0; i < maxConnectionsPerIP; i++)
	            {	            
		            
		            //logger.info(new Date()+ " : Trying to connect SMSC with host name : " + hostName + "\n");
		            instanceNo = i+1;
		            // First get the java.net.InetAddress for the SMSC:
		            smscAddressArray[i] = InetAddress.getByName(hostName);
		                          
		            if(smscAddressArray[i] == null)
		            {
		                throw new Exception("Unable to get the address by the host name :" + hostName + " and instance " + instanceNo);
		            }
		                            
		            smscLinkArray[i] = new TcpLink(smscAddressArray[i], portNo);
		
		            smscLinkArray[i].open();
		           
		            Connection connection = new Connection(smscLinkArray[i], true);
		            connection.setVersion(SMPPVersion.V34);
		            connection.autoAckLink(true);
		            connection.autoAckMessages(true);		            
		            observerArray[i] = new SendingMessageObserver();
		            connection.addObserver(observerArray[i]);  
		          // logger.log("ConnectionObserver added for " + observerName);
		         
		            
	                // Validate whether binding successful with the host1
	            	bindRespArray[i] = connection.bind(Connection.TRANSMITTER, systemId, systemPwd, systemType, 
	                                                        sourceTON, sourceNPI, shortCode);
	            	//logger.info("ConnectionObserver binded for " + observerName);
	                                
//	                if(bindRespArray[i].getCommandStatus() != 0)
//	                {
//	                    // Take the second host and try to connect
//	                    hostName = properties.getProperty("host2");
//
//	                    bindRespArray[i] = connection.bind(Connection.TRANSMITTER, systemId, systemPwd, systemType, 
//	                                                        sourceTON, sourceNPI, shortCode);
//
//	                    if(bindRespArray[i].getCommandStatus() != 0)
//	                    {
//	                       logger.log("SMSC bind failed \n");
//	                        //Thread.sleep(2000L);
//	                       logger.log("After Sleep \n");
//	                        throw new Exception("SMSC bind failed");
//	                    }
//	                }
//	            	if(bindRespArray[i]  != null && bindRespArray[i].getCommandStatus() != 0)
//	            	{
//	            		logger.info("Unable to get Connection for hostName " + hostName + " Port No : " + portNo +  " and instance no : " + instanceNo);
//	            	}
//	            	else
//	            	{
//	            		logger.info(new Date()+ " : Successfully connected with SMSC; host name : " + hostName + " Port No : " + portNo +  " and instance no : " + instanceNo +"\n");
//	            	}
	            	
	            	logger.info("Sent binding request to smsc; host name : " + hostName + " Port No : " + portNo +  " and instance no : " + instanceNo);
	                
	                connectionList.add(connection);	                
		            
		         }
	            
	            smscConnectionPool.put(ctr, connectionList);	            
	        }
        }
        catch(UnknownHostException ux) 
        {
           logger.error("Unable to connected with SMSC Server. Error : " + ux.getMessage());
           throw ux;
        } 
        
        logger.info("..................Connected with All SMSC hosts ...................");
        
    }
    
	
	
	public void startSendingSMS()
	{
		try 
		{
			ExecutorService executor  = Executors.newFixedThreadPool(WORKERS);
			CountDownLatch doneSignal = new CountDownLatch(WORKERS);

			for (int t = 1; t <= WORKERS; t++) 
			{	
				
				Runnable worker = new SMSSenderDao(doneSignal, t);

				executor.execute(worker);
			 }
			executor.shutdown();			
			
			while (!executor.isTerminated()) 
			{ 
		                  
			}
			//executor.awaitTermination(24 * 60, TimeUnit.MINUTES);
			
			logger.info(new Timestamp(System.currentTimeMillis())+" Finished all workers");
			Thread.sleep(1000);
			//System.exit(0);

		} catch (Exception e) {
			logger.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		
	}
	
	public static  Connection getConnection(int grpNo, int threadNo)
	{
		logger.debug("In getConnection() :::connectionCountGrp1 :" + connectionCountGrp1 
				+ ", connectionCountGrp2 :  "  + connectionCountGrp2
				+ ", connectionCountGrp3 : , "  + connectionCountGrp3
				+ ", connectionCountGrp4 : , "  + connectionCountGrp4);
		Connection connection = null;
		try
		{	
			switch(grpNo)
			{
				case 1:
					if (connectionCountGrp1 == maxConnectionsPerIP)
					{	
						Thread.sleep(1000);
						if(connectionCountGrp1 < maxConnectionsPerIP)
						{
							 connection = smscConnectionPool.get(grpNo).get(threadNo);
							++connectionCountGrp1;
						}
						else
						{
							logger.info("Connection Exhausted  connectionCountGrp1 : " +  connectionCountGrp1);
						}
					}
					else
					{
						connection = smscConnectionPool.get(grpNo).get(threadNo);
						++connectionCountGrp1;
					}					
					break;
				case 2:
					if (connectionCountGrp2 == maxConnectionsPerIP)
					{
						Thread.sleep(1000);
						if(connectionCountGrp2 < maxConnectionsPerIP)
						{
							connection = smscConnectionPool.get(grpNo).get(threadNo);
							++connectionCountGrp2;
						}
						else
						{
							logger.info("Connection Exhausted  connectionCountGrp2 : " +  connectionCountGrp2);
						}
					}					
					else
					{
						connection = smscConnectionPool.get(grpNo).get(threadNo);
						++connectionCountGrp2;
					}					
					break;
					
				case 3:
					if (connectionCountGrp3 == maxConnectionsPerIP)
					{
						Thread.sleep(1000);
						if(connectionCountGrp3 < maxConnectionsPerIP)
						{
							connection = smscConnectionPool.get(grpNo).get(threadNo);
							++connectionCountGrp3;
						}
						else
						{
							logger.info("Connection Exhausted  connectionCountGrp3 : " +  connectionCountGrp3);
						}
					}					
					else
					{
						connection = smscConnectionPool.get(grpNo).get(threadNo);
						++connectionCountGrp3;
					}
					break;
				case 4:
					if (connectionCountGrp4 == maxConnectionsPerIP)
					{
						Thread.sleep(1000);
						if(connectionCountGrp4 < maxConnectionsPerIP)
						{
							connection = smscConnectionPool.get(grpNo).get(threadNo);
							++connectionCountGrp4;
						}
						else
						{
							logger.info("Connection Exhausted  connectionCountGrp4 : " +  connectionCountGrp4);
						}
					}					
					else
					{
						connection = smscConnectionPool.get(grpNo).get(connectionCountGrp4);
						++connectionCountGrp4;
					}
					break;
				default :
					connection = null;
					break;			
			}
		}
		catch(Exception e)
		{
			logger.error("Exception in getting connection " + e.getMessage());
		}
		return connection;
	}
	
	public static void removeConnection(int grpNo)
	{
		logger.debug("In RemoveConnection ::: connectionCountGrp1 :" + connectionCountGrp1 
				+ ", connectionCountGrp2 :  "  + connectionCountGrp2
				+ ", connectionCountGrp3 : , "  + connectionCountGrp3
				+ ", connectionCountGrp4 : , "  + connectionCountGrp4);
		
		try
		{
			switch(grpNo)
			{
				case 1:				
					if (connectionCountGrp1 == 0)
					{	
						logger.info("Not Allowed to remove connectionCountGrp1" +  connectionCountGrp1);					
					}					
					else
					{
						--connectionCountGrp1;
					}					
					break;
				case 2:			
					if (connectionCountGrp2 == 0)
					{	
						logger.info("Not Allowed to remove connectionCountGrp2" +  connectionCountGrp2);					
					}					
					else
					{
						--connectionCountGrp2;
					}
					  break;
					
				case 3:			
					if (connectionCountGrp3 == 0)
					{	
						logger.info("Not Allowed to remove connectionCountGrp3" +  connectionCountGrp3);					
					}					
					else
					{
						--connectionCountGrp3;
					}					
					  break;
				case 4:			
					if (connectionCountGrp4 == 0)
					{	
						logger.info("Not Allowed to remove connectionCountGrp4" +  connectionCountGrp4);					
					}					
					else
					{
						--connectionCountGrp4;
					}					
					  break;
				default :			
					break;			
			}
		}
		catch(Exception e)
		{
			logger.error("Exception in remove connection" + e.getMessage());
		}
		
	}
	
	

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception 
	{	
		PropertyConfigurator.configure("/sms/SENDESBSMS/Log4j_ESBValid.properties");
		
		class EnquireLinkPing extends TimerTask 
		{

	        
	        public void run() 
	        {
	            for(int i= 1; i<= WORKERS; i++)
	   	         {
	   	      	   ArrayList<Connection> connections =  smscConnectionPool.get(i);
	   	      	   
	   	      	   for(Connection connection: connections)
	   	      	   {
	   	      		   try 
	   	      		  {
	   	      			if(connection.isBound())
	   	      			{
	   	      				connection.enquireLink();
	   	      			}
	   	      			else
	   	      			{
	   	      				logger.info("Connection not bounded to send enquire link");
	   	      			}
	   	      				
	   	      		  } 
	   	      		   catch (Exception e) 
	   	      		   {
	   	      			  logger.error("Exception while calling enquire link" + e.getMessage());							
	   	      		   }
	   	      		}		        	   
	   	         }
	        }
	    }
		 Timer timer = new Timer();
	     timer.schedule(new EnquireLinkPing(), 0, 45000);
		
	     logger.info("........SMS Sender Application  for ESB Valid messages started............");
		 final Controller controller = new Controller();
		// controller.startSendingSMS();
		 
		 
		 
		 
		 Runnable runnable = new Runnable()
		    {
		      public void run() 
		      {
		    	  controller.startSendingSMS();
		      }	
		    };    

			ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();    
			service.scheduleAtFixedRate(runnable, 0, Constants.POLLING_INTERVAL, TimeUnit.SECONDS);
		 
		 
	}
	
	public void finalize()
	{
		for(SendingMessageObserver sendingMessageObserver : (SendingMessageObserver[])observerArray )
		{
			sendingMessageObserver = null;
		}
		
	}

}
