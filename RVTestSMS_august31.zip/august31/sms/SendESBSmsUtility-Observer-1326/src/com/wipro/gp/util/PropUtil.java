package com.wipro.gp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
 
public class PropUtil
{  
	private static final Logger logger = Logger.getLogger(com.wipro.gp.util.PropUtil.class);
   
    private final Properties configProp = new Properties();  
      
   
    
   private PropUtil()
   {
      //Private constructor to restrict new instances    
	   
     logger.info("Going to Read all properties from file");
      try 
      {
    	  InputStream in = new FileInputStream(Constants.SMS_PROPERTY);    	  
          configProp.load(in);
          logger.info("Read all properties from file");
      } 
      catch (IOException e) 
      {
          logger.error("Error reading property file :" + Constants.SMS_PROPERTY);
    	  e.printStackTrace();
      }
   }
   
   
   private static class LazyHolder
   {
      private static final PropUtil INSTANCE = new PropUtil();
   }
 
   public static PropUtil getInstance()
   {
      return LazyHolder.INSTANCE;
   }
    
   public String getProperty(String key){
      return configProp.getProperty(key);
   }
    
   public Set<String> getAllPropertyNames(){
      return configProp.stringPropertyNames();
   }
    
   public boolean containsKey(String key){
      return configProp.containsKey(key);
   }
   
   public static void main(String[] args)
   {    
	   
	   String workers = PropUtil.getInstance().getProperty("workers.success");
	   logger.info("workers.success :: "  + workers);
	   
	   
   }
}