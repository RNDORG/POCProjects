
package com.wipro.gp.dao;

import ie.omk.smpp.Address;
import ie.omk.smpp.AlreadyBoundException;
import ie.omk.smpp.BadCommandIDException;
import ie.omk.smpp.Connection;
import ie.omk.smpp.UnsupportedOperationException;
import ie.omk.smpp.message.InvalidParameterValueException;
import ie.omk.smpp.message.SMPPPacket;
import ie.omk.smpp.message.SMPPProtocolException;
import ie.omk.smpp.message.SMPPRequest;
import ie.omk.smpp.message.SubmitSM;
import ie.omk.smpp.message.SubmitSMResp;
import ie.omk.smpp.message.UnbindResp;
import ie.omk.smpp.util.DefaultAlphabetEncoding;
import ie.omk.smpp.version.VersionException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.wipro.gp.bean.ESBValidSms;
import com.wipro.gp.controller.Controller;
import com.wipro.gp.util.Constants;
//import ie.omk.smpp.
/**
 *
 * @author Administrator
 */
public final class SendLongSMS implements Runnable
{
	private static final Logger logger = Logger.getLogger(com.wipro.gp.dao.SendLongSMS.class);	
    private static HashMap<Integer, ArrayList<Connection>>  smscConnectionPool;
    
    private static final int maxShortMessageLength   	= 160;
    private static final int maxSegmentLength        	= 153;
    final byte UDHIE_HEADER_LENGTH 						= 0x05;
    final byte UDHIE_IDENTIFIER_SAR 					= 0x00;
    final byte UDHIE_SAR_LENGTH 						= 0x03;
    
//    private static int portNo;
//    private static String systemId;
//    private static String systemPwd;
//    private static String systemType;
//    private static int sourceTON;
//    private static int sourceNPI;
//    private static int destinationTON;
//    private static int destinationNPI;
//    private static String shortCode;
    private int nextRefNum;
    private Connection connection;    
    private DefaultAlphabetEncoding  encoding;                        
    private static SendLongSMS instance;
    private int worker;
    private static Properties properties;
    ByteArrayOutputStream  byteBuffer = new ByteArrayOutputStream();
	private String  workDone;
	private CountDownLatch doneSignal;
	private String destMSISDN;
	private String msg;
	private ESBValidSms esbValidSms;
	private Session session;
	private int count;
	private int threadNo;
	private long recordNum;
	
	  
    
    /***************************************************************************
     * Step 1 : Load all configuration from the property file
     ***************************************************************************/
  
    public SendLongSMS() 
    {
    	
	}
    
    
    public SendLongSMS(long recordNum, CountDownLatch doneSignal, String destMSISDN,  ESBValidSms esbValidSms, Session session, int threadNo) 
    {
    	this.recordNum  = recordNum;
		this.doneSignal = doneSignal;	
		this.destMSISDN = destMSISDN;
		this.msg		= esbValidSms.getSmsText();
		this.worker 	= esbValidSms.getGrpNum();
		this.esbValidSms = esbValidSms;
		this.session	= session;
		this.threadNo	= threadNo; 
		
		workDone = null;
		
	}
	 
    
    public String getWorkDone()
    {
    	return workDone;
    	
    }
    
    
    public void run() 
    {
    	
	    try
	    {
	    	logger.info(" Start Sending SMS for,  MSISDN = " + destMSISDN + ", Message = " +msg + " and  group Number = " + worker);	    	
	    	
	    	sendSMS();
	    	
//	    	if(workDone != null)
//	    	{
//	    		
//	    		logger.info("Going for update, for recordNum :: " + arSuccessNotification.getRecordNum());
//				arSuccessNotification.setStatus(Constants.PUBLISHED);
//				session.update(arSuccessNotification);
//	    	}	    	
	    	
	    		
	    }
	    catch (Exception e) 
	    {
	      logger.info("Exception while sending SMS for,  MSISDN = " + destMSISDN + ", Message = " +msg + " and  group Number = " + worker);	
	      logger.error("exception in thread, while sending  sms,  sendSMS() " + e.getMessage());
		  e.printStackTrace();
		}
	    finally
	    {
	    	// commits the transaction and close the session
//	    	session.getTransaction().commit();
//	    	session.close();
	    }
	    
	    
	    doneSignal.countDown();
    }
    
    
    
    
    public void sendSMS() throws Exception
    {
        
    	
    	logger.debug("In  sendSMS() method and   MSISDN = " + destMSISDN + ", Message = " +msg + " and  group Number = " + worker);
    	
    	
        /***************************************************************
         * Step 1 : Parameter validation
         ***************************************************************/
        if(destMSISDN.isEmpty())
        {
        	logger.info("Exception MSISDN is Empty ......");
        	throw new Exception("Invalid MSISDN" + destMSISDN);
        }
        
        if(msg.isEmpty())
        {
        	logger.info("Exception Message is Empty ......");
        	throw new Exception("Invalid message" + msg);
        }
        
        // Start processing for the valid message
       logger.debug( "Start sending request : " + msg + " To : " + destMSISDN);
        
        int         parts       =   0;
        String      msgId       =   null;
        byte[]      msgInByte   =   null;
        SubmitSMResp response = null;
        
        try
        {
        	
            /***************************************************************
             * Step 2 : Convert message into byte array
             ***************************************************************/
            encoding  = new DefaultAlphabetEncoding();
            msgInByte = encoding.encodeString(msg);
           logger.debug("Message converted into byte : " + msgInByte.toString());
            
            if(msgInByte == null)
            {
                // throw new Exception("Unable to convert message into byte");
            	//logger.info("Unable to convert message into byte");
            	logger.info("Null, Unable to convert message into byte and msg : " + msg);
            }
            
            /***************************************************************
             * Step 3 : Calculate number of parts
             ***************************************************************/
           logger.debug( "length of byte message : " + msgInByte.length);
            
            parts = (msgInByte.length < maxShortMessageLength ? 1 : (int)Math.ceil(((double)msgInByte.length) / maxSegmentLength));
            
           logger.debug( "Message parts : " + parts);
            
            /***************************************************************
             * Step 4 : Connect with the SMSC server 
             ***************************************************************/
//            if(connectSMSC() < 0)
//            {
//               throw new Exception("Unable to connect with SMSC Server");
//            }                
            connection = Controller.getConnection(worker, threadNo);
            
            if(connection == null)
            {   
            	Thread.sleep(1000);
            	logger.info("Additional wait for connection......");
            	connection = Controller.getConnection(worker, threadNo);
            	
            	logger.info("Additional wait for connection......");
            	
            	if(connection == null)
                {   
            		logger.info("Error, Unable to get connection for  worker " +  worker);            		
            		return;            		
            		//throw new Exception("Unable to get connection for  worker " +  worker);
                }
            	
            }
            
           //logger.info(new Date()+ " : Successfully connected with SMSC server " );
            
            
            /***************************************************************
             * Step 5 : Send the SMS
             ***************************************************************/
            
            if(!destMSISDN.startsWith((Constants.COUNTRY_CODE )))
			{
            	destMSISDN = Constants.COUNTRY_CODE + destMSISDN;
			}
            
            this.sendSMS(destMSISDN, msgInByte, parts);
                        
//            switch(worker)
//			{
//				case 1:
//					if(Controller.Count_Grp1 > Controller.THROTTLED_MAX_VALUE)
//					{
//						Thread.sleep(Controller.THROTTLED_SLEEP_VALUE);
//					}
//					else
//					{
//						this.sendSMS(destMSISDN, msgInByte, parts);
//						Controller.Count_Grp1++; 
//					}
//					break;
//				case 2:
//					if(Controller.Count_Grp2 > Controller.THROTTLED_MAX_VALUE)
//					{
//						Thread.sleep(Controller.THROTTLED_SLEEP_VALUE);
//					}
//					else
//					{
//						this.sendSMS(destMSISDN, msgInByte, parts);
//						Controller.Count_Grp2++; 
//					}
//					break;					
//				case 3:
//					if(Controller.Count_Grp3 > Controller.THROTTLED_MAX_VALUE)
//					{
//						Thread.sleep(Controller.THROTTLED_SLEEP_VALUE);
//					}
//					else
//					{
//						this.sendSMS(destMSISDN, msgInByte, parts);
//						Controller.Count_Grp3++; 
//					}
//					break;
//				case 4:
//					if(Controller.Count_Grp4 > Controller.THROTTLED_MAX_VALUE)
//					{
//						Thread.sleep(Controller.THROTTLED_SLEEP_VALUE);
//					}
//					else
//					{
//						this.sendSMS(destMSISDN, msgInByte, parts);
//						Controller.Count_Grp4++; 
//					}
//					break;
//				default :					
//					break;
//            }
            
//            
//            if(connection.isBound())
//            {
//            	this.sendSMS(destMSISDN, msgInByte, parts);
//            	logger.info(new Date()+ " : Successfully sent message for recordNum :" + recordNum);
//            }
//            else
//            {
//            	logger.info("Connection is not bound, so message cannot be send...");
//            }
            
           
            
           //logger.info("Message Id : " + msgId);
            
//            if(msgId != null)
//            {
//            	logger.info("Going for update, for Success and recordNum :: " + arSuccessNotification.getRecordNum());
//				arSuccessNotification.setStatus(Constants.PUBLISHED);
//				session.update(arSuccessNotification);
//            }
//            else
//            {
//            	logger.info("Going for update, for Failure and  recordNum :: " + arSuccessNotification.getRecordNum());
//				arSuccessNotification.setStatus(Constants.STATUS_FAILED);
//				session.update(arSuccessNotification);
//				
//            }
//            
        	
            
        }
        catch(Exception ex)
        {
        	logger.error("Error while sending sms  sendSMS() " + ex.getMessage());
//        	logger.info("Going for update, for Exception and  recordNum :: " + arSuccessNotification.getRecordNum());
//				arSuccessNotification.setStatus(Constants.STATUS_FAILED);
//				session.update(arSuccessNotification);
            throw ex;
        }
        
        
    }
    
     /***********************************************************************
     * List of private functions
     ***********************************************************************/
    
    // Function for connecting SMSC server
//    private int connectSMSC() throws Exception
//    {
//        int             retVal      =   0;
//        String          hostName    =   "";
//        TcpLink         smscLink    =   null;
//        InetAddress     smscAddr    =	null;
//        BindResp    bindResp 		=	null;
//    
//        /***************************************************************************
//         * Step 1 : Establish connection with the SMSC Server
//         ***************************************************************************/
//        try 
//        {
//           // hostName = properties.getProperty("host1");
//        	 hostName = properties.getProperty("worker.grp." + worker + ".host1");
//
//            if(hostName.isEmpty())
//            {
//                throw new Exception("Host name not configured");
//            }
//            
//           logger.info(new Date()+ " : Trying to connect SMSC with host name : " + hostName);                
//            // First get the java.net.InetAddress for the SMSC:
//            smscAddr = InetAddress.getByName(hostName);
//                          
//            if(smscAddr == null)
//            {
//                throw new Exception("Unable to get the address by the host name");
//            }
//                            
//            smscLink = new TcpLink(smscAddr, Controller.portNo);
//
//            smscLink.open();
//            
//           logger.info(new Date()+ " : Connected with SMSC; host name : " + hostName + " Port No : " + Controller.portNo);
//        }
//        catch(UnknownHostException ux) 
//        {
//           logger.info(new Date()+ " : Unable to connected with SMSC Server. Error : " + ux.getMessage());
//            System.err.println("SMPPAPI: " + ux.getMessage());
//            throw ux;
//        }
//
//        try
//        {
//            connection = new Connection(smscLink);
//
//            connection.setVersion(SMPPVersion.V34);
//            connection.autoAckLink(true);
//            connection.autoAckMessages(true);
//
//            // Validate whether binding successful with the host1
//            bindResp = connection.bind(Connection.TRANSMITTER, Controller.systemId, Controller.systemPwd, Controller.systemType, 
//            		Controller.sourceTON, Controller.sourceNPI, Controller.shortCode);
//                            
//            if(bindResp.getCommandStatus() != 0)
//            {	
//                 //Take the second host and try to connect
//                 //hostName = properties.getProperty("host2");            	
//            	try 
//                {
//                   // hostName = properties.getProperty("host1");
//                	 hostName = properties.getProperty("worker.grp." + worker + ".host2");
//
//                    if(hostName.isEmpty())
//                    {
//                        throw new Exception("Host2 name not configured");
//                    }
//                    
//                   logger.info(new Date()+ " : Trying to connect SMSC with host2 name : " + hostName);                
//                    // First get the java.net.InetAddress for the SMSC:
//                    smscAddr = InetAddress.getByName(hostName);
//                                  
//                    if(smscAddr == null)
//                    {
//                        throw new Exception("Unable to get the address by the host2 name");
//                    }
//                                    
//                    smscLink = new TcpLink(smscAddr, Controller.portNo);
//
//                    smscLink.open();
//                    
//                   logger.info(new Date()+ " : Connected with SMSC; host2 name : " + hostName + " Port No : " + Controller.portNo);
//                }
//                catch(UnknownHostException ux) 
//                {
//                   logger.info(new Date()+ " : Unable to connected with SMSC Server backup host. Error : " + ux.getMessage());
//                    System.err.println("SMPPAPI: " + ux.getMessage());
//                    throw ux;
//                }
//            	
//            	connection = new Connection(smscLink);
//                connection.setVersion(SMPPVersion.V34);
//                connection.autoAckLink(true);
//                connection.autoAckMessages(true);
//                
//
//                bindResp = connection.bind(Connection.TRANSMITTER, Controller.systemId, Controller.systemPwd, Controller.systemType, 
//                		Controller.sourceTON, Controller.sourceNPI, Controller.shortCode);
//                
//               logger.info("Binded with host2 " + hostName);
//
//                if(bindResp.getCommandStatus() != 0)
//               {
//                   logger.info("SMSC bind failed  with both of hosts \n");
//                    Thread.sleep(100L);
//                   logger.info("After Sleep \n");
//                    throw new Exception("SMSC bind failed");
//                }
//                
//            }
//            else
//            {	
//                {
//                	 
//                	EnquireLinkResp  enquireLinkResp = connection.enquireLink();
//                	
//                	int enquireLinkRespValue = enquireLinkResp.getCommandId();
//                	logger.info("enquireLinkRespValue :: " +  enquireLinkRespValue);
//                	
//                	if(SMPPPacket.ENQUIRE_LINK_RESP == enquireLinkRespValue)
//                	{
//        	           logger.info("\nENQUIRE_LINK_RESP.");
//                	}
//                }
//            }
//            
//            
//        }
//        catch(Exception ex){
//            throw ex;
//        }
//
//       logger.info(new Date()+ " : Successfully connected with SMSC; host name : " + hostName + " Port No : " + Controller.portNo);
//        
//        return retVal;
//    }
    
    // Function for sending normal / long SMS
    private  void sendSMS(String destMSISDN, byte[] msgInByte, int parts) throws Exception
    {
        String			msgId       	= "";
        SMPPRequest     request     	= null;
        SubmitSMResp    response    	= null;
        byte[]          packet      	= new byte[maxSegmentLength];
        byte[]          msgrefnum   	= getNextRefNum();
        Address 		destAddress 	= new Address(Controller.destinationTON, Controller.destinationNPI, destMSISDN);
        //Address 		sourceAddress 	= new Address(Controller.sourceTON, Controller.sourceNPI, Controller.shortCode);
        Address 		sourceAddress 	= new Address(Controller.sourceTON, Controller.sourceNPI, esbValidSms.getDest_shortCode() );
        
        //30-Aug-16: This variable is used for long SMS
        
        try
        {
            for(int counter = 0; counter < parts; counter++)
            {
                byteBuffer.reset();
                
                // Create the message
               logger.debug( "Creating request for part # : " + counter);
                
                request = (SubmitSM)connection.newInstance(SMPPPacket.SUBMIT_SM);
                request.setDestination(destAddress);
                request.setSource(sourceAddress);
                
                if(parts > 1)
                {
                    // Below tags are required only for long message only
                	request.setEsmClass(0x43);                    	
                    request.setDataCoding(encoding.getDataCoding());
                    
                    // 30-Aug-16: Add UDH Header.
                    byteBuffer.write(UDHIE_HEADER_LENGTH); // UDH Length
                   logger.debug( "Size after UDH Header : " + byteBuffer.size());
                    
                    byteBuffer.write(UDHIE_IDENTIFIER_SAR); // IE Identifier
                   logger.debug( "Size after IE Identifier : " + byteBuffer.size());
                    
                    byteBuffer.write(UDHIE_SAR_LENGTH); // IE Data Length
                   logger.debug( "Size after IE Data Length : " + byteBuffer.size());
                    
                    
                   logger.debug("Value of msgrefnum : " + msgrefnum);
                    byteBuffer.write(msgrefnum) ; //Reference Number
                    
                   logger.debug( "Size after Reference Number : " + byteBuffer.size());
                    
                    
                    
                    byteBuffer.write((byte) parts) ; //Number of pieces
                   logger.debug("Size after Number of pieces : " + byteBuffer.size());
                    
                    byteBuffer.write((byte) (counter+1)) ; //Sequence number
                   logger.debug( "Size after Sequence number : " + byteBuffer.size());                        

                }
                

                if (counter == parts-1) 
                {
                    // Special attaintion for the last part
                    int     pos             =   counter*maxSegmentLength;
                    int     len             =   msgInByte.length - pos;
                    byte[]  finalPacket     =   new byte[len];

                    System.arraycopy(msgInByte, pos, finalPacket, 0, len);
                   logger.debug( "Before setMessage (Last Part): " + finalPacket.toString());
                    // 30-Aug-16: Start Modification
                    //request.setMessage(finalPacket, encoding);
                    byteBuffer.write(finalPacket);
                    // 30-Aug-16: End Modification
                    request.setSequenceNum((int)recordNum);
                }
                else 
                {
                    System.arraycopy(msgInByte, counter*maxSegmentLength, packet, 0, maxSegmentLength);
                   logger.debug("Before setMessage : " + packet.toString());
                    // 30-Aug-16: Start Modification
                    byteBuffer.write(packet);
                    //request.setMessage(packet, encoding);
                    // 30-Aug-16: End Modification
                    request.setSequenceNum(0);
                }
                
                // 30-Aug-16: Start Modification
               logger.debug( "Before setMessage :: byteBuffer.size() : " + byteBuffer.size());
                request.setMessage(byteBuffer.toByteArray(), encoding);
                // 30-Aug-16: end Modification
                
               logger.debug(recordNum + ": Before send request : ");
                // Send the message
                //response = (SubmitSMResp)connection.sendRequest(request);   
               //request.setSequenceNum((int)recordNum);
                //request.setMessageId("" + worker );                
                connection.sendRequest(request);                
                Controller.removeConnection(worker);
               logger.debug(recordNum + ": After send request : ");
                  
                
            }
        }
        catch(BadCommandIDException | VersionException | InvalidParameterValueException | IOException | AlreadyBoundException 
        		| SMPPProtocolException | UnsupportedOperationException ex)
        {
           logger.info( "Unable to send message to SMSC, for record number : " + recordNum + ex.getMessage());
           Controller.removeConnection(worker);
            throw ex;
        }
        
        // Get the final response id
//        if(response != null)
//        {
//            msgId = response.getMessageId();
//           // this.unboundConnection();
//        }
//        
//        return msgId;
       
    }
    
  
    // Function for sending unique message id
   // private synchronized byte[] getNextRefNum ()
//    private  byte[] getNextRefNum ()
//    {
//    	byte[] referenceNumber = new byte[1];
//    	//new Random().nextBytes(referenceNumber);
//    	//recordNum
//    	//byteBuffer.write((byte) referenceNumber[0]);
//    	
//    	
//    	referenceNumber = ByteBuffer.allocate(Long.SIZE / Byte.SIZE).putLong(recordNum).array();
//    	byteBuffer.write((int)recordNum);
//        
//        return referenceNumber;
//    }
    
    
 // Function for sending unique message id
    private  byte[] getNextRefNum ()
    {
    	byte[] referenceNumber = new byte[1];
    	new Random().nextBytes(referenceNumber);
    	byteBuffer.write((byte) referenceNumber[0]) ; 

        
        return referenceNumber;
    }
    
    
    
    
    private  void unboundConnection() throws Exception
    {        	
    	try
    	{
    		UnbindResp ubr = this.connection.unbind();
		
		if (ubr.getCommandStatus() == 0) 
		{
			// logger.info("Successfully unbound from the SMSC");
			logger.info("Successfully unbound from the SMSC");
		}
		else 
		{
			//logger.info("There was an error unbinding.");
    	  logger.info("There was an error unbinding" );
		}
		//logger.info("Unbinding to SMSC finished");
		logger.info("Unbinding to SMSC finished" );
    	}        	
    	catch(Exception e) 
    	{
    		logger.error("Exception :" + e.getMessage());
    		e.printStackTrace();        		
    	}
    }
   
   
}