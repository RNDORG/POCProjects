package com.wipro.gp.util;

public interface JmsESBCMPInterface {


}