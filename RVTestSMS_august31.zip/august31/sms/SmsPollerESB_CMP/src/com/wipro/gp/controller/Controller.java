package com.wipro.gp.controller;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.wipro.gp.service.SmsPollerService;
import com.wipro.gp.util.CMPPropUtilCache;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.ESBPropUtilCache;

public class Controller 
{
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.controller.Controller.class);
	
	public static final HashMap<String, HashMap<String, String[]>> esb_ShortCode_SubsMap;
	public static final HashMap<String, HashMap<String, String[]>> cmp_ShortCode_SubsMap;
	
	static
	{
		ESBPropUtilCache.loadESBFile();
		esb_ShortCode_SubsMap = ESBPropUtilCache.getEPCMap();
		
		CMPPropUtilCache.loadCMPFile();
		cmp_ShortCode_SubsMap = CMPPropUtilCache.getCMPMap();
	}
	
	public static void showESBMap() 
	{
		 ///################ Verification Test #####################
		StringBuilder buildLogString 
							= new StringBuilder("**********************************Values for ESB/EPC file Map*********************************");
		for(Entry<String, HashMap<String, String[]>> entry : esb_ShortCode_SubsMap.entrySet())
		{ 
			buildLogString.append("\n entry.getKey() ::: " + entry.getKey());
		 
			 for(Entry<String, String[]> entrySubs : (entry.getValue()).entrySet())
			 { 	 
				 buildLogString.append("\n ::::" + entrySubs.getKey());		    		 
				 buildLogString.append("->  " + entrySubs.getValue()[0]);		    		 
				 buildLogString.append("->  " + entrySubs.getValue()[1]);
					 
			 }	 
			 logger.info(buildLogString.toString());
		 }
	}
	
	public static void showCMPMap() 
	{
		 ///################ Verification Test #####################
		StringBuilder buildLogString 
								= new StringBuilder("****************************Values from CMP/EPC file Map******************************");
		for(Entry<String, HashMap<String, String[]>> entry : cmp_ShortCode_SubsMap.entrySet())
		{   
		    buildLogString.append("\n entry.getKey() ::: " + entry.getKey());
		    for(Entry<String, String[]> entrySubs : (entry.getValue()).entrySet())
		    { 
		    	buildLogString.append(" ::::" + entrySubs.getKey());
		    	buildLogString.append("->  " + entrySubs.getValue()[0]);
		    	buildLogString.append("->  " + entrySubs.getValue()[1]);		    		 
		    }
		    logger.info(buildLogString.toString());
		 }
	}
	
	public static String[] validateESBKeyWord(String shortCode, String smsKey) 
	{	
		StringBuilder buildLogString = new StringBuilder("\n Entering in method validateESBKeyWord()...........");
		String keyWordInFile 		 = null;
		String smsKeyTrim    		 = smsKey.replaceAll("^ +| +$| (?=)", "");
		String productId     		 = null;
		String actionType    		 = null;
		String startWithKeyword  	 = null;
		
		
		String[] result   = new String[3];
				result[0] =  Constants.NOT_FOUND;
				result[1] =  Constants.NOT_FOUND;
				result[2] =  Constants.SPECIAL_KEY;
		
		if(shortCode == null || shortCode == ""  || smsKey == null || smsKey == "")
		{
			logger.info("Either ShortCode or Sms keyword is null.");
			
			return result;
		}
		
		 ///################ Verification Test #####################
		   for(Entry<String, HashMap<String, String[]>> entry : esb_ShortCode_SubsMap.entrySet())
		     {
		    	
			   buildLogString.append("\n  In, validateESBKeyWord(shortCode = " + shortCode +", smsKey = " + smsKey + ") and ..... (Short Code from ESB/EPC) ::: " + entry.getKey());
			   	
				 if(shortCode.equals(entry.getKey()))
		    	 {
					 buildLogString.append("\n Short code matched for ###############  " + shortCode);
		    	 
			    	 for(Entry<String, String[]> entrySubs : (entry.getValue()).entrySet())
			    	 { 

			    		 productId 			= entrySubs.getValue()[0];
			    		 actionType 		= entrySubs.getValue()[1];
			    		 startWithKeyword	= entrySubs.getValue()[2];
			    		 startWithKeyword   = startWithKeyword.trim();
			    		 //if((smsKey.toUpperCase()).startsWith(startWithKeyword.toUpperCase()) || (Constants.IGNORE_KW_VALIDATION).equals(startWithKeyword))
			    		 if((Constants.IGNORE_KW_VALIDATION).equals(startWithKeyword) && isNumericAndSpaceAnsPlus(smsKey))
			    		 {
			    			 buildLogString.append(" Keyword IGNORE_KW_VALIDATION : " + startWithKeyword + " Matched for  :::: " + smsKey);			    			 			    			 
			    			 result[0] = productId;
			    			 result[1] = actionType;
			    			 result[2] = startWithKeyword;
			    			 
			    			 break;	
			    		 }			    		 
			    		 
			    		 keyWordInFile = entrySubs.getKey();
			    		 if(keyWordInFile != null)
			    		 {
			    			 keyWordInFile = keyWordInFile.replaceAll("^ +| +$| (?=)", "");
			    		 }
			    		 buildLogString.append("\n Loop keys ::::" + keyWordInFile);			    		 
			    		 
			    		if(smsKeyTrim.equalsIgnoreCase(keyWordInFile)) 
				    	{
			    			 buildLogString.append("\n Keyword trimed 'Full' Matched for :::: " + smsKey);			    			 			    			 
			    			 result[0] = productId;
			    			 result[1] = actionType;
			    			 result[2] = startWithKeyword;
			    			 break;			    					 
				    	}
			    		 
			    	 }
			    	 
			    	 if(!(Constants.NOT_FOUND).equals(result[1]))
	    			 {
			    		 break;
	    			 }
		    	  } // end Short code
				 else
				 {
					 buildLogString.append("\n Short code not matched for searched shortcode ###############  " + shortCode);
				 }
		    	 
		     }
		   
		   buildLogString.append("\n Product Type " + result[0]);
		   buildLogString.append("\n Action type " +  result[1]);
		   buildLogString.append("\n Start With Word " +  result[2]);
		   
		   buildLogString.append("\n Exiting from method validateEpcKeyWord()...........");
		   logger.info(buildLogString.toString());
		
		   return  result;
	}
	
	
	public static String[] validateESBKeyWordSpecialCase(String shortCode, String smsKey) 
	{	
		StringBuilder buildLogString = new StringBuilder("\n Entering in method validateESBKeyWord()...........");
		String keyWordInFile 		 = null;
		String smsKeyTrim    		 = smsKey.replaceAll("^ +| +$| (?= )", "");
		String smsTokens[] 			 = smsKeyTrim.split(Constants.TOKEN_KEY);
		String keyWordTokensInFile[] =  null;
		String keyWordTokenInFile	 = null;		
		String productId     		 = null;
		String actionType    		 = null;
		String startWithKeyword  	 = null;
		int i						 = 0;
		String shortCodeInfile		 = null;
		boolean isValid			 	 = true;
		
		
		String[] result   = new String[3];
				result[0] =  Constants.NOT_FOUND;
				result[1] =  Constants.NOT_FOUND;
				result[2] =  Constants.SPECIAL_KEY;
		
		if(shortCode == null || shortCode == ""  || smsKey == null || smsKey == "")
		{
			logger.info("Either ShortCode or Sms keyword is null.");
			
			return result;
		}
		
		///################ Verification Test #####################
		  for(Entry<String, HashMap<String, String[]>> entry : esb_ShortCode_SubsMap.entrySet())
		     {
		    	
			    buildLogString.append("\n  In, validateESBKeyWordSpecialCase(shortCode = " + shortCode +", smsKey = " + smsKey + ") and ..... (Short Code from ESB/EPC) ::: " + entry.getKey());
			   	shortCodeInfile = entry.getKey();
				 if(shortCode.equals(shortCodeInfile))
		    	 {
					 buildLogString.append("\n Short code matched for ###############  " + shortCode);
		    	 
			    	 for(Entry<String, String[]> entrySubs : (entry.getValue()).entrySet())
			    	 { 			    		  
			    		 
			    		 
			    		 productId 			= entrySubs.getValue()[0];
			    		 actionType 		= entrySubs.getValue()[1];
			    		 startWithKeyword	= entrySubs.getValue()[2];
			    		 isValid 			= true;
			    		 
			    		 keyWordInFile = entrySubs.getKey();
			    		 if(keyWordInFile != null)
			    		 {
			    			 keyWordInFile = keyWordInFile.replaceAll("^ +| +$| (?= )", "");
			    			 keyWordTokensInFile = keyWordInFile.split(Constants.TOKEN_KEY);
			    		
				    		 buildLogString.append("\n Loop keys ::::" + keyWordInFile);			    		 
				    		 
				    		 if(smsTokens.length == keyWordTokensInFile.length  || "SI500MB_ON".equalsIgnoreCase(smsTokens[0])) 
					    	 {
				    			 
				    			 for(i = 0; i < smsTokens.length ; i++)
				    			 {
				    				 keyWordTokenInFile = keyWordTokensInFile[i];
				    				 if(!keyWordTokenInFile.contains("<") && !smsTokens[i].equalsIgnoreCase(keyWordTokenInFile))
				    				 { 
				    					isValid = false;
						    			break; 			    	
				    				 }
				    			 }
				    			 
				    			 if (isValid)
				    			 {
				    				 buildLogString.append("\n All Keyword tokens Matched for :::: " + smsKey);			    			 			    			 
					    			 result[0] = productId;
					    			 result[1] = actionType;
					    			 result[2] = startWithKeyword;
					    			 break;
				    			 }
				    			 				 
					    	 }
			    		 
			    		}
			    		 
			    	 }
			    	
			    	 if(!(Constants.NOT_FOUND).equals(result[1]))
	    			 {
			    		 break;
	    			 }
			    	 
		    	  } // end Short code
				 else
				 {
					 buildLogString.append("\n Short code not matched for searched shortcode ###############  " + shortCode);
				 }
		    	 
		     }
		   
		   buildLogString.append("\n Product Type " + result[0]);
		   buildLogString.append("\n Action type " +  result[1]);
		   buildLogString.append("\n Start With Word " +  result[2]);
		   
		   buildLogString.append("\n Exiting from method validateESBKeyWordSpecialCase()...........");
		   logger.info(buildLogString.toString());
		
		   return  result;
	}
	
	public static String[] validateCMPKeyWord(String shortCode, String smsKey) 
	{
		StringBuilder buildLogString = new StringBuilder("\n Entering in method validateCMPKeyWord()...........");
		String keyWordInFile = null;
		
		String[] result   = new String[2];
				result[0] =  Constants.NOT_FOUND;
				result[1] =  Constants.NOT_FOUND;
		
		if(shortCode == null || shortCode == ""  || smsKey == null || smsKey == "")
		{
			logger.info("Either ShortCode or Sms keyword is null.");
			
			return result;
		}
		
		smsKey =  smsKey.replaceAll("^ +| +$| (?=)", "");
		
		 ///################ Verification Test #####################
		   for(Entry<String, HashMap<String, String[]>> entry : cmp_ShortCode_SubsMap.entrySet())
		     {
		    	
			   buildLogString.append("\n  In, validateCMPKeyWord(shortCode = " + shortCode +", smsKey = " + smsKey + ") and ..... (Short Code from CMP/EPC) ::: " + entry.getKey());
			   			   
				 if(shortCode.equals(entry.getKey()))
		    	 {
					 buildLogString.append("\n Short code matched for ###############  " + shortCode);
		    	 
			    	 for(Entry<String, String[]> entrySubs : (entry.getValue()).entrySet())
			    	 { 
			    		 keyWordInFile = entrySubs.getKey();
			    		 buildLogString.append(" Loop keys ::::" + entrySubs.getKey());			    		 
			    		 if(keyWordInFile != null)
			    		 {
			    			 keyWordInFile = keyWordInFile.replaceAll("^ +| +$| (?=)", "");
			    		 }
			    		 
			    		 if(smsKey.equalsIgnoreCase(keyWordInFile))
				    	 {
			    			 buildLogString.append(" Keyword Matched for :::: " + smsKey);			    			 			    			 
			    			 result[0] = entrySubs.getValue()[0];
			    			 result[1] = entrySubs.getValue()[1];
			    			 break;			    					 
				    	 }
			    		 
			    	 }
			    	 if(!(Constants.NOT_FOUND).equals(result[0]))
	    			 {
			    		 break;
	    			 }
			    	 //break;
		    	  } // end Short code
				 else
				 {
					 buildLogString.append("\n Short code not matched for searched shortcode ###############  " + shortCode);
				 }
		    	 
		     }
		   
		   buildLogString.append("\n Service ID  " + result[0]);
				   buildLogString.append("\n Action type " +  result[1]);
		   
		   buildLogString.append("\n Exiting from method validateCMPKeyWord()...........");
		  logger.info(buildLogString.toString());
		  
		   return  result;
	}

	/**
	 * @param s
	 *  Valid: 11111111111 111111111 111111111 111111111 6667888855 8989828932 25635265367 627632675362 6872638762873 +88807276372 +88807276372
	 *  Invalid : 11111111111 111111111 111111111 111111111 6667888855 oooiytt yyyyyyyhhh bbbbkjjhttttj nnnnnbb uuuuuuuu ffffffttt bbbbbbbbb jjjjjjjkkkk hhhhhhhhhhh
	 * 
	 * @return true and false
	 */
	public static boolean  isNumericAndSpaceAnsPlus(String s)
	{
	    //String pattern= "+?[0-9 ]+"; //space and digit
		//String pattern= "(\\+?[0-9 ]+)+";  // //space and digit and plus, it was hanging with alphabets, process freez
		String pattern= "(\\+?[0-9\\s*]+)*+";  // Space and digit and plus, No Hang
		
		
	    return s.matches(pattern);
	}

  public static void main(String[] args) {
	  
	  PropertyConfigurator.configure("/sms/SMSPOLLER/log4j_Poller.properties"); 
	  
	  //Load	  
	  showESBMap();	  
	  showCMPMap();
	  
	final SmsPollerService smsPollerService = new SmsPollerService();    
    Runnable runnable = new Runnable()
						    {
						      public void run() 
						      {
						    	  smsPollerService.processValidSmsList();
						      }	
						    };    
    
    ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();    
    service.scheduleAtFixedRate(runnable, 0, Constants.POLLING_INTERVAL, TimeUnit.SECONDS);    
    
  }

}
