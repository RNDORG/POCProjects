package com.wipro.gp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
 
public class ESBPropUtilCache
{  
	private static final Logger logger = Logger.getLogger(com.wipro.gp.util.ESBPropUtilCache.class);
   
   private final Properties configProp = new Properties();   
   public static HashMap<String, HashMap<String, String[]>> esb_ShortCode_SubsMap = new HashMap<String, HashMap<String, String[]>>();   
   
    
   private ESBPropUtilCache()
   {
      //Private constructor to restrict new instances    
	   
      logger.info("Read all properties from file");
      try 
      {
    	  InputStream in = new FileInputStream(Constants.FILE_NAME_ESB);
          configProp.load(in);
      } 
      catch (IOException e) 
      {
    	  logger.error("Error while reading Keyword Config file : " + Constants.FILE_NAME_ESB + e.getMessage());
          e.printStackTrace();
      }
   }
   
   
   
   public static void loadESBFile()
   {
	   
	   HashMap<String, String[]> esb_Subs_ProductMap = null;
	   
	   //All property names
	   Set<String> allKeys = ESBPropUtilCache.getInstance().getAllPropertyNames();
	   String propVal 	   = "";	   
	   
	   for(String key : allKeys) 
	   {   		     
		     propVal   				= ESBPropUtilCache.getInstance().getProperty(key);		 
		     Pattern p 				= Pattern.compile(Constants.REGEX);
		     Pattern p1 			= null; 
		     String[] items 		= p.split(propVal);		
		     String[] productInfo 	= null;
		     int index 				= 0;
		     int size 				= items.length - 3;
		     int indexPro 			= 0;
		     String keyShotCode 	= null;
		     String[] subscriptions = null;
		     
		     for(String str : items) 
		     {	 
		    	 if(index == 0 )
		    	 {  
		    		 keyShotCode = str;
		    		 esb_Subs_ProductMap = new HashMap<String, String[]>();
		    		 productInfo = new String[3];		    		 
		    	 }
		    	 else		    		 
		    	 { 
		    		 if( index < size)
		    		 {
			    		 if(esb_ShortCode_SubsMap.get(keyShotCode) != null)
			    		 {
			    			 esb_Subs_ProductMap = esb_ShortCode_SubsMap.get(keyShotCode);
			    		 }			    		 
			    		 
			    		 logger.info("str :" + str);
			    		 ///// Pipes logic			    		 
			    		 p1 					 = Pattern.compile(Constants.KEY_SEPARATOR);
					     subscriptions  		 = p1.split(str);
					     for(String subscription : subscriptions) 
					     {  
					    	 esb_Subs_ProductMap.put(subscription, productInfo);		    	 
					     }
			    		 
			    		 
			    		 
		    		 }
		    	 }
		    	 
		    	 if(index >= size)
		    	 {
		    		 productInfo[indexPro++] = str;		    		 
		    	 }
		    	 else
		    	 { 
		    		 indexPro = 0;
		    	 }
		    	 
		    	 index++;
		     } // End of innner loop
		   
		     
		     if(esb_ShortCode_SubsMap.get(keyShotCode) == null)
		     {    			 
    			 esb_ShortCode_SubsMap.put(keyShotCode, esb_Subs_ProductMap);    			 
    		 }
		   
	   }
   }
   
   public static HashMap<String, HashMap<String, String[]>> getEPCMap()
   {
	   return esb_ShortCode_SubsMap;
   }
   
   private static class LazyHolder
   {
      private static final ESBPropUtilCache INSTANCE = new ESBPropUtilCache();
   }
 
   public static ESBPropUtilCache getInstance()
   {
      return LazyHolder.INSTANCE;
   }
    
   public String getProperty(String key){
      return configProp.getProperty(key);
   }
    
   public Set<String> getAllPropertyNames(){
      return configProp.stringPropertyNames();
   }
    
   public boolean containsKey(String key){
      return configProp.containsKey(key);
   }
   
   public static void main(String[] args)
   {
	    
	    HashMap<String, String[]> epc_Subs_ProductMap = null;
	   
	   //All property names
	   Set<String> allKeys = ESBPropUtilCache.getInstance().getAllPropertyNames();
	   String propVal 	   = "";
	  // String REGEX 	   = ",";
	   
	   for(String key : allKeys) 
	   {   		     
		     propVal 				= ESBPropUtilCache.getInstance().getProperty(key);
		     Pattern p 				= Pattern.compile(Constants.REGEX);
		     Pattern p1 			= null;
		     String[] items 		= p.split(propVal);		
		     String[] productInfo 	= null;
		     int index 				= 0;
		     int size 				= items.length - 3;
		     int indexPro 			= 0;
		     String keyShotCode 	= null;
		     
		     for(String str : items) 
		     {	 
		    	 if(index == 0 )
		    	 {  
		    		 keyShotCode 		 = str;
		    		 epc_Subs_ProductMap = new HashMap<String, String[]>();
		    		 productInfo 		 = new String[3];		    		 
		    	 }
		    	 else		    		 
		    	 { 
		    		 if(index < size)
		    		 {
			    		 if(esb_ShortCode_SubsMap.get(keyShotCode) != null)
			    		 {
			    			 epc_Subs_ProductMap = esb_ShortCode_SubsMap.get(keyShotCode);
			    		 }	    		 
			    		 
			    		 logger.info("str :" + str);
			    		 ///// Pipes logic			    		 
			    		 p1 					 = Pattern.compile(Constants.KEY_SEPARATOR);
					     String[] subscriptions  = p1.split(str);
					     for(String subscription : subscriptions) 
					     {  
					    	 epc_Subs_ProductMap.put(subscription, productInfo);		    	 
					     }
		    		 }
		    	 }
		    	 
		    	 if(index >= size)
		    	 {
		    		 productInfo[indexPro++] = str;
		    	 }
		    	 else
		    	 { 
		    		 indexPro = 0;
		    	 }
		    	 
		    	 index++;
		     } // End of innner loop
		   
		     
		     if(esb_ShortCode_SubsMap.get(keyShotCode) == null)
		     {    			 
    			 esb_ShortCode_SubsMap.put(keyShotCode, epc_Subs_ProductMap);    			 
    		 }
	   }
	   
	   
	   ///################ Verification Test #####################
	   for(Entry<String, HashMap<String, String[]>> entry : esb_ShortCode_SubsMap.entrySet())
	     {
		   logger.info("entry.getKey() ::: " + entry.getKey());	    	 
	    	 for(Entry<String, String[]> entrySubs : (entry.getValue()).entrySet())
	    	 { 
	    		 logger.info(" ::::" + entrySubs.getKey());
	    		 logger.info("->  " + entrySubs.getValue()[0]);
	    		 logger.info("->  " + entrySubs.getValue()[1]);
	    		 logger.info("->  " + entrySubs.getValue()[2] + "\n");
	    		 
	    	 }
	     }     
   }
}