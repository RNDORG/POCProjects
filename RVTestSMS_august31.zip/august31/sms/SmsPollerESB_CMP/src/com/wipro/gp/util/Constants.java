package com.wipro.gp.util;


public class Constants {
	
	
	//For SIT with SMSC Server
	//public static final String FILE_NAME_ESB	= "/home/oracle/SMPPSIM/Keyword_Configuration_ESB.csv";
	//public static final String FILE_NAME_CMP 	= "/home/oracle/SMPPSIM/Keyword_Configuration_CMP.csv";
	//public static final String POLLER_CONFIG	= "/home/oracle/SMPPSIM/Poller_Config.properties";
	
	//For SIT with Local Simulator
	//public static final String FILE_NAME_ESB	= "/home/oracle/SMPPSIM/Local/Keyword_Configuration_ESB.csv";
	//public static final String FILE_NAME_CMP 	= "/home/oracle/SMPPSIM/Local/Keyword_Configuration_CMP.csv";	
	
	
	
	//Prod
	public static final String FILE_NAME_ESB	= "/sms/SMSPOLLER/Keyword_Configuration_ESB.csv";
	public static final String FILE_NAME_CMP 	= "/sms/SMSPOLLER/Keyword_Configuration_CMP.csv";
	public static final String POLLER_CONFIG	= "/sms/SMSPOLLER/Poller_Config.properties";
	
	
	//For Local
	//public static final String FILE_NAME_ESB	= "d:/home/oracle/SMPPSIM/Keyword_Configuration_ESB.csv";
	//public static final String FILE_NAME_CMP 	= "d:/home/oracle/SMPPSIM/Keyword_Configuratin_CMP.csv";
	
	
	
	
	
	public static final String STATUS_PENDING 		= "PENDING";
	public static final String STATUS_PUBLISED 		= "PUBLISHED";
	public static final String CRM_ESB 				= "CRM-ESB";
	public static final String INVALID 				= "Invalid";
	public static final String INVALID_KEY 			= "Invalid Key";
	public static final String CRM_CMP 				= "CRM-CMP";
	
	public static final String SMS_APP 				= "SMSApp";
	public static final String NOT_FOUND 			= "NOT_FOUND";	
	public static final String SPECIAL_KEY 			= "NULL";
	public static final String TOKEN_KEY 			= " ";
	// TimeUnit in Seconds
	public static final int POLLING_INTERVAL 		= 10;
	public static final	String REGEX 				= ",";
	public static final	String KEY_SEPARATOR		= "\\|";	
	
	// SIT
	public static final	String URL_ESB				= "t3://10.10.23.191:7001";		
	public static final	String ESB_USR				= "sudipta"; 
	public static final	String ESB_PSW				= "sudipta123";

//  Commented : Requested by Abhijit
//	public static final	String URL_CMP				= "t3://10.10.17.87:7001";
//	public static final	String CMP_USR				= "shubhendu"; 
//	public static final	String CMP_PSW				= "shubhendu123";
	
	public static final	String URL_CMP				= "t3://10.10.23.191:7001";
	public static final	String CMP_USR				= "sudipta"; 
	public static final	String CMP_PSW				= "sudipta123";
	
	
	
	// Prod
	//ESB10.21.8.48:8001/10.21.8.48:8003
//	public static final	String URL_ESB				= "t3://10.21.8.48:8001";		
//	public static final	String ESB_USR				= "shubhendu"; 
//	public static final	String ESB_PSW				= "shubhendu123";
//	
//	//CMP
//	public static final	String URL_CMP				= "t3://10.21.8.48:8001";
//	public static final	String CMP_USR				= "shubhendu"; 
//	public static final	String CMP_PSW				= "shubhendu123";
	
	//Aditi 10.21.9.240:8001
	
	public static final String  IGNORE_SHORT_CODE_1  	= "19221";
	public static final String  IGNORE_SHORT_CODE_2  	= "19240";
	public static final String  IGNORE_SHORT_CODE_3  	= "19226";
	public static final String  IGNORE_SHORT_CODE_4  	= "19230";
	public static final String  IGNORE_SHORT_CODE_5  	= "19234";	
	public static final String  STRING_BLANK  			= "";
	public static final String  DATE_FORMAT  			= "yyyy-MM-dd kk:mm:ss:SS";
	public static final String  IGNORE_KW_VALIDATION  	= "IGNORE_KW_VALIDATION";
	
	

}
