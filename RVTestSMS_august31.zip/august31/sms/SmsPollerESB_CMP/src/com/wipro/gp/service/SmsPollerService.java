package com.wipro.gp.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import org.apache.log4j.Logger;

import com.wipro.gp.bean.InValidSms;
import com.wipro.gp.bean.ValidSms;
import com.wipro.gp.controller.Controller;
import com.wipro.gp.dao.SmsPollerDao;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.DateUtil;
import com.wipro.gp.util.JmsCmpQueueSender;

import com.wipro.gp.util.JmsEsbQueueSender;

public class SmsPollerService {
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.service.SmsPollerService.class); 
	 
	 RestClient restClientObj 				= new RestClient();
	 SmsPollerDao smsPollerDao 				= new SmsPollerDao();
	 JmsEsbQueueSender jmsEsbQueueSender	= null;
	 JmsCmpQueueSender jmsCmpQueueSender 	= null;
	 
	 
	 public void processValidSmsList()
	 {
		 logger.info("Entering into processValidSmsList() method");
		 
		 List<ValidSms> processedValidSmsList	 	=  null;
		 List<ValidSms> preProcessedValidSmsList	=  preProcessPendings();
		 int response								= -1;
		 
		 try
		 {			
			if(preProcessedValidSmsList == null || preProcessedValidSmsList.size() == 0 )
			{
				logger.info("No data Found");
			}
			
			long smsId 							= 0;
         	String messageText  				= "";
         	String source 						= "";
         	String shortCode  					= "";
         	String productId					= "";
         	String actionType					= "";
         	StringBuilder msgBuilder 			= null;
         	String esbFormatDate 				= null;
         	processedValidSmsList 				= new ArrayList<ValidSms>();
         	InValidSMSService inValidSMSService = null;
         	InValidSms inValidSms 				= null;
         	
			for(ValidSms preProcessedValidSms : preProcessedValidSmsList)
			{				
				smsId 			= preProcessedValidSms.getSmsId();
				messageText 	= preProcessedValidSms.getSmsText();
				source 			= preProcessedValidSms.getSource_msisdn();
				shortCode 		= preProcessedValidSms.getDest_shortCode();
				productId		= preProcessedValidSms.getProductId();
				actionType		= preProcessedValidSms.getActionType();
				//esbFormatDate	= DateUtil.parseDate(new Date(), "yyyy-MM-dd kk:mm:ss:SS");
				esbFormatDate	= DateUtil.parseDate(new Date(), "yyyy-MM-dd kk:mm:ss.SS");
				logger.info("smsId: " + smsId + ", ShortCode  : " + shortCode +  ",  messageText : " + messageText  +  ", source msisdn : " + source );				
				
				
				preProcessedValidSms.setModifiedDate(esbFormatDate);
				
				msgBuilder = new StringBuilder("<SMSCGatewayRequest>");  
				msgBuilder.append("<orig_txn_ref_id>" + smsId + "</orig_txn_ref_id>");  
				msgBuilder.append("<orig_txn_ref_date>" + esbFormatDate + "</orig_txn_ref_date>");
				msgBuilder.append("<Source_System>SMS</Source_System>");
				msgBuilder.append("<Product_ID>" + productId + "</Product_ID>");
				msgBuilder.append("<SMSText>" + messageText + "</SMSText>");
				msgBuilder.append("<MSISDN>" + source + "</MSISDN>");
				msgBuilder.append("<Action_Type>" + actionType + "</Action_Type>");
				msgBuilder.append("<Port>" + shortCode + "</Port>");
				msgBuilder.append("</SMSCGatewayRequest>");
				
				if((Constants.CRM_ESB).equals(preProcessedValidSms.getTargetApplication()))
				{	
					logger.info("Routed to ESB system.....");					
					preProcessedValidSms.setStatus(Constants.STATUS_PUBLISED);
					//jmsEsbQueueSender = new JmsEsbQueueSender();
					response = JmsEsbQueueSender.sendMessage(msgBuilder.toString());
					logger.info("result from ESB :: " + response);					
				}
				else if((Constants.CRM_CMP).equals(preProcessedValidSms.getTargetApplication()))
				{
					logger.info("Routed to CMP system.....");
					preProcessedValidSms.setStatus(Constants.STATUS_PUBLISED);
					//jmsCmpQueueSender = new JmsCmpQueueSender();
					response = JmsCmpQueueSender.sendMessage(msgBuilder.toString());
					logger.info("result from CMP :: " + response);
				}
				else
				{
					inValidSMSService = new InValidSMSService();
					
					
//					InValidSms(Sv String dest_shortCode,
//							String smsText, String status, String sendingResponse,
//							String productId, String targetApplication, String creationDate,
//							String createdBy, String modifiedDate, String modifiedBy,
//							String extra_field1, String extra_field2, String extra_field3,
//							String extra_field4, String extra_field5) 
							
							
					inValidSms = new InValidSms(source, shortCode, messageText, Constants.STATUS_PENDING, Constants.STATUS_PENDING,
							productId,null, esbFormatDate, Constants.SMS_APP, null, null, null, null, null,null,
							null);
					
					preProcessedValidSms.setStatus(Constants.INVALID);
					response = 2;
					logger.info("Keyword not found neither in EPC/ESB nor in CMP file.");
					
				}
						
				logger.info("Message for ESB/CMP ::: " + msgBuilder.toString());			
				logger.info("smsId " + smsId + " messageText " + messageText + " source " + source + " destination " + shortCode + " product Id " + productId + " Action Type " + actionType);
				
				if(response == 0 || response == 2)
				{	
					logger.info("Additing into list  for  update and smsId is  :: " + smsId);															
					preProcessedValidSms.setModifiedDate(esbFormatDate);
					preProcessedValidSms.setModifiedBy(Constants.SMS_APP);
					processedValidSmsList.add(preProcessedValidSms);
					
					
				}
			}
			
			if(processedValidSmsList == null || processedValidSmsList.size() == 0 )
			{
				logger.info("No data Found for update");
			}
			else
			{
				
				smsPollerDao.updatePendingList(processedValidSmsList);
				
				if(response == 2)
				{
					inValidSMSService.saveMessage(inValidSms);
				}
				
				
			}
			
			logger.info("END: #############------------ smsId: " + smsId + ", ShortCode  : " + shortCode +  ",  messageText : " + messageText  +  ", source msisdn : " + source  + "\n\n\n");
		}  
		catch(Exception e)
		{
		   logger.error("Exception in com.wipro.gp.service.SmsPollerService.class " + e.getMessage() );
		   
		}
		 
		logger.info("Exiting from processValidSmsList() method");
 }
	 
	 
	 public List<ValidSms> preProcessPendings()
	 {		 
		 logger.info("Entering into preProcessPendings() method");
		 
		 List<ValidSms> validSmsList 				= smsPollerDao.getcurrentPendingList();
		 List<ValidSms> preProcessedValidSmsList 	= null;
		 	
			long smsId 					= 0;
         	String messageText  		= "";
         	String source 				= "";         	
         	String res[] 				= null;
         	String shortCode  			= "";
         	preProcessedValidSmsList 	= new ArrayList<ValidSms>();
         	/** Product ID/Service ID */         	
         	String 	pr_sr_id			= "";         	
         	/** Subscription/Unsubscription */         	
         	String 	action_type			= "";
         	
			for(ValidSms validSms : validSmsList)
			{				
				smsId 		= validSms.getSmsId();
				messageText = validSms.getSmsText();
				source 		= validSms.getSource_msisdn();
				shortCode 	= validSms.getDest_shortCode();
				logger.info("smsId: " + smsId + ", ShortCode  : " + shortCode +  ",  messageText : " + messageText  +  ", source msisdn : " + source );
				
				// Validation against EPC/ESB file
				res 		= Controller.validateESBKeyWord(shortCode, messageText);
				pr_sr_id 	= res[0];
				action_type = res[1]; 
				
				if((Constants.NOT_FOUND).equals(pr_sr_id))
				{	
					res 		= Controller.validateESBKeyWordSpecialCase(shortCode, messageText);
					pr_sr_id 	= res[0];
					action_type = res[1];
					
					if((Constants.NOT_FOUND).equals(pr_sr_id))
					{					
						res = Controller.validateCMPKeyWord(shortCode, messageText);
						pr_sr_id 	= res[0];
						action_type = res[1];
						
						if((Constants.NOT_FOUND).equals(pr_sr_id))
						{							
							validSms.setTargetApplication(Constants.INVALID_KEY);
						}
						else
						{
							validSms.setTargetApplication(Constants.CRM_CMP);
						}
					}
					else
					{
						validSms.setTargetApplication(Constants.CRM_ESB);
					}
				}
				else
				{
					validSms.setTargetApplication(Constants.CRM_ESB);
				}
								
				logger.info("smsId " + smsId + " messageText " + messageText + " source " + source + " destination " + shortCode + " Product Id/ Service Id" + pr_sr_id + " Action Type " + action_type);
				
				validSms.setProductId(pr_sr_id);
				validSms.setActionType(action_type);					
				preProcessedValidSmsList.add(validSms);
				
			}
			
			logger.info("END: #############------------ smsId: " + smsId + ", ShortCode  : " + shortCode +  ",  messageText : " + messageText  +  ", source msisdn : " + source  + "\n\n\n");
		
			logger.info("Exting from preProcessPendings() method");
			
			return preProcessedValidSmsList;
	 
	 }  	 
}

