package com.wipro.gp.util;


import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

public class JmsCmpQueueSender implements JmsESBCMPInterface {
	private static final Logger logger = Logger.getLogger(com.wipro.gp.util.JmsEsbQueueSender.class);	
   private static InitialContext ctx;
   private static QueueConnectionFactory qcf;
   private static QueueConnection qc = null;
   private static QueueSession qsess = null;
   private static Queue q = null;
   private static QueueSender qsndr = null;
   private static TextMessage message = null;
   // NOTE: The next two lines set the name of the Queue Connection Factory
   //       and the Queue that we want to use.
   //private static final String QCF_NAME   = "MyanmarESBFactory";
   //private static final String QUEUE_NAME = "SMSCGatewayCampaignQueue";
   
   private static final String QCF_NAME   = PropUtil.getInstance().getProperty("CMP_QCF_NAME");
   private static final String QUEUE_NAME = PropUtil.getInstance().getProperty("CMP_QUEUE_NAME");
   
   public JmsCmpQueueSender() 
   {
       super();
   }
   
   public static int  sendMessage(String messageText) 
   {
	   
	   int result = -1;
       // create InitialContext
       Hashtable properties = new Hashtable();
       properties.put(Context.INITIAL_CONTEXT_FACTORY,
                      "weblogic.jndi.WLInitialContextFactory");
       // NOTE: The port number of the server is provided in the next line,
       //       followed by the userid and password on the next two lines.
       
       String queueUrl  = "t3://" + PropUtil.getInstance().getProperty("CMP_IP") + ":" + PropUtil.getInstance().getProperty("CMP_PORT");
	   String usr  		= PropUtil.getInstance().getProperty("CMP_ESB_USR");
	   String passw     = PropUtil.getInstance().getProperty("CMP_ESB_PSW");
       
       
       properties.put(Context.PROVIDER_URL, queueUrl);
       properties.put(Context.SECURITY_PRINCIPAL, usr);
       properties.put(Context.SECURITY_CREDENTIALS, passw);
       
       
       try 
       {
           ctx = new InitialContext(properties);
       } 
       catch (NamingException ne) 
       {
           logger.error("URL naming error : " + ne.getMessage());
    	   ne.printStackTrace(System.err);
           System.exit(0);
       }
       logger.info("Got InitialContext " + ctx.toString());
       // create QueueConnectionFactory
       try 
       {
           qcf = (QueueConnectionFactory)ctx.lookup(QCF_NAME);
       }
       catch
       (NamingException ne) 
       {
    	   logger.error("URL naming error : " + ne.getMessage());
    	   ne.printStackTrace(System.err);
           System.exit(0);
       }
       
       logger.info("Got QueueConnectionFactory " + qcf.toString());
       // create QueueConnection
       try {
           qc = qcf.createQueueConnection();
       }
       catch (JMSException jmse) 
       {
    	   logger.error("Java Messaging Service Exception 1 : " + jmse.getMessage());
    	   jmse.printStackTrace(System.err);
           System.exit(0);
       }
       logger.info("Got QueueConnection " + qc.toString());
       
       // create QueueSession
       try
       {
           qsess = qc.createQueueSession(false, 0);
           //qsess = qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
       }
       catch (JMSException jmse) 
       {
    	   logger.error("Java Messaging Service Exception 2 : " + jmse.getMessage());
    	   jmse.printStackTrace(System.err);
           System.exit(0);
       }
       logger.info("Got QueueSession " + qsess.toString());
       // lookup Queue
       try
       {
           q = (Queue) ctx.lookup(QUEUE_NAME);
       }
       catch (NamingException ne) 
       {
    	   logger.error("Queue name error : " + ne.getMessage());
    	   ne.printStackTrace(System.err);
           System.exit(0);
       }
       System.out.println("Got Queue " + q.toString());
       
       // create QueueSender
       try 
       {
           qsndr = qsess.createSender(q);
       }
       catch (JMSException jmse) 
       {
    	   logger.error("Java Messaging Service Exception 3 : " + jmse.getMessage());
    	   jmse.printStackTrace(System.err);
           System.exit(0);
       }
       logger.info("Got QueueSender " + qsndr.toString());
       // create TextMessage
       try
       {
           message = qsess.createTextMessage();
       }
       catch (JMSException jmse) 
       {
    	   logger.error("Java Messaging Service Exception 4 : " + jmse.getMessage());
    	   jmse.printStackTrace(System.err);
           System.exit(0);
       }
       logger.info("Got TextMessage " + message.toString());
       // set message text in TextMessage
       try 
       {
           message.setText(messageText);
       }
       catch (JMSException jmse) 
       {
    	   logger.error("Java Messaging Service Exception 5 : " + jmse.getMessage());
    	   jmse.printStackTrace(System.err);
           System.exit(0);
       }
       logger.info("Set text in TextMessage " + message.toString());
       // send message
       try 
       {
           qsndr.send(message);
           result = 0;
       }
       catch (JMSException jmse)
       {
    	   logger.error("Java Messaging Service Exception 6 : " + jmse.getMessage());
    	   jmse.printStackTrace(System.err);
           System.exit(0);
       }
       logger.info("Sent message ");
       // clean up
       try
       {
           message = null;
           qsndr.close();
           qsndr = null;
           q = null;
           qsess.close();
           qsess = null;
           qc.close();
           qc = null;
           qcf = null;
           ctx = null;
       }
       catch (JMSException jmse) 
       {
    	   logger.error("Java Messaging Service Exception 7 : " + jmse.getMessage());
    	   jmse.printStackTrace(System.err);
       }
       
       logger.info("Cleaned up and done.");
       
       return result;
       
   }
   
   public static void main(String args[]) 
   {
       sendMessage("test");
   }
}