package com.wipro.gp.util;


import java.util.Date;
import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
//import javax.naming.*;
//import javax.jms.*;

import org.apache.log4j.Logger;

public class JmsEsbQueueSender implements JmsESBCMPInterface 
{
   private static final Logger logger = Logger.getLogger(com.wipro.gp.util.JmsEsbQueueSender.class);
   
   private static InitialContext ctx;
   private static QueueConnectionFactory qcf;
   private static QueueConnection qc;
   private static QueueSession qsess;
   private static Queue q;
   private static QueueSender qsndr;
   private static TextMessage message;
   // NOTE: The next two lines set the name of the Queue Connection Factory
   //       and the Queue that we want to use.
//   private static final String QCF_NAME = "jms/MyanmarESBFactory";
//   private static final String QUEUE_NAME = "jms/SMSCGatewayQueue";
   
   private static final String QCF_NAME   = PropUtil.getInstance().getProperty("QCF_NAME");
   private static final String QUEUE_NAME = PropUtil.getInstance().getProperty("QUEUE_NAME");
   
   public JmsEsbQueueSender() 
   {
       super();
   }
   
   public static int   sendMessage(String messageText) 
   {
	   
	   int result = -1;
	   //t3://10.10.23.191:7001
	   String queueUrl  = "t3://" + PropUtil.getInstance().getProperty("IP") + ":" + PropUtil.getInstance().getProperty("PORT");
	   String usr  		= PropUtil.getInstance().getProperty("ESB_USR");
	   String passw     = PropUtil.getInstance().getProperty("ESB_PSW");
	   
       // create InitialContext
       Hashtable env = new Hashtable();
       env.put(Context.INITIAL_CONTEXT_FACTORY,
                      "weblogic.jndi.WLInitialContextFactory");
       // NOTE: The port number of the server is provided in the next line,
       //       followed by the userid and password on the next two lines.
       env.put(Context.PROVIDER_URL, queueUrl);
       env.put(Context.SECURITY_PRINCIPAL, usr);
       env.put(Context.SECURITY_CREDENTIALS, passw);
       
       try
       {
           ctx 		= new InitialContext(env);
           qcf 		= (QueueConnectionFactory)ctx.lookup(QCF_NAME);
           qc 		= qcf.createQueueConnection();
           qsess 	= qc.createQueueSession(false, 0);
           //qsess = qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
           q 		= (Queue) ctx.lookup(QUEUE_NAME);
           qsndr 	= qsess.createSender(q);
           message 	= qsess.createTextMessage();
           message.setText(messageText);
           qsndr.send(message);
           result = 0;
       }
       catch (Exception ex) 
       {
    	   logger.error("Error connecting to queue " + ex.getMessage());    	   
       }
       
       // clean up
       try 
       {
           message = null;
           qsndr.close();
           qsndr = null;
           q = null;
           qsess.close();
           qsess = null;
           qc.close();
           qc = null;
           qcf = null;
           ctx = null;
       }
       catch (JMSException jmse) 
       {
    	   logger.error("Java Messaging Service Exception 1 : " + jmse.getMessage());
    	   jmse.printStackTrace(System.err);
       }
       
       logger.info("Cleaned up and done.");
       
       return result;       
   }
   
   public static void main(String args[]) 
   {
       
	   //JmsEsbQueueSender jmsEsbQueueSender = new JmsEsbQueueSender();
	   //jmsEsbQueueSender.sendMessage("test");
   }
}