package com.wipro.gp.service;

import java.util.Date;

import org.apache.log4j.Logger;

import com.wipro.gp.bean.InValidSms;
import com.wipro.gp.dao.InValidSMSDao;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.DateUtil;

public class InValidSMSService {
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.service.InValidSMSService.class);
	
	InValidSMSDao inValidSMSDao = new InValidSMSDao(); 
	
	
	public void saveMessage(InValidSms pInValidSms)	
	{	
		logger.info("Entering into receiveMessag method.");		
		
		Date currDate 		 	= new Date();
		String creationDate 	= DateUtil.parseDate(currDate, "yyyy-MM-dd HH:mm:ss");		
		boolean isValidSms 		= false;
		
		pInValidSms.setCreationDate(creationDate);				
		inValidSMSDao.saveMessage(pInValidSms);
		
		logger.info("Exiting from  insert...");
		
	}
	
	public static void main(String args[])
	{
		InValidSMSService inValidSMSService = new InValidSMSService();
		
//		InValidSms inValidSms = new InValidSms("9999359786", "1900", "SUBS 2 GB", Constants.INVALID, null,
//				Constants.INVALID_KEY, new Date().toString(), Constants.SMS_APP,
//				null, null, null,
//				null, null, null,
//				null); 
	//	inValidSMSService.saveMessage(inValidSms);
	}
	
}
