package com.wipro.gp.service;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;

import com.wipro.gp.bean.ValidSms;

public class RestClient {

	private static final Logger logger = Logger.getLogger(com.wipro.gp.service.RestClient.class);
      // http://localhost:8080/RESTfulExample/json/product/get
      public long  restApiCall(String messageText,String source,String destination, long smsId) {
    	  

//    	  ASF BasicDBObject publishDocument = new BasicDBObject();
//    	  BasicDBObject searchQuery;
    	  
    	  long result = 0L;
    	  
            try {

            
            	String restUrl = "http://10.10.23.191:7001/MyanmarMFSTriumph/ProxyServices/MFSWalletRegistration/1.0/ReceiveSMSAsyncPS?" +
            			"senderMSISDN="+source+
            			"&textMessage="+messageText +
            			"&shortCode="+destination +
            			"&txnID=ab4484P" +
            			"&sourceSystem=SMS";
            	
                  URL url = new URL(restUrl);
                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                  
                  conn.setDoOutput(true);
                  
                  conn.setRequestMethod("GET");
                  //conn.setRequestProperty("Accept", "application/json");
                  conn.setRequestProperty("Accept", "application/xml");

             //     System.out.println("conn.getResponseCode() " + conn.getResponseCode());
                  if (conn.getResponseCode() != 200) {
                        //throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
                	  logger.info("Failed : HTTP error code : " + conn.getResponseCode());
                	  // :TODO log                	  
                  }
                  else if (conn.getResponseCode() == 200)
                  {
                	  result = smsId;
                  }

                  //BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                  
                  

                  
                  

                  // String output;
                  //System.out.println("Output from Server .... \n");
                /*  while ((output = br.readLine()) != null) {

                        System.out.println(output.toString());
                  }
                 */ 
                  conn.disconnect();

            } catch (MalformedURLException e) {
            	logger.error("Malformed URL error : " + e.getMessage());  
            	e.printStackTrace();
            } catch (IOException e) {
            	logger.error("IO Exception : " + e.getMessage());	
                e.printStackTrace();
                  
            }
            
            return result;

      }

}
