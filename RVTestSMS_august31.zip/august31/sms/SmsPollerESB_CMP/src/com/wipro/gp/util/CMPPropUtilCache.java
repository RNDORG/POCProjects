package com.wipro.gp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
 
public class CMPPropUtilCache
{
  
   private static final Logger logger = Logger.getLogger(com.wipro.gp.util.CMPPropUtilCache.class);
   
   private final Properties configProp = new Properties();   
   public static HashMap<String, HashMap<String, String[]>> cmp_ShortCode_SubsMap = new HashMap<String, HashMap<String, String[]>>();   
   
    
   private CMPPropUtilCache()
   {
      //Private constructor to restrict new instances    
	   
      logger.info("Read all properties from CMP file");
      try 
      {
    	  InputStream in = new FileInputStream(Constants.FILE_NAME_CMP);
          configProp.load(in);
      } 
      catch (IOException e) 
      {
    	  logger.error("Error while reading Keyword Config file : " + Constants.FILE_NAME_CMP + e.getMessage());
          e.printStackTrace();
      }
   }
   
   
   
   public static void loadCMPFile()
   {
	   
	   HashMap<String, String[]> cmp_Subs_ProductMap = null;
	   
	   //All property names
	   Set<String> allKeys = CMPPropUtilCache.getInstance().getAllPropertyNames();
	   String propVal 	   = "";	   
	   
	   for(String key : allKeys) 
	   {   		     
		     propVal   				= CMPPropUtilCache.getInstance().getProperty(key);		 
		     Pattern p 				= Pattern.compile(Constants.REGEX);
		     Pattern p1 			= null; 
		     String[] items 		= p.split(propVal);		
		     String[] productInfo 	= null;
		     int index 				= 0;
		     int size 				= items.length - 2;
		     int indexPro 			= 0;
		     String keyShotCode 	= null;
		     String[] subscriptions = null;
		     
		     for(String str : items) 
		     {	 
		    	 if(index == 0 )
		    	 {  
		    		 keyShotCode 		 = str;
		    		 cmp_Subs_ProductMap = new HashMap<String, String[]>();
		    		 productInfo 		 = new String[2];		    		 
		    	 }
		    	 else		    		 
		    	 { 
		    		 if( index < size)
		    		 {
			    		 if(cmp_ShortCode_SubsMap.get(keyShotCode) != null)
			    		 {
			    			 cmp_Subs_ProductMap = cmp_ShortCode_SubsMap.get(keyShotCode);
			    		 }
			    		 
			    		 logger.info("str :" + str);
			    		 ///// Pipes logic			    		 
			    		 p1 					 = Pattern.compile(Constants.KEY_SEPARATOR);
					     subscriptions  		 = p1.split(str);
					     for(String subscription : subscriptions) 
					     {  
					    	 cmp_Subs_ProductMap.put(subscription, productInfo);		    	 
					     }
			    		 
			    		 
			    		 
		    		 }
		    	 }
		    	 
		    	 if(index >= size)
		    	 {
		    		 productInfo[indexPro++] = str;		    		 
		    	 }
		    	 else
		    	 { 
		    		 indexPro = 0;
		    	 }
		    	 
		    	 index++;
		     } // End of innner loop
		   
		     
		     if(cmp_ShortCode_SubsMap.get(keyShotCode) == null)
		     {    			 
		    	 cmp_ShortCode_SubsMap.put(keyShotCode, cmp_Subs_ProductMap);    			 
    		 }
		   
	   }
   }
   
   public static HashMap<String, HashMap<String, String[]>> getCMPMap()
   {
	   return cmp_ShortCode_SubsMap;
   }
   
   private static class LazyHolder
   {
      private static final CMPPropUtilCache INSTANCE = new CMPPropUtilCache();
   }
 
   public static CMPPropUtilCache getInstance()
   {
      return LazyHolder.INSTANCE;
   }
    
   public String getProperty(String key){
      return configProp.getProperty(key);
   }
    
   public Set<String> getAllPropertyNames(){
      return configProp.stringPropertyNames();
   }
    
   public boolean containsKey(String key){
      return configProp.containsKey(key);
   }
   
   public static void main(String[] args)
   {
	    
	    HashMap<String, String[]> cmp_Subs_ProductMap = null;
	   
	   //All property names
	   Set<String> allKeys = CMPPropUtilCache.getInstance().getAllPropertyNames();
	   String propVal 	   = "";
	  // String REGEX 	   = ",";
	   
	   for(String key : allKeys) 
	   {   		     
		     propVal 				= CMPPropUtilCache.getInstance().getProperty(key);
		     Pattern p 				= Pattern.compile(Constants.REGEX);
		     Pattern p1 			= null;
		     String[] items 		= p.split(propVal);		
		     String[] productInfo 	= null;
		     int index 				= 0;
		     int size 				= items.length - 2;
		     int indexPro 			= 0;
		     String keyShotCode 	= null;
		     
		     for(String str : items) 
		     {	 
		    	 if(index == 0 )
		    	 {  
		    		 keyShotCode 		 = str;
		    		 cmp_Subs_ProductMap = new HashMap<String, String[]>();
		    		 productInfo 		 = new String[2];		    		 
		    	 }
		    	 else		    		 
		    	 { 
		    		 if(index < size)
		    		 {
			    		 if(cmp_ShortCode_SubsMap.get(keyShotCode) != null)
			    		 {
			    			 cmp_Subs_ProductMap = cmp_ShortCode_SubsMap.get(keyShotCode);
			    		 }	    		 
			    		 
			    		 logger.info("str :" + str);
			    		 ///// Pipes logic			    		 
			    		 p1 					 = Pattern.compile(Constants.KEY_SEPARATOR);
					     String[] subscriptions  = p1.split(str);
					     for(String subscription : subscriptions) 
					     {  
					    	 cmp_Subs_ProductMap.put(subscription, productInfo);		    	 
					     }
		    		 }
		    	 }
		    	 
		    	 if(index >= size)
		    	 {
		    		 productInfo[indexPro++] = str;
		    	 }
		    	 else
		    	 { 
		    		 indexPro = 0;
		    	 }
		    	 
		    	 index++;
		     } // End of innner loop
		   
		     
		     if(cmp_ShortCode_SubsMap.get(keyShotCode) == null)
		     {    			 
		    	 cmp_ShortCode_SubsMap.put(keyShotCode, cmp_Subs_ProductMap);    			 
    		 }
	   }
	   
	   
	   ///################ Verification Test #####################
	   for(Entry<String, HashMap<String, String[]>> entry : cmp_ShortCode_SubsMap.entrySet())
	     {
	    	 logger.info("entry.getKey() ::: " + entry.getKey());	    	 
	    	 for(Entry<String, String[]> entrySubs : (entry.getValue()).entrySet())
	    	 { 
	    		 logger.info(" ::::" + entrySubs.getKey());
	    		 logger.info("->  " + entrySubs.getValue()[0]);
	    		 logger.info("->  " + entrySubs.getValue()[1] + "\n");
	    		 
	    	 }
	     }     
   }
}