package com.wipro.gp.util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;


public class HibernateUtil 
{

	private static ServiceRegistryBuilder serviceRegistryBuilder; 
	private static SessionFactory sessionFactory = null;
	
	
	public static SessionFactory getSessionFactory() 
	{
	     if(sessionFactory == null){
	          createSessionFactory();
	      }
	      return sessionFactory;
	}
	
	
	private synchronized static void createSessionFactory()
	{
	    if(sessionFactory != null){return;}
	    Configuration configuration = new Configuration();
	    configuration.configure().addProperties(getConnectionProperties());   
	    serviceRegistryBuilder = new ServiceRegistryBuilder();
	    serviceRegistryBuilder.applySettings(configuration.getProperties());
	    ServiceRegistry serviceRegistry = serviceRegistryBuilder.buildServiceRegistry();
	    sessionFactory = configuration.buildSessionFactory(serviceRegistry);
	    
	 }  
	
	private static Properties getConnectionProperties() {
		 Properties connectionProps = new Properties();
		  connectionProps.put("hibernate.connection.url", getConnectionUrl()); 
		  connectionProps.put("hibernate.connection.username", getUserName());
		  connectionProps.put("hibernate.connection.password", getPassword());
		  return connectionProps;
	}


	private static String getConnectionUrl() {
		String URL   = PropUtil.getInstance().getProperty("DB_CONNECTIONURL");
		return URL;
	}
	
	private static String getUserName() {
		String Username   = PropUtil.getInstance().getProperty("DB_USERNAME");
		return Username;
	}
	
	private static String getPassword() {
		String Password   = PropUtil.getInstance().getProperty("DB_PASSWORD");
		return Password;
	}

}

