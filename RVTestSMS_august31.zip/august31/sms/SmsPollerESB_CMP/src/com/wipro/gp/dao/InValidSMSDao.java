package com.wipro.gp.dao;

import java.io.Serializable;
import java.util.Date;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.wipro.gp.bean.InValidSms;
import com.wipro.gp.bean.ValidSms;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.HibernateUtil;

public class InValidSMSDao {
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.dao.InValidSMSDao.class);
	
	public void saveMessage(InValidSms pInValidSms)
	{	
		logger.info("Entering into saveMessage...");
		
		SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();		
					
		if(sessionFactory == null)
		{			
			logger.info("SESSION IS NULL...");
		}
		
		// opens a new session from the session factory
		Session session = sessionFactory.openSession();		
		session.beginTransaction();
		
		Serializable id = session.save(pInValidSms);
		logger.info("created id for invalid sms: " + id);
				
		
		logger.info("Exiting from  saveMessage...");
		// commits the transaction and closes the session
		session.getTransaction().commit();
		session.close();
		
	}
	
	public static void main(String args[])
	{	
		InValidSMSDao inValidSMSDao = new InValidSMSDao();
		
//		InValidSms inValidSms = new InValidSms("9999359786", "1900", "SUBS 1 GB", Constants.INVALID, null,
//								Constants.INVALID_KEY, new Date().toString(), Constants.SMS_APP,
//								null, null, null,
//								null, null, null,
//								null); 
		
		//inValidSMSDao.saveMessage(inValidSms);
	}
	
}
