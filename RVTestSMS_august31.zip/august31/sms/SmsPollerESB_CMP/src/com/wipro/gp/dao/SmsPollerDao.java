package com.wipro.gp.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.wipro.gp.bean.ValidSms;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.HibernateUtil;

public class SmsPollerDao 
{
	private static final Logger logger = Logger.getLogger(com.wipro.gp.dao.SmsPollerDao.class); 
	RestClient restClientObj = new RestClient();
	 
	
	 public  List<ValidSms>  getcurrentPendingList()
	 {
		logger.info("Entering into getcurrentPendingList( )");
		 
		SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();
		logger.info("Connect to database successfully");			 
						
		// opens a new session from the session factory
		Session session = sessionFactory.openSession();				
		Transaction tx  =  session.beginTransaction();
		List<ValidSms> validSmslist = null;
				
		try
		{
			Criteria criteria = session.createCriteria(ValidSms.class);
			criteria.add(Restrictions.eq("status", Constants.STATUS_PENDING));
			criteria.setMaxResults(1200);
			validSmslist = criteria.list();
		
		}  
		catch(Exception e)
		{
			logger.error("Exception in fetching records from ValidSMS Table for Pending records" + e.getMessage());
		    tx.rollback();
		}
		 finally
		 {
			 tx.commit();
			 session.flush();
			 session.close();
		 }
		  
		logger.info("Exting from  getcurrentPendingList()");
				
		return validSmslist;
	 }
	 
	 
	 public void updatePendingList(List<ValidSms> validSmsList)
	 {
		 logger.info("Entering into updatePendingList() method");
		
		 SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();
		 logger.info("Connect to database successfully");		 				 
					
		 // opens a new session from the session factory
		Session session = sessionFactory.openSession();		
		Transaction tx  = null;		
		try
		{	
			for(ValidSms validSms : validSmsList)
			{	
				tx = session.beginTransaction();
				session.update(validSms);				
				tx.commit();				
			}
			
			session.flush();
			
		}  
		catch(Exception e)
		{
		   logger.error("Exception in updatePendingList()" + e.getMessage() );
		   tx.rollback();
		}
		finally
		{
			 session.close();
		}
			
		logger.info("Exiting from updatePendingList() method");
	 }	 	 
}

