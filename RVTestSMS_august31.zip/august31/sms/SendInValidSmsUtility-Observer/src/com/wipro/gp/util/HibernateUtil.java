package com.wipro.gp.util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateUtil 
{

	private static ServiceRegistryBuilder serviceRegistryBuilder; 
	private static SessionFactory sessionFactory;
	private static SessionFactory sessionFactoryWrite;
	
	
	public static SessionFactory getSessionFactory() 
	{
	     if(sessionFactory == null){
	          createSessionFactory();
	      }
	      return sessionFactory;
	}
	
	
	public static SessionFactory getSessionFactoryWrite() 
	{
	     if(sessionFactoryWrite == null)
	     {
	          createSessionFactoryWrite();
	      }
	     
	      return sessionFactoryWrite;
	}
	
	
	private synchronized static void createSessionFactory()
	{
	    if(sessionFactory != null){return;}
	    Configuration configuration = new Configuration();
	    configuration.configure("hibernate.cfg.xml").addProperties(getConnectionProperties());    
	    serviceRegistryBuilder = new ServiceRegistryBuilder();
	    serviceRegistryBuilder.applySettings(configuration.getProperties());
	    ServiceRegistry serviceRegistry = serviceRegistryBuilder.buildServiceRegistry();
	    sessionFactory = configuration.buildSessionFactory(serviceRegistry);
	    
	 }
	
	private static Properties getConnectionProperties() {
		Properties connectionProps = new Properties();
		  connectionProps.put("hibernate.connection.url", getConnectionUrl()); 
		  connectionProps.put("hibernate.connection.username", getUserName());
		  connectionProps.put("hibernate.connection.password", getPassword());
		  return connectionProps;
	}


	private static String getPassword() {
		String Password   = PropUtil.getInstance().getProperty("DB_PASSWORD");
		return Password;
	}


	private static Object getUserName() {
		String Username   = PropUtil.getInstance().getProperty("DB_USERNAME");
		return Username;
	}


	private static Object getConnectionUrl() {
		String URL   = PropUtil.getInstance().getProperty("DB_CONNECTIONURL");
		return URL;
	}
	
	
	
	private synchronized static void createSessionFactoryWrite()
	{
	    if(sessionFactoryWrite != null){return;}
	    Configuration configuration = new Configuration();
	    configuration.configure("hibernatewrite.cfg.xml").addProperties(getConnectionPropertieswrite());    
	    serviceRegistryBuilder = new ServiceRegistryBuilder();
	    serviceRegistryBuilder.applySettings(configuration.getProperties());
	    ServiceRegistry serviceRegistry = serviceRegistryBuilder.buildServiceRegistry();
	    sessionFactoryWrite = configuration.buildSessionFactory(serviceRegistry);
	    
	 }  
	
	private static Properties getConnectionPropertieswrite() {
		Properties connectionProps = new Properties();
		connectionProps.put("hibernate.connection.url", getConnectionUrlwrite()); 
		connectionProps.put("hibernate.connection.username", getUserNamewrite());
		connectionProps.put("hibernate.connection.password", getPasswordwrite());
		
		return connectionProps;
	}


	private static String getConnectionUrlwrite() {
		String URL   = PropUtil.getInstance().getProperty("DB_CONNECTIONURL_WRITE");
		return URL;
	}
	
	private static String getUserNamewrite() {
		String Username   = PropUtil.getInstance().getProperty("DB_USERNAME_WRITE");
		return Username;
	}
	
	private static String getPasswordwrite() {
		String Password   = PropUtil.getInstance().getProperty("DB_PASSWORD_WRITE");
		
		return Password;
	}

}

