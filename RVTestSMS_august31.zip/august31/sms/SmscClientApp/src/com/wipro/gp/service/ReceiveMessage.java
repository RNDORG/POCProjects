package com.wipro.gp.service;

import ie.omk.smpp.Connection;
import ie.omk.smpp.event.ConnectionObserver;
import ie.omk.smpp.event.ReceiverExitEvent;
import ie.omk.smpp.event.SMPPEvent;
import ie.omk.smpp.message.DeliverSM;
import ie.omk.smpp.message.SMPPPacket;
import ie.omk.smpp.message.Unbind;
import ie.omk.smpp.message.UnbindResp;
import ie.omk.smpp.util.DefaultAlphabetEncoding;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.Date;

import org.apache.log4j.Logger;


public class ReceiveMessage implements ConnectionObserver{
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.service.ReceiveMessage.class);
	
	DefaultAlphabetEncoding  encoding;
	byte[] msgInByte;		
	

	private static int msgCount = 0;

    // Start time (once successfully bound).
    private long start = 0;

    // End time (either send an unbind or an unbind received).
    private long end = 0;

    // Set to true to display each message received.
    private boolean showMsgs = true;    
    private boolean longMessagePart;
    private String source;
    private String destination;
    private int  longMsgcounter;
    
    final static int UDGLENGTH = 6;
    byte[] UDH;	
    
    
    

    // Object for DbInsert Class.
    private ReceiveMessageService receiveMessageService= new ReceiveMessageService(); 

    
    // This is called when the connection receives a packet from the SMSC.
    public void update(Connection r, SMPPEvent ev) {
        switch (ev.getType()) {
        case SMPPEvent.RECEIVER_EXIT:
            receiverExit(r, (ReceiverExitEvent) ev);
            break;
        }
    }

    public void packetReceived(Connection myConnection, SMPPPacket pak) 
    {    	
        switch (pak.getCommandId()) 
	    {
	        // Bind transmitter response. Check it's status for success...
	        case SMPPPacket.BIND_RECEIVER_RESP:
	            if (pak.getCommandStatus() != 0) 
	            {
	                logger.info("Error binding to the SMSC. Error = "+ pak.getCommandStatus());
	            }
	            else 
	            {
	                this.start = System.currentTimeMillis();
	                logger.info("Successfully bound. Waiting for message this is Receive Message delivery..");
	            }
	            break;
	        // Submit message response...
	        case SMPPPacket.DELIVER_SM:
	            if (pak.getCommandStatus() != 0) 
	            {
	            	logger.info("Deliver SM with an error! "  + pak.getCommandStatus());
	
	            } 
	            else 
	            {
	                ++msgCount;
	                if (showMsgs)
	                {
	                	logger.info("New Message Received...");
	                	try
	                	{
		                	logger.info(Integer.toString(pak.getSequenceNum())
		                            + ": \"" + ((DeliverSM) pak).getMessageText()
		                            + "\""+" Destination is " +pak.getDestination().getAddress()
		                            + "\""+" Source  is " +pak.getSource().getAddress());
		                	
		                	longMessagePart = false;
		                    
		                    
		                	logger.info("pak.getEsmClass() : " + pak.getEsmClass());		                	
		                	
		                	longMessagePart = (0x40 == (pak.getEsmClass() & 0x40));
		                	
		                	source = pak.getSource().getAddress();
		                    destination = pak.getDestination().getAddress();
		                    logger.info("Before save");
		                	
		                	if(!longMessagePart)
		                	{
		                		// String messageText = ((DeliverSM) pak).getMessageText();
			                     byte[] bytes =((DeliverSM) pak).getMessage();
			                     String messageText = new String(bytes);		                    
			                    receiveMessageService.receiveMessage(messageText, source, destination, true);
			                    logger.info("Successfully  Saved Valid SMS.");
		                	}		                	
		                	//else if((longMessagePart && (++longMsgcounter == 2) /*2nd Part*/))
		                	else if(longMessagePart)
		                	{	
		                	    logger.info("Long SMS received and going to identify last part");
		                		
		                		encoding  	= new DefaultAlphabetEncoding();
		                    	msgInByte  	=  encoding.encodeString(((DeliverSM) pak).getMessageText());		                    	    	
		                    	UDH			= new byte[UDGLENGTH];		                    	
		                    	//UDH-1
		                    	System.arraycopy(msgInByte, 0, UDH, 0, UDGLENGTH);
		                    	
		                    	String udhMessage = new String(UDH);
		                    	String udh 		  = toHex(udhMessage);
		                    	logger.info("UDH : " + udh);
		                    	
		                    	int  currentPart = Integer.parseInt(udh.substring(10, 12));
		                    	int  totalPart  =  Integer.parseInt(udh.substring(8, 10));
		                    	
		                    	if(currentPart == totalPart)
		                    	{
		                    		logger.info("Last part identified.");
		                    		receiveMessageService.receiveMessage("Long Message Received", source, destination, false);
				                    logger.info("Successfully  Saved InValid SMS.");
		                    	}
		                    	else
		                    	{
		                    		logger.info("Last part not identified.");
		                    	}
			                    
		                	}
		                	else
		                	{
		                		//Nothing
		                	}
		                	
	                	}
	                	catch(Exception ex)
	                	{
	                		logger.error("Exception in packetReceived menthod due to : " + ex.getMessage());
	                	}
	                   
	                }
	                else if ((msgCount % 500) == 0)
	                {
	                	logger.info("."); // Give some feedback
	                }
	            }
	            break;
	
	        // Unbind request received from server..
	        case SMPPPacket.UNBIND:
	            this.end = System.currentTimeMillis();
	            logger.info("SMSC has requested unbind! Responding..");
	            try 
	            {
	                UnbindResp ubr = new UnbindResp((Unbind) pak);
	                myConnection.sendResponse(ubr);
	            }
	            catch (IOException x) 
	            {
	                logger.error("IO Exception :" + x.getMessage());
	            	x.printStackTrace(System.err);
	            }
	            finally 
	            {
	                endReport();
	            }
	            break;	
	        // Unbind response..
	        case SMPPPacket.UNBIND_RESP:
	            this.end = System.currentTimeMillis();
	            logger.info("Unbound.");
	            endReport();
	            break;
	
	        case SMPPPacket.ENQUIRE_LINK_RESP:
	        	logger.info("ENQUIRE_LINK_RESP.");
	            break;   
	         
	        default:
	        	logger.info(pak.getCommandId()+" Unexpected packet received! Id = "
	                    + Integer.toHexString(pak.getCommandId()));
	     }
    }

    private void receiverExit(Connection myConnection, ReceiverExitEvent ev) {
        if (ev.getReason() != ReceiverExitEvent.EXCEPTION) {
        	logger.info("Receiver thread has exited normally.");
        } else {
            Throwable t = ev.getException();
            logger.error("Receiver thread died due to exception:");
            t.printStackTrace(System.out);
            endReport();
        }
    }

    // Print out a report
    private void endReport() {
    	logger.info("deliver_sm's received: " + msgCount);
    	logger.info("Start time: " + new Date(start).toString());
    	logger.info("End time: " + new Date(end).toString());
    	logger.info("Elapsed: " + (end - start) + " milliseconds.");
    }
    
    public static String toHex(String arg) 
    {
    	return String.format("%012x", new BigInteger(1, arg.getBytes(Charset.defaultCharset())));
    	
    }
}
