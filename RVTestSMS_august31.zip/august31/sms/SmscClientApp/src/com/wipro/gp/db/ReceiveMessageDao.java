package com.wipro.gp.db;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.wipro.gp.bean.InValidSms;
import com.wipro.gp.bean.ValidSms;
import com.wipro.gp.service.ReceiveMessageService;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.HibernateUtil;

public class ReceiveMessageDao {
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.db.ReceiveMessageDao.class);	
	
	
	//private static final String STATUS = "PENDING"; 
	
	
	public void saveMessage(String smsText, String source_msisdn, String dest_shortCode, String creationDate, boolean isValidSms)
	{	
		logger.info("Entering into saveMessage...");
		
		SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();		
					
		if(sessionFactory == null)
		{			
			logger.info("SESSION IS NULL...");
		}
		
		// opens a new session from the session factory
		Session session = null;
		Transaction tx	= null;
		
		try
		{			
		
		
		session = sessionFactory.openSession();
		tx 		= session.beginTransaction();
		
		
			if(isValidSms)
			{	
				logger.info("In Valid Sms block.");
				synchronized(this)
				{				
					ValidSms validSms = new  ValidSms(source_msisdn, dest_shortCode, smsText, Constants.STATUS_PENDING, null,
							null,creationDate, Constants.SMS_APP, "", "", null, null, null, null, null);
					Serializable id = session.save(validSms);			
					logger.info("created id for valid sms " + id);
				}
			}
			else
			{	
				logger.info("In invalid Sms block.");
				
				synchronized(this)
				{
					InValidSms invalidSms = new  InValidSms(source_msisdn, dest_shortCode, smsText, Constants.STATUS_PENDING, null,
							null,creationDate, Constants.SMS_APP, "", "", null, null, null, null, null);
					
					Serializable id = session.save(invalidSms);
					logger.info("created id for invalid sms: " + id);
				}
			}
		
		tx.commit();
		logger.info("Exiting from  saveMessage...");
		// commits the transaction and closes the session
		}
		catch(Exception ex)
		{
			logger.error("Error in saveMessage :" + ex.getMessage());
			tx.rollback();
			
		}
		finally
		{	
			session.close();
			
		}
		
		
		
		
	}
	
	public static void main(String args[])
	{	
		ReceiveMessageService receiveMessageService = new ReceiveMessageService();
		receiveMessageService.receiveMessage("SUBS 1 GB", "9999359786", "1900", true);
	}
	
}
