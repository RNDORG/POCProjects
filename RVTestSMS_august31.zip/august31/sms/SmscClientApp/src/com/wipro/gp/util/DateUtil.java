package com.wipro.gp.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {	
	
	
	public static String parseDate(Date pDate, String pFormat)
	{	
		String formatedDate = "";
		if(pFormat == null || pFormat == "")
		{	
			pFormat = "yyyy-MM-dd kk:mm:ss.SS";
		}
		
		try
		{
			SimpleDateFormat esbFormat 	= new SimpleDateFormat(pFormat);	
			
			formatedDate = esbFormat.format(pDate);	
		}
		catch(Exception ex)
		{	
			formatedDate = "";
		}
		
		return formatedDate;
		
	}

}
