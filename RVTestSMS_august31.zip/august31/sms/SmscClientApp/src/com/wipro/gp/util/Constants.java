package com.wipro.gp.util;

public class Constants {
	//SIT with SMSC
	// public static final String SMS_PROPERTY 		= "/home/oracle/SMPPSIM/WebSMSConfiguration.properties";
	
	//SIT with Local simulator
	//public static final String SMS_PROPERTY 		= "/home/oracle/SMPPSIM/Local/WebSMSConfiguration.properties";
	
	//Prod
	//public static final String SMS_PROPERTY 		= "/home/stanveer/smsapp/WebSMSConfiguration.properties";
	public static final String SMS_PROPERTY 		= "/sms/SMSCCLIENT/SMSC_Configuration.properties";
	
	//DB Config
	public static final String SMSC_CONFIG 			= "/sms/SMSCCLIENT/SmscDB_Config.properties";
	
	//Local
	//public static final String SMS_PROPERTY 		= "d:/home/oracle/SMPPSIM/WebSMSConfiguration.properties";
	
	public static final String STATUS_PENDING 			= "PENDING";
	public static final String STATUS_PUBLISHED 		= "PUBLISHED";
	public static final String SMS_APP 					= "SMSApp";
	public static final int  VALID_KEYWORD_LENGTH		= 40;
	public static final String  IGNORE_SHORT_CODE_1  	= "19221";
	public static final String  IGNORE_SHORT_CODE_2  	= "19240";
	public static final String  IGNORE_SHORT_CODE_3  	= "19226";	
	public static final String  IGNORE_SHORT_CODE_4  	= "19230";
	public static final String  IGNORE_SHORT_CODE_5  	= "19234";	
	

}
