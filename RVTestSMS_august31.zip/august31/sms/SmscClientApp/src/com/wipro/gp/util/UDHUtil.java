package com.wipro.gp.util;

import java.nio.charset.StandardCharsets;

public class UDHUtil {

	/**
     * Gets the "User Data Header" part of a short message byte array. Only call this
     * method if the short message contains a user data header. This method will
     * take the value of the first byte ("N") as the length of the user
     * data header and return the first ("N+1") bytes from the the short message.
     * @param shortMessage The byte array representing the entire message including
     *      a user data header and user data.  A null will return null.  An
     *      empty byte array will return an empty byte array.  A byte array
     *      not containing enough data will throw an IllegalArgumentException.
     * @return A byte array of the user data header (minus the user data)
     * @throws IllegalArgumentException If the byte array does not contain
     *      enough data to fit both the user data header and user data.
     */
    static public byte[] getShortMessageUserDataHeader(byte[] shortMessage) throws IllegalArgumentException {
        if (shortMessage == null) {
            return null;
        }

        if (shortMessage.length == 0) {
            return shortMessage;
        }

        // the entire length of UDH is the first byte + the length
        //int userDataHeaderLength = ByteUtil.decodeUnsigned(shortMessage[0]) + 1;
        int userDataHeaderLength = decodeUnsigned(shortMessage[0]) + 1;

        // is there enough data?
        if (userDataHeaderLength > shortMessage.length) {
            throw new IllegalArgumentException("User data header length exceeds short message length [shortMessageLength=" + shortMessage.length + ", userDataHeaderLength=" + userDataHeaderLength + "]");
        }

        // is the user data header the only part of the payload (optimization)
        if (userDataHeaderLength == shortMessage.length) {
            return shortMessage;
        }

        // create a new message with just the header
        byte[] userDataHeader = new byte[userDataHeaderLength];
        System.arraycopy(shortMessage, 0, userDataHeader, 0, userDataHeaderLength);

        return userDataHeader;
    }



public static short decodeUnsigned(byte signed)
    {
        if (signed >= 0) {
            return signed;
        } else {
            return (short)(256+(short)signed);
        }
    }


public void main(String args[])
{
	
}


}
