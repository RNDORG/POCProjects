package com.wipro.gp.controller;

import ie.omk.smpp.Connection;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.wipro.gp.util.BindConnection;

public class Controller {

	private static Scanner read;
	private static Connection myConnection;
	private static boolean flag;

	public static void main(String[] args){
		
		final Logger logger = Logger.getLogger(com.wipro.gp.controller.Controller.class);
		
		read = new Scanner(System.in);
		try 
		{
			PropertyConfigurator.configure("/sms/SMSCCLIENT/log4j_Receiver.properties"); 
			
			BindConnection bindconnectionobj = new BindConnection();
			myConnection = bindconnectionobj.connectSMSC();
			while(true)
			{
				 boolean flag = true;
		            do
		            {
		            	Thread.sleep(8000);
		                myConnection.enquireLink();
		               /* System.out.println("Hit a key to issue an unbind..");
		                int x = System.in.read();
		                if(!flag){
		                   	flag=false;
		                }*/
		            }
		            while(flag);
				logger.info("Please Enter Choice");
				logger.info("1 For Send SMS");
				int choice;
				choice = read.nextInt();
				switch(choice)
				{
					case 1:logger.info("Inside Switch   ::  " + myConnection.getState());
					break;
					case 2:
						if (myConnection.getState() == Connection.BOUND) 
						{
							logger.info("Sending unbind request..");
			                myConnection.unbind();
			            }
			            Thread.sleep(2000);
			            myConnection.closeLink();
			            flag=true;
			            break;
			            	
				}
				
				if(flag == true)
				{
					break;
				}
			}
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
		}
		
	}
}
