package com.wipro.gp.util;

import ie.omk.smpp.Connection;
import ie.omk.smpp.message.BindResp;
import ie.omk.smpp.net.TcpLink;
import ie.omk.smpp.version.SMPPVersion;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.wipro.gp.service.ReceiveMessage;
//import weblogic.logging.NonCatalogLogger;

public class BindConnection {

	  //private static final String SMS_PROPERTY = "com/gp/lta/websms/WebSMSConfiguration.properties";
 	  //private static final String SMS_PROPERTY = "/home/oracle/SMPPSIM/WebSMSConfiguration.properties";
	  //private static final String SMS_PROPERTY = "/home/crm/sm_test/WebSMSConfiguration.properties";
	  //  private static final NonCatalogLogger logger = new NonCatalogLogger("com.gp.lta.websms");
 	  private static final Logger logger = Logger.getLogger(com.wipro.gp.util.BindConnection.class);
	  // private static Logger logger = Logger.getLogger("com.gp.lta.websms");
	     
	    private Connection connection  =   null;
	   // private Connection connection1  =   null;
	                          
	    private static int          portNo;
	    private static String       systemId;
	    private static String       systemPwd;
	    private static String       systemType;
	    private static int          sourceTON;
	    private static int          sourceNPI;
	    private static int          destinationTON;
	    private static int          destinationNPI;
	    private static String       shortCode;
	    
	    private static Properties   properties;
	      
	    public BindConnection()throws Exception{
	        // Load the property file
	        logger.info("Start loading profile ");
	        InputStream   propsInputStream = null;
	        try
	        {  
	        	propsInputStream = new FileInputStream(Constants.SMS_PROPERTY);
	            properties = new Properties();
	            properties.load(propsInputStream);
	        } 
	        catch (IOException ex) 
	        {
	        	logger.error("Problem in reading SMS property file :" + ex.getMessage());
	        	ex.printStackTrace();
	    	} 
	        finally 
	        {
	    		if (propsInputStream != null) 
	    		{
	    			try 
	    			{
	    				propsInputStream.close();
	    			} catch (IOException e) 
	    			{
	    				logger.error("Problem in reading SMS property file :" + e.getMessage());
	    				e.printStackTrace();
	    			}
	    		}
	    	}
	        
	        /***************************************************************************
	         * Step 1 : Load all configuration from the property file
	         ***************************************************************************/
	        try
	        {
	            portNo          =   Integer.parseInt(properties.getProperty("port"));
	            systemId        =   properties.getProperty("systemID");
	            systemPwd       =   properties.getProperty("password");
	            systemType      =   properties.getProperty("systemType");
	            sourceTON       =   Integer.parseInt(properties.getProperty("sourceTON"));
	            sourceNPI       =   Integer.parseInt(properties.getProperty("sourceNPI"));
	            destinationTON  =   Integer.parseInt(properties.getProperty("destinationTON"));
	            destinationNPI  =   Integer.parseInt(properties.getProperty("destinationNPI"));
	            shortCode		=	properties.getProperty("shortCode");
	            
	        }
	        catch(NumberFormatException ex)
	        {
	            logger.error("Number format exception : " + ex.getMessage());
	        	throw ex;
	        }
	        
	        logger.info("Completed loading profile ");
	    }

	    
	    /*******************************************************************************************************************************/
	    // Function for connecting SMSC server
        public synchronized Connection connectSMSC() throws Exception{
             String          hostName    =   "";
             TcpLink         smscLink    =   null;
            //TcpLink         smscLink1   =   null;
        
            /***************************************************************************
             * Step 1 : Establish connection with the SMSC Server
             ***************************************************************************/
            try {
                hostName = properties.getProperty("host1");

                if(hostName.isEmpty()){
                    throw new Exception("Host name not configured");
                }
                
                logger.info("Trying to connect SMSC with host name : " + hostName);
                
                // First get the java.net.InetAddress for the SMSC:
                InetAddress     smscAddr = InetAddress.getByName(hostName);
                              
                if(smscAddr == null){
                    throw new Exception("Unable to get the address by the host name");
                }
                                
                smscLink = new TcpLink(smscAddr, portNo);
               // smscLink1 = new TcpLink(smscAddr, 2776);
              
               smscLink.open();
               //smscLink1.open();
                
                logger.info("Connected with SMSC; host name : " + hostName + " Port No : " + portNo);
            } catch(UnknownHostException ux) {
                logger.error("Unable to connected with SMSC Server. Error : " + ux.getMessage());
                throw ux;
            }
            
            BindResp    bindResp = null;
            
            try
            {
                connection = new Connection(smscLink, true);
                //connection1 = new Connection(smscLink1, true);
                
                ReceiveMessage receivemessageobj = new ReceiveMessage();
             //   ReceiveMessage receivemessageobj1 = new ReceiveMessage();
                connection.addObserver(receivemessageobj);
                
                connection.setVersion(SMPPVersion.V34);
                connection.autoAckLink(true);
                connection.autoAckMessages(true);

                
//                connection1.addObserver(receivemessageobj1);                
//                connection1.setVersion(SMPPVersion.V34);
//                connection1.autoAckLink(true);
//                connection1.autoAckMessages(true);
                
                

                // Validate whether binding successful with the host1
              //  bindResp = connection.bind(Connection.RECEIVER, systemId, systemPwd, systemType, sourceTON, sourceNPI, shortCode);
                
           //     bindResp = connection.bind(Connection.TRANSCEIVER, systemId, systemPwd, systemType); 
                
                //ASF Local all port
                 //bindResp = connection.bind(Connection.RECEIVER,"smppclient1","password","regular");
                // bindResp = connection1.bind(Connection.RECEIVER,"smppclient1","password","regular");
               
                // bindResp = connection.bind(Connection.RECEIVER,systemId,systemPwd,systemType);
               // bindResp = connection1.bind(Connection.RECEIVER,systemId,systemPwd,systemType);
                
                 
               
                // ASF Server at 10.172.200.117/5566
               // bindResp = connection.bind(Connection.RECEIVER,"EsbRx","EsbRx321","regular");
                
                bindResp = connection.bind(Connection.RECEIVER,systemId, systemPwd, systemType);
                
                     
                //Local specific port
             //   bindResp = connection.bind(Connection.RECEIVER,"smppclient1","password","regular",0,0,"9999");
                
                 
                /*if(bindResp.getCommandStatus() != 0){
                    // Take the second host and try to connect
                    hostName = properties.getProperty("host2");

                     bindResp = connection.bind(Connection.TRANSMITTER, systemId, systemPwd, systemType, 
                                                        sourceTON, sourceNPI, shortCode);
                     
                    bindResp = connection.bind(Connection.TRANSMITTER, systemId, systemPwd, systemType); 
                    if(bindResp.getCommandStatus() != 0){
                        logger.debug("SMSC bind failed \n");
                        //Thread.sleep(2000L);
                        logger.debug("After Sleep \n");
                        throw new Exception("SMSC bind failed");
                    }
                }*/
            }
            catch(Exception ex){
            	//System.out.println(ex);
            	logger.error("Connection Bind Error : " + ex.getMessage());
                //throw ex;
            }

            logger.info("Successfully connected with SMSC; host name : " + hostName 
            		+ " Port No : " + portNo + "\n" + " : Bind Connection  " + connection.getState());            
            
            return connection;
        }
	
	
}
