package com.wipro.gp.bean;

public class ValidSms {
	
	private  long smsId; 

	private String source_msisdn;
	
	private String  dest_shortCode;
	
	private String  smsText;
	
	private String status;
	
	private String productId;
	  
	private String targetApplication;
	  
	private String creationDate;
	  
	private String createdBy;
	  
	private String modifiedDate;
	   
	private String modifiedBy;
	
	private String extra_field1;
	
	private String extra_field2;
	
	private String extra_field3;
	
	private String extra_field4;
	
	private String extra_field5;	


	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTargetApplication() {
		return targetApplication;
	}

	public void setTargetApplication(String targetApplication) {
		this.targetApplication = targetApplication;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

		
	public ValidSms()
	{
		
	}	

	public ValidSms(long smsId, String source_msisdn, String dest_shortCode,
			String smsText, String status, String productId,
			String targetApplication, String creationDate, String createdBy,
			String modifiedDate, String modifiedBy, String extra_field1,
			String extra_field2, String extra_field3, String extra_field4,
			String extra_field5) {	
		this.smsId = smsId;
		this.source_msisdn = source_msisdn;
		this.dest_shortCode = dest_shortCode;
		this.smsText = smsText;
		this.status = status;
		this.productId = productId;
		this.targetApplication = targetApplication;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.extra_field1 = extra_field1;
		this.extra_field2 = extra_field2;
		this.extra_field3 = extra_field3;
		this.extra_field4 = extra_field4;
		this.extra_field5 = extra_field5;
	}
	
	public ValidSms(String source_msisdn, String dest_shortCode,
			String smsText, String status, String productId,
			String targetApplication, String creationDate, String createdBy,
			String modifyDate, String modifiedBy, String extra_field1,
			String extra_field2, String extra_field3, String extra_field4,
			String extra_field5) {
		super();
		this.source_msisdn = source_msisdn;
		this.dest_shortCode = dest_shortCode;
		this.smsText = smsText;
		this.status = status;
		this.productId = productId;
		this.targetApplication = targetApplication;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifyDate;
		this.modifiedBy = modifiedBy;
		this.extra_field1 = extra_field1;
		this.extra_field2 = extra_field2;
		this.extra_field3 = extra_field3;
		this.extra_field4 = extra_field4;
		this.extra_field5 = extra_field5;
	}

	public long getSmsId() {
		return smsId;
	}

	public void setSmsId(long smsId) {
		this.smsId = smsId;
	}

	public String getSource_msisdn() {
		return source_msisdn;
	}

	public void setSource_msisdn(String source_msisdn) {
		this.source_msisdn = source_msisdn;
	}

	public String getDest_shortCode() {
		return dest_shortCode;
	}

	public void setDest_shortCode(String dest_shortCode) {
		this.dest_shortCode = dest_shortCode;
	}

	public String getSmsText() {
		return smsText;
	}

	public void setSmsText(String smsText) {
		this.smsText = smsText;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public String getExtra_field1() {
		return extra_field1;
	}

	public void setExtra_field1(String extra_field1) {
		this.extra_field1 = extra_field1;
	}

	public String getExtra_field2() {
		return extra_field2;
	}

	public void setExtra_field2(String extra_field2) {
		this.extra_field2 = extra_field2;
	}

	public String getExtra_field3() {
		return extra_field3;
	}

	public void setExtra_field3(String extra_field3) {
		this.extra_field3 = extra_field3;
	}

	public String getExtra_field4() {
		return extra_field4;
	}

	public void setExtra_field4(String extra_field4) {
		this.extra_field4 = extra_field4;
	}

	public String getExtra_field5() {
		return extra_field5;
	}

	public void setExtra_field5(String extra_field5) {
		this.extra_field5 = extra_field5;
	}	
	   
}
