package com.wipro.gp.service;

import java.util.Date;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.wipro.gp.db.ReceiveMessageDao;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.DateUtil;

public class ReceiveMessageService {
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.service.ReceiveMessageService.class);
	
	ReceiveMessageDao receiveMessageDao = new ReceiveMessageDao();
	Date currDate;
	String creationDate;
	
	
	public void receiveMessage(String smsText, String source_msisdn, String dest_shortCode, boolean isValidSms)	
	{	
		logger.info("Entering into receiveMessage method.");		
		
		try
		{
			currDate 		= new Date();
			creationDate 	= DateUtil.parseDate(currDate, "yyyy-MM-dd HH:mm:ss.SS");
			
			if(isValidSms)
			{	
				
				isValidSms 		= false;
				dest_shortCode = dest_shortCode.trim();
				//Pattern pattern = Pattern.compile("[0-9 ]+");			
				Pattern pattern = Pattern.compile("(\\+?[0-9\\s*]+)*+");
				boolean isExceptionalCase = pattern.matcher(smsText).matches(); // " 9999359786 9999359786   +9999359786 09999359786 8809999359786"
				
				if(smsText.length() <= Constants.VALID_KEYWORD_LENGTH || isExceptionalCase || (smsText.toUpperCase()).startsWith("CF "))
				{	
					isValidSms = true;
				}		
				else
				{
					isValidSms = false;
				}
						
				receiveMessageDao.saveMessage(smsText, source_msisdn, dest_shortCode, creationDate, isValidSms);	
			}
			else
			{
				receiveMessageDao.saveMessage(smsText, source_msisdn, dest_shortCode, creationDate, isValidSms);
			}
		}
		catch(Exception ex)
		{
			logger.info("Exception in receiveMessage() method " + ex.getMessage());
			throw ex;
			
		}
				
		
		logger.info("Exiting from  receiveMessage() insert...");
		
	}
	
	public static void main(String args[])
	{
		ReceiveMessageService dbInsert = new ReceiveMessageService();
		
		//dbInsert.receiveMessage("11111111111 111111111 111111111 111111111 6667888855 oooiytt yyyyyyyhhh bbbbkjjhttttj nnnnnbb uuuuuuuu ffffffttt bbbbbbbbb jjjjjjjkkkk hhhhhhhhhhh", "9999359786", "1900", true);
		dbInsert.receiveMessage("+11111111111 111111111 111111111 111111111 +6667888855 8809999359786 +8809999359786 08809999359786 008809999359786 08809999359786 08809999359786 08809999359786        08809999359786  08809999359786 sdkjk kjskjdk ksjdlkjslk  ", "9999359786", "1900", true);
	}
	
}
