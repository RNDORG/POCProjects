package com.wipro.gp.bean;

public class SmscResponse {

	private  long smsId;	
	private String status;
	private String smscMessageId;
	
	public SmscResponse() 
	{
	
	}

	public SmscResponse(long smsId, String status, String smscMessageId) 
	{	
		this.smsId = smsId;
		this.status = status;
		this.smscMessageId = smscMessageId;
	}

	public long getSmsId() {
		return smsId;
	}

	public void setSmsId(long smsId) {
		this.smsId = smsId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSmscMessageId() {
		return smscMessageId;
	}

	public void setSmscMessageId(String smscMessageId) {
		this.smscMessageId = smscMessageId;
	}	

}
