package com.wipro.gp.bean;

public class SmscSendRequest {
	
	private  long smsId;		
	private String status;
	
	public SmscSendRequest() 
	{
	
	}

	public SmscSendRequest(long smsId, String status)
	{
		this.smsId = smsId;
		this.status = status;
	}

	public long getSmsId() {
		return smsId;
	}

	public void setSmsId(long smsId) {
		this.smsId = smsId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	

}
