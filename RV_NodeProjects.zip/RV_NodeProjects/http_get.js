// Include http module, 
var http = require("http"), 

// And url module, which is very helpful in parsing request parameters. 
url = require("url"); 

// Create the server. 
http.createServer(function (request, response) { 
request.on('end', function () {console.log('request end event fired');}); 	// Attach listener on end event. 
var _get = url.parse(request.url, true).query; 					// Parse the request for arguments and store them in _get variable. 
response.writeHead(200, { 'Content-Type': 'text/plain' }); 			// Write headers to the response. 
response.end('Here is your data: ' + _get['data']); 				// Send data and end response.  
}).listen(8080); // Listen on the 8080 port. 

console.log('Server running at http://127.0.0.1:8080/');