package sst.pyotls.bean.sstdb.esm.EsmSupplier;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ESM_SUPPLIER")
public class EsmSupplierTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="org_id")
  private String                    org_id;
  @Column(name="supplier_id")
  private String                 supplier_id;
  @Column(name="supplier_type")
  private String                supplier_type;
  @Column(name="supplier_ctg")
  private String                 supplier_ctg;
  @Column(name="supplier_name")
  private String                supplier_name;
  @Column(name="referred_by")
  private String                 referred_by;
  @Column(name="turn_over")
  private long                   turn_over;
  @Column(name="supply_capacity")
  private int                 supply_capacity;
  @Column(name="area_code")
  private String                  area_code;
  @Column(name="country_code")
  private String                 country_code;
  @Column(name="status")
  private String                    status;
  @Column(name="expiration_date")
  private String               expiration_date;
  @Column(name="effective_date")
  private String                effective_date;
  @Column(name="business_type")
  private String                business_type;
  @Column(name="business_est_date")
  private String              business_est_date;
  @Column(name="employee_strength")
  private int                employee_strength;
  @Column(name="business_currency")
  private String              business_currency;
  @Column(name="cst_form_num")
  private String                 cst_form_num;
  @Column(name="cst_form_date")
  private String                cst_form_date;
  @Column(name="lst_form_num")
  private String                 lst_form_num;
  @Column(name="lst_form_date")
  private String                lst_form_date;
  @Column(name="tin_num")
  private String                   tin_num;
  @Column(name="tin_date")
  private String                   tin_date;
  @Column(name="pan_num")
  private String                   pan_num;
  @Column(name="pan_date")
  private String                   pan_date;
  @Column(name="tan_num")
  private String                   tan_num;
  @Column(name="tan_date")
  private String                   tan_date;
  @Column(name="strn_num")
  private String                   strn_num;
  @Column(name="strn_date")
  private String                  strn_date;
  @Column(name="account_num")
  private String                 account_num;
  @Column(name="bal_close")
  private double                  bal_close;
  @Column(name="bal_open")
  private double                   bal_open;
  @Column(name="dr_amt")
  private double                    dr_amt;
  @Column(name="cr_amt")
  private double                    cr_amt;
  @Column(name="ar_bal")
  private double                    ar_bal;
  @Column(name="address_1")
  private String                  address_1;
  @Column(name="address_2")
  private String                  address_2;
  @Column(name="address_3")
  private String                  address_3;
  @Column(name="state_code")
  private String                  state_code;



  public String getorg_id()                           { return org_id; }
  public String getsupplier_id()                        { return supplier_id; }
  public String getsupplier_type()                       { return supplier_type; }
  public String getsupplier_ctg()                        { return supplier_ctg; }
  public String getsupplier_name()                       { return supplier_name; }
  public String getreferred_by()                        { return referred_by; }
  public long getturn_over()                          { return turn_over; }
  public int getsupply_capacity()                        { return supply_capacity; }
  public String getarea_code()                         { return area_code; }
  public String getcountry_code()                        { return country_code; }
  public String getstatus()                           { return status; }
  public String getexpiration_date()                      { return expiration_date; }
  public String geteffective_date()                       { return effective_date; }
  public String getbusiness_type()                       { return business_type; }
  public String getbusiness_est_date()                     { return business_est_date; }
  public int getemployee_strength()                       { return employee_strength; }
  public String getbusiness_currency()                     { return business_currency; }
  public String getcst_form_num()                        { return cst_form_num; }
  public String getcst_form_date()                       { return cst_form_date; }
  public String getlst_form_num()                        { return lst_form_num; }
  public String getlst_form_date()                       { return lst_form_date; }
  public String gettin_num()                          { return tin_num; }
  public String gettin_date()                          { return tin_date; }
  public String getpan_num()                          { return pan_num; }
  public String getpan_date()                          { return pan_date; }
  public String gettan_num()                          { return tan_num; }
  public String gettan_date()                          { return tan_date; }
  public String getstrn_num()                          { return strn_num; }
  public String getstrn_date()                         { return strn_date; }
  public String getaccount_num()                        { return account_num; }
  public double getbal_close()                         { return bal_close; }
  public double getbal_open()                          { return bal_open; }
  public double getdr_amt()                           { return dr_amt; }
  public double getcr_amt()                           { return cr_amt; }
  public double getar_bal()                           { return ar_bal; }
  public String getaddress_1()                         { return address_1; }
  public String getaddress_2()                         { return address_2; }
  public String getaddress_3()                         { return address_3; }
  public String getstate_code()                         { return state_code; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setsupplier_id(String supplier_id )               { this.supplier_id = supplier_id; }
  public void  setsupplier_type(String supplier_type )             { this.supplier_type = supplier_type; }
  public void  setsupplier_ctg(String supplier_ctg )              { this.supplier_ctg = supplier_ctg; }
  public void  setsupplier_name(String supplier_name )             { this.supplier_name = supplier_name; }
  public void  setreferred_by(String referred_by )               { this.referred_by = referred_by; }
  public void  setturn_over(long turn_over )                  { this.turn_over = turn_over; }
  public void  setsupply_capacity(int supply_capacity )             { this.supply_capacity = supply_capacity; }
  public void  setarea_code(String area_code )                 { this.area_code = area_code; }
  public void  setcountry_code(String country_code )              { this.country_code = country_code; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setbusiness_type(String business_type )             { this.business_type = business_type; }
  public void  setbusiness_est_date(String business_est_date )         { this.business_est_date = business_est_date; }
  public void  setemployee_strength(int employee_strength )           { this.employee_strength = employee_strength; }
  public void  setbusiness_currency(String business_currency )         { this.business_currency = business_currency; }
  public void  setcst_form_num(String cst_form_num )              { this.cst_form_num = cst_form_num; }
  public void  setcst_form_date(String cst_form_date )             { this.cst_form_date = cst_form_date; }
  public void  setlst_form_num(String lst_form_num )              { this.lst_form_num = lst_form_num; }
  public void  setlst_form_date(String lst_form_date )             { this.lst_form_date = lst_form_date; }
  public void  settin_num(String tin_num )                   { this.tin_num = tin_num; }
  public void  settin_date(String tin_date )                  { this.tin_date = tin_date; }
  public void  setpan_num(String pan_num )                   { this.pan_num = pan_num; }
  public void  setpan_date(String pan_date )                  { this.pan_date = pan_date; }
  public void  settan_num(String tan_num )                   { this.tan_num = tan_num; }
  public void  settan_date(String tan_date )                  { this.tan_date = tan_date; }
  public void  setstrn_num(String strn_num )                  { this.strn_num = strn_num; }
  public void  setstrn_date(String strn_date )                 { this.strn_date = strn_date; }
  public void  setaccount_num(String account_num )               { this.account_num = account_num; }
  public void  setbal_close(double bal_close )                 { this.bal_close = bal_close; }
  public void  setbal_open(double bal_open )                  { this.bal_open = bal_open; }
  public void  setdr_amt(double dr_amt )                    { this.dr_amt = dr_amt; }
  public void  setcr_amt(double cr_amt )                    { this.cr_amt = cr_amt; }
  public void  setar_bal(double ar_bal )                    { this.ar_bal = ar_bal; }
  public void  setaddress_1(String address_1 )                 { this.address_1 = address_1; }
  public void  setaddress_2(String address_2 )                 { this.address_2 = address_2; }
  public void  setaddress_3(String address_3 )                 { this.address_3 = address_3; }
  public void  setstate_code(String state_code )                { this.state_code = state_code; }
}