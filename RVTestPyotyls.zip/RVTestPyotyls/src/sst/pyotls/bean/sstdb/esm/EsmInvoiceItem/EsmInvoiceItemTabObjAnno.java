package sst.pyotls.bean.sstdb.esm.EsmInvoiceItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ESM_INVOICE_ITEM")
public class EsmInvoiceItemTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="invoice_num")
  private String                 invoice_num;
  @Column(name="item_code")
  private String                  item_code;
  @Column(name="oa_num")
  private String                    oa_num;
  @Column(name="make_id")
  private String                   make_id;
  @Column(name="source_id")
  private String                  source_id;
  @Column(name="qty_dispatch")
  private int                  qty_dispatch;
  @Column(name="qty_selected")
  private int                  qty_selected;
  @Column(name="rate_dispatch")
  private double                rate_dispatch;
  @Column(name="invoice_status")
  private String                invoice_status;
  @Column(name="quality_status")
  private String                quality_status;
  @Column(name="quality_status_date")
  private String             quality_status_date;
  @Column(name="dummy_invoice_num")
  private String              dummy_invoice_num;
  @Column(name="qty_block_flag")
  private String                qty_block_flag;



  public String getinvoice_num()                        { return invoice_num; }
  public String getitem_code()                         { return item_code; }
  public String getoa_num()                           { return oa_num; }
  public String getmake_id()                          { return make_id; }
  public String getsource_id()                         { return source_id; }
  public int getqty_dispatch()                         { return qty_dispatch; }
  public int getqty_selected()                         { return qty_selected; }
  public double getrate_dispatch()                       { return rate_dispatch; }
  public String getinvoice_status()                       { return invoice_status; }
  public String getquality_status()                       { return quality_status; }
  public String getquality_status_date()                    { return quality_status_date; }
  public String getdummy_invoice_num()                     { return dummy_invoice_num; }
  public String getqty_block_flag()                       { return qty_block_flag; }



  public void  setinvoice_num(String invoice_num )               { this.invoice_num = invoice_num; }
  public void  setitem_code(String item_code )                 { this.item_code = item_code; }
  public void  setoa_num(String oa_num )                    { this.oa_num = oa_num; }
  public void  setmake_id(String make_id )                   { this.make_id = make_id; }
  public void  setsource_id(String source_id )                 { this.source_id = source_id; }
  public void  setqty_dispatch(int qty_dispatch )                { this.qty_dispatch = qty_dispatch; }
  public void  setqty_selected(int qty_selected )                { this.qty_selected = qty_selected; }
  public void  setrate_dispatch(double rate_dispatch )             { this.rate_dispatch = rate_dispatch; }
  public void  setinvoice_status(String invoice_status )            { this.invoice_status = invoice_status; }
  public void  setquality_status(String quality_status )            { this.quality_status = quality_status; }
  public void  setquality_status_date(String quality_status_date )       { this.quality_status_date = quality_status_date; }
  public void  setdummy_invoice_num(String dummy_invoice_num )         { this.dummy_invoice_num = dummy_invoice_num; }
  public void  setqty_block_flag(String qty_block_flag )            { this.qty_block_flag = qty_block_flag; }
}