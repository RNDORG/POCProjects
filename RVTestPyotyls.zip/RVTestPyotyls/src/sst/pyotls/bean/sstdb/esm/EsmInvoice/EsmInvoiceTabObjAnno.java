package sst.pyotls.bean.sstdb.esm.EsmInvoice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ESM_INVOICE")
public class EsmInvoiceTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="invoice_num")
  private String                 invoice_num;
  @Column(name="invoice_date")
  private String                 invoice_date;
  @Column(name="pack_list_num")
  private String                pack_list_num;
  @Column(name="customer_id")
  private String                 customer_id;
  @Column(name="customer_type")
  private String                customer_type;
  @Column(name="customer_ctg")
  private String                 customer_ctg;
  @Column(name="oa_num")
  private String                    oa_num;
  @Column(name="oa_date")
  private String                   oa_date;
  @Column(name="gate_pass_num")
  private String                gate_pass_num;
  @Column(name="gate_pass_date")
  private String                gate_pass_date;
  @Column(name="net_wt")
  private double                    net_wt;
  @Column(name="gross_wt")
  private double                   gross_wt;
  @Column(name="payment_ref_num")
  private String               payment_ref_num;
  @Column(name="invoice_amt")
  private double                 invoice_amt;
  @Column(name="remark")
  private String                    remark;
  @Column(name="net_sale")
  private double                   net_sale;
  @Column(name="invoice_status")
  private String                invoice_status;
  @Column(name="payment_received")
  private double               payment_received;
  @Column(name="payment_recv_date")
  private String              payment_recv_date;
  @Column(name="lc_num")
  private String                    lc_num;
  @Column(name="lc_date")
  private String                   lc_date;
  @Column(name="gr_num")
  private String                    gr_num;
  @Column(name="gr_date")
  private String                   gr_date;
  @Column(name="ship_agent_id")
  private String                ship_agent_id;
  @Column(name="ship_bill_num")
  private String                ship_bill_num;
  @Column(name="ship_bill_date")
  private String                ship_bill_date;
  @Column(name="bl_num")
  private String                    bl_num;
  @Column(name="bl_date")
  private String                   bl_date;
  @Column(name="port_of_shipment")
  private String               port_of_shipment;
  @Column(name="port_of_destination")
  private String             port_of_destination;
  @Column(name="final_destination")
  private String              final_destination;
  @Column(name="destination_state")
  private String              destination_state;
  @Column(name="destination_country")
  private String             destination_country;
  @Column(name="pre_carrier")
  private String                 pre_carrier;
  @Column(name="pre_carrier_receipt_city")
  private String           pre_carrier_receipt_city;
  @Column(name="carrier")
  private String                   carrier;
  @Column(name="container_num")
  private String                container_num;
  @Column(name="transport_mode")
  private String                transport_mode;
  @Column(name="transport_info")
  private String                transport_info;
  @Column(name="license_head_1")
  private String                license_head_1;
  @Column(name="license_head_2")
  private String                license_head_2;
  @Column(name="exp_license_code")
  private String               exp_license_code;
  @Column(name="ship_load_date")
  private String                ship_load_date;
  @Column(name="fob_local_ship_bl")
  private double              fob_local_ship_bl;
  @Column(name="fob_fc_ship_bill")
  private double               fob_fc_ship_bill;
  @Column(name="fob_fc_id")
  private String                  fob_fc_id;
  @Column(name="fob_fc_exch_rate")
  private float               fob_fc_exch_rate;
  @Column(name="license_update_flag")
  private String             license_update_flag;
  @Column(name="epcg_code")
  private String                  epcg_code;
  @Column(name="epcg_update_flag")
  private String               epcg_update_flag;
  @Column(name="tax_form_type")
  private String                tax_form_type;
  @Column(name="tax_form_num")
  private String                 tax_form_num;
  @Column(name="tax_form_date")
  private String                tax_form_date;
  @Column(name="tax_percent")
  private float                  tax_percent;
  @Column(name="invoice_type")
  private String                 invoice_type;
  @Column(name="planner_id")
  private String                  planner_id;
  @Column(name="planner_name")
  private String                 planner_name;
  @Column(name="dummy_invoice_num")
  private String              dummy_invoice_num;



  public String getinvoice_num()                        { return invoice_num; }
  public String getinvoice_date()                        { return invoice_date; }
  public String getpack_list_num()                       { return pack_list_num; }
  public String getcustomer_id()                        { return customer_id; }
  public String getcustomer_type()                       { return customer_type; }
  public String getcustomer_ctg()                        { return customer_ctg; }
  public String getoa_num()                           { return oa_num; }
  public String getoa_date()                          { return oa_date; }
  public String getgate_pass_num()                       { return gate_pass_num; }
  public String getgate_pass_date()                       { return gate_pass_date; }
  public double getnet_wt()                           { return net_wt; }
  public double getgross_wt()                          { return gross_wt; }
  public String getpayment_ref_num()                      { return payment_ref_num; }
  public double getinvoice_amt()                        { return invoice_amt; }
  public String getremark()                           { return remark; }
  public double getnet_sale()                          { return net_sale; }
  public String getinvoice_status()                       { return invoice_status; }
  public double getpayment_received()                      { return payment_received; }
  public String getpayment_recv_date()                     { return payment_recv_date; }
  public String getlc_num()                           { return lc_num; }
  public String getlc_date()                          { return lc_date; }
  public String getgr_num()                           { return gr_num; }
  public String getgr_date()                          { return gr_date; }
  public String getship_agent_id()                       { return ship_agent_id; }
  public String getship_bill_num()                       { return ship_bill_num; }
  public String getship_bill_date()                       { return ship_bill_date; }
  public String getbl_num()                           { return bl_num; }
  public String getbl_date()                          { return bl_date; }
  public String getport_of_shipment()                      { return port_of_shipment; }
  public String getport_of_destination()                    { return port_of_destination; }
  public String getfinal_destination()                     { return final_destination; }
  public String getdestination_state()                     { return destination_state; }
  public String getdestination_country()                    { return destination_country; }
  public String getpre_carrier()                        { return pre_carrier; }
  public String getpre_carrier_receipt_city()                  { return pre_carrier_receipt_city; }
  public String getcarrier()                          { return carrier; }
  public String getcontainer_num()                       { return container_num; }
  public String gettransport_mode()                       { return transport_mode; }
  public String gettransport_info()                       { return transport_info; }
  public String getlicense_head_1()                       { return license_head_1; }
  public String getlicense_head_2()                       { return license_head_2; }
  public String getexp_license_code()                      { return exp_license_code; }
  public String getship_load_date()                       { return ship_load_date; }
  public double getfob_local_ship_bl()                     { return fob_local_ship_bl; }
  public double getfob_fc_ship_bill()                      { return fob_fc_ship_bill; }
  public String getfob_fc_id()                         { return fob_fc_id; }
  public float getfob_fc_exch_rate()                      { return fob_fc_exch_rate; }
  public String getlicense_update_flag()                    { return license_update_flag; }
  public String getepcg_code()                         { return epcg_code; }
  public String getepcg_update_flag()                      { return epcg_update_flag; }
  public String gettax_form_type()                       { return tax_form_type; }
  public String gettax_form_num()                        { return tax_form_num; }
  public String gettax_form_date()                       { return tax_form_date; }
  public float gettax_percent()                         { return tax_percent; }
  public String getinvoice_type()                        { return invoice_type; }
  public String getplanner_id()                         { return planner_id; }
  public String getplanner_name()                        { return planner_name; }
  public String getdummy_invoice_num()                     { return dummy_invoice_num; }



  public void  setinvoice_num(String invoice_num )               { this.invoice_num = invoice_num; }
  public void  setinvoice_date(String invoice_date )              { this.invoice_date = invoice_date; }
  public void  setpack_list_num(String pack_list_num )             { this.pack_list_num = pack_list_num; }
  public void  setcustomer_id(String customer_id )               { this.customer_id = customer_id; }
  public void  setcustomer_type(String customer_type )             { this.customer_type = customer_type; }
  public void  setcustomer_ctg(String customer_ctg )              { this.customer_ctg = customer_ctg; }
  public void  setoa_num(String oa_num )                    { this.oa_num = oa_num; }
  public void  setoa_date(String oa_date )                   { this.oa_date = oa_date; }
  public void  setgate_pass_num(String gate_pass_num )             { this.gate_pass_num = gate_pass_num; }
  public void  setgate_pass_date(String gate_pass_date )            { this.gate_pass_date = gate_pass_date; }
  public void  setnet_wt(double net_wt )                    { this.net_wt = net_wt; }
  public void  setgross_wt(double gross_wt )                  { this.gross_wt = gross_wt; }
  public void  setpayment_ref_num(String payment_ref_num )           { this.payment_ref_num = payment_ref_num; }
  public void  setinvoice_amt(double invoice_amt )               { this.invoice_amt = invoice_amt; }
  public void  setremark(String remark )                    { this.remark = remark; }
  public void  setnet_sale(double net_sale )                  { this.net_sale = net_sale; }
  public void  setinvoice_status(String invoice_status )            { this.invoice_status = invoice_status; }
  public void  setpayment_received(double payment_received )          { this.payment_received = payment_received; }
  public void  setpayment_recv_date(String payment_recv_date )         { this.payment_recv_date = payment_recv_date; }
  public void  setlc_num(String lc_num )                    { this.lc_num = lc_num; }
  public void  setlc_date(String lc_date )                   { this.lc_date = lc_date; }
  public void  setgr_num(String gr_num )                    { this.gr_num = gr_num; }
  public void  setgr_date(String gr_date )                   { this.gr_date = gr_date; }
  public void  setship_agent_id(String ship_agent_id )             { this.ship_agent_id = ship_agent_id; }
  public void  setship_bill_num(String ship_bill_num )             { this.ship_bill_num = ship_bill_num; }
  public void  setship_bill_date(String ship_bill_date )            { this.ship_bill_date = ship_bill_date; }
  public void  setbl_num(String bl_num )                    { this.bl_num = bl_num; }
  public void  setbl_date(String bl_date )                   { this.bl_date = bl_date; }
  public void  setport_of_shipment(String port_of_shipment )          { this.port_of_shipment = port_of_shipment; }
  public void  setport_of_destination(String port_of_destination )       { this.port_of_destination = port_of_destination; }
  public void  setfinal_destination(String final_destination )         { this.final_destination = final_destination; }
  public void  setdestination_state(String destination_state )         { this.destination_state = destination_state; }
  public void  setdestination_country(String destination_country )       { this.destination_country = destination_country; }
  public void  setpre_carrier(String pre_carrier )               { this.pre_carrier = pre_carrier; }
  public void  setpre_carrier_receipt_city(String pre_carrier_receipt_city )  { this.pre_carrier_receipt_city = pre_carrier_receipt_city; }
  public void  setcarrier(String carrier )                   { this.carrier = carrier; }
  public void  setcontainer_num(String container_num )             { this.container_num = container_num; }
  public void  settransport_mode(String transport_mode )            { this.transport_mode = transport_mode; }
  public void  settransport_info(String transport_info )            { this.transport_info = transport_info; }
  public void  setlicense_head_1(String license_head_1 )            { this.license_head_1 = license_head_1; }
  public void  setlicense_head_2(String license_head_2 )            { this.license_head_2 = license_head_2; }
  public void  setexp_license_code(String exp_license_code )          { this.exp_license_code = exp_license_code; }
  public void  setship_load_date(String ship_load_date )            { this.ship_load_date = ship_load_date; }
  public void  setfob_local_ship_bl(double fob_local_ship_bl )         { this.fob_local_ship_bl = fob_local_ship_bl; }
  public void  setfob_fc_ship_bill(double fob_fc_ship_bill )          { this.fob_fc_ship_bill = fob_fc_ship_bill; }
  public void  setfob_fc_id(String fob_fc_id )                 { this.fob_fc_id = fob_fc_id; }
  public void  setfob_fc_exch_rate(float fob_fc_exch_rate )           { this.fob_fc_exch_rate = fob_fc_exch_rate; }
  public void  setlicense_update_flag(String license_update_flag )       { this.license_update_flag = license_update_flag; }
  public void  setepcg_code(String epcg_code )                 { this.epcg_code = epcg_code; }
  public void  setepcg_update_flag(String epcg_update_flag )          { this.epcg_update_flag = epcg_update_flag; }
  public void  settax_form_type(String tax_form_type )             { this.tax_form_type = tax_form_type; }
  public void  settax_form_num(String tax_form_num )              { this.tax_form_num = tax_form_num; }
  public void  settax_form_date(String tax_form_date )             { this.tax_form_date = tax_form_date; }
  public void  settax_percent(float tax_percent )                { this.tax_percent = tax_percent; }
  public void  setinvoice_type(String invoice_type )              { this.invoice_type = invoice_type; }
  public void  setplanner_id(String planner_id )                { this.planner_id = planner_id; }
  public void  setplanner_name(String planner_name )              { this.planner_name = planner_name; }
  public void  setdummy_invoice_num(String dummy_invoice_num )         { this.dummy_invoice_num = dummy_invoice_num; }
}