package sst.pyotls.bean.sstdb.esm.EsmCustomerPoIaddr;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ESM_CUSTOMER_PO_IADDR")
public class EsmCustomerPoIaddrTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="oa_num")
  private String                    oa_num;
  @Column(name="item_code")
  private String                  item_code;
  @Column(name="make_id")
  private String                   make_id;
  @Column(name="delivery_address")
  private String               delivery_address;



  public String getoa_num()                           { return oa_num; }
  public String getitem_code()                         { return item_code; }
  public String getmake_id()                          { return make_id; }
  public String getdelivery_address()                      { return delivery_address; }



  public void  setoa_num(String oa_num )                    { this.oa_num = oa_num; }
  public void  setitem_code(String item_code )                 { this.item_code = item_code; }
  public void  setmake_id(String make_id )                   { this.make_id = make_id; }
  public void  setdelivery_address(String delivery_address )          { this.delivery_address = delivery_address; }
}