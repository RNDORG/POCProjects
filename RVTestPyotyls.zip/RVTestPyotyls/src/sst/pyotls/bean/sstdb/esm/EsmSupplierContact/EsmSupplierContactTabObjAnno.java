package sst.pyotls.bean.sstdb.esm.EsmSupplierContact;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ESM_SUPPLIER_CONTACT")
public class EsmSupplierContactTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="org_id")
  private String                    org_id;
  @Column(name="supplier_id")
  private String                 supplier_id;
  @Column(name="contact_person")
  private String                contact_person;
  @Column(name="contact_num")
  private String                 contact_num;
  @Column(name="seq_num")
  private byte                    seq_num;
  @Column(name="contact_type")
  private String                 contact_type;
  @Column(name="contact_place")
  private String                contact_place;



  public String getorg_id()                           { return org_id; }
  public String getsupplier_id()                        { return supplier_id; }
  public String getcontact_person()                       { return contact_person; }
  public String getcontact_num()                        { return contact_num; }
  public byte getseq_num()                           { return seq_num; }
  public String getcontact_type()                        { return contact_type; }
  public String getcontact_place()                       { return contact_place; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setsupplier_id(String supplier_id )               { this.supplier_id = supplier_id; }
  public void  setcontact_person(String contact_person )            { this.contact_person = contact_person; }
  public void  setcontact_num(String contact_num )               { this.contact_num = contact_num; }
  public void  setseq_num(byte seq_num )                    { this.seq_num = seq_num; }
  public void  setcontact_type(String contact_type )              { this.contact_type = contact_type; }
  public void  setcontact_place(String contact_place )             { this.contact_place = contact_place; }
}