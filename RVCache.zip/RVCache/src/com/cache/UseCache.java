package com.cache;

public class UseCache {

	public static void main (String args[]) {

	    Load_In_Cache cache=new Load_In_Cache();

	    //String nodeName = args [1];
	    String nodeName = "1";
	    System.out.println("NodeName "+nodeName);

        System.out.println("Node details"+cache.retrieveFromCache(nodeName) );
	    
	}

}
