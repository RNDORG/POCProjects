/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cache;

import java.io.Serializable;

/**
 *
 * @author Rajesh V
 */

public class NodeName implements Serializable 
    {
        private static final long serialVersionUID = 6392376146163510146L;
       
        private String nodeName;
        private int nodeId;
        private int maxCount;
        private int consumedCount;
        private int status;

		public NodeName ( String nodeName, int nodeId, int maxCount, int consumedCount, int status ) 
        {
            this.nodeName = nodeName;
            this.nodeId = nodeId;
            this.maxCount = maxCount;
            this.consumedCount = consumedCount;
            this.status = status;
        }

    
        public String getNodeName() {
			return nodeName;
		}


		public void setNodeName(String nodeName) {
			this.nodeName = nodeName;
		}


		/**
		 * @return the nodeId
		 */
		public int getNodeId() {
			return nodeId;
		}


		/**
		 * @param nodeId the nodeId to set
		 */
		public void setNodeId(int nodeId) {
			this.nodeId = nodeId;
		}


		/**
		 * @return the maxCount
		 */
		public int getMaxCount() {
			return maxCount;
		}


		/**
		 * @param maxCount the maxCount to set
		 */
		public void setMaxCount(int maxCount) {
			this.maxCount = maxCount;
		}


		/**
		 * @return the consumedCount
		 */
		public int getConsumedCount() {
			return consumedCount;
		}


		/**
		 * @param consumedCount the consumedCount to set
		 */
		public void setConsumedCount(int consumedCount) {
			this.consumedCount = consumedCount;
		}


		/**
		 * @return the status
		 */
		public int getStatus() {
			return status;
		}


		/**
		 * @param status the status to set
		 */
		public void setStatus(int status) {
			this.status = status;
		}


		/**
		 * @return the serialversionuid
		 */
		public static long getSerialversionuid() {
			return serialVersionUID;
		}


	@Override
        public String toString() 
        {
		   return String.format("NodeName %s NodeId %d maxCount %d ", nodeName, nodeId, maxCount);
        }
    }

