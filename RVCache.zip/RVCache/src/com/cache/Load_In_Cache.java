package com.cache;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.apache.commons.jcs.JCS;
import org.apache.commons.jcs.access.CacheAccess;
import org.apache.commons.jcs.access.exception.CacheException;

/**
 *
 * @author Rajesh V
 */
public class Load_In_Cache {

	private CacheAccess<String, NodeName> cache = null;
    
    public Load_In_Cache(){
         try 
        {
            cache = JCS.getInstance( "RV" );
            Load_Cache();
                                    
        }
        catch ( CacheException e ) 
        {
            System.out.println( String.format( "Exception occurs in initializing cache: %s", e.getMessage() ) );
        }
    }

	public void putInCache(NodeName nodeName) {
		String key = nodeName.getNodeName();
		try {
			cache.put(key, nodeName);
		} catch (CacheException e) {
			System.out.println("Exception in loading node detail in the cache, for Node" + key + " Exception :: "
					+ e.getMessage());
		}
	}

	public NodeName retrieveFromCache(String nodeName) {
		System.out.println(cache.get(nodeName).toString());
		return cache.get(nodeName);
	}

	public void Load_Cache() {

		for (int i = 0; i < 10; i++) {
			if (i == 6) {
				NodeName nodeName = new NodeName(Integer.toString(i), 1, 50, 0, 0);
				putInCache(nodeName);
			} else {
				NodeName nodeName = new NodeName(Integer.toString(i), i, 50, 0, 0);
				putInCache(nodeName);
			}
		}

	}

}
