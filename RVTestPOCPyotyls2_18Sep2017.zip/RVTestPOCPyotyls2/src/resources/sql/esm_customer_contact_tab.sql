CREATE TABLE ESM_CUSTOMER_CONTACT
(
  ORG_ID                                                                                              VARCHAR(10),
  CUSTOMER_ID                                                                                         VARCHAR(10),
  CONTACT_PERSON                                                                                      VARCHAR(30),
  CONTACT_NUM                                                                                         VARCHAR(60),
  SEQ_NUM                                                                                             VARCHAR(10),
  CONTACT_TYPE                                                                                        VARCHAR(10),
  CONTACT_PLACE                                                                                       VARCHAR(10)
)
 WITH OIDS;
