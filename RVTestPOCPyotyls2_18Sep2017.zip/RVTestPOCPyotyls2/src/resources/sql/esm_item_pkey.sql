ALTER TABLE           ESM_ITEM
  ADD                 CONSTRAINT ESM_ITEM_PK
  PRIMARY             KEY
  ( ORG_ID, ITEM_CODE )
;
