package sst.pyotyls.aq;

/*
Producer.java

Simple JMS producer for Apache ActiveMQ

(c)2013 Kevin Boone
 */

// Note that the only Apache-specific class referred to in the source is
//  the one that provides the initial broker connection. The rest is
//  standard JMS
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.log4j.Logger;

import java.util.Date;

import javax.jms.*;

public class BProducer3 {
	
	private static final Logger logger = Logger.getLogger(BProducer3.class);
	//private final static String queueName = "RV_Queue_1";
	private final static String queueName = "java:jboss/activemq/queue/RVTestQueue";
	private static final String queueUrl = "tcp://localhost:61616";

	public static void main(String[] args) throws Exception {

		BProducer3 producer = new BProducer3();
		producer.sendMessage("Hello, Test message from RV [JNDI: java:jboss/activemq/queue/RVTestQueue]!" + new Date());
	}

	public static void sendMessage( String inMessage) throws Exception {
        logger.info("sendMessage : starts");
        
		try 
		{
			// Create a connection factory referring to the broker host and port
	        logger.info("sendMessage : queueUrl : "+queueUrl);
			ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory( queueUrl );

			// Note that a new thread is created by createConnection, and it
			// does not stop even if connection.stop() is called. We must
			// shut down the JVM using System.exit() to end the program
			Connection connection = factory.createConnection();
	        logger.info("sendMessage : queue factory connected");

			// Start the connection
			connection.start();

			// Create a non-transactional session with automatic acknowledgement
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
	        logger.info("sendMessage : queue session connected");

			// Create a reference to the queue test_queue in this session. Note
			// that ActiveMQ has auto-creation enabled by default, so this JMS
			// destination will be created on the broker automatically
			Queue queue = session.createQueue( queueName );
	        logger.info("sendMessage : queue created");

			// Create a producer for test_queue
			MessageProducer producer = session.createProducer(queue);
	        logger.info("sendMessage : queue producer created");

			// Create a simple text message and send it
			TextMessage message = session.createTextMessage( inMessage );
			logger.info("Message # ["+inMessage+"]" + new Date());
			
			producer.send(message);
	        logger.info("sendMessage : message sent");

			// Stop the connection � good practice but redundant here
			connection.stop();
	        logger.info("sendMessage : queue connection closed");
			//System.exit(0);
		}
		catch (Exception exp)
		{
			logger.info("Exception in sendMessage : "+exp.getMessage());
			exp.printStackTrace();
		}
		
        logger.info("sendMessage : ends");

	}
}
