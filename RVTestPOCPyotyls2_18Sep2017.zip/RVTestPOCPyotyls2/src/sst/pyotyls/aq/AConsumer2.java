package sst.pyotyls.aq;

// Note that the only Apache-specific class referred to in the source is the one that provides the initial broker connection. 
// The rest is standard JMS
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.log4j.Logger;

import javax.jms.*;

public class AConsumer2 {
	
	private static final Logger logger = Logger.getLogger(AConsumer2.class);
	//private final static String queueName = "RV_Queue_1";
	private final static String queueName = "java:jboss/ApacheMQServerV5_15/Queue/RV_Queue_1";
	private static final String queueUrl = "tcp://localhost:61616";

	public static void main(String[] args) throws Exception {

		AConsumer2 consumer = new AConsumer2();
		String message = consumer.receiveMessage();
		logger.info("Post receiveMessage : ["+message+"]");
	}
	
	public String receiveMessage() throws Exception {
		TextMessage textMessage = null;
        logger.info("receiveMessage : starts");
		try
		{
			// Create a connection factory referring to the broker host and port
	        logger.info("receiveMessage : queueUrl: "+queueUrl);
			ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory( queueUrl );

			// Note that a new thread is created by createConnection, and it
			// does not stop even if connection.stop() is called. We must
			// shut down the JVM using System.exit() to end the program
			Connection connection = factory.createConnection();
	        logger.info("receiveMessage : factory connection created");

			// Start the connection
			connection.start();

			// Create a non-transactional session with automatic acknowledgement
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
	        logger.info("receiveMessage : connection session created");

			// Create a reference to the queue test_queue in this session. Note
			// that ActiveMQ has auto-creation enabled by default, so this JMS
			// destination will be created on the broker automatically
			Queue queue = session.createQueue( queueName );
	        logger.info("receiveMessage : queue created");

			int messages = 0;
			MessageConsumer consumer = session.createConsumer(queue);
	        logger.info("receiveMessage : message consumer created");

	        textMessage = (TextMessage) consumer.receive();
			logger.info("Message #" + messages + ": " + textMessage.getText());

//			final int MESSAGES_TO_CONSUME = 10;
//			do {
//				TextMessage message = (TextMessage) consumer.receive();
//				messages++;
//				System.out.println("Message #" + messages + ": " + message.getText());
//			} while (messages < MESSAGES_TO_CONSUME);

			// Stop the connection � good practice but redundant here
			connection.stop();
	        logger.info("receiveMessage : connection stopped");

			//System.exit(0);
		}
		catch (Exception exp)
		{
			logger.info("Exception in receiveMessage : "+exp.getMessage());
			exp.printStackTrace();
			return null;
		}
	       
		logger.info("receiveMessage : ends");

		return textMessage.getText();

	}
}