package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem;


public class EsmItemPkeyObj
{
  public String                                 org_id;
  public String                                 item_code;
}