package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItemRate;


public class EsmItemRatePkeyObj
{
  public String                                 item_code;
  public String                                 make_id;
  public String                                 source_id;
}