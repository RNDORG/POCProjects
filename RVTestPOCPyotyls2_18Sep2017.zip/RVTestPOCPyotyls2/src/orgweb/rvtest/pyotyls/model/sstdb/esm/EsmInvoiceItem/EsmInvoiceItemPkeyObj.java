package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmInvoiceItem;


public class EsmInvoiceItemPkeyObj
{
  public String                                 invoice_num;
  public String                                 item_code;
  public String                                 oa_num;
  public String                                 make_id;
}