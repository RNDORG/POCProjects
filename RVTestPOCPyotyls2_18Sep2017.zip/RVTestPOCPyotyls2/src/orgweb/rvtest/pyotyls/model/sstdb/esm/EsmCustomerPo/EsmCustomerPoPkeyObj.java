package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo;


public class EsmCustomerPoPkeyObj
{
  public String                                 oa_num;
}