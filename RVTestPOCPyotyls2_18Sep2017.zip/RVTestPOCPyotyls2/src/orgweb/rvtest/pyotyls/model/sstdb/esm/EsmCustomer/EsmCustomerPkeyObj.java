package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer;


public class EsmCustomerPkeyObj
{
  public String                                 org_id;
  public String                                 customer_id;
}