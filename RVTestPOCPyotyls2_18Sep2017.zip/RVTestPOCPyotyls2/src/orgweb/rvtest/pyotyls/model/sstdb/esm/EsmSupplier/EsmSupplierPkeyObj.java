package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmSupplier;


public class EsmSupplierPkeyObj
{
  public String                                 org_id;
  public String                                 supplier_id;
}