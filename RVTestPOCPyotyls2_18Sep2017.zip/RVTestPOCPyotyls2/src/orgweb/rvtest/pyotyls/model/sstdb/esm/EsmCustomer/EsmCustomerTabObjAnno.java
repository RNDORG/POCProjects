package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="ESM_CUSTOMER")
public class EsmCustomerTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="org_id")
  private String                    org_id;
  @Column(name="customer_id")
  private String                 customer_id;
  @Column(name="customer_type")
  private String                customer_type;
  @Column(name="customer_ctg")
  private String                 customer_ctg;
  @Column(name="customer_name")
  private String                customer_name;
  @Column(name="customer_group")
  private String                customer_group;
  @Column(name="referred_by")
  private String                 referred_by;
  @Column(name="turn_over")
  private double                  turn_over;
  @Column(name="business_area_cd")
  private String               business_area_cd;
  @Column(name="state_code")
  private String                  state_code;
  @Column(name="region_id")
  private String                  region_id;
  @Column(name="country_code")
  private String                 country_code;
  @Column(name="status")
  private String                    status;
  @Column(name="expiration_date")
  private String               expiration_date;
  @Column(name="effective_date")
  private String                effective_date;
  @Column(name="business_type")
  private String                business_type;
  @Column(name="business_est_date")
  private String              business_est_date;
  @Column(name="employee_strength")
  private int                employee_strength;
  @Column(name="business_currency")
  private String              business_currency;
  @Column(name="address_1")
  private String                  address_1;
  @Column(name="address_2")
  private String                  address_2;
  @Column(name="address_3")
  private String                  address_3;
  @Column(name="cst_form_num")
  private String                 cst_form_num;
  @Column(name="cst_form_date")
  private String                cst_form_date;
  @Column(name="lst_form_num")
  private String                 lst_form_num;
  @Column(name="lst_form_date")
  private String                lst_form_date;
  @Column(name="tin_num")
  private String                   tin_num;
  @Column(name="tin_date")
  private String                   tin_date;
  @Column(name="pan_num")
  private String                   pan_num;
  @Column(name="pan_date")
  private String                   pan_date;
  @Column(name="tan_num")
  private String                   tan_num;
  @Column(name="tan_date")
  private String                   tan_date;
  @Column(name="strn_num")
  private String                   strn_num;
  @Column(name="strn_date")
  private String                  strn_date;
  @Column(name="account_num")
  private String                 account_num;
  @Column(name="bal_close")
  private double                  bal_close;
  @Column(name="bal_open")
  private double                   bal_open;
  @Column(name="dr_amt")
  private double                    dr_amt;
  @Column(name="cr_amt")
  private double                    cr_amt;
  @Column(name="ar_bal")
  private double                    ar_bal;
  @Column(name="sal_cycle_code")
  private String                sal_cycle_code;
  @Column(name="prev_sal_cycle_code")
  private String             prev_sal_cycle_code;
  @Column(name="next_sal_cycle_code")
  private String             next_sal_cycle_code;
  @Column(name="sal_cycle_change_sts")
  private String             sal_cycle_change_sts;
  @Column(name="sal_cycle_change_sts_date")
  private String          sal_cycle_change_sts_date;
  @Column(name="curr_sal_cycle_year")
  private short              curr_sal_cycle_year;
  @Column(name="curr_sal_cycle_month")
  private byte              curr_sal_cycle_month;
  @Column(name="last_sal_cycle_year")
  private short              last_sal_cycle_year;
  @Column(name="last_sal_cycle_month")
  private byte              last_sal_cycle_month;
  @Column(name="salary_run_sts")
  private String                salary_run_sts;
  @Column(name="salary_run_sts_date")
  private String             salary_run_sts_date;
  @Column(name="salary_apr_sts")
  private String                salary_apr_sts;
  @Column(name="salary_apr_sts_date")
  private String             salary_apr_sts_date;
  @Column(name="bill_cycle_code")
  private String               bill_cycle_code;
  @Column(name="prev_bill_cycle_code")
  private String             prev_bill_cycle_code;
  @Column(name="next_bill_cycle_code")
  private String             next_bill_cycle_code;
  @Column(name="bill_cycle_change_sts")
  private String            bill_cycle_change_sts;
  @Column(name="bill_cycle_change_sts_date")
  private String          bill_cycle_change_sts_date;
  @Column(name="curr_bill_cycle_year")
  private short             curr_bill_cycle_year;
  @Column(name="curr_bill_cycle_month")
  private byte             curr_bill_cycle_month;
  @Column(name="last_bill_cycle_year")
  private short             last_bill_cycle_year;
  @Column(name="last_bill_cycle_month")
  private byte             last_bill_cycle_month;
  @Column(name="bill_run_sts")
  private String                 bill_run_sts;
  @Column(name="bill_run_sts_date")
  private String              bill_run_sts_date;
  @Column(name="bill_apr_sts")
  private String                 bill_apr_sts;
  @Column(name="bill_apr_sts_date")
  private String              bill_apr_sts_date;



  public String getorg_id()                           { return org_id; }
  public String getcustomer_id()                        { return customer_id; }
  public String getcustomer_type()                       { return customer_type; }
  public String getcustomer_ctg()                        { return customer_ctg; }
  public String getcustomer_name()                       { return customer_name; }
  public String getcustomer_group()                       { return customer_group; }
  public String getreferred_by()                        { return referred_by; }
  public double getturn_over()                         { return turn_over; }
  public String getbusiness_area_cd()                      { return business_area_cd; }
  public String getstate_code()                         { return state_code; }
  public String getregion_id()                         { return region_id; }
  public String getcountry_code()                        { return country_code; }
  public String getstatus()                           { return status; }
  public String getexpiration_date()                      { return expiration_date; }
  public String geteffective_date()                       { return effective_date; }
  public String getbusiness_type()                       { return business_type; }
  public String getbusiness_est_date()                     { return business_est_date; }
  public int getemployee_strength()                       { return employee_strength; }
  public String getbusiness_currency()                     { return business_currency; }
  public String getaddress_1()                         { return address_1; }
  public String getaddress_2()                         { return address_2; }
  public String getaddress_3()                         { return address_3; }
  public String getcst_form_num()                        { return cst_form_num; }
  public String getcst_form_date()                       { return cst_form_date; }
  public String getlst_form_num()                        { return lst_form_num; }
  public String getlst_form_date()                       { return lst_form_date; }
  public String gettin_num()                          { return tin_num; }
  public String gettin_date()                          { return tin_date; }
  public String getpan_num()                          { return pan_num; }
  public String getpan_date()                          { return pan_date; }
  public String gettan_num()                          { return tan_num; }
  public String gettan_date()                          { return tan_date; }
  public String getstrn_num()                          { return strn_num; }
  public String getstrn_date()                         { return strn_date; }
  public String getaccount_num()                        { return account_num; }
  public double getbal_close()                         { return bal_close; }
  public double getbal_open()                          { return bal_open; }
  public double getdr_amt()                           { return dr_amt; }
  public double getcr_amt()                           { return cr_amt; }
  public double getar_bal()                           { return ar_bal; }
  public String getsal_cycle_code()                       { return sal_cycle_code; }
  public String getprev_sal_cycle_code()                    { return prev_sal_cycle_code; }
  public String getnext_sal_cycle_code()                    { return next_sal_cycle_code; }
  public String getsal_cycle_change_sts()                    { return sal_cycle_change_sts; }
  public String getsal_cycle_change_sts_date()                 { return sal_cycle_change_sts_date; }
  public short getcurr_sal_cycle_year()                     { return curr_sal_cycle_year; }
  public byte getcurr_sal_cycle_month()                     { return curr_sal_cycle_month; }
  public short getlast_sal_cycle_year()                     { return last_sal_cycle_year; }
  public byte getlast_sal_cycle_month()                     { return last_sal_cycle_month; }
  public String getsalary_run_sts()                       { return salary_run_sts; }
  public String getsalary_run_sts_date()                    { return salary_run_sts_date; }
  public String getsalary_apr_sts()                       { return salary_apr_sts; }
  public String getsalary_apr_sts_date()                    { return salary_apr_sts_date; }
  public String getbill_cycle_code()                      { return bill_cycle_code; }
  public String getprev_bill_cycle_code()                    { return prev_bill_cycle_code; }
  public String getnext_bill_cycle_code()                    { return next_bill_cycle_code; }
  public String getbill_cycle_change_sts()                   { return bill_cycle_change_sts; }
  public String getbill_cycle_change_sts_date()                 { return bill_cycle_change_sts_date; }
  public short getcurr_bill_cycle_year()                    { return curr_bill_cycle_year; }
  public byte getcurr_bill_cycle_month()                    { return curr_bill_cycle_month; }
  public short getlast_bill_cycle_year()                    { return last_bill_cycle_year; }
  public byte getlast_bill_cycle_month()                    { return last_bill_cycle_month; }
  public String getbill_run_sts()                        { return bill_run_sts; }
  public String getbill_run_sts_date()                     { return bill_run_sts_date; }
  public String getbill_apr_sts()                        { return bill_apr_sts; }
  public String getbill_apr_sts_date()                     { return bill_apr_sts_date; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcustomer_id(String customer_id )               { this.customer_id = customer_id; }
  public void  setcustomer_type(String customer_type )             { this.customer_type = customer_type; }
  public void  setcustomer_ctg(String customer_ctg )              { this.customer_ctg = customer_ctg; }
  public void  setcustomer_name(String customer_name )             { this.customer_name = customer_name; }
  public void  setcustomer_group(String customer_group )            { this.customer_group = customer_group; }
  public void  setreferred_by(String referred_by )               { this.referred_by = referred_by; }
  public void  setturn_over(double turn_over )                 { this.turn_over = turn_over; }
  public void  setbusiness_area_cd(String business_area_cd )          { this.business_area_cd = business_area_cd; }
  public void  setstate_code(String state_code )                { this.state_code = state_code; }
  public void  setregion_id(String region_id )                 { this.region_id = region_id; }
  public void  setcountry_code(String country_code )              { this.country_code = country_code; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setbusiness_type(String business_type )             { this.business_type = business_type; }
  public void  setbusiness_est_date(String business_est_date )         { this.business_est_date = business_est_date; }
  public void  setemployee_strength(int employee_strength )           { this.employee_strength = employee_strength; }
  public void  setbusiness_currency(String business_currency )         { this.business_currency = business_currency; }
  public void  setaddress_1(String address_1 )                 { this.address_1 = address_1; }
  public void  setaddress_2(String address_2 )                 { this.address_2 = address_2; }
  public void  setaddress_3(String address_3 )                 { this.address_3 = address_3; }
  public void  setcst_form_num(String cst_form_num )              { this.cst_form_num = cst_form_num; }
  public void  setcst_form_date(String cst_form_date )             { this.cst_form_date = cst_form_date; }
  public void  setlst_form_num(String lst_form_num )              { this.lst_form_num = lst_form_num; }
  public void  setlst_form_date(String lst_form_date )             { this.lst_form_date = lst_form_date; }
  public void  settin_num(String tin_num )                   { this.tin_num = tin_num; }
  public void  settin_date(String tin_date )                  { this.tin_date = tin_date; }
  public void  setpan_num(String pan_num )                   { this.pan_num = pan_num; }
  public void  setpan_date(String pan_date )                  { this.pan_date = pan_date; }
  public void  settan_num(String tan_num )                   { this.tan_num = tan_num; }
  public void  settan_date(String tan_date )                  { this.tan_date = tan_date; }
  public void  setstrn_num(String strn_num )                  { this.strn_num = strn_num; }
  public void  setstrn_date(String strn_date )                 { this.strn_date = strn_date; }
  public void  setaccount_num(String account_num )               { this.account_num = account_num; }
  public void  setbal_close(double bal_close )                 { this.bal_close = bal_close; }
  public void  setbal_open(double bal_open )                  { this.bal_open = bal_open; }
  public void  setdr_amt(double dr_amt )                    { this.dr_amt = dr_amt; }
  public void  setcr_amt(double cr_amt )                    { this.cr_amt = cr_amt; }
  public void  setar_bal(double ar_bal )                    { this.ar_bal = ar_bal; }
  public void  setsal_cycle_code(String sal_cycle_code )            { this.sal_cycle_code = sal_cycle_code; }
  public void  setprev_sal_cycle_code(String prev_sal_cycle_code )       { this.prev_sal_cycle_code = prev_sal_cycle_code; }
  public void  setnext_sal_cycle_code(String next_sal_cycle_code )       { this.next_sal_cycle_code = next_sal_cycle_code; }
  public void  setsal_cycle_change_sts(String sal_cycle_change_sts )      { this.sal_cycle_change_sts = sal_cycle_change_sts; }
  public void  setsal_cycle_change_sts_date(String sal_cycle_change_sts_date ) { this.sal_cycle_change_sts_date = sal_cycle_change_sts_date; }
  public void  setcurr_sal_cycle_year(short curr_sal_cycle_year )        { this.curr_sal_cycle_year = curr_sal_cycle_year; }
  public void  setcurr_sal_cycle_month(byte curr_sal_cycle_month )       { this.curr_sal_cycle_month = curr_sal_cycle_month; }
  public void  setlast_sal_cycle_year(short last_sal_cycle_year )        { this.last_sal_cycle_year = last_sal_cycle_year; }
  public void  setlast_sal_cycle_month(byte last_sal_cycle_month )       { this.last_sal_cycle_month = last_sal_cycle_month; }
  public void  setsalary_run_sts(String salary_run_sts )            { this.salary_run_sts = salary_run_sts; }
  public void  setsalary_run_sts_date(String salary_run_sts_date )       { this.salary_run_sts_date = salary_run_sts_date; }
  public void  setsalary_apr_sts(String salary_apr_sts )            { this.salary_apr_sts = salary_apr_sts; }
  public void  setsalary_apr_sts_date(String salary_apr_sts_date )       { this.salary_apr_sts_date = salary_apr_sts_date; }
  public void  setbill_cycle_code(String bill_cycle_code )           { this.bill_cycle_code = bill_cycle_code; }
  public void  setprev_bill_cycle_code(String prev_bill_cycle_code )      { this.prev_bill_cycle_code = prev_bill_cycle_code; }
  public void  setnext_bill_cycle_code(String next_bill_cycle_code )      { this.next_bill_cycle_code = next_bill_cycle_code; }
  public void  setbill_cycle_change_sts(String bill_cycle_change_sts )     { this.bill_cycle_change_sts = bill_cycle_change_sts; }
  public void  setbill_cycle_change_sts_date(String bill_cycle_change_sts_date ){ this.bill_cycle_change_sts_date = bill_cycle_change_sts_date; }
  public void  setcurr_bill_cycle_year(short curr_bill_cycle_year )       { this.curr_bill_cycle_year = curr_bill_cycle_year; }
  public void  setcurr_bill_cycle_month(byte curr_bill_cycle_month )      { this.curr_bill_cycle_month = curr_bill_cycle_month; }
  public void  setlast_bill_cycle_year(short last_bill_cycle_year )       { this.last_bill_cycle_year = last_bill_cycle_year; }
  public void  setlast_bill_cycle_month(byte last_bill_cycle_month )      { this.last_bill_cycle_month = last_bill_cycle_month; }
  public void  setbill_run_sts(String bill_run_sts )              { this.bill_run_sts = bill_run_sts; }
  public void  setbill_run_sts_date(String bill_run_sts_date )         { this.bill_run_sts_date = bill_run_sts_date; }
  public void  setbill_apr_sts(String bill_apr_sts )              { this.bill_apr_sts = bill_apr_sts; }
  public void  setbill_apr_sts_date(String bill_apr_sts_date )         { this.bill_apr_sts_date = bill_apr_sts_date; }
}