package orgweb.rvtest.pyotyls.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.*;

@Repository("esmItemDAO")
public class EsmItemDAOImpl implements EsmItemDAOIFace {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<EsmItemTabObjAnno> getList() {
		return (List<EsmItemTabObjAnno>) sessionFactory.getCurrentSession().createCriteria(EsmItemTabObjAnno.class).list();
	}

	@Override
	public EsmItemTabObjAnno get(String itemCode) {
		return (EsmItemTabObjAnno) sessionFactory.getCurrentSession().get(EsmItemTabObjAnno.class, itemCode);
	}

	@Override
	public EsmItemTabObjAnno create(EsmItemTabObjAnno esmItemTabObjAnno) {
		sessionFactory.getCurrentSession().saveOrUpdate(esmItemTabObjAnno);
		return esmItemTabObjAnno;
	}

	@Override
	public EsmItemTabObjAnno createOrEdit(EsmItemTabObjAnno esmItemTabObjAnno) {
		sessionFactory.getCurrentSession().saveOrUpdate(esmItemTabObjAnno);
		return esmItemTabObjAnno;
	}
	
	@Override
	public String delete(String itemCode) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM ESB_ITEM WHERE ITEM_CODE = "+itemCode).executeUpdate();
		return itemCode;
	}

}