package orgweb.rvtest.pyotyls.dao;

import java.util.List;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.EsmItemTabObjAnno;

public interface EsmItemDAOIFace {

	public List<EsmItemTabObjAnno> getList();

	public EsmItemTabObjAnno get(String itemCode);
	
	public EsmItemTabObjAnno create(EsmItemTabObjAnno esmItemTabObjAnno);

	public EsmItemTabObjAnno createOrEdit(EsmItemTabObjAnno esmItemTabObjAnno);

	public String delete(String itemCode);

	
	//public EsmCustomerPoTabObjAnno update(String oaNum, EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno);
	
}
