package orgweb.rvtest.pyotyls.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.EsmItemTabObjAnno;
import orgweb.rvtest.pyotyls.service.EsmItemServiceIFace;

@Controller
public class ServletControllerItemMaster {
	
	private static final Logger logger = Logger.getLogger(ServletControllerItemMaster.class);

	@Autowired
	private EsmItemServiceIFace esmItemService;

	@RequestMapping(value={"/manageItemMasterPage/new", "/manageItemMasterPage/list"}, method = RequestMethod.GET)
	public ModelAndView getItemMasterListMVC() {
		logger.info("getItemMasterListMVC : starts");
		ModelAndView modelAndView = new ModelAndView("manageItemMaster");
		modelAndView.addObject("esmItemTabObjAnno", new EsmItemTabObjAnno());
		modelAndView.addObject("esmItemTabObjAnnoList", (List<EsmItemTabObjAnno>) esmItemService.getList());
		logger.info("getItemMasterListMVC : ends");
		return modelAndView;
	}

	@RequestMapping(value={"/manageItemMasterPage/edit"}, method = RequestMethod.GET)
	public ModelAndView editItemMasterListMVC(@ModelAttribute("command")  EsmItemTabObjAnno esmItemTabObjAnno, BindingResult result) {
		logger.info("editItemMasterListMVC : starts");
		if (result.hasErrors()) {
			System.out.println("Binding result encountered");
	    }
		Map<String, Object> mapModel = new HashMap<String, Object>();
		mapModel.put("esmItemTabObjAnno",  esmItemService.get(esmItemTabObjAnno.getitem_code()));
		mapModel.put("esmItemTabObjAnnoList",  (List<EsmItemTabObjAnno>) esmItemService.getList());
		logger.info("editItemMasterListMVC : ends");
		return new ModelAndView("manageItemMaster", mapModel);
	}

	@RequestMapping(value = "/manageItemMasterPage/delete", method = RequestMethod.GET)
	public ModelAndView deleteItemMasterMVC(@ModelAttribute("command")  EsmItemTabObjAnno esmItemTabObjAnno, BindingResult result) {
		logger.info("deleteItemMasterMVC : starts");
		esmItemService.delete(esmItemTabObjAnno.getitem_code());
		Map<String, Object> mapModel = new HashMap<String, Object>();
		//mapModel.put("esmItemTabObjAnno",  esmItemService.get(esmItemTabObjAnno.getitem_code()));
		mapModel.put("esmItemTabObjAnnoList",  (List<EsmItemTabObjAnno>) esmItemService.getList());
		logger.info("deleteItemMasterMVC : ends");
		return new ModelAndView("manageItemMaster", mapModel);
	}

	@RequestMapping(value = "/manageItemMasterPage/save", method = RequestMethod.POST)
	public ModelAndView saveItemMasterMVC(@ModelAttribute("command") EsmItemTabObjAnno esmItemTabObjAnno, BindingResult result) {
		logger.info("saveItemMasterMVC : starts");
		esmItemService.createOrEdit(esmItemTabObjAnno);
		Map<String, Object> mapModel = new HashMap<String, Object>();
		mapModel.put("esmItemTabObjAnnoList",  (List<EsmItemTabObjAnno>) esmItemService.getList());
		logger.info("saveItemMasterMVC : ends");
		//return new ModelAndView("redirect:/views/manageItemMaster.html");
		return new ModelAndView("manageItemMaster", mapModel);
	}

}
