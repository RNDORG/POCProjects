package orgweb.rvtest.pyotyls.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo.EsmCustomerPoTabObjAnno;
import orgweb.rvtest.pyotyls.service.EsmCustomerPoServiceIFace;

@RestController
public class RestControllerCustomerOrder {

	
	//@Autowired
	//private EsmCustomerPoDAO esmCustomerPoDAO;

	@Autowired
	private EsmCustomerPoServiceIFace esmCustomerPoService;

	@GetMapping("/manageCustomerOrder/list")
	public List<EsmCustomerPoTabObjAnno> getCustomerOrderList() {
		//return esmCustomerPoDAO.getEsmCustomerPoTabObjAnnoList();
		return esmCustomerPoService.getList();
	}

	@GetMapping("/manageCustomerOrder/get/{oaNum}")
	public ResponseEntity getCustomerOrderRecord(@PathVariable("oaNum") String oaNum) {

		//EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno = esmCustomerPoDAO.get(oaNum);
		EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno = esmCustomerPoService.get(oaNum);
		if (esmCustomerPoTabObjAnno == null) {
			return new ResponseEntity("No Customer found for OA_NUM " + oaNum, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(esmCustomerPoTabObjAnno, HttpStatus.OK);
	}

	@PostMapping(value = "/manageCustomerOrder/submit")
	public ResponseEntity submitCustomerOrder(@RequestBody EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno) {

		//esmCustomerPoDAO.create(esmCustomerPoTabObjAnno);
		try {
			sst.pyotyls.aq.Producer.sendMessage( esmCustomerPoTabObjAnno.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity(esmCustomerPoTabObjAnno, HttpStatus.OK);
	}


	@PostMapping(value = "/manageCustomerOrder/create")
	public ResponseEntity createCustomerOrder(@RequestBody EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno) {
		//return new ResponseEntity(esmCustomerPoDAO.create(esmCustomerPoTabObjAnno), HttpStatus.OK);
		return new ResponseEntity(esmCustomerPoService.createOrEdit(esmCustomerPoTabObjAnno), HttpStatus.OK);
	}

	@DeleteMapping("/manageCustomerOrder/delete/{oaNum}")
	public ResponseEntity deleteCustomerOrder(@PathVariable String oaNum) {
		//if (null == esmCustomerPoDAO.delete(oaNum)) {
		if (null == esmCustomerPoService.delete(oaNum)) {
			return new ResponseEntity("No Customer found for OA_NUM " + oaNum, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(oaNum, HttpStatus.OK);
	}

	@PutMapping("/manageCustomerOrder/update/{oaNum}")
	public ResponseEntity updateCustomerOrder(@PathVariable String oaNum, @RequestBody EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno) {
		//esmCustomerPoTabObjAnno = esmCustomerPoDAO.update(oaNum, esmCustomerPoTabObjAnno);
		esmCustomerPoTabObjAnno = esmCustomerPoService.createOrEdit(esmCustomerPoTabObjAnno);
		if (null == esmCustomerPoTabObjAnno) {
			return new ResponseEntity("No Customer found for OA_NUM " + oaNum, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(esmCustomerPoTabObjAnno, HttpStatus.OK);
	}

}