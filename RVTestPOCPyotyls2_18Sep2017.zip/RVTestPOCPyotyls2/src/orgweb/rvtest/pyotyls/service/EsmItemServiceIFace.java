package orgweb.rvtest.pyotyls.service;

import java.util.List;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.EsmItemTabObjAnno;

public interface EsmItemServiceIFace {

	List<EsmItemTabObjAnno> getList();

	EsmItemTabObjAnno get(String itemCode);

	String delete(String itemCode);

	public EsmItemTabObjAnno createOrEdit (EsmItemTabObjAnno esmItemTabObjAnno);
	

}
