package orgweb.rvtest.pyotyls.service;

import java.util.List;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo.EsmCustomerPoTabObjAnno;

public interface EsmCustomerPoServiceIFace {

	List<EsmCustomerPoTabObjAnno> getList();

	EsmCustomerPoTabObjAnno get(String oaNum);

	String delete(String oaNum);

	public EsmCustomerPoTabObjAnno createOrEdit (EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno);
	

}
