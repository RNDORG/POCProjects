package orgweb.rvtest.pyotyls.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import orgweb.rvtest.pyotyls.dao.EsmItemDAOIFace;
import orgweb.rvtest.pyotyls.dao.EsmItemDAOImpl;
import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.EsmItemTabObjAnno;

@Service("esmItemService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class EsmItemServiceImpl implements EsmItemServiceIFace {
	
	@Autowired
	private EsmItemDAOIFace esmItemDAO;

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public EsmItemTabObjAnno createOrEdit (EsmItemTabObjAnno esmItemTabObjAnno) {
		return esmItemDAO.createOrEdit(esmItemTabObjAnno);
	}

	@Override
	public List<EsmItemTabObjAnno> getList() {
		return esmItemDAO.getList();
	}

	@Override
	public EsmItemTabObjAnno get (String itemCode) {
		return esmItemDAO.get(itemCode);
	}

	@Override
	public String delete (String itemCode) {
		return esmItemDAO.delete(itemCode);
	}

}
