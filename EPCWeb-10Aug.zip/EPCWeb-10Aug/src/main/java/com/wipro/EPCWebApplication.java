/*
 * Copyright 2012-2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.wipro;

import java.lang.reflect.Field;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import ch.qos.logback.classic.ViewStatusMessagesServlet;

import com.wipro.common.config.domain.ServerStatus;
import com.wipro.common.config.service.ServerStatusService;
import com.wipro.common.gs.mailnotification.SmtpMailSender;
import com.wipro.common.gs.util.GetPortAddressController;
import com.wipro.common.version.ReadFileInMap;
import com.wipro.epc.controller.CachedProductController;

/**
 * @author Developer
 * @version 1.0
 * type EPCWebApplication
 */
@SpringBootApplication
@EnableScheduling
public class EPCWebApplication implements CommandLineRunner {

	/*
	 * private static Logger logger =
	 * LoggerFactory.getLogger(EPCWebApplication.class);
	 */

	/*
	 * @Autowired ExcelDisplay excelDisplay;
	 */
	private static Logger logger = LoggerFactory.getLogger(EPCWebApplication.class);
	
	@Autowired
	private SmtpMailSender mailSender;

	@Autowired
	private ServerStatusService serverStatusService;
	
	@Autowired
	private GetPortAddressController getPortAddressController;
	
	@Value("${spring.datasource.jndi-name:na}")
	private String dataSource; 
	
	@Value("${spring.profiles.active:nonjndi}")
	private String profile; 
	
	@Autowired
	CachedProductController cacheProdController;
	
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		// Update the is_spring_boot_app property
		Map<String, String> env = new HashMap<String, String>();
		env.put("is_spring_boot_app", "true");
		setEnv(env);

		Map<String, String> sys_env = System.getenv();
		if (sys_env.get("spring.profiles.active") == null) {
			Map<String, String> env2 = new HashMap<String, String>();
			env2.put("epcContainerFlag", "nonjndi-h2");
			setEnv(env2);
		}

		// new SpringApplicationBuilder(EPCWebApplication.class).run(args);

		// set is_spring_boot=true
		SpringApplicationBuilder builder = new SpringApplicationBuilder(
				EPCWebApplication.class);
		builder.headless(false);
		ConfigurableApplicationContext context = builder.run(args);

	}

	/**
	 * @return
	 */
	@Bean
	public ServletRegistrationBean servletRegistrationBean() {
		/*
		 * logger.info(
		 * "--------------------------------------------------------BYE-----------------------"
		 * );
		 */return new ServletRegistrationBean(new ViewStatusMessagesServlet(),
				"/logbuffer/*");
	}

	/* (non-Javadoc)
	 * @see org.springframework.boot.CommandLineRunner#run(java.lang.String[])
	 */
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * @param newenv
	 */
	protected static void setEnv(Map<String, String> newenv) {
		try {
			Class<?> processEnvironmentClass = Class
					.forName("java.lang.ProcessEnvironment");
			Field theEnvironmentField = processEnvironmentClass
					.getDeclaredField("theEnvironment");
			theEnvironmentField.setAccessible(true);
			Map<String, String> env = (Map<String, String>) theEnvironmentField
					.get(null);
			env.putAll(newenv);
			Field theCaseInsensitiveEnvironmentField = processEnvironmentClass
					.getDeclaredField("theCaseInsensitiveEnvironment");
			theCaseInsensitiveEnvironmentField.setAccessible(true);
			Map<String, String> cienv = (Map<String, String>) theCaseInsensitiveEnvironmentField
					.get(null);
			cienv.putAll(newenv);
		} catch (NoSuchFieldException e) {
			try {
				Class[] classes = Collections.class.getDeclaredClasses();
				Map<String, String> env = System.getenv();
				for (Class cl : classes) {
					if ("java.util.Collections$UnmodifiableMap".equals(cl
							.getName())) {
						Field field = cl.getDeclaredField("m");
						field.setAccessible(true);
						Object obj = field.get(env);
						Map<String, String> map = (Map<String, String>) obj;
						map.clear();
						map.putAll(newenv);
					}
				}
			} catch (Exception e2) {
				logger.error(ExceptionUtils.getStackTrace(e2));
			}
		} catch (Exception e1) {
			logger.error(ExceptionUtils.getStackTrace(e1));
		}
	}

	/**
	 * @throws UnknownHostException 
	 * 	 * 
	 */
	@PostConstruct
	
	protected void SendDeploymentMail() throws UnknownHostException  {
		final String ip = InetAddress.getLocalHost().getHostAddress().trim();
		final String host =InetAddress.getLocalHost().getHostName().trim();
		ReadFileInMap readFile = new ReadFileInMap();
		Map<String, String>	 fileData = readFile.fileRead();
		String version = fileData.get("Version")+"."+fileData.get("Build_TimeStamp");
		String server = System.getProperty("jboss.server.name");
		if (server !=null){
			server = server+ " in ";
		}else{
			server="";
		}
		String subject= "EPC "+version+" is deployed on "+server+host+"@"+ip;
		Thread backgroudCall = new Thread(new Runnable(){				
			@Override
			public void run() {
				
				/*
					Code to put an entry in server status table when the 
					application gets deployed.
				*/
				
				/*
				 * Server status table insertion ends here.
				 */
				
				mailSender.send("supratim.sen@wipro.com,ashweeja.k88@wipro.com,keerthikumar.g63@wipro.com,kunal.gaurav1@wipro.com,vimala.n15@wipro.com", null, "somanath.bhat@wipro.com,manas.sahu1@wipro.com", "EPC Application Started on "+ip, subject, null);
				
				
				
				
				logger.info("Mail sent via container with subject "+subject );
				//logger.info("Mail sent via container with subject "+subject + serverName);
				
				
				try {			
					
					Thread.sleep(2000*60);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				String serverName = ip+":"+getPortAddressController.returnPortNumber();
				
				ServerStatus serverStatusObject = new ServerStatus(serverName,("java:jboss/datasources/EPCJDBCDataSource".equalsIgnoreCase(dataSource) ? 0 : 1));
				serverStatusService.entryIntoServerStatus(serverStatusObject);
		
				if(!("java:jboss/datasources/EPCJDBCDataSource".equalsIgnoreCase(dataSource))  && !profile.contains("nonjndi")) {
					
					MultiValueMap<String, String> valueMap = new LinkedMultiValueMap<String, String>();
					valueMap.add("id", "ALL");
					valueMap.add("broadcast", "false");
					valueMap.add("delay", "true");
					cacheProdController.reload(valueMap);
				}
				
				
			}
			
		});	
		backgroudCall.start();
	}
	
}
