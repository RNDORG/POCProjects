package com.wipro.epc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;

import com.wipro.common.config.service.ServerStatusService;
import com.wipro.epc.services.CachedProductService;

@RestController
public class CachedProductController {
	
	private static Logger logger =LoggerFactory.getLogger( CachedProductController.class);
	
	@Autowired
	CachedProductService cachedProductService;
	
	@Autowired
	ServerStatusService serverService;
	
	@RequestMapping(value="rest/extapi/v1/cache/product/reloadMemory", method=RequestMethod.GET)
	public String reloadMemory(@RequestParam MultiValueMap allRequestParams){
		
			return cachedProductService.reloadMemoryService(allRequestParams);
	}
	
	@RequestMapping(value="/rest/extapi/v1/cache/product/reloadMemoryLocal", method=RequestMethod.GET)
	public String reloadMemoryLocal(@RequestParam MultiValueMap allRequestParams){
		
		return cachedProductService.reloadMemoryLocalService(allRequestParams);
	}
	
	@RequestMapping(value="rest/extapi/v1/cache/product/reload", method=RequestMethod.GET)
	public String reload(@RequestParam MultiValueMap allRequestParams){
		
			return cachedProductService.reloadService(allRequestParams);
	}
	
	/*
	  class MCachedProductController {
  
   		"reLoadLocal" ids=ALL or 1,3,4,      
   			mCachedProductService.reloadLocal( ids ); // Reload only Memory from Physical table.  } 
  
   		"reload"  ids=ALL or 1,2,3 
  			mCachedProductService.reload( ids ); 
  		}
	 */

}
