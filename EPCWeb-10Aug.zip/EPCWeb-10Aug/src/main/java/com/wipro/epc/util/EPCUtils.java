package com.wipro.epc.util;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.epc.domain.EpcNotificationTemplate;
import com.wipro.epc.domain.EpcNotificationTemplateDetail;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.domain.EpcProductInitChannel;

/**
 * @author Developer
 * @version 1.0
 * type EPCUtils
 */
public class EPCUtils {

	/**
	 * @param ratePlanCategory
	 * @param addOnCategory
	 * @return
	 */
	public static boolean validateCategory(String ratePlanCategory, String addOnCategory){
		if( ratePlanCategory.equals(addOnCategory) ){
			return true;
		}
		if( "Both".equals(ratePlanCategory) && ("Prepaid".equals(addOnCategory) ||"Postpaid".equals(addOnCategory)) ){
			return true;
		}
		if( "Both".equals(addOnCategory) && ("Prepaid".equals(ratePlanCategory) ||"Postpaid".equals(ratePlanCategory)) ){
			return true;
		}
		return false;
	}
	
	/**
	 * @param ratePlanSubCategory
	 * @param addOnSubCategory
	 * @return
	 */
	public static boolean validateSubCategory(String ratePlanSubCategory, String addOnSubCategory){
		if( ratePlanSubCategory.equals(addOnSubCategory) ){
			return true;
		}
		if( "ALL".equals(ratePlanSubCategory) || "ALL".equals(addOnSubCategory) ){
			return true;
		}
		return false;
	}
	
	public static String objectToJson(Object obj) throws JsonProcessingException{
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(obj);
	}
	
	public static List<EpcProductInitChannel> deepCopyInitChannels(List<EpcProductInitChannel> srcChannels){
		List<EpcProductInitChannel> channels = new ArrayList<EpcProductInitChannel>();
		EpcProductInitChannel targetChannel = null;
		for(EpcProductInitChannel channel : srcChannels){
			targetChannel = new EpcProductInitChannel();
			BeanUtils.copyProperties(channel, targetChannel, new String []{"epcNotificationTemplate"} );
			if (channel.getEpcNotificationTemplate() != null){
				targetChannel.setEpcNotificationTemplate(deepCopyNotificationTemplate(channel.getEpcNotificationTemplate()));
			}
			channels.add(targetChannel);
		}
		return channels;
	}
	
	private static EpcNotificationTemplate deepCopyNotificationTemplate(
			EpcNotificationTemplate epcNotificationTemplate) {
		EpcNotificationTemplate epcNotificationTemplateTemp = new EpcNotificationTemplate();
		BeanUtils.copyProperties(epcNotificationTemplate, epcNotificationTemplateTemp, new String []{"epcNotificationTemplateDetail"} );
		List<EpcNotificationTemplateDetail> details = new ArrayList<EpcNotificationTemplateDetail>();
		EpcNotificationTemplateDetail detailTarget = null;
		if(epcNotificationTemplate.getEpcNotificationTemplateDetail() != null){
			for( EpcNotificationTemplateDetail detail : epcNotificationTemplate.getEpcNotificationTemplateDetail()){
				if (detail != null) {
					detailTarget = new EpcNotificationTemplateDetail();
					BeanUtils.copyProperties(detail, detailTarget);
					details.add(detailTarget);
				}
			}
			epcNotificationTemplateTemp.setEpcNotificationTemplateDetail(details);
		}
		return epcNotificationTemplateTemp;
	}

	public static List<EpcProductAttribute> deepCopyProdAttributes(List<EpcProductAttribute> srcAttrs){
		List<EpcProductAttribute> attrs = new ArrayList<EpcProductAttribute>();
		EpcProductAttribute targetAttr = null;
		for(EpcProductAttribute attr : srcAttrs){
			targetAttr = new EpcProductAttribute();
			BeanUtils.copyProperties(attr, targetAttr );
			attrs.add(targetAttr);
		}
		return attrs;
	}

	public static List<EpcProductDecomposition> deepCopyDecompositions(
			List<EpcProductDecomposition> epcProductDecomposition) {
		List<EpcProductDecomposition> decomps = new ArrayList<EpcProductDecomposition>();
		EpcProductDecomposition targetDecomp = null;
		for(EpcProductDecomposition decomp : epcProductDecomposition){
			
			if (decomp != null) {
				targetDecomp = new EpcProductDecomposition();
				BeanUtils.copyProperties(decomp, targetDecomp,
						new String[] { "epcNotificationTemplate" });
				
				if (decomp.getEpcNotificationTemplate() != null) {
					targetDecomp
							.setEpcNotificationTemplate(deepCopyNotificationTemplate(decomp
									.getEpcNotificationTemplate()));
				}
				decomps.add(targetDecomp);
			}
			
		}
		return decomps;
	}
	
	
}
