package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.FNFCallblockAttribute;
import com.wipro.epc.dto.ProviderAttributesQueryInput;
import com.wipro.epc.dto.ProviderAttributesQueryResponse;
import com.wipro.epc.repositories.EpcProductProviderSystemRepository;
import com.wipro.epc.util.Constants;


/**
 * @author Developer
 * @version 1.0
 * type ProviderProductQueryService
 */
@Service
public class ProviderAttributesQueryService {
	
	
	@Autowired
	EpcProductProviderSystemRepository epcProductProviderSystemRepository;
	
	@Autowired
	MCachedProductService mCachedProductService;
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	public ProviderAttributesQueryResponse queryProviderProduct(
			ProviderAttributesQueryInput queryInput, Map<String, List<String>> allRequestParams) {
		
		if(StringUtils.isBlank(queryInput.getFnf()) && StringUtils.isBlank(queryInput.getCallblock()) ){
			throw new GenericException("InvalidSearch", "Mandatory Fields are missing. Please provide any one field from (fnf, callblock).", "Mandatory Fields are missing. Please provide any one field from (fnf, callblock).");
		}
		
		String [] fnf =  null;
		if(StringUtils.isNotBlank(queryInput.getFnf())){
			fnf = queryInput.getFnf().split(":") ;
			if(fnf.length != 2){
				throw new GenericException("InvalidSearch", "Provider details for fnf is not in proper format.", "Provider details for fnf is not in proper format.");
			}
		}
		
		String [] callblock = null;
		if(StringUtils.isNotBlank(queryInput.getCallblock())){
			callblock = queryInput.getCallblock().split(":") ;
			if(callblock.length != 2){
				throw new GenericException("InvalidSearch", "Provider details for callblock is not in proper format.", "Provider details for callblock is not in proper format.");
			}
		}
		
		StringBuilder sqlQuery = new StringBuilder();
		sqlQuery.append("select  amst.attribute_name,pattr.attribute_uom, pattr.attribute_value1, pattr.attribute_value2, pattr.default_value1, pattr.default_value2, spec.product_short_code, spec.product_id ");
		sqlQuery.append("from ");
		sqlQuery.append("epc_product_specification spec, ");
		sqlQuery.append("epc_product_provider_system sys, ");
		sqlQuery.append("epc_product_attribute pattr, ");
		sqlQuery.append("epc_attribute_master amst ");
		sqlQuery.append("where pattr.product_id = sys.product_id ");
		sqlQuery.append("and spec.product_id = sys.product_id ");
		sqlQuery.append("and amst.attribute_id = pattr.attribute_id ");
		sqlQuery.append("and ( ");
		
		if(StringUtils.isNotBlank(queryInput.getFnf())){
			sqlQuery.append("(sys.provider_product_id ='").append(fnf[1]).append("' ");
			sqlQuery.append("and  ");
			sqlQuery.append("sys.provider_system_code ='").append(fnf[0]).append("' ");
			sqlQuery.append("and ");
			sqlQuery.append("amst.attribute_name in ('FNF_ONNET_ALLOWED','FNF_MAX_EXCEPT_SFNF','FNF_OFFNET_ALLOWED','FNF_SFNF_ALLOWED','FNF_LOCKING_PERIOD','FNF_SFNF_MUTUALLY_EXCLUSIVE','FNF_PRODUCT_DEFAULT_FLAG') ");
			sqlQuery.append(")  ");
		}
		if(StringUtils.isNotBlank(queryInput.getFnf()) && StringUtils.isNotBlank(queryInput.getCallblock())){
			sqlQuery.append("or ");
		}
		if(StringUtils.isNotBlank(queryInput.getCallblock())){
			sqlQuery.append("(sys.provider_product_id ='").append(callblock[1]).append("' "); 
			sqlQuery.append("and ");
			sqlQuery.append("sys.provider_system_code ='").append(callblock[0]).append("' ");
			sqlQuery.append("and  ");
			sqlQuery.append("amst.attribute_name in ('MAX_BLACK_LIST_COUNT','MAX_WHITE_LIST_COUNT') ");
			sqlQuery.append(") ");
		}
		sqlQuery.append(") ");
		sqlQuery.append("order by spec.product_short_code ");

		List<Object[]> attributes = epcProductProviderSystemRepository.getAttributeList(sqlQuery.toString());
		if(attributes != null && !attributes.isEmpty()){
			List<FNFCallblockAttribute> fnfList = new ArrayList<FNFCallblockAttribute>();
			List<FNFCallblockAttribute> callblockList = new ArrayList<FNFCallblockAttribute>();	
			Set<String> fnfId = new HashSet<String>();
			Set<String> callblockId = new HashSet<String>();
			Integer fnfProdId = null;
			Integer callblockProdId = null;
			for(Object[] obj : attributes){
				FNFCallblockAttribute attribute = new FNFCallblockAttribute();
				attribute.setAttributeName(obj[0].toString());
				if(obj[1] != null){
					attribute.setAttributeUom(obj[1].toString());
				}
				if(obj[2] != null){
					attribute.setAttributeValue1(obj[2].toString());
				}
				if(obj[3] != null){
					attribute.setAttributeValue2(obj[3].toString());
				}
				if(obj[4] != null){
					attribute.setDefaultValue1(obj[4].toString());
				}
				if(obj[5] != null){
					attribute.setDefaultValue2(obj[5].toString());
				}
				if(Arrays.asList(Constants.FNF_ATTRIBUTES).contains(obj[0])){
					if(fnfId.isEmpty()){
						fnfId.add(obj[6].toString());
						fnfProdId = Integer.valueOf(obj[7].toString());
						fnfList.add(attribute);
					}else if(fnfId.contains(obj[6].toString())){
						fnfList.add(attribute);
					}
				}else if(Arrays.asList(Constants.CALLBLOCK_ATTRIBUTES).contains(obj[0])){
					if(callblockId.isEmpty()){
						callblockId.add(obj[6].toString());
						callblockProdId = Integer.valueOf(obj[7].toString());
						callblockList.add(attribute);
					}else if(callblockId.contains(obj[6].toString())){
						callblockList.add(attribute);
					}
				}
			}
			ProviderAttributesQueryResponse response = new ProviderAttributesQueryResponse();
			if(!fnfList.isEmpty()){
				if (allRequestParams.get("with") != null && allRequestParams.get("with").contains("ta-TariffCtg")) {
					EpcProductSpecification prod = mCachedProductService
							.find(String.valueOf(fnfProdId));
					response.setFnfTariff(copyAttributes(prod
							.getEpcProductTariff()));
				}
				response.setFnf(fnfList);
			}
			if(!callblockList.isEmpty()){
				if (allRequestParams.get("with") != null && allRequestParams.get("with").contains("ta-TariffCtg")) {
					EpcProductSpecification prod = mCachedProductService
							.find(String.valueOf(callblockProdId));
					response.setCallblockTariff(copyAttributes(prod
							.getEpcProductTariff()));
				}
				response.setCallblock(callblockList);
			}
			return response;
		}
		return null;
	}
	
	private List<FNFCallblockAttribute> copyAttributes(List<EpcProductAttribute> list){
		if(list != null){
			List<FNFCallblockAttribute> fnfCbAttrs = new ArrayList<FNFCallblockAttribute>();
			FNFCallblockAttribute fnfCbAttr = null;
			for(EpcProductAttribute attr: list){
				fnfCbAttr = new FNFCallblockAttribute();
				fnfCbAttr.setAttributeName(attr.getEpcAttributeMaster().getAttributeName());
				fnfCbAttr.setAttributeUom(attr.getAttributeUom());
				fnfCbAttr.setAttributeValue1(attr.getAttributeValue1());
				fnfCbAttr.setAttributeValue2(attr.getAttributeValue2());
				fnfCbAttr.setDefaultValue1(attr.getDefaultValue1());
				fnfCbAttr.setDefaultValue2(attr.getDefaultValue2());
				fnfCbAttrs.add(fnfCbAttr);
			}
			return fnfCbAttrs;
		}
		return null;
	}

}
