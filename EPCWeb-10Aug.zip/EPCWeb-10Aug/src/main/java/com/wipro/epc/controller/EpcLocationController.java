
package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcLocation;
import com.wipro.epc.services.EpcLookupMasterService;
import com.wipro.epc.services.*;

/**
 * @author Developer
 * @version 1.0
 * type EpcLocationController
 */
@RestController

public class EpcLocationController {

	/**
	 * EpcLocationService EpcLocationController.java
	 */
	@Autowired
	EpcLocationService locationService;
	
	/**
	 * EpcLookupMasterService EpcLocationController.java
	 */
	@Autowired
	EpcLookupMasterService lookupMasterService;
	
	/**
	 * @param value
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/locations" , method=RequestMethod.GET)
	public List<EpcLocation> getLocations(@RequestParam(required=false) String value)
	{
		if(value==null)
			return locationService.getLocationList();
		else
			return locationService.locationsForCorrespdingIds(lookupMasterService.getLookupId(value));
	}
	
}




