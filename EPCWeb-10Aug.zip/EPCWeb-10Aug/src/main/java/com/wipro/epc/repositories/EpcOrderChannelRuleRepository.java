package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcProductSpecification;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
@Repository
public interface EpcOrderChannelRuleRepository extends CrudRepository< EpcOrderChannelRule, Integer>, 
EpcOrderChannelRuleRepositoryCustom{

    /**
     * This Query selects the data from epc_order_channel_rule table
     * @param orderChannelRuleId
     * @return List<EpcOrderChannelRule>
     */
	@Query(value="select * from epc_order_channel_rule where order_channel_rule_id =:orderChannelRuleId", nativeQuery=true)
	List<EpcOrderChannelRule> findOrderByorderChannelRuleId(@Param("orderChannelRuleId") Integer orderChannelRuleId);
    
	/**
	 * This Query selects the data from epc_order_channel_rule table
	 * @param notification_template_id
	 * @return List<EpcProductSpecification>
	 */
    @Query(value="select * from epc_order_channel_rule where notification_template_id = :notification_template_id", nativeQuery=true)
	List<EpcProductSpecification> searchEpcOrderChannelRule(@Param("notification_template_id") Integer notification_template_id);

}
