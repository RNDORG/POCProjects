package com.wipro.epc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.dto.OrderType;
import com.wipro.epc.services.ComplexSearchInputService;



/**
 * @author Developer
 * @version 1.0
 * type OrderRuleQueryController
 */
@RestController
public class OrderRuleQueryController {

	/**
	 * ComplexSearchInputService OrderRuleQueryController.java
	 */
	@Autowired
	ComplexSearchInputService searchService;
	
	/**
	 * @param orderTypeValue
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/queryOrderRule", method=RequestMethod.GET)
	public OrderType queryOrderRuleExt(@RequestParam String orderTypeValue,@RequestParam MultiValueMap allRequestParams)
	{
		return searchService.queryOrderRule(orderTypeValue,allRequestParams);
	}
	
	
	/**
	 * @param orderTypeValue
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/queryOrderRule", method=RequestMethod.GET)
	public OrderType queryOrderRule(@RequestParam String orderTypeValue,@RequestParam MultiValueMap allRequestParams)
	{
		return searchService.queryOrderRule(orderTypeValue,allRequestParams);
	}
	
}
