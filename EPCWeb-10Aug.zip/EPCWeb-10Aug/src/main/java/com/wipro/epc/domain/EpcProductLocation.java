package com.wipro.epc.domain;


import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;




/**
 * The persistent class for the epc_product_location database table.
 * @author VI251443 
 * @version 1.0
 * 
 */
@Entity
@Table(name="epc_product_location")
@NamedQuery(name="EpcProductLocation.findAll", query="SELECT e FROM EpcProductLocation e")
public class EpcProductLocation  implements Serializable  {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_location_id")
	private Integer productLocationId;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@Column(name="location_code_1")
	private String locationCode1;
	
/*	@Transient
	@JsonSerialize(using = LocationValueSerializer.class)
	private String locationCode1Value;*/

	@Column(name="location_code_2")
	private String locationCode2;
/*	
	@Transient
	@JsonSerialize(using = LocationValueSerializer.class)
	private String locationCode2Value;*/

	@Column(name="location_code_3")
	private String locationCode3;
	
/*	@Transient
	@JsonSerialize(using = LocationValueSerializer.class)
	private String locationCode3Value;*/

	@Column(name="location_code_4")
	private String locationCode4;
/*	
	@Transient
	@JsonSerialize(using = LocationValueSerializer.class)
	private String locationCode4Value;*/

	@Column(name="location_code_5")
	private String locationCode5;
	
/*	@Transient
	@JsonSerialize(using = LocationValueSerializer.class)
	private String locationCode5Value;*/

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;

	@Column(name="product_id")
	private Integer productId;

	@Column(name="status")
	private String status;
	
/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;
	*/
	@Transient
	private Map<String,String> metaInfo;	
	


	public EpcProductLocation() {
	}
	
	@Transient
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}
	
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}


	public Integer getProductLocationId() {
		return this.productLocationId;
	}

	public void setProductLocationId(Integer productLocationId) {
		this.productLocationId = productLocationId;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLocationCode1() {
		return this.locationCode1;
	}

	public void setLocationCode1(String locationCode1) {
		this.locationCode1 = locationCode1;
	}

	public String getLocationCode2() {
		return this.locationCode2;
	}

	public void setLocationCode2(String locationCode2) {
		this.locationCode2 = locationCode2;
	}

	public String getLocationCode3() {
		return this.locationCode3;
	}

	public void setLocationCode3(String locationCode3) {
		this.locationCode3 = locationCode3;
	}

	public String getLocationCode4() {
		return this.locationCode4;
	}

	public void setLocationCode4(String locationCode4) {
		this.locationCode4 = locationCode4;
	}

	public String getLocationCode5() {
		return this.locationCode5;
	}

	public void setLocationCode5(String locationCode5) {
		this.locationCode5 = locationCode5;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getProductId() {
		return this.productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "EpcProductLocation [productLocationId=" + productLocationId
				+ ", createDate=" + createdDate + ", createdBy=" + createdBy
				+ ", locationCode1=" + locationCode1 + ", locationCode2="
				+ locationCode2 + ", locationCode3=" + locationCode3
				+ ", locationCode4=" + locationCode4 + ", locationCode5="
				+ locationCode5 + ", modifiedBy=" + modifiedBy
				+ ", modifyDate=" + modifiedDate + ", productId=" + productId
				+ ", status=" + status + ", metaInfo=" + metaInfo + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result
				+ ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result
				+ ((locationCode1 == null) ? 0 : locationCode1.hashCode());
		result = prime * result
				+ ((locationCode2 == null) ? 0 : locationCode2.hashCode());
		result = prime * result
				+ ((locationCode3 == null) ? 0 : locationCode3.hashCode());
		result = prime * result
				+ ((locationCode4 == null) ? 0 : locationCode4.hashCode());
		result = prime * result
				+ ((locationCode5 == null) ? 0 : locationCode5.hashCode());
		result = prime * result
				+ ((metaInfo == null) ? 0 : metaInfo.hashCode());
		result = prime * result
				+ ((modifiedBy == null) ? 0 : modifiedBy.hashCode());
		result = prime * result
				+ ((modifiedDate == null) ? 0 : modifiedDate.hashCode());
		result = prime * result
				+ ((productId == null) ? 0 : productId.hashCode());
		result = prime
				* result
				+ ((productLocationId == null) ? 0 : productLocationId
						.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		EpcProductLocation other = (EpcProductLocation) obj;
		if (createdDate == null) {
			if (other.createdDate != null){
				return false;
			}
		} else if (!createdDate.equals(other.createdDate)){
			return false;
		}
		if (createdBy == null) {
			if (other.createdBy != null){
				return false;
			}
		} else if (!createdBy.equals(other.createdBy)){
			return false;
		}
		if (locationCode1 == null) {
			if (other.locationCode1 != null){
				return false;
			}
		} else if (!locationCode1.equals(other.locationCode1)){
			return false;
		}
		if (locationCode2 == null) {
			if (other.locationCode2 != null){
				return false;
			}
		} else if (!locationCode2.equals(other.locationCode2)){
			return false;
		}
		if (locationCode3 == null) {
			if (other.locationCode3 != null){
				return false;
			}
		} else if (!locationCode3.equals(other.locationCode3)){
			return false;
		}
		if (locationCode4 == null) {
			if (other.locationCode4 != null){
				return false;
			}
		} else if (!locationCode4.equals(other.locationCode4)){
			return false;
		}
		if (locationCode5 == null) {
			if (other.locationCode5 != null){
				return false;
			}
		} else if (!locationCode5.equals(other.locationCode5)){
			return false;
		}
		if (metaInfo == null) {
			if (other.metaInfo != null){
				return false;
			}
		} else if (!metaInfo.equals(other.metaInfo)){
			return false;
		}
		if (modifiedBy == null) {
			if (other.modifiedBy != null){
				return false;
			}
		} else if (!modifiedBy.equals(other.modifiedBy)){
			return false;
		}
		if (modifiedDate == null) {
			if (other.modifiedDate != null){
				return false;
			}
		} else if (!modifiedDate.equals(other.modifiedDate)){
			return false;
		}
		if (productId == null) {
			if (other.productId != null){
				return false;
			}
		} else if (!productId.equals(other.productId)){
			return false;
		}
		if (productLocationId == null) {
			if (other.productLocationId != null){
				return false;
			}
		} else if (!productLocationId.equals(other.productLocationId)){
			return false;
		}
		if (status == null) {
			if (other.status != null){
				return false;
			}
		} else if (!status.equals(other.status)){
			return false;
		}
		return true;
	}

	/*public String getLocationCode1Value() {
		this.locationCode1Value = locationCode1;
		return locationCode1Value;
	}

	public void setLocationCode1Value(String locationCode1Value) {
		this.locationCode1Value = locationCode1Value;
	}

	public String getLocationCode2Value() {
		this.locationCode2Value = locationCode2;
		return locationCode2Value;
	}

	public void setLocationCode2Value(String locationCode2Value) {
		this.locationCode2Value = locationCode2Value;
	}

	public String getLocationCode3Value() {
		this.locationCode3Value = locationCode3;
		return locationCode3Value;
	}

	public void setLocationCode3Value(String locationCode3Value) {
		this.locationCode3Value = locationCode3Value;
	}

	public String getLocationCode4Value() {
		this.locationCode4Value = locationCode4;
		return locationCode4Value;
	}

	public void setLocationCode4Value(String locationCode4Value) {
		this.locationCode4Value = locationCode4Value;
	}

	public String getLocationCode5Value() {
		this.locationCode5Value = locationCode5;
		return locationCode5Value;
	}

	public void setLocationCode5Value(String locationCode5Value) {
		this.locationCode5Value = locationCode5Value;
	}

	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}
	*/
	

}