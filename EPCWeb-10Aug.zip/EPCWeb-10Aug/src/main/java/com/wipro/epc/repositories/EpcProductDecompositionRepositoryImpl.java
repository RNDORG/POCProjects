package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcProductDecomposition;

/**
 * This is Implementation class for 
 * EpcProductDecompositionRepositoryCustom
 * @author VI251443
 * @version 1.0
 */
public class EpcProductDecompositionRepositoryImpl implements EpcProductDecompositionRepositoryCustom{

	
	private static Logger logger =LoggerFactory.getLogger(EpcProductDecompositionRepositoryImpl.class);
	
	@PersistenceContext
	EntityManager em; 
	
	@Override
	public EpcProductDecomposition modifyProductDecomposition(
			EpcProductDecomposition decomposition) {
		StringBuilder queryBuilder = new StringBuilder("update epc_product_decomposition set product_decomposition_id="+decomposition.getProductDecompositionId());
		
		if(decomposition.getStatus()!=null && !decomposition.getStatus().isEmpty()){
			queryBuilder.append(",").append(" status = '").append(decomposition.getStatus()).append("'");
		}
		if(decomposition.getServiceIdSequence()!=null && !decomposition.getServiceIdSequence().isEmpty()){
			queryBuilder.append(",").append(" service_id = '").append(decomposition.getServiceIdSequence()).append("'");
		}
		if(decomposition.getOrderType()!=null && !decomposition.getOrderType().isEmpty()){
			queryBuilder.append(",").append(" order_type = '").append(decomposition.getOrderType()).append("'");
		}
		if(decomposition.getParamName()!=null){
			queryBuilder.append(",").append(" param_name = '").append(decomposition.getParamName()).append("'");
		}
		if(decomposition.getParamValue()!=null){
			queryBuilder.append(",").append(" param_value = '").append(decomposition.getParamValue()).append("'");
		}
		if(decomposition.getNodeId()!=null && !decomposition.getNodeId().isEmpty()){
			queryBuilder.append(",").append(" node_id = '").append(decomposition.getNodeId()).append("'");
		}
		if(decomposition.getNodeType()!=null && !decomposition.getNodeType().isEmpty()){
			queryBuilder.append(",").append(" node_type = '").append(decomposition.getNodeType()).append("'");
		}
		if(decomposition.getNotificationTemplateId()!=null && decomposition.getNotificationTemplateId()!=0){
			queryBuilder.append(",").append(" notification_template_id = '").append(decomposition.getNotificationTemplateId()).append("'");
		}
		if(decomposition.getUrlString()!=null ){
			queryBuilder.append(",").append(" url_string = '").append(decomposition.getUrlString()).append("'");
		}
		
		queryBuilder.append(" where product_decomposition_id=").append(decomposition.getProductDecompositionId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		////System.out.println(queryBuilder);
	return decomposition;
		
	}

	@Override
	public List<EpcProductDecomposition> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductDecomposition.class).getResultList();
	
	}

}
