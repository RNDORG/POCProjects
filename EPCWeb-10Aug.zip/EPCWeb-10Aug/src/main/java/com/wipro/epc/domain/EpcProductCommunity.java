package com.wipro.epc.domain;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;



/**
 * The persistent class for the epc_product_community database table.
 * @author VI251443
 * @version  1.0
 * 
 */
@Entity
@Table(name="epc_product_community")
public class EpcProductCommunity  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_community_id")
	private Integer productCommunityId;

	@Column(name="applicable_emp_band")
	private String applicableEmpBand;

	@Column(name="community_id")
	private String communityId;

	@Column(name="community_name")
	private String communityName;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;

	@Column(name="discounted_price")
	private BigDecimal discountedPrice;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;

	@Column(name="product_id")
	private Integer productId;

	@Column(name="status")
	private String status;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;*/
	
	@Column(name="slab_id")
	private String slabId;
	
	@Column(name="is_employee_allowed_to_purchase", columnDefinition = "bit", length = 1)
	private Byte isEmployeeAllowedToPurchase;
	
	@Column(name="cug_id")
	private String cugId;
	
	@Column(name="community_short_code")
	private String communityShortCode;
	
	@Column(name="is_vat_exempted", columnDefinition = "bit", length = 1)
	private Byte isVatExempted;
	
	@Column(name="remarks")
	private String remarks;
	
	@Column(name="community_status")
	private String communityStatus;
	
	/**
	 * @param communityName
	 */
	public EpcProductCommunity(String communityName) {
		super();
		this.communityName = communityName;
		
	}
	

	/**
	 * 
	 */
	public EpcProductCommunity() {
	}
	
	@Override
	public String toString() {
		return "EpcProductCommunity [productCommunityId=" + productCommunityId
				+ ", applicableEmpBand=" + applicableEmpBand + ", communityId="
				+ communityId + ", communityName=" + communityName
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", discountedPrice=" + discountedPrice + ", modifiedBy="
				+ modifiedBy + ", modifiedDate=" + modifiedDate
				+ ", productId=" + productId + ", status=" + status
				+ ", slabId=" + slabId + ", isEmployeeAllowedToPurchase="
				+ isEmployeeAllowedToPurchase + ", cugId=" + cugId
				+ ", communityShortCode=" + communityShortCode
				+ ", isVatExempted=" + isVatExempted + ", remarks=" + remarks
				+ "]";
	}


	/**
	 * @return
	 */
	public Integer getProductCommunityId() {
		return this.productCommunityId;
	}

	/**
	 * @param productCommunityId
	 */
	public void setProductCommunityId(Integer productCommunityId) {
		this.productCommunityId = productCommunityId;
	}

	/**
	 * @return
	 */
	public String getApplicableEmpBand() {
		return this.applicableEmpBand;
	}

	/**
	 * @param applicableEmpBand
	 */
	public void setApplicableEmpBand(String applicableEmpBand) {
		this.applicableEmpBand = applicableEmpBand;
	}

	/**
	 * @return
	 */
	public String getCommunityId() {
		return this.communityId;
	}

	/**
	 * @param communityId
	 */
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	/**
	 * @return
	 */
	public String getCommunityName() {
		return this.communityName;
	}

	/**
	 * @param communityName
	 */
	public void setCommunityName(String communityName) {
		this.communityName = communityName;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return
	 */
	public Integer getProductId() {
		return this.productId;
	}

	/**
	 * @param productId
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return
	 */
	public String getSlabId() {
		return slabId;
	}

	/**
	 * @param slabId
	 */
	public void setSlabId(String slabId) {
		this.slabId = slabId;
	}

	/*public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}*/

	/**
	 * @return
	 */
	public BigDecimal getDiscountedPrice() {
		return discountedPrice;
	}

	/**
	 * @param discountedPrice
	 */
	public void setDiscountedPrice(BigDecimal discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	/**
	 * @return
	 */
	public Byte getIsEmployeeAllowedToPurchase() {
		return isEmployeeAllowedToPurchase;
	}

	/**
	 * @param isEmployeeAllowedToPurchase
	 */
	public void setIsEmployeeAllowedToPurchase(Byte isEmployeeAllowedToPurchase) {
		this.isEmployeeAllowedToPurchase = isEmployeeAllowedToPurchase;
	}


	public String getCugId() {
		return cugId;
	}


	public void setCugId(String cugId) {
		this.cugId = cugId;
	}


	public String getCommunityShortCode() {
		return communityShortCode;
	}


	public void setCommunityShortCode(String communityShortCode) {
		this.communityShortCode = communityShortCode;
	}


	public Byte getIsVatExempted() {
		return isVatExempted;
	}


	public void setIsVatExempted(Byte isVatExempted) {
		this.isVatExempted = isVatExempted;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	/**
	 * @return the communityStatus
	 */
	public String getCommunityStatus() {
		return communityStatus;
	}


	/**
	 * @param communityStatus the communityStatus to set
	 */
	public void setCommunityStatus(String communityStatus) {
		this.communityStatus = communityStatus;
	}

	
	

}