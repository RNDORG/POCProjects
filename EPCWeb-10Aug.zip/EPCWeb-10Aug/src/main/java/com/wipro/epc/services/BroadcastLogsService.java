package com.wipro.epc.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.epc.domain.BroadcastLogs;
import com.wipro.epc.repositories.BroadcastLogsRepository;

@Service
public class BroadcastLogsService {

	@Autowired
	BroadcastLogsRepository broadcastLogsRepository;
	
	public void insertToBroadCastLog(BroadcastLogs broadcastLog){
		broadcastLogsRepository.save(broadcastLog);
	}
}
