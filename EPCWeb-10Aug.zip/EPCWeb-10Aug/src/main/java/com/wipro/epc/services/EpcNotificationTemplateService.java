package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;





import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcNotificationTemplate;
import com.wipro.epc.domain.EpcNotificationTemplateDetail;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcNotificationTemplateDetailRepository;
import com.wipro.epc.repositories.EpcNotificationTemplateRepository;

@Service
public class EpcNotificationTemplateService {
	
	private static Logger logger = LoggerFactory.getLogger(EpcNotificationTemplateService.class);

	/**
	 * 
	 */
	@Autowired
	private EpcNotificationTemplateRepository notificationRepository;
	
	/**
	 * 
	 */
	@Autowired
	private EpcNotificationTemplateDetailRepository epcNotificationTemplateDetailRepository;
	
	/**
	 * 
	 */
	@Autowired
	private EpcLookupMasterService epcLookupMasterService;
	//@Autowired
	//EpcNotificationTemplateDetailImpl epcNotificationTemplateDetailImpl;
	/**
	 * 
	 */
	private List<EpcNotificationTemplate> epcActivityMasterCache;
	 
	/**
	 * 
	 */
	public void loadNotificationCache() {
	epcActivityMasterCache = notificationRepository.getAllListofValues();
	}
	
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcNotificationTemplate> searchEpcNotificationTemplateFromUI(
			Map<String, List<String>> allRequestParams) {
		logger.info("All request Parameters is "+allRequestParams);
		String query = "select * from epc_notification_template where 1=1 ";
		if(!allRequestParams.isEmpty()) {
			if(allRequestParams.get("template_name")!=null) { 
				if(!("".equals(allRequestParams.get("template_name").get(0)))) {
					String templateName = allRequestParams.get("template_name").get(0).replace("*", "%");
					query = query + " and (lower(template_name) like lower('"+templateName+"'))";
				}
			}
			if(allRequestParams.get("source_system")!=null) {
				if(allRequestParams.get("source_system").size()>0) {
					if(!("".equals(allRequestParams.get("source_system").get(0)))) {
						query = query + " and (lower(source_system) = lower('"+allRequestParams.get("source_system").get(0)+"'))";
					}
				}
				}
			if(allRequestParams.get("template_type")!=null) {
				if(allRequestParams.get("template_type").size()>0) {
					if(!("".equals(allRequestParams.get("template_type").get(0)))) {
						query = query + " and (lower(template_type) = lower('"+allRequestParams.get("template_type").get(0)+"'))";
					}
				}
				}
		}
			List<EpcNotificationTemplate> listOfNotificationsReturned = null;
		
		//logger.info("Query generated is "+query);
		query = query + " order by template_name";
		try {
			listOfNotificationsReturned = notificationRepository.getList(query.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + query.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		//-------------------old code-------------------
		/*
		for(EpcNotificationTemplate notification: listOfNotificationsReturned)
		{
			notification.setEpcNotificationTemplateDetail(epcNotificationTemplateDetailRepository.getByNotificationTemplateId(notification.getNotificationTemplateId()));
		}
		 */	
		//-------------------old code-------------------
		
		
		//----------------------------------optimized code-------------------------
		if (listOfNotificationsReturned != null && !listOfNotificationsReturned.isEmpty()) {
			Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
			List<String> notificationIds = new ArrayList<String>();
			List<EpcNotificationTemplateDetail> epcNotificationTemplateDetails = null;
			for (EpcNotificationTemplate notification : listOfNotificationsReturned) {
				notificationIds.add(String.valueOf(notification
						.getNotificationTemplateId()));
			}
			if (!notificationIds.isEmpty()) {
				notificationRequestParams.put("notificationTemplateId",
						notificationIds);
				epcNotificationTemplateDetails = searchEpcNotificationTemplateDetails(notificationRequestParams);
			}
			if (epcNotificationTemplateDetails != null
					&& !epcNotificationTemplateDetails
							.isEmpty()) {
				for(EpcNotificationTemplate notificationtemplate: listOfNotificationsReturned)
				{
						for (EpcNotificationTemplateDetail epcNotificationTemplateDetail : epcNotificationTemplateDetails) {
							if (epcNotificationTemplateDetail
									.getNotificationTemplateId()
									.equals(notificationtemplate
											.getNotificationTemplateId())) {
									notificationtemplate
											.setEpcNotificationTemplateDetail(new ArrayList<EpcNotificationTemplateDetail>());
								notificationtemplate
										.getEpcNotificationTemplateDetail()
										.add(epcNotificationTemplateDetail);
						}
					}
				}
			}
		}
		//------------------------------------------optimized code-------------------------
		return listOfNotificationsReturned;	
		
	}
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcNotificationTemplate> searchEpcNotificationTemplate(
			Map<String, List<String>> allRequestParams) {
		
		logger.info("All request params is "+allRequestParams);
		List<String> templateTypeValue = allRequestParams.get("templateTypeValue");
		if(templateTypeValue != null && !templateTypeValue.isEmpty()){
			List<String> templateType = new ArrayList<String>();
			for(String value : templateTypeValue){
				templateType.add(epcLookupMasterService.getLookupId(value));
			}
			allRequestParams.put("templateType", templateType);
			allRequestParams.remove("templateTypeValue");
		}
		
		
		List<String> modeOfDeliveryValue = allRequestParams.get("modeOfDeliveryValue");
		if(modeOfDeliveryValue != null && !modeOfDeliveryValue.isEmpty()){
			List<String> modeOfDelivery = new ArrayList<String>();
			for(String value : modeOfDeliveryValue){
				modeOfDelivery.add(epcLookupMasterService.getLookupId(value));
			}
			allRequestParams.put("modeOfDelivery", modeOfDelivery);
			allRequestParams.remove("modeOfDeliveryValue");
		}
		
		List<String> sourceSystemValue = allRequestParams.get("sourceSystemValue");
		if(sourceSystemValue != null && !sourceSystemValue.isEmpty()){
			List<String> sourceSystem = new ArrayList<String>();
			for(String value : sourceSystemValue){
				sourceSystem.add(epcLookupMasterService.getLookupId(value));
			}
			allRequestParams.put("sourceSystem", sourceSystem);
			allRequestParams.remove("sourceSystemValue");
		}
		
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcNotificationTemplate.class.getName(), null);
		List<EpcNotificationTemplate> listOfNotificationsReturned = null;
		queryBuilder = queryBuilder + " order by template_name";
		try {
			listOfNotificationsReturned = notificationRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		
		if (listOfNotificationsReturned != null && !listOfNotificationsReturned.isEmpty()) {
			Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
			List<String> notificationIds = new ArrayList<String>();
			List<EpcNotificationTemplateDetail> epcNotificationTemplateDetails = null;
			for (EpcNotificationTemplate notification : listOfNotificationsReturned) {
				notificationIds.add(String.valueOf(notification
						.getNotificationTemplateId()));
			}
			if (!notificationIds.isEmpty()) {
				notificationRequestParams.put("notificationTemplateId",
						notificationIds);
				epcNotificationTemplateDetails = searchEpcNotificationTemplateDetails(notificationRequestParams);
			}
			if (epcNotificationTemplateDetails != null
					&& !epcNotificationTemplateDetails
							.isEmpty()) {
				for(EpcNotificationTemplate notificationtemplate: listOfNotificationsReturned)
				{
						for (EpcNotificationTemplateDetail epcNotificationTemplateDetail : epcNotificationTemplateDetails) {
							if (epcNotificationTemplateDetail
									.getNotificationTemplateId()
									.equals(notificationtemplate
											.getNotificationTemplateId())) {
									notificationtemplate
											.setEpcNotificationTemplateDetail(new ArrayList<EpcNotificationTemplateDetail>());
								notificationtemplate
										.getEpcNotificationTemplateDetail()
										.add(epcNotificationTemplateDetail);
						}
					}
				}
			}
		}
		return listOfNotificationsReturned;
	}
	
	
	
	/**
	 * @param notificationList
	 * @param txn
	 * @param mix_op
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcNotificationTemplate> manageNotifications(List<EpcNotificationTemplate> notificationList,
			boolean txn,boolean mix_op, String createdBy){
		List<EpcNotificationTemplate> retListOfEpcNotificationTemplate = new ArrayList<EpcNotificationTemplate>();
		
		for(EpcNotificationTemplate notification:notificationList)
		{
			notification=managenotification(notification,createdBy);
			if((notification.getMetaInfo().get("STATUS")==null))
			{
				notification.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
			}
			retListOfEpcNotificationTemplate.add(notification);
	}
		return retListOfEpcNotificationTemplate;
	}
	
	/**
	 * @param notification
	 * @param createdBy
	 * @return
	 */
	EpcNotificationTemplate managenotification(EpcNotificationTemplate notification,
			String createdBy)
			{
		//EpcNotificationTemplate retnotification=null;
			
			switch(notification.getMetaInfo().get("OPERATION"))
			{
			case "CREATE":createNotifications(notification, createdBy);
						  break;
			case "UPDATE": modifyNotifications(notification, createdBy);
						  break;
			case "DELETE": deleteNotifications(notification);
						  break;
			default:
				throw new EPCException("not supported");
			}
			return notification;
			}

	/**
	 * @param notification
	 * @return
	 */
	EpcNotificationTemplate deleteNotifications(EpcNotificationTemplate notification) {
		
		EpcNotificationTemplateDetail epcNotificationTemplateDetails = notification.getEpcNotificationTemplateDetail().get(0);
		//logger.infoln("epcNotificationTemplateDetails.getNotificationTemplateDetailId(): "+epcNotificationTemplateDetails.getNotificationTemplateDetailId());
		epcNotificationTemplateDetailRepository.delete(epcNotificationTemplateDetails.getNotificationTemplateDetailId());
		
		List<EpcNotificationTemplateDetail> notiDetailList=epcNotificationTemplateDetailRepository.getByNotificationTemplateId(notification.getNotificationTemplateId());
		//logger.info("size"+notiDetailList.size());
	
		if(notiDetailList.isEmpty()){			
			notificationRepository.delete(notification.getNotificationTemplateId());
			logger.info("****************Network Detail(Child) Deleted...Network Template(Parent) is Deleted...");
			
		}else{
			logger.info("****************Network Detail(Child) Deleted...Network Template(Parent) is not Deleted...");
		}
		
        return notification;
	}
	
	/**
	 * @param notification
	 * @param modifiedBy
	 * @return
	 */
	EpcNotificationTemplate modifyNotifications(EpcNotificationTemplate notification, String modifiedBy) {
		notification.setModifiedBy(modifiedBy);
		notification.setModifiedDate(new Date());
		
		//List<EpcNotificationTemplateDetail> notiDetailList=new ArrayList<EpcNotificationTemplateDetail>();
		
		EpcNotificationTemplateDetail epcNotificationTemplateDetails = notification.getEpcNotificationTemplateDetail().get(0);
		
		epcNotificationTemplateDetails.setNotificationTemplateId(notification.getNotificationTemplateId());	
		epcNotificationTemplateDetails.setStatus(notification.getStatus());
		epcNotificationTemplateDetails.setModifiedBy(modifiedBy);
		epcNotificationTemplateDetails.setModifiedDate(new Date());
		
		
			epcNotificationTemplateDetailRepository.modifyNotificationTemplateDetail(epcNotificationTemplateDetails);
		
			return notificationRepository.modifyNotifications(notification);
		
	//return notificationRepository.modifyNotifications(notification);
    }

	/**
	 * @param notification
	 * @param createdBy
	 * @return
	 */
	EpcNotificationTemplate createNotifications(EpcNotificationTemplate notification, String createdBy) {
		notification.setCreatedBy(createdBy);
		notification.setCreatedDate(new Date());
		int notificationId=0;
		//EpcNotificationTemplate existingNoti=notificationRepository.findByTemplateNameAndTemplateTypeAndSourceSystemAndModeOfDelivery(notification.getTemplateName(),notification.getTemplateType(), notification.getSourceSystem(), notification.getModeOfDelivery());
		EpcNotificationTemplate existingNoti=notificationRepository.findByTemplateNameAndTemplateType(notification.getTemplateName(),notification.getTemplateType());
		
		if(existingNoti!=null){
			notificationId=existingNoti.getNotificationTemplateId();
			notification.setNotificationTemplateId(notificationId);
			logger.info("*********************Network Template Already  Existing*******************************");
			
		}else{
			logger.info("*********************Not in DB.. Creating Network Template*******************************");
			EpcNotificationTemplate notif=notificationRepository.save(notification);
			notificationId= notif.getNotificationTemplateId();
		}
		EpcNotificationTemplateDetail epcNotificationTemplateDetails = notification.getEpcNotificationTemplateDetail().get(0);
		
		EpcNotificationTemplateDetail existNotiDetail=epcNotificationTemplateDetailRepository.findByNotificationTemplateIdAndTemplateLanguage(notificationId, epcNotificationTemplateDetails.getTemplateLanguage());
		List<EpcNotificationTemplateDetail> notiDetailList=new ArrayList<EpcNotificationTemplateDetail>();
		if(existNotiDetail!=null){
			logger.info("**************************Network Template Detail Exist in DB ***********************************");
			notiDetailList.add(existNotiDetail);
			notification.setEpcNotificationTemplateDetail(notiDetailList);
		}else{
			logger.info("**************************Not in DB....Creating Network Template Detail***********************************");
			
			epcNotificationTemplateDetails.setNotificationTemplateId(notificationId);	
			epcNotificationTemplateDetails.setStatus(notification.getStatus());
			epcNotificationTemplateDetails.setCreatedBy(createdBy);
			epcNotificationTemplateDetails.setCreatedDate(new Date());
			
			notiDetailList.add(epcNotificationTemplateDetailRepository.save(epcNotificationTemplateDetails));
			notification.setEpcNotificationTemplateDetail(notiDetailList);
		}
		
	return notification;
}
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcNotificationTemplateDetail> searchEpcNotificationTemplateDetails(
			Map<String, List<String>> allRequestParams) {

			String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
					EpcNotificationTemplateDetail.class.getName(), null);
			List<EpcNotificationTemplateDetail> listOfNotificationDetailsReturned = null;
			try {
			listOfNotificationDetailsReturned = epcNotificationTemplateDetailRepository.getList(queryBuilder.toString());
			} catch (Exception e) {
			throw new EPCException(
			"Error occurred while fetching results from database.\n"
			+ " Query: " + queryBuilder.toString() + "\n"
			+ " Exception: " + e.getMessage(), e);
			}

			return listOfNotificationDetailsReturned;
			}
	/**
	 * @param id
	 * @return
	 */
	public EpcNotificationTemplate getLookupValue(Integer id) {
	//	if (epcActivityMasterCache == null) {
		loadNotificationCache();
		//}
		for (EpcNotificationTemplate epcNotificationTemplate : epcActivityMasterCache) {
		if (epcNotificationTemplate != null
		&& epcNotificationTemplate.getNotificationTemplateId().equals(id)) {
		logger.info("--------------"+epcNotificationTemplate.getTemplateName());
		return epcNotificationTemplate;
		}
		}
		return null;
		}


	/**
	 * @return
	 */
	public static Logger getLogger() {
		return logger;
	}


	/**
	 * @param logger
	 */
	public static void setLogger(Logger logger) {
		EpcNotificationTemplateService.logger = logger;
	}


	/**
	 * @return
	 */
	public EpcNotificationTemplateRepository getNotificationRepository() {
		return notificationRepository;
	}


	/**
	 * @param notificationRepository
	 */
	public void setNotificationRepository(
			EpcNotificationTemplateRepository notificationRepository) {
		this.notificationRepository = notificationRepository;
	}


	/**
	 * @return
	 */
	public EpcNotificationTemplateDetailRepository getEpcNotificationTemplateDetailRepository() {
		return epcNotificationTemplateDetailRepository;
	}


	/**
	 * @param epcNotificationTemplateDetailRepository
	 */
	public void setEpcNotificationTemplateDetailRepository(
			EpcNotificationTemplateDetailRepository epcNotificationTemplateDetailRepository) {
		this.epcNotificationTemplateDetailRepository = epcNotificationTemplateDetailRepository;
	}


	/**
	 * @return
	 */
	public EpcLookupMasterService getEpcLookupMasterService() {
		return epcLookupMasterService;
	}


	/**
	 * @param epcLookupMasterService
	 */
	public void setEpcLookupMasterService(
			EpcLookupMasterService epcLookupMasterService) {
		this.epcLookupMasterService = epcLookupMasterService;
	}


	/**
	 * @return
	 */
	public List<EpcNotificationTemplate> getEpcActivityMasterCache() {
		return epcActivityMasterCache;
	}


	/**
	 * @param epcActivityMasterCache
	 */
	public void setEpcActivityMasterCache(
			List<EpcNotificationTemplate> epcActivityMasterCache) {
		this.epcActivityMasterCache = epcActivityMasterCache;
	}
	
	
	
	public void getOptimizedNotification(List<EpcNotificationTemplate> listOfNotificationsReturned)
	{
		if (listOfNotificationsReturned != null && !listOfNotificationsReturned.isEmpty()) {
			Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
			List<String> notificationIds = new ArrayList<String>();
			List<EpcNotificationTemplateDetail> epcNotificationTemplateDetails = null;
			for (EpcNotificationTemplate notification : listOfNotificationsReturned) {
				notificationIds.add(String.valueOf(notification
						.getNotificationTemplateId()));
			}
			if (!notificationIds.isEmpty()) {
				notificationRequestParams.put("notificationTemplateId",
						notificationIds);
				epcNotificationTemplateDetails = searchEpcNotificationTemplateDetails(notificationRequestParams);
			}
			if (epcNotificationTemplateDetails != null
					&& !epcNotificationTemplateDetails
							.isEmpty()) {
				for(EpcNotificationTemplate notificationtemplate: listOfNotificationsReturned)
				{
						for (EpcNotificationTemplateDetail epcNotificationTemplateDetail : epcNotificationTemplateDetails) {
							if (epcNotificationTemplateDetail
									.getNotificationTemplateId()
									.equals(notificationtemplate
											.getNotificationTemplateId())) {
									notificationtemplate
											.setEpcNotificationTemplateDetail(new ArrayList<EpcNotificationTemplateDetail>());
								notificationtemplate
										.getEpcNotificationTemplateDetail()
										.add(epcNotificationTemplateDetail);
						}
					}
				}
			}
		
	}
}
}
