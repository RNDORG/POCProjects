package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcTriggerOrderRule;
import com.wipro.epc.services.EpcOrderTriggerRuleService;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
@RestController
public class EpcTriggerOrderRuleController {

	@Autowired
	EpcOrderTriggerRuleService service;
	
	/**
	 * 
	 * @param orderList
	 * @param allRequestParams
	 * @param txn
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/triggers", method=RequestMethod.POST)
	public List<EpcTriggerOrderRule> manageTriggers(@RequestBody List<EpcTriggerOrderRule> orderList, @RequestParam MultiValueMap allRequestParams,
			@RequestParam(value="txn",defaultValue="true")boolean txn)
			//@RequestParam(value="mix_op",defaultValue="true")boolean mix_op
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		
		return service.manageTriggers(orderList, txn, allRequestParams, user);
	}
	
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/triggers", method=RequestMethod.GET)
	public List<EpcTriggerOrderRule> searchTriggers(@RequestParam MultiValueMap allRequestParams)
	{
 			return service.searchTriggerOrderRule(allRequestParams);
	}
}
