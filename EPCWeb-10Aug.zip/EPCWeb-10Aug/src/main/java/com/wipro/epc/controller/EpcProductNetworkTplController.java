package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.wipro.epc.domain.EpcProductNetworkTpl;

import com.wipro.epc.services.EpcProductNetworkTplService;

/**
 * 
 * @author KE334465
 *
 */
@RestController 
public class EpcProductNetworkTplController {

	
	@Autowired
	private EpcProductNetworkTplService epcProductNetworkTplService;
		
	
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/networkServices" , method=RequestMethod.GET)
	public List<EpcProductNetworkTpl> searchNetworkServices(@RequestParam MultiValueMap allRequestParams)
	{
		/**
		 * passes the controller to the service
		 */
				return epcProductNetworkTplService.searchNetworkServices(allRequestParams);
	}
	
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/networkProfiles" , method=RequestMethod.GET)
	public List<EpcProductNetworkTpl> getNetworkProfiles()
	{
		/**
		 * passes the controller to the service
		 */
				return epcProductNetworkTplService.getNetworkProfiles();
	}
}
