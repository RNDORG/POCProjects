package com.wipro.epc.util;


/**
 * @author KE334465
 *
 */
public class Constants {
	private static String COLUMN_SEPARATOR = " || ";
	
	/**
	 * constant Active
	 */
	public static final String COMMON_STATUS_ACTIVE = "Active";

	/**
	 * Constant CRM
	 */
	public static final String INITCHANNEL_CRM="CRM";
	/**
	 * Constant OMNI
	 */
	public static final String INITCHANNEL_OMNI="Omni";
	
	/**
	 * Constant Draft
	 */
	public static final String PRODUCT_STATUS_DRAFT = "Draft";
	/**
	 * Constant Submitted
	 */
	public static final String PRODUCT_STATUS_SUBMITTED = "Submitted";
	/**
	 * Constant Approved
	 */
	public static final String PRODUCT_STATUS_APPROVED = "Approved";
	/**
	 * Constant Launch
	 */
	public static final String PRODUCT_STATUS_LAUNCH = "Launch";
	/**
	 * Constant Tested
	 */
	public static final String PRODUCT_STATUS_TESTED = "Tested";
	/**
	 * Constant Retire
	 */
	public static final String PRODUCT_STATUS_RETIRE = "Retire";
	
	/**
	 * constant true
	 */
	public static final String RETIRE_PREVIOUS_PRODUCT = "true";

	/**
	 * @return
	 */
	public static String getCOLUMN_SEPARATOR() {
		return COLUMN_SEPARATOR;
	}

	/**
	 * @param cOLUMN_SEPARATOR
	 */
	public static void setCOLUMN_SEPARATOR(String cOLUMN_SEPARATOR) {
		COLUMN_SEPARATOR = cOLUMN_SEPARATOR;
	}
	public static final String DATA_UNIT_MB="MB";
	public static final String DATA_UNIT_GB="GB";
	public static final String VOICE_TYPE_ANYNET="ANYNET";
	public static final String VOICE_TYPE_ONNET="ONNET";
	public static final String PLAN_ONNETVOICE="Voice_On_Net";
	public static final String PLAN_ANYNETVOICE="Voice_Any_Net";
	public static final String PLAN_ONNETDATA="Data_On_Net";
	public static final String PLAN_ANYNETDATA="Data_Any_Net";
	public static final String PLAN_SMS="SMS";
	//public static final String MARKET_PLAN_ONNETVOICE="Market_Voice_On_Net";
	//public static final String MARKET_PLAN_ANYNETVOICE="Market_Voice_Any_Net";
	//public static final String MARKET_PLAN_ONNETDATA="Market_Data_On_Net";
	//public static final String MARKET_PLAN_ANYNETDATA="Market_Data_Any_Net";
	//public static final String MARKET_PLAN_SMS="Market_SMS";
	public static final String VALIDITY_OPTIONS="1|7|15|30";
	
	public static final String RESPONSE_SUCCESS_STATUS="SUCCESS";
	public static final String RESPONSE_FAIL_STATUS="FAILURE";
	
	public static final String VOICE_UNIT_HOURS="Hours";
	public static final String VOICE_UNIT_MINUTES="Minutes";
	public static final String [] FNF_ATTRIBUTES={"FNF_ONNET_ALLOWED","FNF_MAX_EXCEPT_SFNF","FNF_OFFNET_ALLOWED","FNF_SFNF_ALLOWED","FNF_LOCKING_PERIOD","FNF_SFNF_MUTUALLY_EXCLUSIVE","FNF_PRODUCT_DEFAULT_FLAG"};
	public static final String [] CALLBLOCK_ATTRIBUTES={"MAX_BLACK_LIST_COUNT","MAX_WHITE_LIST_COUNT"};
	
	public static final String PRODUCT_SUB_FAMILY_DATA="Data";
	
	 public static final String SOURCE_SYSTEM_ESB="ESB";
	 public static final String DOWNSTREAM_SYSTEM_COMS="COMS";
	 
	 public static final String PRODUCT_SUB_CATEGORY_CORPORATE="Corporate";
	 public static final String PRODUCT_SUB_CATEGORY_REGULAR="Regular";
	 public static final String PRODUCT_SUB_CATEGORY_ALL="ALL";
	 public static final String PRODUCT_TYPE_OPTIONAL="Optional";
	 public static final String ACTION_TYPE_SUBSCRIPTION="Subscription";
	 
	 public static final String COMMUNITY_STATUS_DELETED="Deleted";
	 public static final String COMMUNITY_STATUS_INACTIVE="Inactive";
	 public static final String COMMUNITY_STATUS_ACTIVE="Active";
	 public static final String COMMUNITY_APPLICABLE_EMP_Band_ALL="ALL";
	 public static final String INIT_CHANNEL_STATUS_ACTIVE="Active";
	 
	 public static final String MIGRATION_INCLUSIVEOREXCLUSIVE_INCLUSION="Inclusion";	 
	 
	 public static final String ATTRIBUTE_CTG_TARIFFCTG="TariffCtg";
	 public static final String ATTRIBUTE_CTG_TYPE_ONETIME="OneTime";
	 public static final String ATTRIBUTE_NAME_SUBSCRIPTIONFEE="SUBSCRIPTION_FEE";
	 public static final String ATTRIBUTE_NAME_EXTERNALDATA1="EXTERNAL_DATA_1";
	 public static final String ATTRIBUTE_NAME_EXTERNALDATA1ARON="EXTERNAL_DATA_1_ARON";
	 public static final String ATTRIBUTE_NAME_EXTERNALDATA1SLAB="EXTERNAL_DATA_1_SLAB";
	 public static final String ATTRIBUTE_NAME_TRANSACTIONTYPENEW="TRANSACTION_TYPE_NEW";
	 public static final String ATTRIBUTE_NAME_DA="DA";
	
	 public static final String ACTION_TYPE_MIGRATION_OR_MODIFICATION="Migration/Modification";
	 
	 public static final String ORDER_TYPE_OFFER_SUBS="OFFER_SUBS";
	 public static final String ORDER_TYPE_OFFER_UNSU="OFFER_UNSU";
	 public static final String ATTRIBUTE_CTG_PRODUCTCTG="ProductCtg";
	 
	 public static final String CACHED_PRODUCT_DETAILS_STATUS_ACTIVE="Active";
	 
	 public static final String OPT_PROD_CALL_BLOCK_SERVICE_POSTPAID="CALL_BLOCK_SERVICE_POSTPAID";
	 
	 public static final String [] XPLORE_LEGEND_PROVIDER_PROD_IDS={"1198","1213","1214"};
	 
	 public static final String PRODUCT_CATEGORY_POSTPAID="Postpaid";
	 
	 public static final String PRODUCT_CATEGORY_PREPAID="Prepaid";
	 
	 public static final String FLEXI_PLAN_GIFT="FLEXI_PLAN_GIFT";

	public static final String DOWNSTREAM_SYSTEM_COMS_SIMPLE = "COMS_SIMPLE";
	
	public static final String RECONNECTION_SC = "RECONNECTION_SC";
	 
}
