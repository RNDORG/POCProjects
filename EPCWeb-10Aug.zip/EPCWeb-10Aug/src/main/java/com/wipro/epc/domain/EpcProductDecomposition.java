package com.wipro.epc.domain;



import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the epc_product_decomposition database table. 
 * @author VI251443
 * @version 1.0
 */
@Entity
@Table(name="epc_product_decomposition")
public class EpcProductDecomposition  implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_decomposition_id")
	private Integer productDecompositionId;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="created_date")
	private Date createdDate;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="end_date")
	private Date endDate;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="node_id")
	private String nodeId;
	
	@Column(name="node_type")
	private String nodeType;

	@Column(name="is_notification_required", columnDefinition = "bit", length = 1)
	private Byte isNotificationRequired;
	
	@Column(name="notification_template_id")
	private Integer notificationTemplateId;

	@Column(name="order_type")
	private String orderType;

	@Column(name="param_name")
	private String paramName;

	@Column(name="param_value")
	private String paramValue;

	@Column(name="product_classification")
	private String productClassification;

	@Column(name="service_id_sequence")
	private String serviceIdSequence;

	@Column(name="product_sub_family")
	private String productSubFamily;
	
	@Column(name="product_short_code")
	private String productShortCode;
	
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="start_date")
	private Date startDate;

	@Column(name="status")
	private String status;
	
	@Column(name="task")
	private String task;
	
	@Column(name="task_type")
	private String taskType;
	
	@Column(name="url_string")
	private String urlString;
	
	@Column(name="integration_mode")
	private String integrationMode;
	
	@Transient
	private Map<String,String> metaInfo;
	
    @Transient
	private EpcNotificationTemplate epcNotificationTemplate;
	
	

	/**
	 * 
	 */
	public EpcProductDecomposition() 
	{
	}
	
	/**
	 * 
	 */
	@Override
	public String toString() {
		return "EpcProductDecomposition [productDecompositionId="
				+ productDecompositionId + ", createdDate=" + createdDate
				+ ", createdBy=" + createdBy + ", endDate=" + endDate
				+ ", modifiedBy=" + modifiedBy + ", modifiedDate="
				+ modifiedDate + ", nodeId=" + nodeId + ", nodeType="
				+ nodeType 
				+ ", isNotificationRequired=" + isNotificationRequired
				+ ", notificationTemplateId=" + notificationTemplateId
				+ ", orderType=" + orderType + ", paramName=" + paramName
				+ ", paramValue=" + paramValue + ", productClassification="
				+ productClassification + ", serviceIdSequence="
				+ serviceIdSequence + ", productSubFamily=" + productSubFamily + ", productShortCode="
				+ productShortCode + ", startDate=" + startDate + ", status="
				+ status + ", urlString="
				+ urlString + ", metaInfo=" + metaInfo
				+ ", epcNotificationTemplate=" + epcNotificationTemplate + "]";
	}

	
	/**
	 * @return
	 */
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}
	
	/**
	 * @param metaInfo
	 */
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}
	
	/**
	 * Getter for ProductDecompositionId
	 * @return
	 */
	public Integer getProductDecompositionId() {
		return this.productDecompositionId;
	}

	/**
	 * Setter for ProductDecompositionId
	 * @param productDecompositionId
	 */
	public void setProductDecompositionId(Integer productDecompositionId) {
		this.productDecompositionId = productDecompositionId;
	}

	/**
	 * Getter for CreatedDate
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * Setter for CreatedDate
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Getter for CreatedBy
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/** 
	 * Setter for CreatedBy
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Getter for EndDate
	 * @return
	 */
	public Date getEndDate() {
		return this.endDate;
	}

	/**
	 * Setter for EndDate
	 * @param endDate
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Getter for ModifiedBy
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * Setter for ModifiedBy
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * Getter for ModifiedDate
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * Setter for ModifiedDate
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * Getter for NodeId
	 * @return
	 */
	public String getNodeId() {
		return this.nodeId;
	}

	/**
	 * Setter for NodeId
	 * @param nodeId
	 */
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

	/**
	 * Getter for nodeType
	 * @return
	 */
	public String getNodeType() {
		return this.nodeType;
	}

	/**
	 * Setter for nodeType
	 * @param nodeType
	 */
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	/**
	 * Getter for NotificationTemplateId
	 * @return
	 */
	public Integer getNotificationTemplateId() {
		return this.notificationTemplateId;
	}

	/**
	 * Setter for NotificationTemplateId
	 * @param notificationTemplateId
	 */
	public void setNotificationTemplateId(Integer notificationTemplateId) {
		this.notificationTemplateId = notificationTemplateId;
	}

    /**
	 * Getter for ParamName
	 * @return
	 */
	public String getParamName() {
		return this.paramName;
	}

	/**
	 * Setter for ParamName
	 * @param paramName
	 */
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	/**
	 * Getter for ParamValue
	 * @return
	 */
	public String getParamValue() {
		return this.paramValue;
	}

	/**
	 * Setter for ParamValue
	 * @param paramValue
	 */
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	/**
	 * Getter for ServiceIdSequence
	 * @return
	 */
	public String getServiceIdSequence() {
		return this.serviceIdSequence;
	}

	/**
	 * Setter for ServiceIdSequence
	 * @param serviceIdSequence
	 */
	public void setServiceIdSequence(String serviceIdSequence) {
		this.serviceIdSequence = serviceIdSequence;
	}

	/**
	 * Getter for StartDate
	 * @return
	 */
	public Date getStartDate() {
		return this.startDate;
	}

	/**
	 * Setter for StartDate
	 * @param startDate
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * Getter for Status
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * Setter for Status
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Getter for UrlString
	 * @return
	 */
	public String getUrlString() {
		return this.urlString;
	}

	/**
	 * Setter for UrlString
	 * @param urlString
	 */
	public void setUrlString(String urlString) {
		this.urlString = urlString;
	}

	/**
	 * Setter for ProductClassification
	 * @return
	 */
	public String getProductClassification() {
		return productClassification;
	}

	/**
	 * Setter for ProductClassification
	 * @param productClassification
	 */
	public void setProductClassification(String productClassification) {
		this.productClassification = productClassification;
	}

	/**
	 * Getter for productSubFamily
	 * @return
	 */
	public String getProductSubFamily() {
		return productSubFamily;
	}

	/**
	 * Setter for productSubFamily
	 * @param productSubFamily
	 */
	public void setProductSubFamily(String productSubFamily) {
		this.productSubFamily = productSubFamily;
	}

	/**
	 * Getter for OrderType
	 * @return
	 */
	public String getOrderType() {
		return orderType;
	}

	/**
	 * Setter for OrderType
	 * @param orderType
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	/**
	 * Setter for ProductShortCode
	 * @param productShortCode
	 */
	public void setProductShortCode(String productShortCode) {
		this.productShortCode = productShortCode;
	}
	
	/**
	 * Getter for ProductShortCode
	 * @return
	 */
	public String getProductShortCode() {
		return productShortCode;
	}

	/**
	 * Getter for IsNotificationRequired
	 * @return
	 */
	public Byte getIsNotificationRequired() {
		return isNotificationRequired;
	}

	/**
	 * Getter for IsNotificationRequired
	 * @param isNotificationRequired
	 */
	public void setIsNotificationRequired(Byte isNotificationRequired) {
		this.isNotificationRequired = isNotificationRequired;
	}

	/**
	 * Getter for EpcNotificationTemplate
	 * @return
	 */
	public EpcNotificationTemplate getEpcNotificationTemplate() {
		return epcNotificationTemplate;
	}

	/**
	 * Setter for EpcNotificationTemplate
	 * @param epcNotificationTemplate
	 */
	public void setEpcNotificationTemplate(
			EpcNotificationTemplate epcNotificationTemplate) {
		this.epcNotificationTemplate = epcNotificationTemplate;
	}

	/**
	 * Getter for Task
	 * @return
	 */
	public String getTask() {
		return task;
	}

	/**
	 * Setter for Task
	 * @param task
	 */
	public void setTask(String task) {
		this.task = task;
	}

	/**
	 * Getter for TaskType
	 * @return
	 */
	public String getTaskType() {
		return taskType;
	}

	/**
	 * Setter for TaskType
	 * @param taskType
	 */
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
		
	/**
	 * Setter for IntegrationMode
	 * @return
	 */
	public String getIntegrationMode() {
		return integrationMode;
	}

	/**
	 * Setter for IntegrationMode
	 * @param integrationMode
	 */
	public void setIntegrationMode(String integrationMode) {
		this.integrationMode = integrationMode;
	}
}