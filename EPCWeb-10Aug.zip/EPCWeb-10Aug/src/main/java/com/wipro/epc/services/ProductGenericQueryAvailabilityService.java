package com.wipro.epc.services;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductAvailability;
import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.domain.EpcProductCompatibility;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductLocation;
import com.wipro.epc.domain.EpcProductSalesChannel;
import com.wipro.epc.domain.EpcProductSegment;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.ComplexSearchInput;
import com.wipro.epc.dto.GenericQueryAvailabilityResponse;
import com.wipro.epc.dto.GenericQueryAvailabilitySearchInput;
import com.wipro.epc.util.Constants;


/**
 * @author Developer
 * @version 1.0
 * type ProductGenericQueryAvailabilityService
 */
@Service
public class ProductGenericQueryAvailabilityService {
	
	private static Logger logger = LoggerFactory.getLogger(ProductGenericQueryAvailabilityService.class);
	/**
	 * EpcLookupMasterService ProductGenericQueryAvailabilityService.java
	 */
	@Autowired
	EpcLookupMasterService epcLookupMasterService;
	
	/**
	 * EpcProductInitChannelService ProductGenericQueryAvailabilityService.java
	 */
	@Autowired
	EpcProductInitChannelService epcProductInitChannelService;
	
	/**
	 * EpcProductAttributeService ProductGenericQueryAvailabilityService.java
	 */
	@Autowired
	EpcProductAttributeService epcProductAttributeService;
	
	/**
	 * EpcLocationService ProductGenericQueryAvailabilityService.java
	 */
	@Autowired
	EpcLocationService epcLocationService;
	
	/**
	 * EpcOrderChannelRuleService ProductGenericQueryAvailabilityService.java
	 */
	@Autowired
	EpcOrderChannelRuleService epcOrderChannelRuleService;

	/**
	 * EpcAttributeMasterService ProductGenericQueryAvailabilityService.java
	 */
	@Autowired
	EpcAttributeMasterService epcAttributeMasterService;
	
	/**
	 * ComplexSearchInputService ProductGenericQueryAvailabilityService.java
	 */
	@Autowired
	ComplexSearchInputService complexSearchInputService;
	
	/**
	 * DateFormat ProductGenericQueryAvailabilityService.java
	 */
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@Transactional
	public GenericQueryAvailabilityResponse queryEligibility(GenericQueryAvailabilitySearchInput searchInput, Map<String, List<String>> allRequestParams)
	{
			if(searchInput.getSubscribedProductList() == null  || (searchInput.getSubscribedProductList() != null && searchInput.getSubscribedProductList().isEmpty())
				|| StringUtils.isBlank(searchInput.getSalesChannelValue()) || StringUtils.isBlank(searchInput.getCharacteristicServiceClass())
				|| StringUtils.isBlank(searchInput.getInitChannelValue())|| StringUtils.isBlank(searchInput.getProductSubCategoryValue())
				|| StringUtils.isBlank(searchInput.getStartDate())){
				throw new GenericException("InvalidSearch", "Mandatory Fields are missing. Please provide all mandatory fields (characteristicServiceClass, subscribedProductList,"
						+ " initChannelValue, salesChannelValue, startDate, productSubCategoryValue)", "Mandatory Fields are missing.");
			}
			
			GenericQueryAvailabilityResponse queryEligibilityResponse = new GenericQueryAvailabilityResponse();
			//converting values to ids
			if(searchInput.getProductStatusValue() != null) {
				searchInput.setProductStatusValue(epcLookupMasterService.getLookupId(searchInput.getProductStatusValue()));
			}
			
			if(searchInput.getProductSubCategoryValue() != null){
				searchInput.setProductSubCategoryValue(epcLookupMasterService.getLookupId(searchInput.getProductSubCategoryValue()));
			}
			
			if(searchInput.getInitChannelValue() != null){
				searchInput.setInitChannelValue(epcLookupMasterService.getLookupId(searchInput.getInitChannelValue()));
			}
			if(searchInput.getSalesChannelValue() != null){
				searchInput.setSalesChannelValue(epcLookupMasterService.getLookupId(searchInput.getSalesChannelValue()));
			}
			if(searchInput.getRegionValue() != null)	{
				searchInput.setRegionValue(epcLocationService.getLocationId(searchInput.getRegionValue()));
			}
			if(searchInput.getAreaValue() != null){
				searchInput.setAreaValue(epcLocationService.getLocationId(searchInput.getAreaValue()));
			}
			if(searchInput.getTerritoryValue() != null){
				searchInput.setTerritoryValue(epcLocationService.getLocationId(searchInput.getTerritoryValue()));
			}
			if(searchInput.getSegmentValue() != null){
				searchInput.setSegmentValue(epcLookupMasterService.getLookupId(searchInput.getSegmentValue()));
			}
			
			if(searchInput.getOrderTypeValue() != null){
				searchInput.setOrderTypeValue(epcLookupMasterService.getLookupId(searchInput.getOrderTypeValue()));
			}
			
			
			//logic to fetch primary product
			Integer prodId = fetchPrimaryProductId(searchInput.getCharacteristicServiceClass());
			logger.info("Primary Product Id : "+prodId);
			EpcProductSpecification primaryProduct = null;
			if (prodId != null) {
				ComplexSearchInput complexSearchInput = new ComplexSearchInput();
				complexSearchInput.setProductId(String.valueOf(prodId));
				MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
				criteria.add("with", "segment");
				criteria.add("with", "location");
				criteria.add("with", "community");
				criteria.add("with", "availability");
				criteria.add("with", "compatibility");
				primaryProduct = complexSearchInputService.searchComplex(complexSearchInput, criteria, false).get(0);
			}else{
				queryEligibilityResponse.setRemarks("Primary product is null.");
				return queryEligibilityResponse;
			}
			
			
			//logic to fetch addOn products
			List<EpcProductSpecification> addOnProducts = null;
			List<EpcProductCompatibility>  primaryProdCompatibilities = primaryProduct.getEpcProductCompatibility();
			List<String> addOnProductids = new ArrayList<String>();
			if(primaryProdCompatibilities != null){
				for(EpcProductCompatibility epcProductCompatibility :primaryProdCompatibilities){
					addOnProductids.add(String.valueOf(epcProductCompatibility.getOtherProductId()));
				}
			}
			if(!addOnProductids.isEmpty() ){
				Map<String, List<String>> multiValueMap = new HashMap<String, List<String>>();
				multiValueMap.put("with", Arrays.asList("all"));
				multiValueMap.put("productId", addOnProductids);
				
				addOnProducts = complexSearchInputService.searchProducts(multiValueMap,null, false);
			}else{
				queryEligibilityResponse.setRemarks("There is no Addon products for the given primary product.");
				return queryEligibilityResponse;
			}
			
			
			
			//logic for OCR check
			if(StringUtils.isNotBlank(searchInput.getOrderTypeValue() ) ){
				EpcOrderChannelRule orderChannelRule = fetchOrderChannelRule(searchInput);
				if(orderChannelRule != null && Constants.COMMON_STATUS_ACTIVE.equals(orderChannelRule.getStatus())){
					//OCR checked 
				}else{
					queryEligibilityResponse.setRemarks("Failed for Order Channel Rule check.");
					return queryEligibilityResponse;
				}
			}
			
			
			//removing already subscribed products
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				for( String prodShortCode: searchInput.getSubscribedProductList()){
					if(prodShortCode.equals(epcProductSpecification.getProductShortCode())){
						iterator.remove();
					}
				}
			}
			if( addOnProducts.size() < 1 ){
				queryEligibilityResponse.setRemarks("Nothing to be subscribed. All are already subscribed.");
				return queryEligibilityResponse;
			}
			
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				//logic for basicinfo check
				if (primaryProduct.getProductAssociationLevel().equals(epcProductSpecification
						.getProductAssociationLevel())
						&& primaryProduct.getProductFamily() .equals(epcProductSpecification
								.getProductFamily())
						&& primaryProduct.getProductCategory() .equals(epcProductSpecification
								.getProductCategory())
						&& primaryProduct.getProductSubCategory() .equals(searchInput
										.getProductSubCategoryValue())
						&& epcProductSpecification.getProductSubCategory().equals( searchInput
										.getProductSubCategoryValue())) {
					//do nothing
				} else {
					iterator.remove();
				}
			}
			logger.info("AddOn products size after Basic Check :"+addOnProducts.size());
			
			
			//logic for init channel check
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				boolean initChannelCheck = false;
				List<EpcProductInitChannel> initChannels = epcProductSpecification.getEpcProductInitChannel();
				for(EpcProductInitChannel initChannel : initChannels){
				if(searchInput.getInitChannelValue().equals(String.valueOf(initChannel.getChannelId()))){
					initChannelCheck = true;
					break;
				}
				}
				
				if(!initChannelCheck){
					iterator.remove();
				}
			}
			logger.info("AddOn products size after init channel Check :"+addOnProducts.size());
			
			//logic for sales channel check			
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				boolean salesChannelCheck = false;
				List<EpcProductSalesChannel> saleChannels = epcProductSpecification.getEpcProductSalesChannel();
				for(EpcProductSalesChannel salesChannel : saleChannels){
					if(searchInput.getSalesChannelValue().equals(String.valueOf(salesChannel.getPartnerType()))){
						salesChannelCheck = true;
						break;
					}
				}
				
				if(!salesChannelCheck){
					iterator.remove();
				}
			}
			logger.info("AddOn products size after sales channel Check :"+addOnProducts.size());
			
			//logic for segment check
			if(StringUtils.isNotBlank(searchInput.getSegmentValue())){
				for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
					EpcProductSpecification epcProductSpecification = iterator.next();
					boolean pFound = false;
					boolean aFound = false;
					List<EpcProductSegment> primaryProductSegments = primaryProduct
							.getEpcProductSegment();
					List<EpcProductSegment> addOnProdSegments = epcProductSpecification
							.getEpcProductSegment();
					if (primaryProductSegments != null
							&& addOnProdSegments != null) {
						for (EpcProductSegment epcProductSegment : primaryProductSegments) {
							if (epcProductSegment.getSegment() .equals( searchInput.getSegmentValue())) {
								pFound = true;
								break;
							}
						}
						for (EpcProductSegment epcProductSegment : addOnProdSegments) {
							if (epcProductSegment.getSegment() .equals(searchInput.getSegmentValue())) {
								aFound = true;
								break;
							}
						}
						if (pFound && aFound) {
							//Do nothing
						}else{
							iterator.remove();
						}
					}
				}
			}
			logger.info("AddOn products size after segment Check :"+addOnProducts.size());
			
			//logic for community check
			if(StringUtils.isNotBlank(searchInput.getCommunityId())){
				for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
					EpcProductSpecification epcProductSpecification = iterator.next();
					boolean pFound = false;
					boolean aFound = false;
					List<EpcProductCommunity>  primaryProductCommunities = primaryProduct.getEpcProductCommunity();
					List<EpcProductCommunity>  addOnProdCommunities = epcProductSpecification.getEpcProductCommunity();
					if(primaryProductCommunities != null &&  addOnProdCommunities != null){
						for(EpcProductCommunity epcProductCommunity :primaryProductCommunities){
							if(epcProductCommunity.getCommunityId().equals(Integer.valueOf(searchInput.getCommunityId()))){
								pFound = true;
								break;
							}
						}
						for(EpcProductCommunity epcProductCommunity :addOnProdCommunities){
							if(epcProductCommunity.getCommunityId().equals( Integer.valueOf(searchInput.getCommunityId()))){
								aFound = true;
								break;
							}
						}
						if(pFound && aFound){
							// community check fine
						}else{
							iterator.remove();
							continue;
						}
					}
				}
			}
			logger.info("AddOn products size after community Check :"+addOnProducts.size());
			
			List<EpcProductLocation>  primaryProductLocations = primaryProduct.getEpcProductLocation();
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				List<EpcProductLocation>  addOnProdLocations = epcProductSpecification.getEpcProductLocation();
				//logic for Region check
				if(StringUtils.isNotBlank(searchInput.getRegionValue())){
					boolean pFound = false;
					boolean aFound = false;
					if(primaryProductLocations != null &&  addOnProdLocations != null){
						for(EpcProductLocation epcProductLoc :primaryProductLocations){
							if(epcProductLoc.getLocationCode2().equals(searchInput.getRegionValue())){
								pFound = true;
								break;
							}
						}
						for(EpcProductLocation epcProductLoc :addOnProdLocations){
							if(epcProductLoc.getLocationCode2() .equals(searchInput.getRegionValue())){
								aFound = true;
								break;
							}
						}
						if(pFound && aFound){
							//do nothing
						}else{
							iterator.remove();
							continue;
						}
					}
					
				}
				logger.info("AddOn products size after region Check :"+addOnProducts.size());
				//logic for Area check
				if(StringUtils.isNotBlank(searchInput.getAreaValue())){
					boolean pFound = false;
					boolean aFound = false;
					if(primaryProductLocations != null &&  addOnProdLocations != null){
						for(EpcProductLocation epcProductLoc :primaryProductLocations){
							if(epcProductLoc.getLocationCode3() .equals(searchInput.getAreaValue())){
								pFound = true;
								break;
							}
						}
						for(EpcProductLocation epcProductLoc :addOnProdLocations){
							if(epcProductLoc.getLocationCode3() .equals( searchInput.getAreaValue())){
								aFound = true;
								break;
							}
						}
						if(pFound && aFound){
							// do nothing 
						}else{
							iterator.remove();
							continue;
						}
					}
					
				}
				logger.info("AddOn products size after area Check :"+addOnProducts.size());
				
				
				//logic for Territory check
				if(StringUtils.isNotBlank(searchInput.getTerritoryValue())){
					boolean pFound = false;
					boolean aFound = false;
					if(primaryProductLocations != null &&  addOnProdLocations != null){
						for(EpcProductLocation epcProductLoc :primaryProductLocations){
							if(epcProductLoc.getLocationCode4() .equals( searchInput.getTerritoryValue())){
								pFound = true;
								break;
							}
						}
						for(EpcProductLocation epcProductLoc :addOnProdLocations){
							if(epcProductLoc.getLocationCode4() .equals( searchInput.getTerritoryValue())){
								aFound = true;
								break;
							}
						}
						if(pFound && aFound){
							// do nothing 
						}else{
							iterator.remove();
							continue;
						}
					}
					
				}
				logger.info("AddOn products size after territory Check :"+addOnProducts.size());
			}
			
			//start date check
			Date startDate;
			try {
				startDate = df.parse(searchInput.getStartDate());
			} catch (ParseException e) {
				logger.error(ExceptionUtils.getStackTrace(e));
				queryEligibilityResponse.setRemarks("Start Date is not provided in proper format");
				return queryEligibilityResponse;
			}
			//Add on product paused status and product status
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				if(epcProductSpecification.getIsProductPaused() == 1){
					iterator.remove();
					continue;
				}
				
				if(!(epcProductSpecification.getProductStatus() .equals( epcLookupMasterService.getLookupId("Launch")))){
					iterator.remove();
					continue;
				}
				
				
				//start date check
				EpcProductAvailability availability = epcProductSpecification.getEpcProductAvailability().get(0);
				if(availability.getLifeValidityStartDate().before(startDate) && 
						availability.getLifeValidityEndDate().after(startDate) && 
						availability.getSubscriptionStartDate().before(startDate)&& 
						availability.getSubscriptionEndDate().after(startDate)&& 
						availability.getSellingStartDate().before(startDate)&& 
						availability.getSellingEndDate().after(startDate)
						){
					//do nothing 
				}else{
					iterator.remove();
					continue;
				}
			}
			logger.info("AddOn products size after is paused,product status and start date Check :"+addOnProducts.size());
			
			
			//to get the product as per with request params.
			List<String> finalProdIds = new ArrayList<String>();
			for(EpcProductSpecification epcProductSpecification : addOnProducts){
				finalProdIds.add(String.valueOf(epcProductSpecification.getProductId()));
			}
			allRequestParams.put("productId", finalProdIds);
			logger.info("allRequestParams :"+allRequestParams);
			List<EpcProductSpecification> finalProds = complexSearchInputService.searchProducts(allRequestParams, searchInput.getOrderTypeValue(), true);
			
			//populating the product lists based on classification value
			Map<String, List<EpcProductSpecification>> eligibleProduct = new HashMap<String, List<EpcProductSpecification>>();
			List<String> otherClassification = null;
			if("0".equals(searchInput.getLazy())){
				for(EpcProductSpecification epcProductSpecification : finalProds){
					String classification = epcProductSpecification.getProductClassification();
					if(classification != null && searchInput.getOtherClassification().contains(classification)){
						if(eligibleProduct.containsKey(classification)){
							eligibleProduct.get(classification).add(epcProductSpecification);
						}else{
							List<EpcProductSpecification> epcProds = new ArrayList<EpcProductSpecification>();
							epcProds.add(epcProductSpecification);
							eligibleProduct.put(classification, epcProds);
						}
					}
				}
					
			}else{
				List<String> classifications = Arrays.asList(new String[]{"Social", "Volume", "Voice", "SMS"});
				otherClassification = new ArrayList<String>();
				for(EpcProductSpecification epcProductSpecification : finalProds){
					String classification = epcProductSpecification.getProductClassification();
					if(classification != null && classifications.contains(classification)){
						if(eligibleProduct.containsKey(classification)){
							eligibleProduct.get(classification).add(epcProductSpecification);
						}else{
							List<EpcProductSpecification> epcProds = new ArrayList<EpcProductSpecification>();
							epcProds.add(epcProductSpecification);
							eligibleProduct.put(classification, epcProds);
						}
					}else if (classification != null){
						otherClassification.add(classification);
					}
				}
				
			}
			queryEligibilityResponse.setOtherClassification(otherClassification);
			queryEligibilityResponse.setEligibleProduct(eligibleProduct);
			
			return queryEligibilityResponse;
	}
	
	/**
	 * @param searchInput
	 * @return
	 */
	private EpcOrderChannelRule fetchOrderChannelRule(
			GenericQueryAvailabilitySearchInput searchInput) {
		MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
		criteria.add("orderType", searchInput.getOrderTypeValue());
		criteria.add("initiatingChannel", searchInput.getInitChannelValue());
		criteria.add("salesChannel", searchInput.getSalesChannelValue());
		List<EpcOrderChannelRule> epcOrderChannelRules = epcOrderChannelRuleService.searchEpcOrderChannelRule(criteria);
		EpcOrderChannelRule epcOrderChannelRule = null;
		if(epcOrderChannelRules != null && !epcOrderChannelRules.isEmpty() ){
			epcOrderChannelRule = epcOrderChannelRules.get(0);
		}
		return epcOrderChannelRule;
	}

	/**
	 * @param characteristicServiceClass
	 * @return
	 */
	private Integer fetchPrimaryProductId(
			String characteristicServiceClass) {
		Integer attributeId = epcAttributeMasterService.getAttributeId("Service Class");
		MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
		criteria.add("attributeId", String.valueOf(attributeId));
		List<EpcProductAttribute> epcProductAttrs = epcProductAttributeService.searchProductAttribute(criteria);
		Integer prodId = null;
		if (epcProductAttrs != null && !epcProductAttrs.isEmpty() ){
			for(EpcProductAttribute epcProductAttribute : epcProductAttrs){
				if(characteristicServiceClass.equals(epcProductAttribute.getAttributeValue1()) ){
					prodId = epcProductAttrs.get(0).getProductId();
				}
			}
				
		}
		return prodId;
	}

}
