package com.wipro.epc.uam.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.uam.domain.Users;


/**
 * @author KE334465
 *
 */
public interface UsersRepository extends CrudRepository<Users, String>, UsersRepositoryCustom {

	/**
	 * gets all the users corresponding to the given user name along with their roles
	 * @param username
	 * @return
	 */
	@Query("select u from Users u where u.username = :username")		
	Users findUserAlongWithRoles(@Param("username") String username);
	
}
