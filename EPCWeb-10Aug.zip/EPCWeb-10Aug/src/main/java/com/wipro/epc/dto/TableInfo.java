/**
 * EPC Application - TableInfo.java
 */
package com.wipro.epc.dto;

import java.util.Map;

/**
 * @author Developer
 * @version 1.0
 * type TableInfo
 */
public class TableInfo {
	
	private String tableName;
	private Map <String, FieldInfo> fields;
	
	/**
	 * @return
	 */
	public String getTableName() {
		return tableName;
	}
	/**
	 * @param tableName
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	/**
	 * @return
	 */
	public Map<String, FieldInfo> getFields() {
		return fields;
	}
	/**
	 * @param fields
	 */
	public void setFields(Map<String, FieldInfo> fields) {
		this.fields = fields;
	}
	@Override
	public String toString() {
		return "TableInfo [tableName=" + tableName + ", fields=" + fields + "]";
	}
			
}
