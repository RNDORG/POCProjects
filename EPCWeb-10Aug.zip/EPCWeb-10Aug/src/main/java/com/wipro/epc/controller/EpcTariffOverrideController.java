package com.wipro.epc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.domain.EpcTariffOverride;
import com.wipro.epc.dto.CorporatesAssociatedResponse;
import com.wipro.epc.repositories.EpcTariffOverrideRepository;
import com.wipro.epc.services.BroadcastService;
import com.wipro.epc.services.EpcProductSpecificationService;
import com.wipro.epc.services.EpcTariffOverrideService;

@RestController
public class EpcTariffOverrideController {

	@Autowired
	private EpcProductSpecificationService productService;
	
	@Autowired
	private EpcTariffOverrideRepository tariffOverrideRepository;
	
	@Autowired
	EpcTariffOverrideService epcTariffOverrideService;
	
	@Autowired
	BroadcastService broadcastService;
	
	@RequestMapping(value="rest/api/v1/tariffOverrideUI",method=RequestMethod.GET)
	public List<CorporatesAssociatedResponse> getResultsForUI(@RequestParam(required=false) String productType, @RequestParam(required=false) String productId,
			@RequestParam(required=false) String productClassification, @RequestParam(required=false) String productSubFamily)
	{
		return epcTariffOverrideService.getProductsFromQuery(productType, productId, productClassification, productSubFamily);
	}
    
	@RequestMapping(value="/rest/api/v1/tariffOverride", method=RequestMethod.GET)
	public List<EpcTariffOverride> getTariffOverride(
			 @RequestParam MultiValueMap allRequestParams)
	{
		EpcProductSpecification spec = new EpcProductSpecification();
		List<EpcProductSpecification> speclist = new ArrayList<EpcProductSpecification>();
		speclist = productService.searchProducts(allRequestParams);
		spec=speclist.get(0);
		if(spec!=null) {
			
			if(spec.getProductType().equals("Optional")) {
				
				return tariffOverrideRepository.getTariffOverrideOptional(spec.getProductShortCode());
			}
			else {
				return tariffOverrideRepository.getTariffOverridePrimary(spec.getProductShortCode());
			}
		}
		else {
			return null;
		}
	}
	
	@RequestMapping(value="rest/extapi/v1/reloadTariffOverrideCacheLocal", method=RequestMethod.GET)
	public String reloadTariffOverrideCacheLocal(){
		String msg="";
		try{
		epcTariffOverrideService.loadTariffOverrideCache();
		msg="SUCCESSFULLY RELOADED.";
		}
		catch(GenericException g){
			msg="FAILURE";
		}		
		return msg;
	}
	
	@RequestMapping(value="rest/extapi/v1/reloadTariffOverrideCache", method=RequestMethod.GET)
	public String reloadTariffOverrideCache(){
		String msg="";
		try{
			MultiValueMap allRequestParams=new LinkedMultiValueMap<>();
			allRequestParams.add("api", "reloadTariffOverrideCacheLocal");
			allRequestParams.add("to", "all");
			broadcastService.getReplyService(allRequestParams);
		    msg="SUCCESSFULLY RELOADED.";
		}
		catch(GenericException g){
			msg="FAILURE";
		}		
		return msg;
	}
}
