package com.wipro.epc.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcAttributeMaster;
import com.wipro.epc.exception.EPCException;

/**
 * @author Developer
 * @version 1.0
 * type EpcAttributeMasterRepositoryImpl
 */
public class EpcAttributeMasterRepositoryImpl implements EpcAttributeMasterRepositoryCustom{
	
	
	private static Logger logger =LoggerFactory.getLogger(EpcAttributeMasterRepositoryImpl.class);
	
	/**
	 * EntityManager EpcAttributeMasterRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcAttributeMasterRepositoryCustom#getCharList(java.lang.String)
	 */
	@Override
	public List<EpcAttributeMaster> getCharList(String query){
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcAttributeMaster.class).getResultList();
	
	}
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcAttributeMasterRepositoryCustom#getDataTypeList(java.lang.String)
	 */
	@Override
	public List<EpcAttributeMaster> getDataTypeList(String query){
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcAttributeMaster.class).getResultList();
	
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcAttributeMasterRepositoryCustom#deleteChars(com.wipro.epc.domain.EpcAttributeMaster)
	 */
	@Override
	public EpcAttributeMaster deleteChars(EpcAttributeMaster characteristic){
		
		StringBuilder queryBuilder = new StringBuilder("select count(1) from epc_product_attribute where attribute_id = "+ characteristic.getAttributeId());	
		String query = queryBuilder.toString();
		int maxValue = ((Number) em.createNativeQuery(query).getSingleResult()).intValue();
		
		//System.out.println(maxValue+"-----------");
		
		if(maxValue <1){
			StringBuilder queryBuilderForDelete = new StringBuilder("delete from EPC_ATTRIBUTE_MASTER where attribute_id = "+ characteristic.getAttributeId());	
			String queryForDelete = queryBuilderForDelete.toString();
			logger.debug("#Query: "+queryForDelete);
			em.createNativeQuery(queryForDelete).executeUpdate();
			
		}
		else{
			throw new EPCException("Error in deleting");
		}
			
			return characteristic;
		
		
		
		}
	
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcAttributeMasterRepositoryCustom#searchCharName()
	 */
	@Override
	public List<String> searchCharName(){
		
		List<String> temp = new ArrayList<String>();
		StringBuilder queryBuilder = new StringBuilder("select distinct prod.attribute_name from epc_attribute_master prod inner join epc_product_attribute mstr on prod.attribute_id = mstr.attribute_id;");	
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		temp =  em.createNativeQuery(query).getResultList();;
		
		
		
			
			return temp;
		
		
		
		}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcAttributeMasterRepositoryCustom#checkChars(com.wipro.epc.domain.EpcAttributeMaster)
	 */
	@Override
	public int checkChars(EpcAttributeMaster characteristic){
		
		StringBuilder queryBuilder = new StringBuilder("select count(1) from epc_attribute_master where attribute_name = '"+ characteristic.getAttributeName()+"'");	
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		//System.out.println(query+"---2--------");
		int maxValue = ((Number) em.createNativeQuery(query).getSingleResult()).intValue();
		//
		////System.out.println(maxValue+"---1--------");
		
			return maxValue;
		
		}
	
	
	}

