package com.wipro.epc.dto;

import java.io.Serializable;
import java.util.List;

import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.domain.EpcTriggerOrderRule;

/**
 * @author Developer
 * @version 1.0
 * type OrderType
 */
public class OrderType implements Serializable{
	
	/**
	 * long OrderType.java
	 */
	private static final long serialVersionUID = 1711876966677124386L;
	/**
	 * String OrderType.java
	 */
	private String orderType;
	/**
	 * List<EpcOrderChannelRule> OrderType.java
	 */
	private List<EpcOrderChannelRule> epcOrderChannelRule;
	/**
	 * List<EpcProductDecomposition> OrderType.java
	 */
	private List<EpcProductDecomposition> epcProductDecomposition;
	/**
	 * List<EpcTriggerOrderRule> OrderType.java
	 */
	private List<EpcTriggerOrderRule> epcTriggerOrderRule;
		
	/**
	 * @return
	 */
	public String getOrderType() {
		return orderType;
	}
	/**
	 * @param orderType
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	/*public Integer getOrderTypeValue() {
		this.orderTypeValue = orderType;
		return orderTypeValue;
	}
	public void setOrderTypeValue(Integer orderTypeValue) {
		this.orderTypeValue = orderTypeValue;
	}*/
	
	/**
	 * @return
	 */
	public List<EpcOrderChannelRule> getEpcOrderChannelRule() {
		return epcOrderChannelRule;
	}
	/**
	 * @param epcOrderChannelRule
	 */
	public void setEpcOrderChannelRule(List<EpcOrderChannelRule> epcOrderChannelRule) {
		this.epcOrderChannelRule = epcOrderChannelRule;
	}
	/**
	 * @return
	 */
	public List<EpcProductDecomposition> getEpcProductDecomposition() {
		return epcProductDecomposition;
	}
	/**
	 * @param epcProductDecomposition
	 */
	public void setEpcProductDecomposition(
			List<EpcProductDecomposition> epcProductDecomposition) {
		this.epcProductDecomposition = epcProductDecomposition;
	}
	/**
	 * @return
	 */
	public List<EpcTriggerOrderRule> getEpcTriggerOrderRule() {
		return epcTriggerOrderRule;
	}
	/**
	 * @param epcTriggerOrderRule
	 */
	public void setEpcTriggerOrderRule(List<EpcTriggerOrderRule> epcTriggerOrderRule) {
		this.epcTriggerOrderRule = epcTriggerOrderRule;
	}
	
}
