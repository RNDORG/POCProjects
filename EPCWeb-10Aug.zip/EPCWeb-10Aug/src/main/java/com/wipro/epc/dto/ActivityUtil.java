package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type ActivityUtil
 */
public class ActivityUtil {
	/**
	 * String ActivityUtil.java
	 */
	private String activityName;
	/**
	 * String ActivityUtil.java
	 */
	private String activityKey;
	/**
	 * String ActivityUtil.java
	 */
	private String activityValue;
	/**
	 * String ActivityUtil.java
	 */
	private String activityId;
	/**
	 * String ActivityUtil.java
	 */
	private String activityDetailId;
	/**
	 * @return
	 */
	public String getActivityId() {
		return activityId;
	}
	/**
	 * @param activityId
	 */
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	/**
	 * @return
	 */
	public String getActivityDetailId() {
		return activityDetailId;
	}
	/**
	 * @param activityDetailId
	 */
	public void setActivityDetailId(String activityDetailId) {
		this.activityDetailId = activityDetailId;
	}
	/**
	 * @return
	 */
	public String getActivityName() {
		return activityName;
	}
	/**
	 * @param activityName
	 */
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	/**
	 * @return
	 */
	public String getActivityKey() {
		return activityKey;
	}
	/**
	 * @param activityKey
	 */
	public void setActivityKey(String activityKey) {
		this.activityKey = activityKey;
	}
	/**
	 * @return
	 */
	public String getActivityValue() {
		return activityValue;
	}
	/**
	 * @param activityValue
	 */
	public void setActivityValue(String activityValue) {
		this.activityValue = activityValue;
	}
	
	
}
