/**
 * EPC Application - FlexiPlanResponse.java
 */
package com.wipro.epc.dto;

import java.math.BigDecimal;

import com.wipro.epc.util.Constants;

/**
 * @author Developer
 * @version 1.0
 * type FlexiPlanResponse
 */
public class FlexiPlanResponse {

	private String status = Constants.RESPONSE_FAIL_STATUS;
	private BigDecimal flexiPrice;
	private BigDecimal flexiPriceWithTax;
	private BigDecimal savingPercentage;
	private String remarks;
	/**
	 * @return
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return
	 */
	public BigDecimal getFlexiPrice() {
		return flexiPrice;
	}
	/**
	 * @param flexiPrice
	 */
	public void setFlexiPrice(BigDecimal flexiPrice) {
		this.flexiPrice = flexiPrice;
	}
	public BigDecimal getFlexiPriceWithTax() {
		return flexiPriceWithTax;
	}
	public void setFlexiPriceWithTax(BigDecimal flexiPriceWithTax) {
		this.flexiPriceWithTax = flexiPriceWithTax;
	}
	/**
	 * @return the savingPercentage
	 */
	public BigDecimal getSavingPercentage() {
		return savingPercentage;
	}
	/**
	 * @param savingPercentage the savingPercentage to set
	 */
	public void setSavingPercentage(BigDecimal savingPercentage) {
		this.savingPercentage = savingPercentage;
	}
	/**
	 * @return
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	

}
