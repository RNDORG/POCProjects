package com.wipro.epc.esb;



//import com.wipro.epc.esb.vassubscriptiondetails.VASSubscriptiondetails;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;



/**
 * @author Developer
 * @version 1.0
 * type QueryVASServiceConfig
 */
@Configuration
public class QueryVASServiceConfig {

	/**
	 * @return
	 */
	@Bean
	public Jaxb2Marshaller marshaller() {
		//System.out.println("in 1");
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		//marshaller.setContextPath("com.wipro.epc.esb.queryvasservice");
		marshaller.setContextPath("com.wipro.epc.esb.queryvasservice");
		return marshaller;
	}
	
	/**
	 * @param marshaller
	 * @return
	 */
	@Bean
	public EsbRequestService VASService (Jaxb2Marshaller marshaller) {
		//System.out.println("in 2");
		EsbRequestService queryVAS = new EsbRequestService();
		queryVAS.setMarshaller(marshaller());
		queryVAS.setUnmarshaller(marshaller());
		return queryVAS;
	}
/*	@Bean(name="vasClient")
	public JaxWsPortProxyFactoryBean VasClient() throws MalformedURLException{
		JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
		 bean.setServiceInterface(VASSubscriptiondetails.class);
		bean.setWsdlDocumentUrl(new URL("http://10.10.23.191:7001/VASSubscriptiondetails/PS/VASSubscriptiondetailsPS?wsdl"));
		bean.setServiceName("VASSubscriptiondetails");
		bean.setPortName("VASSubscriptiondetailsSOAP");
		bean.setEndpointAddress("http://10.10.23.191:7001/VASSubscriptiondetails/PS/VASSubscriptiondetailsPS?wsdl");
		
		return bean;
	}*/
	
	
}
