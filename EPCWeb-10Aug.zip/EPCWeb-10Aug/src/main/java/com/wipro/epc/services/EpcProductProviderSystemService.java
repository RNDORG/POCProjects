package com.wipro.epc.services;

import java.util.ArrayList;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductProviderSystem;
import com.wipro.epc.dto.ProviderProductListInput;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.uam.definitions.MetaInfo;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductProviderSystemService
 */
@Service
public class EpcProductProviderSystemService {
	/**
	 * Logger EpcProductProviderSystemService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(EpcProductProviderSystemService.class);

	/**
	 * com.wipro.epc.repositories.EpcProductProviderSystemRepository EpcProductProviderSystemService.java
	 */
	@Autowired
	com.wipro.epc.repositories.EpcProductProviderSystemRepository epcProductProviderSystemRepository;

	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductProviderSystem> searchProvider(Map<String, List<String>> allRequestParams) {
		if (allRequestParams.get("with") != null) {
			allRequestParams.remove("with");
		}
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductProviderSystem.class.getName(), null);
		List<EpcProductProviderSystem> listOfProviderReturned = null;
		try {
			listOfProviderReturned = epcProductProviderSystemRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return listOfProviderReturned;
		
	}



	
	/**
	 * @param ProductProviderSystemList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductProviderSystem> manageProductProviders(List<EpcProductProviderSystem> ProductProviderSystemList, String createdBy )
	{
		List<EpcProductProviderSystem> retListOfEpcProductProviderSystem = new ArrayList<EpcProductProviderSystem>();

		for (EpcProductProviderSystem productProviderSystem : ProductProviderSystemList) {
			
				productProviderSystem = manageProductProviderSystem(productProviderSystem, createdBy);
				if((productProviderSystem.getMetaInfo().get("STATUS")==null))
				{
					productProviderSystem.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
				}
			
			
			retListOfEpcProductProviderSystem.add(productProviderSystem);
		}
		return retListOfEpcProductProviderSystem;
	}
	
	/**
	 * @param productProviderSystem
	 * @param createdBy
	 * @return
	 */
	EpcProductProviderSystem manageProductProviderSystem(EpcProductProviderSystem productProviderSystem, String createdBy)
	{
		EpcProductProviderSystem retProductProviderSystem = null;
		switch (productProviderSystem.getMetaInfo().get("OPERATION")) {

		case "CREATE":
			retProductProviderSystem = createProductProviderSystem(productProviderSystem, createdBy);
			break;
		case "UPDATE":
			retProductProviderSystem = modifyProductProviderSystem(productProviderSystem, createdBy);
			break;
		case "DELETE":
			retProductProviderSystem = deleteProductProviderSystem(productProviderSystem);
			break;
		default:
			throw new EPCException("not supported");
		}
		return retProductProviderSystem;
		
	}
	/**
	 * @param ProductProviderSystem
	 * @return
	 */
	EpcProductProviderSystem deleteProductProviderSystem(EpcProductProviderSystem ProductProviderSystem) {
		
		epcProductProviderSystemRepository.delete(ProductProviderSystem.getProductProviderSystemId());
		return ProductProviderSystem;
	}

	/**
	 * @param ProductProviderSystem
	 * @param lastUpdatedBy
	 * @return
	 */
	EpcProductProviderSystem modifyProductProviderSystem(EpcProductProviderSystem ProductProviderSystem, String lastUpdatedBy) {
		ProductProviderSystem.setModifiedBy(lastUpdatedBy);
		return epcProductProviderSystemRepository.modifyProductProviders(ProductProviderSystem);
	}

	/**
	 * @param ProductProviderSystem
	 * @param createdBy
	 * @return
	 */
	EpcProductProviderSystem createProductProviderSystem(EpcProductProviderSystem ProductProviderSystem, String createdBy) {
		ProductProviderSystem.setCreatedBy(createdBy);
		ProductProviderSystem.setCreatedDate(new Date());
		epcProductProviderSystemRepository.save(ProductProviderSystem);
		return ProductProviderSystem;
	}

	/**
	 * @param providersList
	 * @return
	 */
	public List<EpcProductProviderSystem> getList(
			List<ProviderProductListInput> providersList) {
		StringBuilder queryBuilder = new StringBuilder(" select * from epc_product_provider_system where ");
		for (int i = 0; i < providersList.size() ; i++){
			queryBuilder.append(" provider_product_id ='").append(providersList.get(i).getProviderProductId()).append("' and provider_system_code= '").append(providersList.get(i).getProviderSystem()).append("'") ;
			if( i != (providersList.size()-1)){
				queryBuilder.append(" or ");
			}
		}
	//	logger.info("Query is>>"+queryBuilder.toString());
		List<EpcProductProviderSystem> list = null;
		try {
			list = epcProductProviderSystemRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		return list;
	}
	
	
	List<EpcProductProviderSystem> providers = null;
    
    public Integer getAddOnIdCached(String providerProductId, String providerSystemCode ){
          Integer id = null;      
          if(providers == null)
                {
                      loadProviderCache();
                }
                for ( EpcProductProviderSystem  provProdSystem: providers ){
                      if (providerProductId.equals(provProdSystem.getProviderProductId())
                                  && providerSystemCode.equals(provProdSystem.getProviderSystemCode())){
                            id = provProdSystem.getProductId();
                      }
                }
          return id;
    }
    
    public void loadProviderCache()
    {
    	providers=new ArrayList<EpcProductProviderSystem>();
        providers = epcProductProviderSystemRepository.getList("select * from epc_product_provider_system ");
    }

}
