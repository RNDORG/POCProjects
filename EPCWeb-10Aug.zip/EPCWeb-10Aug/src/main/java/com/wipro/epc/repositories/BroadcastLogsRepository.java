package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.BroadcastLogs;


@Repository
public interface BroadcastLogsRepository extends CrudRepository<BroadcastLogs, Integer> {

	@Query(value="select  * from broadcast_logs order by broadcast_timestamp desc limit 10", nativeQuery=true)
	List<BroadcastLogs> findBroadCasts();
	
	@Query(value="select  * from broadcast_logs order by broadcast_timestamp desc limit 1", nativeQuery=true)
	BroadcastLogs findTheRecentOne();
	
}
