package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.common.config.domain.Config;
import com.wipro.common.config.service.ConfigService;
import com.wipro.common.config.service.ReloadListener;
import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcLookupMaster;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcLookupMasterRepository;
/**
 * 
 * @author VI251443
 * @version 1.0
 */
@Service
public class EpcLookupMasterService implements ReloadListener {

	@Autowired
	EpcLookupMasterRepository masterRepo;
	
	List<EpcLookupMaster> epcLookupCache;

	@Autowired
	ConfigService configService;
	
	@PostConstruct 
	void postConstruct() {
		configService.addListener(this);
	}
	
	
	
	
	private static Logger logger = LoggerFactory
			.getLogger(EpcLookupMasterService.class);

	/**
	 * 
	 */
	synchronized public void loadCache() {
		epcLookupCache = masterRepo.getAllListofValues();
	}
  /**
   * 
   * @param group
   * @param name
   * @param value
   * @return
   */
	public String getLookupId(String group, String name, String value) {
		if (epcLookupCache == null) {
			loadCache();
		}
		for (EpcLookupMaster epcLookupMaster : epcLookupCache) {
			if (epcLookupMaster != null
					&& epcLookupMaster.getLookupGroup().equals(group)
					&& epcLookupMaster.getLookupName().equals(name)
					&& epcLookupMaster.getLookupId().equals(value)) {
				return epcLookupMaster.getLookupId();
			}

		}
		return null;
	}
	
	/*public String getLookupValue(Integer id) {
		if (epcLookupCache == null) {
			loadCache();
		}
		for (EpcLookupMaster epcLookupMaster : epcLookupCache) {
			if (epcLookupMaster != null
					&& epcLookupMaster.getLookupId().equals(id)) {
				return epcLookupMaster.getLookupValue();
			}
		}
		return null;
	}*/
	
	/**
	 * 
	 * @param value
	 * @return
	 */
	public String getLookupId(String value) {
		if (epcLookupCache == null) {
			loadCache();
		}
		for (EpcLookupMaster epcLookupMaster : epcLookupCache) {
			if (epcLookupMaster != null
					&& epcLookupMaster.getLookupValue().equals(value)) {
				return String.valueOf(epcLookupMaster.getLookupId());
			}

		}
		return "9999999";
	}
/**
 * 
 * @param parent_lookup_id
 * @param lookup_group
 * @param lookup_name
 * @return
 */
	public List<EpcLookupMaster> getLookupvalues(Integer parent_lookup_id,
			String lookup_group, String lookup_name) {
		String queryBuilder = "select * from epc_lookup_master where lookup_group = "
				+ "'"
				+ lookup_group
				+ "' and lookup_name ='"
				+ lookup_name
				+ "'";
		logger.info("service parent " + parent_lookup_id);

		if (parent_lookup_id != null) {

			logger.info("Inside what we wanted.....");
			queryBuilder += " and parent_lookup_id =" + parent_lookup_id;
		}
		//logger.info("Query Builder is >>>" + queryBuilder);
		List<EpcLookupMaster> listOfValuesReturned = null;
		try {
			listOfValuesReturned = this.masterRepo
					.getListofValues(queryBuilder);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		return listOfValuesReturned;
	}
/**
 * 
 * @return
 */
	public List<EpcLookupMaster> getAllListofValues(){
		if (epcLookupCache == null) {
			loadCache();
		}
		return 	epcLookupCache;
	}
	
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcLookupMaster> searchLookUpMaster(Map<String, List<String>> allRequestParams){
		
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,EpcLookupMaster.class.getName(), null);
		
		List<EpcLookupMaster> retLookUps=null;
		try {
			retLookUps = masterRepo.getListofValues(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return retLookUps;
		
	}
	
	public List<String> getLookUpValuesByGroupAndName(String group, String name){
		if (epcLookupCache == null) {
			loadCache();
		}
		List<String> lookups = new ArrayList<String>();
		for (EpcLookupMaster epcLookupMaster : epcLookupCache) {
			if (epcLookupMaster != null
					&& epcLookupMaster.getLookupGroup().equals(group)
					&& epcLookupMaster.getLookupName().equals(name)) {
				lookups.add(epcLookupMaster.getLookupId());
			}
		}
		return 	lookups;
	}
	/* (non-Javadoc)
	 * @see com.wipro.common.config.service.ReloadListener#onReload(java.util.List, java.util.List)
	 */
	@Override
	public void onReload(List<Config> oldConfig, List<Config> newConfig) {
		String group="LookupService";
		String key="LookupReloadCount";
		String oldLookupMasterConfig = configService.searchConfigKey(oldConfig,group,key).getConfigValue();
		String newLookupMasterConfig = configService.searchConfigKey(newConfig,group,key).getConfigValue();
		if (oldLookupMasterConfig!=null && newLookupMasterConfig!=null && !oldLookupMasterConfig.equals(newLookupMasterConfig))  {
			logger.debug("Reloading Lookup Master Cache");
			loadCache();
		}		
	}
}
