package com.wipro.epc.dto;


/**
 * @author Developer
 * @version 1.0
 * type ProviderProductQueryInput
 */
public class ProviderAttributesQueryInput {

	
	private String fnf;
	
	private String  callblock;
	
	private String clientRequestId;

	/**
	 * @return the fnf
	 */
	public String getFnf() {
		return fnf;
	}

	/**
	 * @param fnf the fnf to set
	 */
	public void setFnf(String fnf) {
		this.fnf = fnf;
	}

	/**
	 * @return the callblock
	 */
	public String getCallblock() {
		return callblock;
	}

	/**
	 * @param callblock the callblock to set
	 */
	public void setCallblock(String callblock) {
		this.callblock = callblock;
	}

	/**
	 * @return the clientRequestId
	 */
	public String getClientRequestId() {
		return clientRequestId;
	}

	/**
	 * @param clientRequestId the clientRequestId to set
	 */
	public void setClientRequestId(String clientRequestId) {
		this.clientRequestId = clientRequestId;
	}
}
