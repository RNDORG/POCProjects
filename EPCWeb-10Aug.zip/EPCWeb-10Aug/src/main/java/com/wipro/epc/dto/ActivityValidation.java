package com.wipro.epc.dto;


/**
 * @author Developer
 * @version 1.0
 * type ActivityValidation
 */
public class ActivityValidation {

	/**
	 * Integer ActivityValidation.java
	 */
	private Integer activityId;
	/**
	 * Integer ActivityValidation.java
	 */
	private Integer salesChannel;
	/**
	 * Integer ActivityValidation.java
	 */
	private Integer initiatingChannel;
	
	/**
	 * @return
	 */
	public Integer getActivityId() {
		return activityId;
	}
	
	/**
	 * @param activityId
	 */
	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}
	
	/**
	 * @return
	 */
	public Integer getSalesChannel() {
		return salesChannel;
	}
	
	/**
	 * @param salesChannel
	 */
	public void setSalesChannel(Integer salesChannel) {
		this.salesChannel = salesChannel;
	}
	
	/**
	 * @return
	 */
	public Integer getInitiatingChannel() {
		return initiatingChannel;
	}
	
	/**
	 * @param initiatingChannel
	 */
	public void setInitiatingChannel(Integer initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}
	
}
