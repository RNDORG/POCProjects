package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductCompatibility;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductCompatibilityRepositoryCustom
 */
public interface EpcProductCompatibilityRepositoryCustom {
	
/**
 * @param string
 * @return
 */
List<EpcProductCompatibility> getList(String string);
	
/**
 * @param product
 * @return
 */
EpcProductCompatibility modifyProductCompatibility(EpcProductCompatibility product);

}
