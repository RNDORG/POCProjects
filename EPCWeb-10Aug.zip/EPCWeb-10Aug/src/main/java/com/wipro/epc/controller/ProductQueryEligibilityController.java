package com.wipro.epc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.dto.QueryEligibilityResponse;
import com.wipro.epc.dto.QueryEligibiltySearchInput;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.ProductQueryEligibiltyService;



/**
 * @author Developer
 * @version 1.0
 * type ProductQueryEligibilityController
 */
@RestController
public class ProductQueryEligibilityController {

	/**
	 * ProductQueryEligibiltyService ProductQueryEligibilityController.java
	 */
	
	private static Logger logger = LoggerFactory.getLogger(ProductQueryEligibilityController.class);
	
	
	@Autowired
	ProductQueryEligibiltyService queryEligibiltyService;
	

	/**
	 * TransactionsService ProductQueryEligibilityController.java
	 */
	@Autowired
	TransactionsService transactionsLogging ;

	/**
	 * ObjectMapper ProductQueryEligibilityController.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * TransactionStore ProductQueryEligibilityController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/queryEligibilityNonCached", method=RequestMethod.POST)
	public QueryEligibilityResponse checkEligibilityExt(@RequestBody QueryEligibiltySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		String txnType="queryEligibility";
		String request=null;
		QueryEligibilityResponse response=null;
		try{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, searchInput);
		response=queryEligibiltyService.checkEligibility(searchInput,allRequestParams);
		}
		 catch (Exception e ) {
				logger.error("#interfaceException: " + e.getMessage());
				throw new EPCException(e.getMessage());
			}
		finally{
		ePCTxnInterceptor.postTxn(txnType, request,response);
		}
		return response;
		
	}
	
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/queryEligibilityNonCached", method=RequestMethod.POST)
	public QueryEligibilityResponse checkEligibility(@RequestBody QueryEligibiltySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		return queryEligibiltyService.checkEligibility(searchInput,allRequestParams);
	}
	
}
