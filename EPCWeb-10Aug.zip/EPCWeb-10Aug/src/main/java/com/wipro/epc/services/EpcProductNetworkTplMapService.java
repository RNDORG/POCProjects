package com.wipro.epc.services;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductNetworkTplMap;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.uam.definitions.MetaInfo;


/**
 * @author KE334465
 *
 */
@Service
public class EpcProductNetworkTplMapService {

	
	private static Logger logger = LoggerFactory.getLogger(EpcProductNetworkTplMapService.class);

	/**
	 * 
	 */
	@Autowired
	private com.wipro.epc.repositories.EpcProductNetworkTplMapRepository epcProductNetworkTplMapRepository;

	
	/**
	 * @param ProductNetworkTplMapList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductNetworkTplMap> manageNetworkTplMaps(List<EpcProductNetworkTplMap> ProductNetworkTplMapList, String createdBy )
	{
		//List<EpcProductNetworkTplMap> retListOfEpcProductNetworkTplMap = new ArrayList<EpcProductNetworkTplMap>();

		for (EpcProductNetworkTplMap networkTplMap : ProductNetworkTplMapList) {
			
				manageNetworkTplMap(networkTplMap, createdBy);
				if((networkTplMap.getMetaInfo().get("STATUS")==null))
				{
					networkTplMap.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
				}
			
			
			//retListOfEpcProductNetworkTplMap.add(networkTplMap);
		}
		return ProductNetworkTplMapList;
	}
	
	/**
	 * @param networkTplMap
	 * @param createdBy
	 * @return
	 */
	EpcProductNetworkTplMap manageNetworkTplMap(EpcProductNetworkTplMap networkTplMap, String createdBy)
	{
		EpcProductNetworkTplMap retNetworkTplMap = null;
		switch (networkTplMap.getMetaInfo().get("OPERATION")) {

		case "CREATE":
			retNetworkTplMap = createNetworkTplMap(networkTplMap, createdBy);
			break;
		case "UPDATE":
			retNetworkTplMap = modifyNetworkTplMap(networkTplMap, createdBy);
			break;
		case "DELETE":
			retNetworkTplMap = deleteNetworkTplMap(networkTplMap);
			break;
		default:
			throw new EPCException("not supported");
		}
		return retNetworkTplMap;
		
	}
	/**
	 * @param networkTplMap
	 * @return
	 */
	EpcProductNetworkTplMap deleteNetworkTplMap(EpcProductNetworkTplMap networkTplMap) {
		
		epcProductNetworkTplMapRepository.deleteProductFromNetworkTpl(networkTplMap.getProductId());
		return networkTplMap;
	}

	/**
	 * @param networkTplMap
	 * @param lastUpdatedBy
	 * @return
	 */
	EpcProductNetworkTplMap modifyNetworkTplMap(EpcProductNetworkTplMap networkTplMap, String lastUpdatedBy) {
		networkTplMap.setModifiedBy(lastUpdatedBy);
		epcProductNetworkTplMapRepository.modifyNetworkId(networkTplMap);
		return networkTplMap;
	}

	/**
	 * @param networkTplMap
	 * @param createdBy
	 * @return
	 */
	EpcProductNetworkTplMap createNetworkTplMap(EpcProductNetworkTplMap networkTplMap, String createdBy) {
		networkTplMap.setCreatedBy(createdBy);
		epcProductNetworkTplMapRepository.save(networkTplMap);
		return networkTplMap;
	}
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductNetworkTplMap> searchNetworkTemplateMap(Map<String, List<String>> allRequestParams) {
		 String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,EpcProductNetworkTplMap.class.getName(), null);
		
		List<EpcProductNetworkTplMap> returnedChar = null;
		try {
			returnedChar = epcProductNetworkTplMapRepository.getNetworkTemplateMapList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		return returnedChar;
	}

	/**
	 * @return
	 */
	public static Logger getLogger() {
		return logger;
	}

	/**
	 * @param logger
	 */
	public static void setLogger(Logger logger) {
		EpcProductNetworkTplMapService.logger = logger;
	}

	/**
	 * @return
	 */
	public com.wipro.epc.repositories.EpcProductNetworkTplMapRepository getEpcProductNetworkTplMapRepository() {
		return epcProductNetworkTplMapRepository;
	}

	/**
	 * @param epcProductNetworkTplMapRepository
	 */
	public void setEpcProductNetworkTplMapRepository(
			com.wipro.epc.repositories.EpcProductNetworkTplMapRepository epcProductNetworkTplMapRepository) {
		this.epcProductNetworkTplMapRepository = epcProductNetworkTplMapRepository;
	}

}
