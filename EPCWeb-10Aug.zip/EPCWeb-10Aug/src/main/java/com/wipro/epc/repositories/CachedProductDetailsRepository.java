package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.CachedProductDetails;



@Repository
public interface CachedProductDetailsRepository extends  CrudRepository<CachedProductDetails, Integer>,
CachedProductDetailsRepositoryCustom{
	
	CachedProductDetails getById(int id);
	
	@Query( value=" select * from cached_product_details where id IN :ids  ",nativeQuery=true)
	List<CachedProductDetails> findByIds(@Param( "ids" ) List<Integer> ids);
	
	@Query( value=" select id from cached_product_details  ",nativeQuery=true)
	List<Integer> getIds();
	

	@Query( value=" Select * from cached_product_details  where status= 'Load' and id IN :ids  ",nativeQuery=true)
	List<CachedProductDetails> findByIdsForStatus(@Param( "ids" ) List<Integer> ids);
	
	
	/*@Modifying(clearAutomatically=true)
	@Query( value=" delete from cached_product_details where id IN :ids  ",nativeQuery=true)
	void deleteByGivenIds(@Param( "ids" ) List<String> ids);*/

}
