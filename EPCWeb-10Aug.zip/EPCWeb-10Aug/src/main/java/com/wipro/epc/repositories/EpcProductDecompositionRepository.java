package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.domain.EpcProductSpecification;

/**
 * This class extending the crud Repositories
 * of Domain class and EpcProductDecompositionRepositoryCustom
 * @author VI251443
 * @version 1.0
 */
public interface EpcProductDecompositionRepository extends CrudRepository<EpcProductDecomposition,Integer>,
EpcProductDecompositionRepositoryCustom{
	
	/**
	 * 
	 * @param productId
	 * @return list of EpcProductDecomposition
	 */
	@Query(value="select * from epc_product_decomposition where product_id=:productId", nativeQuery = true)
	List<EpcProductDecomposition> findDecompositionByProductId(@Param("productId") Integer productId);
	
	/**
	 *
	 * @param productId
	 */
	@Modifying
	@Query(value="delete from epc_product_decomposition where product_id=:productId", nativeQuery=true)
	void deleteProductFromDecomposition(@Param("productId") Integer productId);

	/**
	 * 
	 * @param notification_template_id
	 * @return list of EpcProductDecomposition
	 */
	@Query(value="select * from epc_product_decomposition where notification_template_id = :notification_template_id", nativeQuery=true)
	List<EpcProductSpecification> getDecompositionByNotificationTemplate(@Param("notification_template_id")
			Integer notification_template_id);

}
