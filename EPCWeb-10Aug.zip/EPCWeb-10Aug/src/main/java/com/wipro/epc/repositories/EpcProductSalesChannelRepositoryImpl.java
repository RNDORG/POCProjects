package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcProductSalesChannel;


/**
 * @author Developer
 * @version 1.0
 * type EpcProductSalesChannelRepositoryImpl
 */
public class EpcProductSalesChannelRepositoryImpl implements EpcProductSalesChannelRepositoryCustom{

	private static Logger logger =LoggerFactory.getLogger(EpcProductSalesChannelRepositoryImpl.class);
	
	
	/**
	 * EntityManager EpcProductSalesChannelRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductSalesChannelRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcProductSalesChannel> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductSalesChannel.class).getResultList();
		
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductSalesChannelRepositoryCustom#modifyProductSalesChannel(com.wipro.epc.domain.EpcProductSalesChannel)
	 */
	@Override
	public EpcProductSalesChannel modifyProductSalesChannel(EpcProductSalesChannel channel) {
StringBuilder queryBuilder = new StringBuilder("update epc_product_sales_channel set product_sales_channel_id="+channel.getProductSalesChannelId());
		
		if(channel.getPartnerType()!=null && !channel.getPartnerType().isEmpty())
			queryBuilder.append(",").append(" partner_type = '").append(channel.getPartnerType()).append("'");
		if(channel.getStatus()!=null && !channel.getStatus().isEmpty())
			queryBuilder.append(",").append(" status = '").append(channel.getStatus()).append("'");
		if(channel.getPartnersList()!=null )
			queryBuilder.append(",").append(" partners_list = '").append(channel.getPartnersList()).append("'");
		queryBuilder.append(" where product_sales_channel_id =").append(channel.getProductSalesChannelId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		
		return channel;
	}

}
