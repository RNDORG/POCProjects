package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductAvailability;


/**
 * @author KE334465
 *
 */
public interface EpcProductAvailabilityRepositoryCustom {
	
	/**
	 * @param string
	 * @return
	 */
	List<EpcProductAvailability> getList(String string);
	
	/**
	 * @param product
	 * @return
	 */
	EpcProductAvailability modifyProductAvailability(EpcProductAvailability product);
}
