package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcActivityChannelRule;
/**
 * @version 1.0
 * @author VI251443
 *
 */
@Repository
public interface EpcActivityChannelRuleRepositoryCustom {
/**
 * 	
 * @param query
 * @return
 */
List<EpcActivityChannelRule> getSearchResult (String query);

/**
 * 	
 * @param order
 * @return
 */
EpcActivityChannelRule modifyActivity (EpcActivityChannelRule order);

}
