package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcProductInitChannel;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductInitChannelRepositoryImpl
 */
public class EpcProductInitChannelRepositoryImpl implements EpcProductInitChannelRepositoryCustom{
	
	
	private static Logger logger =LoggerFactory.getLogger(EpcProductInitChannelRepositoryImpl.class);
	
	
	/**
	 * EntityManager EpcProductInitChannelRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductInitChannelRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcProductInitChannel> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductInitChannel.class).getResultList();
	}

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductInitChannelRepositoryCustom#modifyProductInitChannel(com.wipro.epc.domain.EpcProductInitChannel)
	 */
	@Override
	public EpcProductInitChannel modifyProductInitChannel(
			EpcProductInitChannel channel) {
	
StringBuilder queryBuilder = new StringBuilder("update epc_product_init_channel set product_init_channel_id="+channel.getProductInitChannelId());
		
		if(channel.getChannelId()!=null && !channel.getChannelId().isEmpty())
			queryBuilder.append(",").append(" channel_id = '").append(channel.getChannelId()).append("'");
		if(channel.getStatus()!=null && !channel.getStatus().isEmpty())
			queryBuilder.append(",").append(" status = '").append(channel.getStatus()).append("'");
		if(channel.getActionType()!=null && !channel.getActionType().isEmpty())
			queryBuilder.append(",").append(" action_type = '").append(channel.getActionType()).append("'");
		if(channel.getChannelLevelMarketName()!=null)
			queryBuilder.append(",").append(" channel_level_market_name = '").append(channel.getChannelLevelMarketName()).append("'");
		if(channel.getServiceKeyword()!=null )
			queryBuilder.append(",").append(" service_keyword = '").append(channel.getServiceKeyword()).append("'");
		if(channel.getChannelShortCode()!=null )
			queryBuilder.append(",").append(" channel_short_code = '").append(channel.getChannelShortCode()).append("'");
		if(channel.getUrlString()!=null )
			queryBuilder.append(",").append(" url_string = '").append(channel.getUrlString()).append("'");
		if(channel.getIsNotificationRequired()!=null && channel.getIsNotificationRequired()!=0)
			queryBuilder.append(",").append(" is_notification_required = '").append(channel.getIsNotificationRequired()).append("'");
		if(channel.getNotificationTemplateId()!=null && channel.getNotificationTemplateId()!=0 )
			queryBuilder.append(",").append(" notification_template_id = ").append(channel.getNotificationTemplateId());
		if(channel.getChannelLevelProductId()!=null && !channel.getChannelLevelProductId().isEmpty() )
			queryBuilder.append(",").append(" channel_level_product_id= '").append(channel.getChannelLevelProductId()).append("'");
		if(channel.getServiceKeywordOther()!=null && !channel.getServiceKeywordOther().isEmpty() )
			queryBuilder.append(",").append(" service_keyword_other = '").append(channel.getServiceKeywordOther()).append("'");
		queryBuilder.append(" where product_init_channel_id =").append(channel.getProductInitChannelId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		
		return channel;
	}

}
