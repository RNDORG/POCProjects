package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductCompatibility;


/**
 * @author Developer
 * @version 1.0
 * type EpcProductCompatibilityRepository
 */
public interface EpcProductCompatibilityRepository extends CrudRepository<EpcProductCompatibility,Integer>,
EpcProductCompatibilityRepositoryCustom{
	
	/**
	 * @param productId
	 * @return
	 */
	@Query(value="select * from epc_product_compatibility where product_id=:productId", nativeQuery = true)
	List<EpcProductCompatibility> findCompatibilityByProductId(@Param("productId") Integer productId);
	
	/**
	 * @param productId
	 */
	@Modifying
	@Query(value="delete from epc_product_compatibility where product_id=:productId", nativeQuery=true)
	void deleteProductFromCompatibility(@Param("productId") Integer productId);

	/**
	 * @param productId
	 * @param otherProductId
	 */
	@Modifying
	@Query(value="delete from epc_product_compatibility where (product_id=:productId and other_product_id=:otherProductId) or (product_id=:otherProductId and other_product_id=:productId )", nativeQuery=true)
	void removeProductFromCompatibility(@Param("productId") Integer productId,@Param("otherProductId") Integer otherProductId);
}
