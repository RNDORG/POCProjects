/**
 * 
 */
package com.wipro.epc.esb;




import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.wipro.epc.esb.queryvasservice.CurrentSubscriptionsType;
import com.wipro.epc.esb.queryvasservice.QueryVASServiceRequestType;
import com.wipro.epc.esb.queryvasservice.QueryVASServicesResponseMsg;
import com.wipro.epc.esb.vassubscriptiondetails.VASSubscriptiondetails_Service;


/**
 * @author Developer
 * @version 1.0
 * type EsbRequestService
 */
public class EsbRequestService extends WebServiceGatewaySupport {

	 /**
	 * Logger EsbRequestService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(EsbRequestService.class);
	 
	 /**
	 * @param msisdn
	 * @param URL
	 * @return
	 */
	public List<Map<String,String>> getVASAddons(String msisdn, String URL){
		 if(StringUtils.isBlank(msisdn)){
			 logger.error("MSISDN not Received");
			 return null;
		 }
		 logger.info("ESB Request URL is "+URL);
		 synchronized(this){
		 QueryVASServiceRequestType vasServiceRequest = new QueryVASServiceRequestType();
		 vasServiceRequest.setSubscriberNo(msisdn);
		// vasServiceRequest.setSubscriberNo("8801711083817");
		 vasServiceRequest.setOrigSourceSystem("CCC");
		 vasServiceRequest.setOrigTxnRefId("89765");
		 vasServiceRequest.setOfferProvider("");
		 
		 /*VASSubscriptiondetails b = (VASSubscriptiondetails) config.VasClient();
		 QueryVASServicesResponseMsg  resp = b.queryVASSService(vasServiceRequest);
		 //System.out.println(resp.getQueryVASServiceResponse());*/
		 
		 VASSubscriptiondetails_Service ser= new VASSubscriptiondetails_Service();	 
		 logger.info("ESB Request : subcriberNo="+ vasServiceRequest.getSubscriberNo()+", origSourceSystem="+ vasServiceRequest.getOrigSourceSystem()+", origTxnRefId="+ vasServiceRequest.getOrigTxnRefId()+", offerProvider="+ vasServiceRequest.getOfferProvider());
		 QueryVASServicesResponseMsg resp = (QueryVASServicesResponseMsg) getWebServiceTemplate()
					.marshalSendAndReceive(URL,ser.getVASSubscriptiondetailsSOAP().queryVASSService(vasServiceRequest));
		logger.info("Received Response from ESB");	
		
		if(resp!=null && resp.getQueryVASServiceResponse()!=null ){
		// List<String> productShortCodes = new ArrayList<>();
		 List<Map<String, String>> esbOutList =  new ArrayList<Map<String, String>>();
		 for(CurrentSubscriptionsType currenSubscription : resp.getQueryVASServiceResponse().getCurrentSubscriptions()){
			 
			 Map<String, String> esbOut =  new HashMap<String, String>();
		 
		   // Adding Key and Value pairs to Hashtable
			  esbOut.put("providerProductId",(currenSubscription.getOfferId()==null ? "" : currenSubscription.getOfferId()));
			  esbOut.put("providerSystemCode",(currenSubscription.getOfferProvider()==null ? "" : currenSubscription.getOfferProvider()));
			// productShortCodes.add(currenSubscription.getOfferId());
			 esbOutList.add(esbOut);
			
		 }
		 logger.info("ESB CurntSubscriptions are "+esbOutList);//System.out.println(esbOutList);
		 return esbOutList;
		}
		else{
			logger.error("Problem in recieving response from ESB");
			return null;
		}
		 }
	 }



}
