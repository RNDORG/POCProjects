package com.wipro.epc.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.WebUtils;

/**
 * @author Developer
 * @version 1.0
 * type SecurityConfig
 */
@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableWebSecurity
public class SecurityConfig {
	/**
	 * Logger SecurityConfig.java
	 */
	private static Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

	/**
	 * @author Developer
	 * @version 1.0
	 * type ApiApplicationSecurity1
	 */
	@Configuration
	@Order(1)
	protected static class ApiApplicationSecurity1 extends
			EPCWebSecurityConfigurationAdapter {
		@Value("${spring.profiles.active:nonjndi}")
		private String jndiName;
		
		@Override
	    protected void configure(HttpSecurity httpSecurity) throws Exception {
			
	        httpSecurity.csrf().disable()	        
			.antMatcher("/db-console/**").authorizeRequests()
			.anyRequest().authenticated().and()
			.httpBasic();
	        httpSecurity.headers().frameOptions().disable();
	    }
	 

	}
	
	
	/**
	 * @author Developer
	 * @version 1.0
	 * type ApiApplicationSecurity
	 */
	@Configuration
	@Order(2)
	protected static class ApiApplicationSecurity extends
			EPCWebSecurityConfigurationAdapter {
	
		@Override
		protected void configure(HttpSecurity http) throws Exception {
			// @formatter:off
			http
			.csrf().disable()
			.antMatcher("/rest/extapiauth/v1/**").authorizeRequests()//.and()
			//.antMatcher("/rest/api/v1/**").authorizeRequests()
			.anyRequest().authenticated().and()
			.httpBasic();			
			// @formatter:on
		}

	}
	
	@Configuration
	@Order(3)
	protected static class ExtApiApplicationSecurity extends
			EPCWebSecurityConfigurationAdapter {
	
		@Override
		protected void configure(HttpSecurity http) throws Exception {
			// @formatter:off
			http
			.csrf().disable()
			.antMatcher("/rest/extapi/v1/**").authorizeRequests()
			.anyRequest().permitAll();
			// @formatter:on
		}

	}

	/**
	 * @return
	 */
	@Bean
	public ApplicationSecurity applicationSecurity() {
		return new ApplicationSecurity();
	}

	/**
	 * @author Developer
	 * @version 1.0
	 * type ApplicationSecurity
	 */
	@Configuration
	@Order(4) // SecurityProperties.ACCESS_OVERRIDE_ORDER)
	protected static class ApplicationSecurity extends
			EPCWebSecurityConfigurationAdapter {

		@Override
		protected void configure(HttpSecurity http) throws Exception {
			// @formatter:off
			http
				.authorizeRequests()
					.antMatchers("/rest/spcl/uri/**").permitAll()
					.antMatchers("/assets/**").permitAll()
					.antMatchers("/err/**").permitAll()
					.antMatchers("/logbuffer/**").permitAll()
					.anyRequest().authenticated().and()
				.formLogin().loginPage("/login")
					.failureUrl("/login?error")
					.usernameParameter("username")
					.passwordParameter("password")
					.permitAll().and()
				.logout().deleteCookies("JSESSIONID", "XSRF-TOKEN")
				.logoutRequestMatcher(new AntPathRequestMatcher("/logout")).permitAll()
				.and()
			
				.csrf().csrfTokenRepository(csrfTokenRepository())
				.and()
				.addFilterAfter(new SecurityConfig.CsrfHeaderFilter(), CsrfFilter.class);
					
			// @formatter:on
		}
		
		 @Bean
		 public CsrfTokenRepository csrfTokenRepository() {
		 HttpSessionCsrfTokenRepository repository = new HttpSessionCsrfTokenRepository();
		 repository.setHeaderName("X-XSRF-TOKEN");
		 return repository;
		 }
	}

	public static class CsrfHeaderFilter extends OncePerRequestFilter {
		 @Override
		 protected void doFilterInternal(HttpServletRequest request,
		 HttpServletResponse response, FilterChain filterChain)
		 throws ServletException, IOException {
			 
			 //making cookie http-only
			// String sessionid = request.getSession().getId();
			// be careful overwriting: JSESSIONID may have been set with other flags
			//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionid + "; HttpOnly");
			
			
		 CsrfToken csrf = (CsrfToken) request.getAttribute(CsrfToken.class
		 .getName());
		 if (csrf != null) {
		 Cookie cookie = WebUtils.getCookie(request, "XSRF-TOKEN");
		 String token = csrf.getToken();
		 if (cookie == null || token != null && !token.equals(cookie.getValue())) {
		 cookie = new Cookie("XSRF-TOKEN", token);
		 cookie.setPath("/");		
		 response.addCookie(cookie);
		 }
		 }
		 filterChain.doFilter(request, response);
		 }
		 }
	
}
