
package com.wipro.epc.esb.gettransactionshistory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.CustomRefType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.TransactionReferenceType;


/**
 * <p>Java class for getTransactionsHistoryRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getTransactionsHistoryRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}TransactionReference" minOccurs="0"/>
 *         &lt;element name="phoneNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="startRecordNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="endRecordNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="queryType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="startTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="endTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OperatorId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrigSourceSystem" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrigTxnRefId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrigTxnRefDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}CustomRef" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getTransactionsHistoryRequestType", propOrder = {
    "transactionReference",
    "phoneNumber",
    "startRecordNum",
    "endRecordNum",
    "queryType",
    "startTime",
    "endTime",
    "operatorId",
    "origSourceSystem",
    "origTxnRefId",
    "origTxnRefDate",
    "customRef"
})
public class GetTransactionsHistoryRequestType {

    @XmlElement(name = "TransactionReference", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected TransactionReferenceType transactionReference;
    @XmlElement(required = true)
    protected String phoneNumber;
    protected String startRecordNum;
    protected String endRecordNum;
    protected String queryType;
    protected String startTime;
    protected String endTime;
    @XmlElement(name = "OperatorId")
    protected String operatorId;
    @XmlElement(name = "OrigSourceSystem")
    protected String origSourceSystem;
    @XmlElement(name = "OrigTxnRefId")
    protected String origTxnRefId;
    @XmlElement(name = "OrigTxnRefDate")
    protected String origTxnRefDate;
    @XmlElement(name = "CustomRef", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected CustomRefType customRef;

    /**
     * Gets the value of the transactionReference property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionReferenceType }
     *     
     */
    public TransactionReferenceType getTransactionReference() {
        return transactionReference;
    }

    /**
     * Sets the value of the transactionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionReferenceType }
     *     
     */
    public void setTransactionReference(TransactionReferenceType value) {
        this.transactionReference = value;
    }

    /**
     * Gets the value of the phoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the value of the phoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneNumber(String value) {
        this.phoneNumber = value;
    }

    /**
     * Gets the value of the startRecordNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartRecordNum() {
        return startRecordNum;
    }

    /**
     * Sets the value of the startRecordNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartRecordNum(String value) {
        this.startRecordNum = value;
    }

    /**
     * Gets the value of the endRecordNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndRecordNum() {
        return endRecordNum;
    }

    /**
     * Sets the value of the endRecordNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndRecordNum(String value) {
        this.endRecordNum = value;
    }

    /**
     * Gets the value of the queryType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQueryType() {
        return queryType;
    }

    /**
     * Sets the value of the queryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQueryType(String value) {
        this.queryType = value;
    }

    /**
     * Gets the value of the startTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartTime() {
        return startTime;
    }

    /**
     * Sets the value of the startTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartTime(String value) {
        this.startTime = value;
    }

    /**
     * Gets the value of the endTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndTime() {
        return endTime;
    }

    /**
     * Sets the value of the endTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndTime(String value) {
        this.endTime = value;
    }

    /**
     * Gets the value of the operatorId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatorId() {
        return operatorId;
    }

    /**
     * Sets the value of the operatorId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorId(String value) {
        this.operatorId = value;
    }

    /**
     * Gets the value of the origSourceSystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigSourceSystem() {
        return origSourceSystem;
    }

    /**
     * Sets the value of the origSourceSystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigSourceSystem(String value) {
        this.origSourceSystem = value;
    }

    /**
     * Gets the value of the origTxnRefId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigTxnRefId() {
        return origTxnRefId;
    }

    /**
     * Sets the value of the origTxnRefId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigTxnRefId(String value) {
        this.origTxnRefId = value;
    }

    /**
     * Gets the value of the origTxnRefDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigTxnRefDate() {
        return origTxnRefDate;
    }

    /**
     * Sets the value of the origTxnRefDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigTxnRefDate(String value) {
        this.origTxnRefDate = value;
    }

    /**
     * Gets the value of the customRef property.
     * 
     * @return
     *     possible object is
     *     {@link CustomRefType }
     *     
     */
    public CustomRefType getCustomRef() {
        return customRef;
    }

    /**
     * Sets the value of the customRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomRefType }
     *     
     */
    public void setCustomRef(CustomRefType value) {
        this.customRef = value;
    }

}
