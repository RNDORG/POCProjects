package com.wipro.epc.dto;

import java.util.List;

import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductProviderSystem;

/**
 * @author Developer
 * @version 1.0
 * type QueryAvailabilityProductSpec
 */
public class QueryAvailabilityProductSpec {
	
	/**
	 * String QueryAvailabilityProductSpec.java
	 */
	private String offerId;
	/**
	 * String QueryAvailabilityProductSpec.java
	 */
	private String offerName;
	/**
	 * String QueryAvailabilityProductSpec.java
	 */
	private String description;
	/**
	 * String QueryAvailabilityProductSpec.java
	 */
	private String offerProvider;
	/**
	 * String QueryAvailabilityProductSpec.java
	 */
	private String offerType;
	/**
	 * String QueryAvailabilityProductSpec.java
	 */
	private String offerLevel;
	/*private String price;
	private String priceType;*/
	/**
	 * List<EpcProductAttribute> QueryAvailabilityProductSpec.java
	 */
	private List<EpcProductAttribute> productCharacteristic;
	/**
	 * List<EpcProductProviderSystem> QueryAvailabilityProductSpec.java
	 */
	private List<EpcProductProviderSystem> productProvider;
	/**
	 * List<EpcProductAttribute> QueryAvailabilityProductSpec.java
	 */
	private List<EpcProductAttribute> productTariff;
	/**
	 * List<EpcProductInitChannel> QueryAvailabilityProductSpec.java
	 */
	private List<EpcProductInitChannel> productInitiatingChannel;
	/**
	 * @return
	 */
	public String getOfferId() {
		return offerId;
	}
	/**
	 * @param offerId
	 */
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	/**
	 * @return
	 */
	public String getOfferName() {
		return offerName;
	}
	/**
	 * @param offerName
	 */
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}
	/**
	 * @return
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return
	 */
	public String getOfferProvider() {
		return offerProvider;
	}
	/**
	 * @param offerProvider
	 */
	public void setOfferProvider(String offerProvider) {
		this.offerProvider = offerProvider;
	}
	/**
	 * @return
	 */
	public String getOfferType() {
		return offerType;
	}
	/**
	 * @param offerType
	 */
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	/**
	 * @return
	 */
	public String getOfferLevel() {
		return offerLevel;
	}
	/**
	 * @param offerLevel
	 */
	public void setOfferLevel(String offerLevel) {
		this.offerLevel = offerLevel;
	}
	/*public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getPriceType() {
		return priceType;
	}
	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}*/
	/**
	 * @return
	 */
	public List<EpcProductAttribute> getProductCharacteristic() {
		return productCharacteristic;
	}
	/**
	 * @param productCharacteristic
	 */
	public void setProductCharacteristic(
			List<EpcProductAttribute> productCharacteristic) {
		this.productCharacteristic = productCharacteristic;
	}
	/**
	 * @return
	 */
	public List<EpcProductProviderSystem> getProductProvider() {
		return productProvider;
	}
	/**
	 * @param productProvider
	 */
	public void setProductProvider(List<EpcProductProviderSystem> productProvider) {
		this.productProvider = productProvider;
	}
	/**
	 * @return
	 */
	public List<EpcProductAttribute> getProductTariff() {
		return productTariff;
	}
	/**
	 * @param productTariff
	 */
	public void setProductTariff(List<EpcProductAttribute> productTariff) {
		this.productTariff = productTariff;
	}
	/**
	 * @return
	 */
	public List<EpcProductInitChannel> getProductInitiatingChannel() {
		return productInitiatingChannel;
	}
	/**
	 * @param productInitiatingChannel
	 */
	public void setProductInitiatingChannel(
			List<EpcProductInitChannel> productInitiatingChannel) {
		this.productInitiatingChannel = productInitiatingChannel;
	}
	
}
