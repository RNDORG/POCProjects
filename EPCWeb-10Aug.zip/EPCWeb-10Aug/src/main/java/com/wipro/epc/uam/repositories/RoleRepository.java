package com.wipro.epc.uam.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.uam.domain.Role;


/**
 * @author KE334465
 *
 */
public interface RoleRepository extends CrudRepository<Role, Long>{

	/**
	 * finds a role corresponding to given name 
	 * @param name
	 * @return
	 */
	Role findByName(String name);
	
	
	/**
	 * given an user, this functions returns the roles for him, 
	 * @param username
	 * @return
	 */
	@Query(value="select * from role where role_id in (select role_id from user_role_map where user_name=:username)", nativeQuery=true)
	List<Role> findRolesByUsername(@Param("username") String username);
}
