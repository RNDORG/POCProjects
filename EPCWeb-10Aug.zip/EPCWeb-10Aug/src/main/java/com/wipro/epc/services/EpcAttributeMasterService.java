package com.wipro.epc.services;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcAttributeMaster;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcAttributeMasterRepository;
import com.wipro.epc.util.Constants;

/**
 * @author Developer
 * @version 1.0
 * type EpcAttributeMasterService
 */
@Service
public class EpcAttributeMasterService {
/**
 * EpcAttributeMasterRepository EpcAttributeMasterService.java
 */
@Autowired
EpcAttributeMasterRepository epcAttributeMasterRepository;
	
	/**
	 * Logger EpcAttributeMasterService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(EpcAttributeMasterService.class);
	
	/**
	 * @param attributeName
	 * @return
	 */
	public Integer getAttributeId(String attributeName) {
		
		List<EpcAttributeMaster> epcAttributeCache = epcAttributeMasterRepository.getCharList(" select * from epc_attribute_master where attribute_name = '"+attributeName+"'");
		if (epcAttributeCache != null){
			return epcAttributeCache.get(0).getAttributeId();
		}
		return null;
	}
	
	/**
	 * @return
	 */
	public Map<Integer,EpcAttributeMaster> getAttributes() {
		List<EpcAttributeMaster> attrMasters = epcAttributeMasterRepository.getCharList(" select * from epc_attribute_master ");
		Map<Integer,EpcAttributeMaster> returnMap = new HashMap<Integer,EpcAttributeMaster>();
		for (EpcAttributeMaster epcAttributeMaster : attrMasters) {
			returnMap.put(epcAttributeMaster.getAttributeId(), epcAttributeMaster);
		}
		return returnMap;
	}
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcAttributeMaster> searchChar(Map<String, List<String>> allRequestParams) {
		 String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,EpcAttributeMaster.class.getName(), null);
		
		//logger.info("*****************query Search****************************************************************");		
		//logger.info(queryBuilder);		
		//logger.info("*****************query Search****************************************************************");
		
		List<EpcAttributeMaster> returnedChar = null;
		try {
			returnedChar = epcAttributeMasterRepository.getCharList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		 
		//logger.info("*************return object Search********************************************************************");		
		//logger.info(returnedChar.toString());		
		//logger.info("**************return object Search*******************************************************************");
		
			return returnedChar;
	}
//**********************************************UPDATE CHARACTERISTICS*****************************************************************************************	
	
	/**
	 * @param charList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcAttributeMaster> updateCharacteristics(List<EpcAttributeMaster> charList,String createdBy){
		
		List<EpcAttributeMaster> retCharList = new ArrayList<EpcAttributeMaster>();		
		
		for(EpcAttributeMaster characteristic : charList){
			try{
				characteristic =  updateCharacteristic(characteristic , createdBy);
				characteristic.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);				
			}
			catch(Exception e){				
					characteristic.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.ERROR);
					characteristic.getMetaInfo().put(MetaInfo.ERROR_MESSAGE, e.getMessage());
			}
			retCharList.add(characteristic);
		}		
		return retCharList;
	}
	
	/**
	 * @param characteristic
	 * @param createdBy
	 * @return
	 */
	public EpcAttributeMaster updateCharacteristic(EpcAttributeMaster characteristic, String  createdBy){		

		EpcAttributeMaster retChar = null;
		
		
		switch(characteristic.getMetaInfo().get("OPERATION")){
		
		case "CREATE":
			retChar = createCharacteristic(characteristic, createdBy);
			break;
			
		case "DELETE":
			retChar = deleteCharacteristic(characteristic, createdBy);
			break;

		default:
			throw new EPCException("Not Valid Opeation");
	}
		return retChar;		
	}
	
	/**
	 * @param characteristic
	 * @param createdBy
	 * @return
	 */
	public EpcAttributeMaster createCharacteristic(EpcAttributeMaster characteristic , String createdBy){
		
		int returnValidation =  epcAttributeMasterRepository.checkChars(characteristic);
		if(returnValidation >0){
			throw new EPCException("characteristic data already exits");
			
		}
		else{
			characteristic.setStatus(Constants.COMMON_STATUS_ACTIVE);
			characteristic.setCreatedBy(createdBy);//foreign key
			characteristic.setCreatedDate(new Date());
			characteristic.setModifiedBy(createdBy);//foreign key
			characteristic.setModifiedDate(new Date());
			
			//logger.info(characteristic+" is the object gonna get saved");
			
			epcAttributeMasterRepository.save(characteristic);
			
			//logger.info("********************************FROM DATABASE Create*******************************");
			//logger.info(epcAttributeMasterRepository.findByAttributeName(characteristic.getAttributeName()).toString());
			//logger.info("********************************FROM DATABASE Create*******************************");
			//logger.debug("Product charactereistic added succesfully....");
			
			return characteristic;
		}
		
	}
	
	/**
	 * @param characteristic
	 * @param createdBy
	 * @return
	 */
	public EpcAttributeMaster deleteCharacteristic(EpcAttributeMaster characteristic, String  createdBy ){

		 epcAttributeMasterRepository.deleteChars(characteristic);
		
		return characteristic;
		
	}

	/**
	 * @return
	 */
	public List<String> searchCharName( ){

		List<String> charName =epcAttributeMasterRepository.searchCharName();
		
		return charName;
		
	}

	//***********************************************************************************************************
	
	/**
	 * @return
	 */
	public List<EpcAttributeMaster> searchDataType() {
		{ 	
			String queryBuilder = "select attribute_data_type from epc_attribute_master ;";
			//logger.info("Query Builder is >>> "+queryBuilder);
			List<EpcAttributeMaster> listOfValuesReturned = null;
			try {
				listOfValuesReturned = epcAttributeMasterRepository.getDataTypeList(queryBuilder);
			} catch (Exception e) {
				throw new EPCException(
						"Error occurred while fetching results from database.\n"
								+ " Query: " + queryBuilder.toString() + "\n"
								+ " Exception: " + e.getMessage(), e);
			}
				return listOfValuesReturned;
		}	
		
	}

	/**
	 * @param attributeName
	 * @param attributeDataType
	 * @param attributeCtg
	 * @param attributeCtgType
	 * @return
	 */
	public List<EpcAttributeMaster> searchCharFromUI(
			String attributeName, String attributeDataType, String attributeCtg,String attributeCtgType) {
		
		
		String query = "";//"select * from epc_attribute_master ";
	//	if(attributeCtgType!=null){
			if(!"null".equals(attributeCtgType) && !"".equals(attributeCtgType)) {
				query = query+"select * from epc_attribute_master ";
				attributeCtgType = attributeCtgType.replace("*", "%");
				query = query + " where attribute_ctg_type = '"+attributeCtgType+"'";
				
				if(attributeName!=null && !attributeName.equals("null") && !attributeName.equals("") ){
					
					attributeName = attributeName.replace("*", "%");
						query = query + " and attribute_name like ('"+attributeName+"')";
				}
				if(attributeDataType!=null){
					if(!"null".equals(attributeDataType) && !"".equals(attributeDataType)){
						attributeDataType = attributeDataType.replace("*", "%");
						query = query + " and attribute_data_type = '"+attributeDataType+"'";
					}
				}
				if(attributeCtg!=null){
					if(!"null".equals(attributeCtg) && !"".equals(attributeCtg)){
						attributeCtg = attributeCtg.replace("*", "%");
						query = query + " and attribute_ctg = '"+attributeCtg+"'";
					}
				}
			
			}
	//	}
		/*else {
			if(attributeDataType!=null)
				if(!attributeDataType.equals("null") && !attributeDataType.equals("")) {
					attributeDataType = attributeDataType.replace("*", "%");
					query = query + " where attribute_data_type = '"+attributeDataType+"'";
				}
		
		}*/
		
		//logger.info("Query generated is "+query);
		List<EpcAttributeMaster> returnedChar = null;
		try {
			returnedChar = epcAttributeMasterRepository.getCharList(query.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + query.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		return returnedChar;
	}

	/**
	 * @param charQuery
	 * @return
	 */
	public List<Integer> getAttributeIds(String charQuery) {
		String query = " select * from epc_attribute_master where "+charQuery;
	//	logger.debug(query);
		List<EpcAttributeMaster> attrMasters = epcAttributeMasterRepository.getCharList(query);
		List<Integer> ids = null;
		
		if (attrMasters != null && !attrMasters.isEmpty()) {
			ids = new ArrayList<Integer>();
			for (EpcAttributeMaster epcAttributeMaster : attrMasters) {
				ids.add(epcAttributeMaster.getAttributeId());
			}
		}
		
		return ids;
	}
		
}	
