@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.wipro.epc.esb.xmlns.schema.common._1_0.common;
