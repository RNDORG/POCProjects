package com.wipro.epc.domain;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;


/**
 * The persistent class for the cache_eligibility database table.
 * 
 */
@Entity
@Table(name="cache_eligibility")
public class CacheEligibility implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer id;

	@Column(name="action_type")
	private String actionType;

	@Column(name="bypass_eligibility_check")
	private String bypassEligibilityCheck;

	@Column(name="community_id")
	private String communityId;

	@Column(name="customer_rate_plan_id")
	private String customerRatePlanId;

	private Integer data;

	@Column(name="data_unit")
	private String dataUnit;

	@Column(name="flexi_price")
	private BigDecimal flexiPrice;

	@Column(name="initiating_channel")
	private String initiatingChannel;

	@Column(name="optional_product_id")
	private String optionalProductId;

	@Column(name="order_type")
	private String orderType;

	@Column(name="other_product_id1")
	private String otherProductId1;

	@Column(name="other_product_id2")
	private String otherProductId2;

	@Column(name="other_product_id3")
	private String otherProductId3;

	@Column(name="other_product_id4")
	private String otherProductId4;

	@Lob
	private String response;

	@Column(name="sales_channel")
	private String salesChannel;

	@Column(name="slab_id")
	private String slabId;

	private Integer sms;

	@Column(name="source_system")
	private String sourceSystem;

	@Column(name="start_date")
	private String startDate;

	@Column(name="subscribed_add_on_id")
	private String subscribedAddOnId;

	private Integer validity;

	private Integer voice;

	@Column(name="voice_type")
	private String voiceType;

	@Column(name="voice_unit")
	private String voiceUnit;

	@Column(name="with_char")
	private String withChar;

	@Column(name="with_decomposition")
	private String withDecomposition;

	@Column(name="with_init_channel")
	private String withInitChannel;

	@Column(name="with_notification")
	private String withNotification;

	@Column(name="with_nta")
	private String withNta;

	@Column(name="with_ocr")
	private String withOcr;

	@Column(name="with_provider")
	private String withProvider;

	@Column(name="with_ta")
	private String withTa;

	@Column(name="with_tariff")
	private String withTariff;

	@Column(name="with_tor")
	private String withTor;

	public CacheEligibility() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getActionType() {
		return this.actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getBypassEligibilityCheck() {
		return this.bypassEligibilityCheck;
	}

	public void setBypassEligibilityCheck(String bypassEligibilityCheck) {
		this.bypassEligibilityCheck = bypassEligibilityCheck;
	}

	public String getCommunityId() {
		return this.communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public String getCustomerRatePlanId() {
		return this.customerRatePlanId;
	}

	public void setCustomerRatePlanId(String customerRatePlanId) {
		this.customerRatePlanId = customerRatePlanId;
	}

	public Integer getData() {
		return this.data;
	}

	public void setData(Integer data) {
		this.data = data;
	}

	public String getDataUnit() {
		return this.dataUnit;
	}

	public void setDataUnit(String dataUnit) {
		this.dataUnit = dataUnit;
	}

	public BigDecimal getFlexiPrice() {
		return this.flexiPrice;
	}

	public void setFlexiPrice(BigDecimal flexiPrice) {
		this.flexiPrice = flexiPrice;
	}

	public String getInitiatingChannel() {
		return this.initiatingChannel;
	}

	public void setInitiatingChannel(String initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}

	public String getOptionalProductId() {
		return this.optionalProductId;
	}

	public void setOptionalProductId(String optionalProductId) {
		this.optionalProductId = optionalProductId;
	}

	public String getOrderType() {
		return this.orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getOtherProductId1() {
		return this.otherProductId1;
	}

	public void setOtherProductId1(String otherProductId1) {
		this.otherProductId1 = otherProductId1;
	}

	public String getOtherProductId2() {
		return this.otherProductId2;
	}

	public void setOtherProductId2(String otherProductId2) {
		this.otherProductId2 = otherProductId2;
	}

	public String getOtherProductId3() {
		return this.otherProductId3;
	}

	public void setOtherProductId3(String otherProductId3) {
		this.otherProductId3 = otherProductId3;
	}

	public String getOtherProductId4() {
		return this.otherProductId4;
	}

	public void setOtherProductId4(String otherProductId4) {
		this.otherProductId4 = otherProductId4;
	}

	public String getResponse() {
		return this.response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getSalesChannel() {
		return this.salesChannel;
	}

	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}

	public String getSlabId() {
		return this.slabId;
	}

	public void setSlabId(String slabId) {
		this.slabId = slabId;
	}

	public Integer getSms() {
		return this.sms;
	}

	public void setSms(Integer sms) {
		this.sms = sms;
	}

	public String getSourceSystem() {
		return this.sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getStartDate() {
		return this.startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getSubscribedAddOnId() {
		return this.subscribedAddOnId;
	}

	public void setSubscribedAddOnId(String subscribedAddOnId) {
		this.subscribedAddOnId = subscribedAddOnId;
	}

	public Integer getValidity() {
		return this.validity;
	}

	public void setValidity(Integer validity) {
		this.validity = validity;
	}

	public Integer getVoice() {
		return this.voice;
	}

	public void setVoice(Integer voice) {
		this.voice = voice;
	}

	public String getVoiceType() {
		return this.voiceType;
	}

	public void setVoiceType(String voiceType) {
		this.voiceType = voiceType;
	}

	public String getVoiceUnit() {
		return this.voiceUnit;
	}

	public void setVoiceUnit(String voiceUnit) {
		this.voiceUnit = voiceUnit;
	}

	public String getWithChar() {
		return this.withChar;
	}

	public void setWithChar(String withChar) {
		this.withChar = withChar;
	}

	public String getWithDecomposition() {
		return this.withDecomposition;
	}

	public void setWithDecomposition(String withDecomposition) {
		this.withDecomposition = withDecomposition;
	}

	public String getWithInitChannel() {
		return this.withInitChannel;
	}

	public void setWithInitChannel(String withInitChannel) {
		this.withInitChannel = withInitChannel;
	}

	public String getWithNotification() {
		return this.withNotification;
	}

	public void setWithNotification(String withNotification) {
		this.withNotification = withNotification;
	}

	public String getWithNta() {
		return this.withNta;
	}

	public void setWithNta(String withNta) {
		this.withNta = withNta;
	}

	public String getWithOcr() {
		return this.withOcr;
	}

	public void setWithOcr(String withOcr) {
		this.withOcr = withOcr;
	}

	public String getWithProvider() {
		return this.withProvider;
	}

	public void setWithProvider(String withProvider) {
		this.withProvider = withProvider;
	}

	public String getWithTa() {
		return this.withTa;
	}

	public void setWithTa(String withTa) {
		this.withTa = withTa;
	}

	public String getWithTariff() {
		return this.withTariff;
	}

	public void setWithTariff(String withTariff) {
		this.withTariff = withTariff;
	}

	public String getWithTor() {
		return this.withTor;
	}

	public void setWithTor(String withTor) {
		this.withTor = withTor;
	}

	public CacheEligibility(String actionType, String bypassEligibilityCheck,
			String communityId, String customerRatePlanId, Integer data,
			String dataUnit, BigDecimal flexiPrice, String initiatingChannel,
			String optionalProductId, String orderType, String otherProductId1,
			String otherProductId2, String otherProductId3,
			String otherProductId4, String response, String salesChannel,
			String slabId, Integer sms, String sourceSystem, String startDate,
			String subscribedAddOnId, Integer validity, Integer voice,
			String voiceType, String voiceUnit, String withChar,
			String withDecomposition, String withInitChannel,
			String withNotification, String withNta, String withOcr,
			String withProvider, String withTa, String withTariff,
			String withTor) {
		super();
		this.actionType = actionType;
		this.bypassEligibilityCheck = bypassEligibilityCheck;
		this.communityId = communityId;
		this.customerRatePlanId = customerRatePlanId;
		this.data = data;
		this.dataUnit = dataUnit;
		this.flexiPrice = flexiPrice;
		this.initiatingChannel = initiatingChannel;
		this.optionalProductId = optionalProductId;
		this.orderType = orderType;
		this.otherProductId1 = otherProductId1;
		this.otherProductId2 = otherProductId2;
		this.otherProductId3 = otherProductId3;
		this.otherProductId4 = otherProductId4;
		this.response = response;
		this.salesChannel = salesChannel;
		this.slabId = slabId;
		this.sms = sms;
		this.sourceSystem = sourceSystem;
		this.startDate = startDate;
		this.subscribedAddOnId = subscribedAddOnId;
		this.validity = validity;
		this.voice = voice;
		this.voiceType = voiceType;
		this.voiceUnit = voiceUnit;
		this.withChar = withChar;
		this.withDecomposition = withDecomposition;
		this.withInitChannel = withInitChannel;
		this.withNotification = withNotification;
		this.withNta = withNta;
		this.withOcr = withOcr;
		this.withProvider = withProvider;
		this.withTa = withTa;
		this.withTariff = withTariff;
		this.withTor = withTor;
	}

}