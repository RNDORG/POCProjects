
package com.wipro.epc.esb.queryvasservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.FaultType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="QueryVASServiceResponse" type="{http://www.telenor.com.mm/QueryVASService}QueryVASSServiceResponseType" minOccurs="0"/>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}Fault" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "queryVASServiceResponse",
    "fault"
})
@XmlRootElement(name = "QueryVASServicesResponseMsg")
public class QueryVASServicesResponseMsg {

    @XmlElement(name = "QueryVASServiceResponse")
    protected QueryVASSServiceResponseType queryVASServiceResponse;
    @XmlElement(name = "Fault", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected FaultType fault;

    /**
     * Gets the value of the queryVASServiceResponse property.
     * 
     * @return
     *     possible object is
     *     {@link QueryVASSServiceResponseType }
     *     
     */
    public QueryVASSServiceResponseType getQueryVASServiceResponse() {
        return queryVASServiceResponse;
    }

    /**
     * Sets the value of the queryVASServiceResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryVASSServiceResponseType }
     *     
     */
    public void setQueryVASServiceResponse(QueryVASSServiceResponseType value) {
        this.queryVASServiceResponse = value;
    }

    /**
     * Gets the value of the fault property.
     * 
     * @return
     *     possible object is
     *     {@link FaultType }
     *     
     */
    public FaultType getFault() {
        return fault;
    }

    /**
     * Sets the value of the fault property.
     * 
     * @param value
     *     allowed object is
     *     {@link FaultType }
     *     
     */
    public void setFault(FaultType value) {
        this.fault = value;
    }

}
