package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type Attribute
 */
public class Attribute {
	/**
	 * Integer Attribute.java
	 */
	private Integer attributeId;
	/**
	 * String Attribute.java
	 */
	private String attributeName;
	/**
	 * String Attribute.java
	 */
	private String attributeValue;
	/**
	 * @return
	 */
	public String getAttributeName() {
		return attributeName;
	}
	/**
	 * @param attributeName
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	/**
	 * @return
	 */
	public String getAttributeValue() {
		return attributeValue;
	}
	/**
	 * @param attributeValue
	 */
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}
	/**
	 * @return
	 */
	public Integer getAttributeId() {
		return attributeId;
	}
	/**
	 * @param attributeId
	 */
	public void setAttributeId(Integer attributeId) {
		this.attributeId = attributeId;
	}
}
