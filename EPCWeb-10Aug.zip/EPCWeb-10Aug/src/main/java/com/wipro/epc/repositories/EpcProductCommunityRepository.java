package com.wipro.epc.repositories;

import java.util.List;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcProductCommunity;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
@Repository
public interface EpcProductCommunityRepository extends CrudRepository<EpcProductCommunity, Integer>,
														EpcProductCommunityRepositoryCustom{
    /**
     * 
     * @param productId
     * @return List<EpcProductCommunity>
     */
	@Query(value="select * from epc_product_community where product_id=:productId", nativeQuery = true)
	List<EpcProductCommunity> findCommunitiesByProductId(@Param("productId") Integer productId);
    
	/**
	 * 
	 * @return List<EpcProductCommunity>
	 */
	@Query(value="select distinct new com.wipro.epc.domain.EpcProductCommunity(e.communityName) from EpcProductCommunity e order by"
			+ " e.communityName")
	List<EpcProductCommunity> getCommunityNames();
	
	@Query(value="select distinct applicable_emp_band from epc_product_community e order by e.applicable_emp_band", nativeQuery=true)
	List<String> getEmployeeBands();

	List<EpcProductCommunity> findEpcProductCommunityByCommunityId(@Param("communityId") String communityId);

	

	
	
}
