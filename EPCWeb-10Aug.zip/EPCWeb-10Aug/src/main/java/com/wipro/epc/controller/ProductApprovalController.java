package com.wipro.epc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.services.ProductApprovalService;
import com.wipro.epc.dto.ProductApprovalInput;

/**
 * @author Developer
 * @version 1.0
 * type ProductApprovalController
 */
@RestController
public class ProductApprovalController {
	
	/**
	 * ProductApprovalService ProductApprovalController.java
	 */
	@Autowired
	private ProductApprovalService approvalService;

	/**
	 * @param approvalInput
	 * @return
	 */
	@RequestMapping(value = "rest/api/v1/productApproval", method=RequestMethod.POST)
	public List<String> approvalController(@RequestBody @Valid List<ProductApprovalInput> approvalInput){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String user=auth.getName();
		
		Object[] authorities = auth.getAuthorities().toArray();
		////System.out.println(authorities.toString());
		
		List<String> transitionFunctions = new ArrayList<String>();
		for(Object ob : authorities){
			if(ob.toString().startsWith("Transition_",0)){
				transitionFunctions.add(ob.toString());}
		}
				
		List<String> list= new ArrayList<String>();
		list.add(approvalService.updateProductStatus(approvalInput, transitionFunctions,user));
				
		return list;
		
	}
	
}
