
package com.wipro.epc.esb.getfailedtransactionshistory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fieldType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="fieldType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="logtime" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="phonenumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sendphonenumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="downtype" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="resourcetype" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="resourcecode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adtype" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="admincode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="operator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="account" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="invokedresult" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shortToneCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fieldType", propOrder = {
    "logtime",
    "phonenumber",
    "sendphonenumber",
    "downtype",
    "resourcetype",
    "resourcecode",
    "adtype",
    "admincode",
    "operator",
    "account",
    "description",
    "invokedresult",
    "serviceID",
    "shortToneCode"
})
public class FieldType {

    @XmlElement(required = true)
    protected String logtime;
    @XmlElement(required = true)
    protected String phonenumber;
    protected String sendphonenumber;
    @XmlElement(required = true)
    protected String downtype;
    @XmlElement(required = true)
    protected String resourcetype;
    @XmlElement(required = true)
    protected String resourcecode;
    protected String adtype;
    protected String admincode;
    @XmlElement(required = true)
    protected String operator;
    @XmlElement(required = true)
    protected String account;
    protected String description;
    @XmlElement(required = true)
    protected String invokedresult;
    protected String serviceID;
    protected String shortToneCode;

    /**
     * Gets the value of the logtime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogtime() {
        return logtime;
    }

    /**
     * Sets the value of the logtime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogtime(String value) {
        this.logtime = value;
    }

    /**
     * Gets the value of the phonenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhonenumber() {
        return phonenumber;
    }

    /**
     * Sets the value of the phonenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhonenumber(String value) {
        this.phonenumber = value;
    }

    /**
     * Gets the value of the sendphonenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendphonenumber() {
        return sendphonenumber;
    }

    /**
     * Sets the value of the sendphonenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendphonenumber(String value) {
        this.sendphonenumber = value;
    }

    /**
     * Gets the value of the downtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDowntype() {
        return downtype;
    }

    /**
     * Sets the value of the downtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDowntype(String value) {
        this.downtype = value;
    }

    /**
     * Gets the value of the resourcetype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResourcetype() {
        return resourcetype;
    }

    /**
     * Sets the value of the resourcetype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResourcetype(String value) {
        this.resourcetype = value;
    }

    /**
     * Gets the value of the resourcecode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResourcecode() {
        return resourcecode;
    }

    /**
     * Sets the value of the resourcecode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResourcecode(String value) {
        this.resourcecode = value;
    }

    /**
     * Gets the value of the adtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdtype() {
        return adtype;
    }

    /**
     * Sets the value of the adtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdtype(String value) {
        this.adtype = value;
    }

    /**
     * Gets the value of the admincode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdmincode() {
        return admincode;
    }

    /**
     * Sets the value of the admincode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdmincode(String value) {
        this.admincode = value;
    }

    /**
     * Gets the value of the operator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperator() {
        return operator;
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperator(String value) {
        this.operator = value;
    }

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccount() {
        return account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccount(String value) {
        this.account = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the invokedresult property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvokedresult() {
        return invokedresult;
    }

    /**
     * Sets the value of the invokedresult property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvokedresult(String value) {
        this.invokedresult = value;
    }

    /**
     * Gets the value of the serviceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceID() {
        return serviceID;
    }

    /**
     * Sets the value of the serviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceID(String value) {
        this.serviceID = value;
    }

    /**
     * Gets the value of the shortToneCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortToneCode() {
        return shortToneCode;
    }

    /**
     * Sets the value of the shortToneCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortToneCode(String value) {
        this.shortToneCode = value;
    }

}
