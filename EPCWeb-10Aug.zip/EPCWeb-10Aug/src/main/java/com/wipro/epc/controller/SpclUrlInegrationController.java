/**
 * EPC Application - TestController.java
 */
package com.wipro.epc.controller;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.DigestUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Developer
 * @version 1.0
 * type TestController
 */
@RestController
public class SpclUrlInegrationController {
	
	@Autowired
	private ApplicationContext appContext;
	
	@RequestMapping(value="rest/spcl/uri/community",method=RequestMethod.GET)
	public void returnedList(HttpServletResponse response, @RequestParam MultiValueMap allRequestParams) throws IOException, NoSuchAlgorithmException{
		List<String> communityName= (List<String> )allRequestParams.get("communityName");		
		
		List<String> communityShortCode=(List<String>) allRequestParams.get("communityShortCode");
		List<String> bsCode=(List<String>) allRequestParams.get("bsCode");
		List<String> cugId=(List<String>) allRequestParams.get("cugId");
		List<String> slabId=(List<String>) allRequestParams.get("slabId");
		List<String> isVatExempted=(List<String>) allRequestParams.get("isVatExempted");
		List<String> communityStatus=(List<String>) allRequestParams.get("communityStatus");
		List<String> mode=(List<String>) allRequestParams.get("mode");
		
		List<String> userName=allRequestParams.containsKey("userName") ? (List<String>) allRequestParams.get("userName") : new ArrayList<String>();
		List<String> token=allRequestParams.containsKey("token") ? (List<String>) allRequestParams.get("token") : new ArrayList<String>();
		List<String> timestamp=allRequestParams.containsKey("timestamp") ? (List<String>) allRequestParams.get("timestamp") : new ArrayList<String>();
		
		
		
		
		
		if(!userName.isEmpty() || !token.isEmpty() || !timestamp.isEmpty()) {
		//token generation
		String authString= userName.get(0)+"CimAuth"+timestamp.get(0);
		byte[] bytesOfMessage = authString.getBytes("UTF-8");
		System.out.println("--- "+DigestUtils.md5DigestAsHex( bytesOfMessage ));
		
		if(token.get(0).equalsIgnoreCase(DigestUtils.md5DigestAsHex( bytesOfMessage ))) {
		
		 List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		 authorities.add(new SimpleGrantedAuthority("Page_ManageCommunity"));
		SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(userName.get(0), timestamp.get(0), authorities));
		
		}
		}
		
		StringBuilder Url=new StringBuilder(appContext.getApplicationName()+"/#/CommunityAssociation?");
		if(communityName==null) {
			communityName=new ArrayList<String>();
			communityName.add(""); 
			}
		Url.append("communityName="+communityName.get(0));
		if(communityShortCode!=null) {Url.append("&communityShortCode="+communityShortCode.get(0));}
		if(bsCode!=null) {Url.append("&bsCode="+bsCode.get(0));}
		if(cugId!=null) {Url.append("&cugId="+cugId.get(0));}
		if(slabId!=null) {Url.append("&slabId="+slabId.get(0));}
		if(isVatExempted!=null) {Url.append("&isVatExempted="+isVatExempted.get(0));}
		if(communityStatus!=null) {Url.append("&communityStatus="+communityStatus.get(0));}
		if(mode!=null) {Url.append("&mode="+mode.get(0));}
		
		response.sendRedirect(Url.toString());
		
		
	}
}
