package com.wipro.epc.util;

import org.springframework.stereotype.Component;

/**
 * @author Developer
 * @version 1.0
 * type EscapeSpecialCharacters
 */
@Component
public class EscapeSpecialCharacters {
	
	/**
	 * @param inputString
	 * @return String
	 */
	public String escapeMetaCharacters(String inputString){
	    final String[] metaCharacters = {"'"};
	   //    ,"\\","^","$","{","}","[","]","(",")",".","*","+","?","|","<",">","-","&"
	    String outputString="";
	    for (int i = 0 ; i < metaCharacters.length ; i++){
	        if(inputString.contains(metaCharacters[i])){
	            outputString = inputString.replace(metaCharacters[i],"'"+metaCharacters[i]);//Escaping quotes(') only working with twice quotes('')
	            inputString = outputString;
	        }
	        else
	        	outputString = inputString;
	    }
	    return outputString;
	}

}
