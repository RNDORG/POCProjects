package com.wipro.epc.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


@Entity
@Table(name="cached_product_details")
public class CachedProductDetails  implements Serializable{
	
	@Id
	@Column(name = "id", nullable = false)
	private Integer id;
	
	@Lob
	private byte[] value;
	
	@Column(name="status")
	private String status;

	

	public CachedProductDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CachedProductDetails(Integer id, byte[] value, String status) {
		super();
		this.id = id;
		this.value = value;
		this.status = status;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public byte[] getValue() {
		return value;
	}

	public void setValue(byte[] value) {
		this.value = value;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "ProductCache [id=" + id 
				+ ", value=" + value 
				+ ", status="+ status + "]";
	}
}
