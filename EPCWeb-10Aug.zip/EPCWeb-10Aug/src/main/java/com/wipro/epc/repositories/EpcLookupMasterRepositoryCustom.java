package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcLookupMaster;
/**
 * 
 * @author VI251443
 * @version 1.0
 */
public interface EpcLookupMasterRepositoryCustom {
    /**
     * 
     * @param string
     * @return List<EpcLookupMaster>
     */
	List<EpcLookupMaster> getListofValues(String string);
}
