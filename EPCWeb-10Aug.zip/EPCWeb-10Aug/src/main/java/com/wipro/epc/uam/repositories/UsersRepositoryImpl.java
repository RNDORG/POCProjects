package com.wipro.epc.uam.repositories;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.wipro.epc.uam.domain.Authorities;
import com.wipro.epc.uam.domain.Role;
import com.wipro.epc.uam.domain.UserRoleMap;
import com.wipro.epc.uam.domain.Users;
import com.wipro.epc.util.SimpleDateConvertion;

/**
 * @author Developer
 * @version 1.0
 * type UsersRepositoryImpl
 */
public class UsersRepositoryImpl implements UsersRepositoryCustom{

	/**
	 * EntityManager UsersRepositoryImpl.java
	 */
	@PersistenceContext
	private EntityManager em;
	
	/**
	 * UsersRepository UsersRepositoryImpl.java
	 */
	@Autowired
	private UsersRepository userRepo;
	
	/**
	 * UserRoleMapRepository UsersRepositoryImpl.java
	 */
	@Autowired
	private UserRoleMapRepository userRoleMapRepo;
	
	/**
	 * AuthorityRepository UsersRepositoryImpl.java
	 */
	@Autowired
	private AuthorityRepository authorityRepo;
	
	/**
	 * FunctionRepository UsersRepositoryImpl.java
	 */
	@Autowired
	private FunctionRepository functionRepo;
	
	/**
	 * SimpleDateConvertion UsersRepositoryImpl.java
	 */
	@Autowired
	private SimpleDateConvertion convert;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.uam.repositories.UsersRepositoryCustom#addRolesAssociatedWithAnUser(com.wipro.epc.uam.domain.Users)
	 */
	@Override
	public void addRolesAssociatedWithAnUser(Users user) {
		String managedBy = (user.getModifiedBy() == null || "".equals(user.getModifiedBy())) ?  user.getCreatedBy() : user.getModifiedBy();
		List<Role> roles = user.getRoles();
		List<Authorities> authorities = null;
		List<UserRoleMap> listUserRoleMap = new ArrayList<UserRoleMap>();
		UserRoleMap userRoleMap = null;

		for (Role role : roles) {
			userRoleMap = new UserRoleMap(role.getRoleId(), user.getUsername(), managedBy,new Date());
			listUserRoleMap.add(userRoleMap);
			
			String[] functionNames = functionRepo.getFunctionNames(role.getRoleId());
			

			// Also set in Authorities to keep Spring Security happy.
			authorities = new ArrayList<Authorities>();
			Authorities authority;

			for (String functionName : functionNames) {				
				authority = new Authorities(user.getUsername(), functionName, managedBy, new Date());
				authorities.add(authority);
			}
			authorityRepo.save(authorities);

		}
		userRoleMapRepo.save(listUserRoleMap);	
		
		
	}

	
	/* (non-Javadoc)
	 * @see com.wipro.epc.uam.repositories.UsersRepositoryCustom#modifyUser(com.wipro.epc.uam.domain.Users)
	 */
	@Override
	public Users modifyUser(Users user) {
		StringBuilder queryBuilder = new StringBuilder("update users set username='"+user.getUsername().toLowerCase()+"'");
		
		if(user.getAddress()!=null) {
			queryBuilder.append(",").append(" address = '").append(user.getAddress()).append("'");
		}
		if(user.getCreatedBy()!=null) {
			queryBuilder.append(",").append(" created_by = '").append(user.getCreatedBy()).append("'");
		}
		if(user.getCreatedDate()!=null) {
			queryBuilder.append(",").append(" created_date = '").append(user.getCreatedDate()).append("'");
		}
		if(user.getDob()!=null) {
			queryBuilder.append(",").append(" dob = '").append(convert.getDateInFormat(user.getDob(),"yyyy-MM-dd")).append("' ");
		}
		if(user.getEmail()!=null) {
			queryBuilder.append(",").append(" email = '").append(user.getEmail().toLowerCase()).append("'");
		}
		if(user.getEnabled()!=null) {
			queryBuilder.append(",").append(" enabled = '").append(user.getEnabled()).append("'");
		}
		if(user.getFname()!=null) {
			queryBuilder.append(",").append(" fname = '").append(user.getFname()).append("'");
		}
		if(user.getModifiedBy()!=null) {
			queryBuilder.append(",").append(" modified_by = '").append(user.getUsername()).append("'");
		}
		//needs clarification
		if(user.getModifiedDate()!=null) {
			queryBuilder.append(",").append(" modified_date = '").append(convert.getDateInFormat(new Date(),"yyyy-MM-dd kk:mm:ss")).append("'");
		}
		if(user.getLname()!=null) {
			queryBuilder.append(",").append(" lname = '").append(user.getLname()).append("'");
		}
		if(user.getMname()!=null) {
			queryBuilder.append(",").append(" mname = '").append(user.getMname()).append("'");
		}
		if(user.getPassword()!=null) {
			queryBuilder.append(",").append(" password = '").append(user.getPassword()).append("'");
		}
		if(user.getMobileNumber()!=null) {
			queryBuilder.append(",").append(" mobile_number = '").append(user.getMobileNumber()).append("'");
		}
		if(user.getEmployeeNo()!=null) {
			queryBuilder.append(",").append(" employee_number = '").append(user.getEmployeeNo()).append("'");
		}
		
		queryBuilder.append(" where username='").append(user.getUsername().toLowerCase()).append("'");
		String query = queryBuilder.toString();
		int count;
		count = em.createNativeQuery(query).executeUpdate();
		//System.out.println(count);
		if(user.getRoles()!=null && user.getRoles().get(0).getRoleId()!=null ){
			authorityRepo.deleteFromAuthorities(user.getUsername());
			userRoleMapRepo.deleteFromUserRoleMap(user.getUsername());
			
			// adding new roles
			addRolesAssociatedWithAnUser(user);
		}
		//System.out.println("The modified query is "+query);
		return user;
	}

	/* (non-Javadoc)
	 * @see com.wipro.epc.uam.repositories.UsersRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<Users> getList(String query) {
		////System.out.println((List<Users>)em.createNativeQuery(query, Users.class).getResultList());
		return em.createNativeQuery(query, Users.class).getResultList();
	}


	/**
	 * @return
	 */
	public EntityManager getEm() {
		return em;
	}


	/**
	 * @param em
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}


	/**
	 * @return
	 */
	public UsersRepository getUserRepo() {
		return userRepo;
	}


	/**
	 * @param userRepo
	 */
	public void setUserRepo(UsersRepository userRepo) {
		this.userRepo = userRepo;
	}


	/**
	 * @return
	 */
	public UserRoleMapRepository getUserRoleMapRepo() {
		return userRoleMapRepo;
	}


	/**
	 * @param userRoleMapRepo
	 */
	public void setUserRoleMapRepo(UserRoleMapRepository userRoleMapRepo) {
		this.userRoleMapRepo = userRoleMapRepo;
	}


	/**
	 * @return
	 */
	public AuthorityRepository getAuthorityRepo() {
		return authorityRepo;
	}


	/**
	 * @param authorityRepo
	 */
	public void setAuthorityRepo(AuthorityRepository authorityRepo) {
		this.authorityRepo = authorityRepo;
	}


	/**
	 * @return
	 */
	public FunctionRepository getFunctionRepo() {
		return functionRepo;
	}


	/**
	 * @param functionRepo
	 */
	public void setFunctionRepo(FunctionRepository functionRepo) {
		this.functionRepo = functionRepo;
	}


	/**
	 * @return
	 */
	public SimpleDateConvertion getConvert() {
		return convert;
	}


	/**
	 * @param convert
	 */
	public void setConvert(SimpleDateConvertion convert) {
		this.convert = convert;
	}

}
