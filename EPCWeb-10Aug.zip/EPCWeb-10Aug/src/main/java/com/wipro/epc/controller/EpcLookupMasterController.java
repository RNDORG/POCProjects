package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.services.EpcLookupMasterService;
import com.wipro.epc.domain.EpcLookupMaster;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
@RestController
public class EpcLookupMasterController {

	@Autowired
	EpcLookupMasterService service;
	
	/**
	 * 
	 * @param parent_lookup_id
	 * @param lookup_group
	 * @param lookup_name
	 * @return List<EpcLookupMaster>
	 */
	@RequestMapping(value="rest/api/v1/lookupmaster", method=RequestMethod.GET)
	
	public List<EpcLookupMaster> getLookupvalues(@RequestParam(required=false) Integer parent_lookup_id, @RequestParam String lookup_group,@RequestParam String lookup_name )
	{
		return service.getLookupvalues(parent_lookup_id,lookup_group,lookup_name);
	}
	
	/**
	 * 
	 * @return List<EpcLookupMaster>
	 */
	@RequestMapping(value="rest/api/v1/lookupmaster/all", method=RequestMethod.GET)
	public List<EpcLookupMaster> GetAllListofValues()
	{
		return service.getAllListofValues();
	}
}

		
 

