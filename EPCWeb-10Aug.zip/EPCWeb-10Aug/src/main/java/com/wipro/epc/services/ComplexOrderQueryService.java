package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcNotificationTemplate;
import com.wipro.epc.domain.EpcNotificationTemplateDetail;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcOrderCharge;
import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.domain.EpcTriggerOrderRule;
import com.wipro.epc.dto.ComplexOrderQueryInput;
import com.wipro.epc.dto.OrderType;
import com.wipro.epc.util.Constants;


/**
 * @author Developer
 * @version 1.0
 * type ComplexOrderQueryService
 */
@Service
public class ComplexOrderQueryService {
	/**
	 * EpcProductSpecificationService ComplexOrderQueryService.java
	 */
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	
	/**
	 * EpcLookupMasterService ComplexOrderQueryService.java
	 */
	@Autowired
	EpcLookupMasterService epcLookupMasterService;

	/**
	 * EpcNotificationTemplateService ComplexOrderQueryService.java
	 */
	@Autowired
	EpcNotificationTemplateService epcNotificationTemplateService;
	
	/**
	 * EpcOrderChannelRuleService ComplexOrderQueryService.java
	 */
	@Autowired
	EpcOrderChannelRuleService epcOrderChannelRuleService;
	
	/**
	 * EpcProductDecompositionService ComplexOrderQueryService.java
	 */
	@Autowired
	EpcProductDecompositionService epcProductDecompositionService;
	
	/**
	 * EpcOrderTriggerRuleService ComplexOrderQueryService.java
	 */
	@Autowired
	EpcOrderTriggerRuleService epcOrderTriggerRuleService;
	

	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@Transactional
	public OrderType queryOrderRule(ComplexOrderQueryInput queryInput, Map<String, List<String>> allRequestParams){
		
		if(StringUtils.isBlank(queryInput.getInitiatingChannel()) || StringUtils.isBlank(queryInput.getOrderType())){
				throw new GenericException("InvalidSearch", "Mandatory Fields are missing. Please provide all mandatory fields (orderType, initChannel)", "Mandatory Fields are missing.");
			}

		List<String> with = allRequestParams.get("with");
		
		List<String> supportedWith = Arrays.asList(new String []{"all", "triggerOrderRule", "notification", "orderChannelRule"});
		if(with != null && !with.isEmpty()){
			for(String str : with){
				if(!supportedWith.contains(str)){
						throw new GenericException("UnsupportedWith", "Unsupported with parameter ("+ str +") provided.", "Unsupported with parameter ("+ str +") provided.");
				}
			}
		}

		//logic for OCR check
		EpcOrderChannelRule orderChannelRule = fetchOrderChannelRule(queryInput);
		if(orderChannelRule != null && orderChannelRule.getStatus().equals(Constants.COMMON_STATUS_ACTIVE)){
			//OCR checked 
		}else{
			throw new GenericException("SearchFailed", "Failed for Order Channel Rule check.", "Failed for Order Channel Rule check.");
		}
		
		OrderType orderType = new OrderType();
		orderType.setOrderType(queryInput.getOrderType());
		
		//Getting Decomposition Rules
		List<EpcProductDecomposition>  decompositions = null;
		if(queryInput.getProductClassification() != null && queryInput.getProductSubfamily() != null){
			decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
						" where product_short_code is null and order_type = '"+queryInput.getOrderType() 
						+"' and product_classification = '"+queryInput.getProductClassification()
						+"' and product_sub_family = '"+queryInput.getProductSubfamily()+"'");
			
			if(decompositions == null || decompositions.isEmpty() ){
				decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
						" where product_short_code is null and order_type = '"+queryInput.getOrderType() 
						+"' and product_classification is null"
						+" and product_sub_family = '"+queryInput.getProductSubfamily()+"'");
			}
			if(decompositions == null || decompositions.isEmpty() ){
				decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
						" where product_short_code is null and order_type = '"+queryInput.getOrderType() 
						+"' and product_classification is null "
						+" and product_sub_family is null ");
			}
		}else if(queryInput.getProductSubfamily() != null){
			decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
						" where product_short_code is null and order_type = '"+queryInput.getOrderType() 
						+"' and product_classification is null"
						+" and product_sub_family = '"+queryInput.getProductSubfamily()+"'");
			if(decompositions == null || decompositions.isEmpty() ){
				decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
						" where product_short_code is null and order_type = '"+queryInput.getOrderType() 
						+"' and product_classification is null "
						+" and product_sub_family is null ");
			}
		}else{
			decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
						" where product_short_code is null and order_type = '"+queryInput.getOrderType() 
						+"' and product_classification is null "
						+" and product_sub_family is null ");
		}
		
		
		if (decompositions != null && !decompositions.isEmpty()) {
			Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
			List<String> notificationIds = new ArrayList<String>();
			if ( with!= null && ( with.contains("all") ||  with.contains("notification"))) {
				for (EpcProductDecomposition epcProductDecomposition : decompositions) {
					notificationIds.add(String.valueOf(epcProductDecomposition
							.getNotificationTemplateId()));
				}
				notificationRequestParams.put(
						"notificationTemplateId", notificationIds);
			}
			List<EpcNotificationTemplate> notificationTemplates = epcNotificationTemplateService
					.searchEpcNotificationTemplate(notificationRequestParams);
			List<EpcNotificationTemplateDetail> epcNotificationTemplateDetails = epcNotificationTemplateService.searchEpcNotificationTemplateDetails(notificationRequestParams);
			for (EpcProductDecomposition epcProductDecomposition : decompositions) {
				if ( with!= null && ( with.contains("all") ||  with.contains("notification")) && notificationTemplates != null) {
					for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
						if (notificationtemplate.getNotificationTemplateId().equals(epcProductDecomposition.getNotificationTemplateId() )) {
							if (epcNotificationTemplateDetails != null && !epcNotificationTemplateDetails.isEmpty()) {
								for (EpcNotificationTemplateDetail epcNotificationTemplateDetail : epcNotificationTemplateDetails) {
									if(epcNotificationTemplateDetail.getNotificationTemplateId() .equals( notificationtemplate.getNotificationTemplateId())){
										if(notificationtemplate.getEpcNotificationTemplateDetail() == null){
											notificationtemplate.setEpcNotificationTemplateDetail(new ArrayList<EpcNotificationTemplateDetail>());
										}
										notificationtemplate.getEpcNotificationTemplateDetail().add(epcNotificationTemplateDetail);
									}
								}
							}
							epcProductDecomposition.setEpcNotificationTemplate(notificationtemplate);
						}
					}
				}
				
			}
			orderType.setEpcProductDecomposition(decompositions);
		}
		
		//setting Order Channel rule
		if(with!= null && (with.contains("all") || with.contains("orderChannelRule"))){
			
			MultiValueMap<String, String> searchCriteriaActivityCharge = new LinkedMultiValueMap<String, String>();
			List<String> orderChannelRuleIds = new ArrayList<String>();
			
			Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
			List<String> notificationIds = new ArrayList<String>();
			if ( with!= null && (with.contains("all") || with.contains("notification"))) {
				notificationIds.add(String.valueOf(orderChannelRule.getNotificationTemplateId()));
				notificationRequestParams.put("notificationTemplateId", notificationIds);
			}
				orderChannelRuleIds.add(String.valueOf(orderChannelRule.getOrderChannelRuleId()));
				searchCriteriaActivityCharge.put("orderChannelRuleId", orderChannelRuleIds);
				List<EpcOrderCharge> EpcOrderCharges = epcOrderChannelRuleService.searchEpcActivityChargeByChannelRuleId(searchCriteriaActivityCharge);
				if(EpcOrderCharges != null && EpcOrderCharges.size() == 1)
					orderChannelRule.setEpcOrderCharge(EpcOrderCharges.get(0));
				List<EpcNotificationTemplate> notificationTemplates = epcNotificationTemplateService.searchEpcNotificationTemplate(notificationRequestParams);
				List<EpcNotificationTemplateDetail> epcNotificationTemplateDetails = epcNotificationTemplateService.searchEpcNotificationTemplateDetails(notificationRequestParams);
				
				
				if ( with!= null && (with.contains("all") || with.contains("notification")) && notificationTemplates != null) {
					for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
						if (notificationtemplate.getNotificationTemplateId().equals(orderChannelRule.getNotificationTemplateId()) ){
							if (epcNotificationTemplateDetails != null && !epcNotificationTemplateDetails.isEmpty()) {
								for (EpcNotificationTemplateDetail epcNotificationTemplateDetail : epcNotificationTemplateDetails) {
									if(epcNotificationTemplateDetail.getNotificationTemplateId() .equals( notificationtemplate.getNotificationTemplateId())){
										if(notificationtemplate.getEpcNotificationTemplateDetail() == null){
											notificationtemplate.setEpcNotificationTemplateDetail(new ArrayList<EpcNotificationTemplateDetail>());
										}
										notificationtemplate.getEpcNotificationTemplateDetail().add(epcNotificationTemplateDetail);
									}
								}
							}
							orderChannelRule.setEpcNotificationTemplate(notificationtemplate);
						}
					}
				}
				
			List<EpcOrderChannelRule> epcOrderChannelRules = new ArrayList<EpcOrderChannelRule>();
			epcOrderChannelRules.add(orderChannelRule);
			orderType.setEpcOrderChannelRule(epcOrderChannelRules);
		}
		
		//Getting Trigger Order Rules
		if( with!= null &&  (with.contains("all") || with.contains("triggerOrderRule"))){
			List<EpcTriggerOrderRule>  epcTriggerOrderRules = null;
			if(queryInput.getProductClassification() != null && queryInput.getProductSubfamily() != null){
				epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
							" where source_product_short_code is null and source_order_type = '"+queryInput.getOrderType() 
							+"' and source_product_classification = '"+queryInput.getProductClassification()
							+"' and source_product_sub_family = '"+queryInput.getProductSubfamily()+"'");
				if(epcTriggerOrderRules == null || epcTriggerOrderRules.isEmpty() ){
					epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
							" where source_product_short_code is null and source_order_type = '"+queryInput.getOrderType() 
							+"' and source_product_classification is null"
							+" and source_product_sub_family = '"+queryInput.getProductSubfamily()+"'");
				}
				if(epcTriggerOrderRules == null || epcTriggerOrderRules.isEmpty() ){
					epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
							" where source_product_short_code is null and source_order_type = '"+queryInput.getOrderType() 
							+"' and source_product_classification is null "
							+" and source_product_sub_family is null ");
				}
			}else if(queryInput.getProductSubfamily() != null){
				epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
						" where source_product_short_code is null and source_order_type = '"+queryInput.getOrderType() 
						+"' and source_product_classification is null"
						+" and source_product_sub_family = '"+queryInput.getProductSubfamily()+"'");
				if(epcTriggerOrderRules == null || epcTriggerOrderRules.isEmpty() ){
					epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
							" where source_product_short_code is null and source_order_type = '"+queryInput.getOrderType() 
							+"' and source_product_classification is null "
							+" and source_product_sub_family is null ");
				}
			}else{
				epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
						" where source_product_short_code is null and source_order_type = '"+queryInput.getOrderType() 
						+"' and source_product_classification is null "
						+" and source_product_sub_family is null ");
			}
			if(epcTriggerOrderRules != null && !epcTriggerOrderRules.isEmpty() ){
				orderType.setEpcTriggerOrderRule(epcTriggerOrderRules);
			}
		}
		
		return orderType;		
	}
	
	/**
	 * @param queryInput
	 * @return
	 */
	private EpcOrderChannelRule fetchOrderChannelRule(ComplexOrderQueryInput queryInput) {
		StringBuilder query = new StringBuilder().append(" where order_type = '").append(queryInput.getOrderType()).append("' and initiating_channel = '")
				.append(queryInput.getInitiatingChannel()).append("'");
		if(queryInput.getSalesChannel() != null){
			query.append(" and sales_channel = '").append(queryInput.getSalesChannel()).append("'");
		}else{
			query.append(" and sales_channel is null ");
		}
		
		if(queryInput.getProductSubfamily() != null){
			query.append(" and product_sub_family = '").append(queryInput.getProductSubfamily()).append("'");
		}else{
			query.append(" and product_sub_family is null ");
		}
		
		if(queryInput.getProductClassification() != null){
			query.append(" and product_classification = '").append(queryInput.getProductClassification()).append("'");
		}else{
			query.append(" and product_classification is null ");
		}
		
		List<EpcOrderChannelRule> epcOrderChannelRules = epcOrderChannelRuleService.getOrderChannelRulesByWhereClause(query.toString() );
		EpcOrderChannelRule epcOrderChannelRule = null;
		if(epcOrderChannelRules != null && !epcOrderChannelRules.isEmpty() ){
			epcOrderChannelRule = epcOrderChannelRules.get(0);
		}
		return epcOrderChannelRule;
	}
}
