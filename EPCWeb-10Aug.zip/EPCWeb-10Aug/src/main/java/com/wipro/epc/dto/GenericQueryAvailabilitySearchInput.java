package com.wipro.epc.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;


/**
 * @author Developer
 * @version 1.0
 * type GenericQueryAvailabilitySearchInput
 */
public class GenericQueryAvailabilitySearchInput {
	
	/**
	 * List<String> GenericQueryAvailabilitySearchInput.java
	 */
	private List<String> otherClassification;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String lazy;
	/**
	 * List<String> GenericQueryAvailabilitySearchInput.java
	 */
	private List<String> subscribedProductList;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String characteristicServiceClass;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String orderTypeValue;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String initChannelValue;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String salesChannelValue;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String segmentValue;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String areaValue;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String regionValue;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String territoryValue;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String communityId;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss")
	private String startDate;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String productStatusValue;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String isPaused;
	/**
	 * String GenericQueryAvailabilitySearchInput.java
	 */
	private String productSubCategoryValue;
	/**
	 * @return
	 */
	public String getCharacteristicServiceClass() {
		return characteristicServiceClass;
	}
	/**
	 * @param characteristicServiceClass
	 */
	public void setCharacteristicServiceClass(String characteristicServiceClass) {
		this.characteristicServiceClass = characteristicServiceClass;
	}
	/**
	 * @return
	 */
	public String getOrderTypeValue() {
		return orderTypeValue;
	}
	/**
	 * @param orderTypeValue
	 */
	public void setOrderTypeValue(String orderTypeValue) {
		this.orderTypeValue = orderTypeValue;
	}
	/**
	 * @return
	 */
	public String getInitChannelValue() {
		return initChannelValue;
	}
	/**
	 * @param initChannelValue
	 */
	public void setInitChannelValue(String initChannelValue) {
		this.initChannelValue = initChannelValue;
	}
	/**
	 * @return
	 */
	public String getSalesChannelValue() {
		return salesChannelValue;
	}
	/**
	 * @param salesChannelValue
	 */
	public void setSalesChannelValue(String salesChannelValue) {
		this.salesChannelValue = salesChannelValue;
	}
	/**
	 * @return
	 */
	public String getSegmentValue() {
		return segmentValue;
	}
	/**
	 * @param segmentValue
	 */
	public void setSegmentValue(String segmentValue) {
		this.segmentValue = segmentValue;
	}	
	/**
	 * @return
	 */
	public String getAreaValue() {
		return areaValue;
	}
	/**
	 * @param areaValue
	 */
	public void setAreaValue(String areaValue) {
		this.areaValue = areaValue;
	}
	/**
	 * @return
	 */
	public String getRegionValue() {
		return regionValue;
	}
	/**
	 * @param regionValue
	 */
	public void setRegionValue(String regionValue) {
		this.regionValue = regionValue;
	}
	/**
	 * @return
	 */
	public String getTerritoryValue() {
		return territoryValue;
	}
	/**
	 * @param territoryValue
	 */
	public void setTerritoryValue(String territoryValue) {
		this.territoryValue = territoryValue;
	}
	/**
	 * @return
	 */
	public String getCommunityId() {
		return communityId;
	}
	/**
	 * @param communityId
	 */
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
	/**
	 * @return
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return
	 */
	public String getProductStatusValue() {
		return productStatusValue;
	}
	/**
	 * @param productStatusValue
	 */
	public void setProductStatusValue(String productStatusValue) {
		this.productStatusValue = productStatusValue;
	}
	/**
	 * @return
	 */
	public String getIsPaused() {
		return isPaused;
	}
	/**
	 * @param isPaused
	 */
	public void setIsPaused(String isPaused) {
		this.isPaused = isPaused;
	}
	
	/**
	 * @return
	 */
	public String getProductSubCategoryValue() {
		return productSubCategoryValue;
	}
	/**
	 * @param productSubCategoryValue
	 */
	public void setProductSubCategoryValue(String productSubCategoryValue) {
		this.productSubCategoryValue = productSubCategoryValue;
	}
	/**
	 * @return
	 */
	public List<String> getOtherClassification() {
		return otherClassification;
	}
	/**
	 * @param otherClassification
	 */
	public void setOtherClassification(List<String> otherClassification) {
		this.otherClassification = otherClassification;
	}
	/**
	 * @return
	 */
	public String getLazy() {
		return lazy;
	}
	/**
	 * @param lazy
	 */
	public void setLazy(String lazy) {
		this.lazy = lazy;
	}
	/**
	 * @return
	 */
	public List<String> getSubscribedProductList() {
		return subscribedProductList;
	}
	/**
	 * @param subscribedProductList
	 */
	public void setSubscribedProductList(List<String> subscribedProductList) {
		this.subscribedProductList = subscribedProductList;
	}
}
