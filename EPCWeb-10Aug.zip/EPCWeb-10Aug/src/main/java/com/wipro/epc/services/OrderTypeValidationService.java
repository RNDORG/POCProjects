package com.wipro.epc.services;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.repositories.OrderTypeValidationRepository;

/**
 * @author Developer
 * @version 1.0
 * type OrderTypeValidationService
 */
@Service
public class OrderTypeValidationService {

	/**
	 * OrderTypeValidationRepository OrderTypeValidationService.java
	 */
	@Autowired
	OrderTypeValidationRepository repository;
	
	/**
	 * @param orderList
	 * @return
	 */
	@Transactional
	public int validateOrders(EpcOrderChannelRule orderList)
			{
				
				int validType = repository.validateOrders(orderList);
				return validType;
		
			}
}
