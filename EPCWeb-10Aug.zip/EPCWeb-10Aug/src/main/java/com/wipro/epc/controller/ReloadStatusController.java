package com.wipro.epc.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.ReloadStatus;
import com.wipro.epc.services.ReloadStatusService;


@RestController
public class ReloadStatusController {
	
	@Autowired
	ReloadStatusService reloadStatusService;
	
	@RequestMapping(value="rest/extapi/v1/cache/product/reloadStatus", method=RequestMethod.GET)
	public List<ReloadStatus>  reloadStatus(@RequestParam(value="id",required=false)  Integer request)
	{
	   return	reloadStatusService.getStatus(request);
	}

	
	@RequestMapping(value="rest/extapi/v1/cache/product/reloadStatus/list", method=RequestMethod.GET)
	public List<ReloadStatus>  reloadStatusWithLimit(@RequestParam(value="limit",required=false)  Integer limit)
	{
		return	reloadStatusService.getStatusWithLimit(limit);
	}
}