package com.wipro.epc.repositories;

import java.util.List;

import javax.transaction.Transactional;

import com.wipro.epc.domain.CachedProductDetails;


public interface CachedProductDetailsRepositoryCustom {
	
	@Transactional
	CachedProductDetails updateCachedProductDetails(CachedProductDetails cpd);
	
	@Transactional
	void deleteByIds(String ids);

	List<CachedProductDetails> getList(String query);
}
