package com.wipro.epc.services;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductInitChannelRepository;
import com.wipro.epc.uam.definitions.MetaInfo;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductInitChannelService
 */
@Service
public class EpcProductInitChannelService {
	
	/**
	 * EpcProductInitChannelRepository EpcProductInitChannelService.java
	 */
	@Autowired
	private EpcProductInitChannelRepository epcProductInitChannelRepository;
	
	
	/**
	 * @return
	 */
	public EpcProductInitChannelRepository getEpcProductInitChannelRepository() {
		return epcProductInitChannelRepository;
	}


	/**
	 * @param epcProductInitChannelRepository
	 */
	public void setEpcProductInitChannelRepository(
			EpcProductInitChannelRepository epcProductInitChannelRepository) {
		this.epcProductInitChannelRepository = epcProductInitChannelRepository;
	}


	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductInitChannel> searchEpcProductInitChannel(
			Map<String, List<String>> allRequestParams) {
		String with = "";
		
		if (allRequestParams.get("with") != null) {
			with = allRequestParams.get("with").toString();
			with = with.substring(1, "with".length());
		}

		allRequestParams.remove("with");
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductInitChannel.class.getName(), null);
		List<EpcProductInitChannel> listOfEpcProductInitChannelsReturned = null;
		try {
				listOfEpcProductInitChannelsReturned = epcProductInitChannelRepository.getList(queryBuilder);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		
		return listOfEpcProductInitChannelsReturned;
	}

	
	/**
	 * @param productInitChannelList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductInitChannel> manageProductInitChannels(List<EpcProductInitChannel> productInitChannelList,
			String createdBy)
			{
				//List<EpcProductInitChannel> retListOfEpcProductInitChannel=new ArrayList<EpcProductInitChannel>();
				
				for(EpcProductInitChannel producInitChannel:productInitChannelList)
				{
					producInitChannel=manageProductInitChannel(producInitChannel,createdBy);
					if((producInitChannel.getMetaInfo().get("STATUS")==null))
					{
						producInitChannel.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
					}
				//retListOfEpcProductInitChannel.add(producInitChannel);
			}
		     	return productInitChannelList;
			}
	
	/**
	 * @param productInitChannel
	 * @param createdBy
	 * @return
	 */
	EpcProductInitChannel manageProductInitChannel(EpcProductInitChannel productInitChannel,
			String createdBy)
			{
		EpcProductInitChannel retProductLocation=null;
			
			switch(productInitChannel.getMetaInfo().get("OPERATION"))
			{
			case "CREATE":
				retProductLocation = createProductInitChannel(productInitChannel, createdBy);
						  break;
			case "UPDATE":retProductLocation = modifyProductInitChannel(productInitChannel, createdBy);
						  break;
			case "DELETE":retProductLocation = deleteProductInitChannel(productInitChannel);
						  break;
			default:
				throw new EPCException("not supported");
			}
			return retProductLocation;
			}
	
		/**
		 * @param productInitChannel
		 * @return
		 */
		private EpcProductInitChannel deleteProductInitChannel(
				EpcProductInitChannel productInitChannel) {
			epcProductInitChannelRepository.delete(productInitChannel.getProductInitChannelId());
		
		return productInitChannel;
		}

		/**
		 * @param productInitChannel
		 * @param createdBy
		 * @return
		 */
		private EpcProductInitChannel modifyProductInitChannel(
				EpcProductInitChannel productInitChannel,String createdBy) {
			productInitChannel.setModifiedBy(createdBy);
			if(productInitChannel.getServiceKeyword()!=null){
				productInitChannel.setServiceKeyword(productInitChannel.getServiceKeyword().toUpperCase());
			}
			if(productInitChannel.getServiceKeywordOther()!=null){
				productInitChannel.setServiceKeywordOther(productInitChannel.getServiceKeywordOther().toUpperCase());
			}
			
			return epcProductInitChannelRepository.modifyProductInitChannel(productInitChannel);
		}

		/**
		 * @param productInitChannel
		 * @param createdBy
		 * @return
		 */
		private EpcProductInitChannel createProductInitChannel(EpcProductInitChannel productInitChannel, String createdBy) {
			
			productInitChannel.setCreatedBy(createdBy);
			productInitChannel.setCreatedDate(new Date());
			if(productInitChannel.getServiceKeyword()!=null){
			productInitChannel.setServiceKeyword(productInitChannel.getServiceKeyword().toUpperCase());
			}
			if(productInitChannel.getServiceKeywordOther()!=null){
			productInitChannel.setServiceKeywordOther(productInitChannel.getServiceKeywordOther().toUpperCase());
			}
			/*productInitChannel.setEndDate(new Date());
			productInitChannel.setStartDate(new Date());*/
		epcProductInitChannelRepository.save(productInitChannel);
		return productInitChannel;
	}

	/**
	 * @param productId
	 * @param channelLevelMarketName
	 * @return
	 */
	public List<EpcProductInitChannel> marketingNameCorrect(String productId, String channelLevelMarketName)
	{
		return epcProductInitChannelRepository.marketNameExist(productId, channelLevelMarketName);
	}

	
	/**
	 * @param productId
	 * @param channelLevelMarketName
	 * @return
	 */
	public List<EpcProductInitChannel> productIdCorrect(String productId, String channelLevelMarketName)
	{
		return epcProductInitChannelRepository.productIdExist(productId, channelLevelMarketName);
	}
}
