package com.wipro.epc.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.wipro.epc.domain.EpcActivityChannelRule;


/**
 * @author Developer
 * @version 1.0
 * type ActivitySearchOutput
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ActivitySearchOutput {
	

	/**
	 * Map<String,String> ActivitySearchOutput.java
	 */
	private List<KeyValueDetail> activityDetails;
	
	public List<KeyValueDetail> getActivityDetails() {
		return activityDetails;
	}
	public void setActivityDetails(List<KeyValueDetail> activityDetails) {
		this.activityDetails = activityDetails;
	}
	

	
	/**
	 * List<EpcActivityChannelRule> ActivitySearchOutput.java
	 */
	private List<EpcActivityChannelRule> epcActivityChannelRule;
	
	/**
	 * @return
	 */
	public List<EpcActivityChannelRule> getEpcActivityChannelRule() {
		return epcActivityChannelRule;
	}
	/**
	 * @param epcActivityChannelRule
	 */
	public void setEpcActivityChannelRule(
			List<EpcActivityChannelRule> epcActivityChannelRule) {
		this.epcActivityChannelRule = epcActivityChannelRule;
	}
	
	

}
