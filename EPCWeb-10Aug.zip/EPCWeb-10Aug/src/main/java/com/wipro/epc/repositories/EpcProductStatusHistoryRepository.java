
package com.wipro.epc.repositories;

import org.springframework.data.repository.CrudRepository;

import com.wipro.epc.domain.EpcProductStatusHistory;


/**
 * @author Developer
 * @version 1.0
 * type EpcProductStatusHistoryRepository
 */
public interface EpcProductStatusHistoryRepository extends CrudRepository<EpcProductStatusHistory, Integer> {

}
