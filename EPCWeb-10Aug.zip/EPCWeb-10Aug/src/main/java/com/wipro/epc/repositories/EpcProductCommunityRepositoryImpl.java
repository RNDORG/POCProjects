package com.wipro.epc.repositories;

import java.util.List;




import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wipro.epc.domain.EpcProductCommunity;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
public class EpcProductCommunityRepositoryImpl implements EpcProductCommunityRepositoryCustom {

	private static Logger logger =LoggerFactory.getLogger(EpcProductCommunityRepositoryImpl.class);
	
	@PersistenceContext
	EntityManager em; 

	@Override
	public List<EpcProductCommunity> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductCommunity.class).getResultList();
	}

	@Override
	public void modify(EpcProductCommunity community) {
		String query = "update epc_product_community set product_id = "+community.getProductId()+", modified_by='"+community.getModifiedBy()+"', modified_date=current_timestamp()";
				if(community.getIsEmployeeAllowedToPurchase()!=null) {
					query += ", is_employee_allowed_to_purchase = "+community.getIsEmployeeAllowedToPurchase()+" ";
				}
				if(community.getCommunityId()!=null){
					query += ", community_id = '"+community.getCommunityId()+"' ";
				}
				if(community.getCommunityName()!=null){
					query += ", community_name = '"+community.getCommunityName()+"' ";
				}
				//if(community.getDiscountedPrice()!=null)
					query += ", discounted_price = "+community.getDiscountedPrice()+" ";
				if(community.getSlabId()!=null){
					query += ", slab_id = '"+community.getSlabId() +"' ";
				}
				if(community.getStatus()!=null) {
					query += ", status = '"+community.getStatus() +"' ";
				query += " where product_id= "+community.getProductId();
				query += " and community_id= '"+community.getCommunityId()+"' ";
				query +=  " and applicable_emp_band = '"+community.getApplicableEmpBand()+"' ";
				}
				if(!(community.getIsEmployeeAllowedToPurchase()==null))
				{
					String query1="update epc_product_community set is_employee_allowed_to_purchase = "
				+community.getIsEmployeeAllowedToPurchase()+" where community_name='"
							+community.getCommunityName()+"'";
					logger.debug("#Query: "+query1);
					em.createNativeQuery(query1).executeUpdate();
					
				}
				logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
	}
	
	
	/**
	 * @param searchInput
	 * @return
	 */
	@Override
	public List<Integer> getAllNonGlobalCorpPoolProductIds() {
		String query =  "select distinct product_id from epc_product_community order by product_id";
		logger.debug("#Query: "+query);
		List<Integer> returnList =  em.createNativeQuery(query).getResultList();
		return returnList;
	}

	@Override
	public void update(EpcProductCommunity community) {
		String query = "update epc_product_community ";
		query = query + " set product_id = "+community.getProductId()+", community_id = "+community.getCommunityId();
		query = query + ", applicable_emp_band='ALL' ,community_name ='"+community.getCommunityName()+"', ";
		query = query + " discounted_price = "+community.getDiscountedPrice()+", slab_id = '"+community.getSlabId()+"' ";
		query = query + ", is_employee_allowed_to_purchase = "+community.getIsEmployeeAllowedToPurchase();
		query = query + " , status = '"+community.getStatus()+"' where product_community_id = "+community.getProductCommunityId();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		
	}
}
