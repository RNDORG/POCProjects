package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductAttributeRepository;


/**
 * @author Developer
 * @version 1.0
 * type ProductAttributeService
 */
@Service
public class ProductAttributeService {
	
	/**
	 * EpcProductAttributeRepository ProductAttributeService.java
	 */
	@Autowired
	EpcProductAttributeRepository epcProductAttributeRepository;

/**
 * @param productAttributeList
 * @param createdBy
 * @return
 */
@Transactional
public List<EpcProductAttribute> manageProductAttribute(List<EpcProductAttribute> productAttributeList,String createdBy){
	
	List<EpcProductAttribute> retProductAttributeList=new ArrayList<EpcProductAttribute>();
	
		for (EpcProductAttribute productAttribute : productAttributeList) {
			productAttribute=manageProductAttribute(productAttribute, createdBy);
			if (productAttribute.getMetaInfo().get("STATUS") == null) {
				productAttribute.getMetaInfo().put(MetaInfo.STATUS,
						MetaInfo.SUCCESS);
			}
			retProductAttributeList.add(productAttribute);

		}
		return retProductAttributeList;
		
	}
	
	/**
	 * @param productAttribute
	 * @param createdBy
	 * @return
	 */
	public EpcProductAttribute manageProductAttribute(EpcProductAttribute productAttribute,String createdBy){
		
		 EpcProductAttribute retProductAttribute = null;
		 
		switch(productAttribute.getMetaInfo().get("OPERATION")){		
			
				case "CREATE":
					retProductAttribute=createProductAttribute(productAttribute,createdBy);
						break;
				case "UPDATE":
					retProductAttribute=modifyProductAttribute(productAttribute, createdBy);
					break;
				case "DELETE":
					retProductAttribute=deleteProductAttribute(productAttribute);
						break;
				default:
						throw new EPCException("not supported");
		}
		
		return retProductAttribute;
	}
	
	/**
	 * @param productAttribute
	 * @param createdBy
	 * @return
	 */
	public EpcProductAttribute createProductAttribute(EpcProductAttribute  productAttribute, String createdBy){
		productAttribute.setAttributeId(productAttribute.getAttributeId());
		productAttribute.setAttributeUom(productAttribute.getAttributeUom());
		productAttribute.setStatus(productAttribute.getStatus());
		productAttribute.setIsChildProductAttribute(productAttribute.getIsChildProductAttribute());
		productAttribute.setIsMandatory(productAttribute.getIsMandatory());
		productAttribute.setIsOtcAttribute(productAttribute.getIsOtcAttribute());
		productAttribute.setIsPriceingAttribute(productAttribute.getIsPriceingAttribute());
		productAttribute.setDefaultValue1(productAttribute.getDefaultValue1());
		productAttribute.setAttributeValue1(productAttribute.getAttributeValue1());
		productAttribute.setDefaultValue1(productAttribute.getDefaultValue2());
		productAttribute.setAttributeValue1(productAttribute.getAttributeValue2());
		productAttribute.setCreatedBy(createdBy);
		productAttribute.setCreatedDate(new Date());
		
		epcProductAttributeRepository.save(productAttribute);
		
		return productAttribute;
		
	}
	
	/**
	 * @param productAttribute
	 * @param lastUpdatedBy
	 * @return
	 */
	EpcProductAttribute modifyProductAttribute(EpcProductAttribute productAttribute, String lastUpdatedBy) {
		epcProductAttributeRepository.modifyProductAttribute(productAttribute);
		return productAttribute;
	}
	
	/**
	 * @param productAttribute
	 * @return
	 */
	public EpcProductAttribute deleteProductAttribute(EpcProductAttribute productAttribute){
		
		epcProductAttributeRepository.delete(productAttribute.getProductAttributeId());
		return productAttribute;
	}
	
	//****************************************SEARCH*************************************************************
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductAttribute> searchProductAttribute(Map<String, List<String>> allRequestParams){
		
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,EpcProductAttribute.class.getName(), null);
		
		List<EpcProductAttribute> retProductAttributeList=null;
		//retEpcProductAttributeList=epcProductAttributeRepository.getEpcProductAttributeList(queryBuilder.toString());
		try {
			retProductAttributeList = epcProductAttributeRepository.getEpcProductAttributeList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return retProductAttributeList;
		
	}

}
