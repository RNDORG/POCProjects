package com.wipro.epc.repositories;

import java.util.List;


import com.wipro.epc.domain.EpcProductLocation;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductLocationRepositoryCustom
 */
public interface EpcProductLocationRepositoryCustom {
	
	/**
	 * @param query
	 * @return
	 */
	List<EpcProductLocation> getList(String query);
	/**
	 * @param location
	 * @return
	 */
	EpcProductLocation modifyProductLocation(EpcProductLocation location);


}
