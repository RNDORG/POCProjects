package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.wipro.epc.domain.CacheEligibility;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.CacheEligibilityRepository;


@Service
public class CacheEligibilityService {
	
	@Autowired
	CacheEligibilityRepository cacheEligibilityRepository;
	
	@Transactional
	public CacheEligibility saveEligibility(CacheEligibility eligibility)
			{
				return	cacheEligibilityRepository.save(eligibility);
			}

	@Transactional
	public void deleteEligibilities(List<CacheEligibility> eligibilities)
	{
		for(CacheEligibility eligibility:eligibilities)
		{
			cacheEligibilityRepository.delete(eligibility);
		}
		
	}
	

	public List<CacheEligibility> searchEligibility(String query)
	{
		List<CacheEligibility> listOfEligibilitiesReturned = new ArrayList<CacheEligibility>();
		try {
		listOfEligibilitiesReturned = cacheEligibilityRepository.getList(query);
		} catch (Exception e) {
		throw new EPCException(
				"Error occurred while fetching results from database.\n"
						+ " Query: " + query + "\n"
						+ " Exception: " + e.getMessage(), e);
	}
		return listOfEligibilitiesReturned;
	}
}
