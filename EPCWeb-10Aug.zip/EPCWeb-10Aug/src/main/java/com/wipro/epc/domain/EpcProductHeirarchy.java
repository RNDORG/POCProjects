package com.wipro.epc.domain;



import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;


/**
 * The persistent class for the epc_product_heirarchy database table.
 * @author VI251443
 * @version 1.0
 * 
 */
@Entity
@Table(name="epc_product_heirarchy")
public class EpcProductHeirarchy  implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_heirarchy_id")
	private Integer productHeirarchyId;

	@Column(name="child_product_id")
	private Integer childProductId;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="parent_product_id")
	private Integer parentProductId;

	@Column(name="status")
	private String status;
	
	@Transient
	private Map<String,String> metaInfo;	
	

	public EpcProductHeirarchy() {
	}

	@Transient
	public Map<String, String> getMetaInfo() {
		return metaInfo;		
	}
	
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}
	
	public Integer getProductHeirarchyId() {
		return this.productHeirarchyId;
	}

	public void setProductHeirarchyId(Integer productHeirarchyId) {
		this.productHeirarchyId = productHeirarchyId;
	}

	public Integer getChildProductId() {
		return this.childProductId;
	}

	public void setChildProductId(Integer childProductId) {
		this.childProductId = childProductId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getParentProductId() {
		return this.parentProductId;
	}

	public void setParentProductId(Integer parentProductId) {
		this.parentProductId = parentProductId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "EpcProductHeirarchy [productAttributeId=" + productHeirarchyId
				+ ", attributeId=" + childProductId + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", modifiedBy=" + modifiedBy
				+ ", modifiedDate=" + modifiedDate + ", parentProductId="
				+ parentProductId + ", status=" + status
				+", metaInfo=" + metaInfo + "]";
	}

}