package com.wipro.epc.security;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.wipro.epc.uam.domain.Users;
import com.wipro.epc.uam.repositories.AuthorityRepository;
import com.wipro.epc.uam.repositories.UsersRepository;



@Service
public class CustomUserDetailsService implements UserDetailsService {
	
	@Autowired
	UsersRepository usersRepo;
	
	@Autowired
	AuthorityRepository authRepo;

	@Override
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {
		try {
		System.out.println("CustomUserDetailsService.loadUserByUsername( " + username + " ) invoked ---------- ");
				
		Users user = usersRepo.findUserAlongWithRoles(username); 
		System.out.println("userRepo.findOne("+username+") => " + user.toString() );
		List<String> listOfAuthorities = authRepo.getAuthoritiesForUser(username);
	   	CustomUserDetails customUserDetails = new CustomUserDetails(user, listOfAuthorities);
    	
    	System.out.println("CustomUserDetailsService.loadUserByUsername( " + username + " ) ends ---------- ");
    	return customUserDetails;
		}catch (Exception e) {
			String errMsg = "Exception while looking up User \"" + username + "\" Probably user does not exist in Database. Underlying exception : " + e.getClass().getName() + " : " + e.getMessage();
			System.out.println( errMsg );
			throw new UsernameNotFoundException( errMsg ,e);
		}
	}

}
