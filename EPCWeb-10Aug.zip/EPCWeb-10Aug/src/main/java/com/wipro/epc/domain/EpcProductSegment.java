package com.wipro.epc.domain;



import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;


/**
 * The persistent class for the epc_product_segment database table.
 * @author KE334465
 * @version 1.0
 */

@Entity
@Table(name="epc_product_segment")
public class EpcProductSegment  implements Serializable  {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_segment_id")
	private Integer productSegmentId;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;

	@Column(name="product_id")
	private Integer productId;

	@Column(name="segment_type")
	private String segmentType;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String segmentTypeValue;
*/
	@Column(name="segment_value")
	private String segment;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String segmentValue;*/
	
	@Column(name="status")
	private String status;
	
	/**
	 * 
	 */
	public EpcProductSegment() {
	}
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;
	*/
	@Transient
	private Map<String,String> metaInfo;	
	//
	/**
	 * @return
	 */
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}
	
	/**
	 * @param metaInfo
	 */
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}



	/**
	 * @return
	 */
	public Integer getProductSegmentId() {
		return this.productSegmentId;
	}

	/**
	 * @param productSegmentId
	 */
	public void setProductSegmentId(Integer productSegmentId) {
		this.productSegmentId = productSegmentId;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return
	 */
	public Integer getProductId() {
		return this.productId;
	}

	/**
	 * @param productId
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return
	 */
	public String getSegmentType() {
		return this.segmentType;
	}

	/**
	 * @param segmentType
	 */
	public void setSegmentType(String segmentType) {
		this.segmentType = segmentType;
	}

	/**
	 * @return
	 */
	public String getSegment() {
		return this.segment;
	}

	/**
	 * @param segmentValue
	 */
	public void setSegment(String segmentValue) {
		this.segment = segmentValue;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	

	/*public String getSegmentTypeValue() {
		this.segmentTypeValue = segmentType;
		return segmentTypeValue;
	}

	public void setSegmentTypeValue(String segmentTypeValue) {
		this.segmentTypeValue = segmentTypeValue;
	}

	public String getSegmentValue() {
		this.segmentValue = segment;
		return segmentValue;
	}

	public void setSegmentValue(String segmentValue) {
		this.segmentValue = segmentValue;
	}

	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}*/

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EpcProductSegment [productSegmentId=" + productSegmentId
				+ ", createDate=" + createdDate + ", createdBy=" + createdBy
				+ ", modifiedBy=" + modifiedBy + ", modifyDate=" + modifiedDate
				+ ", productId=" + productId + ", segmentType=" + segmentType
				+ ", segmentValue=" + segment + ", status=" + status
				+ ", metaInfo=" + metaInfo + "]";
	}

	

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result
				+ ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result
				+ ((metaInfo == null) ? 0 : metaInfo.hashCode());
		result = prime * result
				+ ((modifiedBy == null) ? 0 : modifiedBy.hashCode());
		result = prime * result
				+ ((modifiedDate == null) ? 0 : modifiedDate.hashCode());
		result = prime * result
				+ ((productId == null) ? 0 : productId.hashCode());
		result = prime
				* result
				+ ((productSegmentId == null) ? 0 : productSegmentId.hashCode());
		result = prime * result
				+ ((segmentType == null) ? 0 : segmentType.hashCode());
		result = prime * result
				+ ((segment == null) ? 0 : segment.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		
		EpcProductSegment other = (EpcProductSegment) obj;
		if (createdDate == null) {
			if (other.createdDate != null){
				return false;
			}
		} else if(!createdDate.equals(other.createdDate)) {
			return false;
		}
		if (createdBy == null) {
			if (other.createdBy != null) {
				return false;
			}
		} else if (!createdBy.equals(other.createdBy)) {
			return false;
		}
		if (metaInfo == null) {
			if (other.metaInfo != null) {
				return false;
			}
		} else if (!metaInfo.equals(other.metaInfo)) {
			return false;
		}
		if (modifiedBy == null) {
			if (other.modifiedBy != null) {
				return false;
			}
		} else if (!modifiedBy.equals(other.modifiedBy)) {
			return false;
		}
		if (modifiedDate == null) {
			if (other.modifiedDate != null) {
				return false;
			}
		} else if (!modifiedDate.equals(other.modifiedDate)) {
			return false;
		}
		if (productId == null) {
			if (other.productId != null) {
				return false;
			}
		} else if (!productId.equals(other.productId)) {
			return false;
		}
		if (productSegmentId == null) {
			if (other.productSegmentId != null){
				return false;
			}
		} else if (!productSegmentId.equals(other.productSegmentId)) {
			return false;
		}
		if (segmentType == null) {
			if (other.segmentType != null) {
				return false;
			}
		} else if (!segmentType.equals(other.segmentType)){
			return false;
		}
		if (segment == null) {
			if (other.segment != null) {
				return false;
			}
		} else if (!segment.equals(other.segment)) {
			return false;
		}
		if (status == null) {
			if (other.status != null) {
				return false;
			}
		} else if (!status.equals(other.status)) {
			return false;
		}
		return true;
	}
	
	

}