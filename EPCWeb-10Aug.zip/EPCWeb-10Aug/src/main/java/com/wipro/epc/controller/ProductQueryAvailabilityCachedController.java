package com.wipro.epc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.dto.QueryAvailabilityResponse;
import com.wipro.epc.dto.QueryAvailabilitySearchInput;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.ProductQueryAvailabilityCachedService;



/**
 * @author Developer
 * @version 1.0
 * type ProductQueryAvailabilityController
 */
@RestController
public class ProductQueryAvailabilityCachedController {

	private static Logger logger = LoggerFactory.getLogger(ProductQueryAvailabilityCachedController.class);
	/**
	 * ProductQueryAvailabilityService ProductQueryAvailabilityController.java
	 */
	@Autowired
	ProductQueryAvailabilityCachedService queryAvailabilityService;
	
	/**
	 * TransactionsService ProductQueryAvailabilityController.java
	 */
	@Autowired
	TransactionsService transactionsLogging ;

	/**
	 * ObjectMapper ProductQueryAvailabilityController.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * TransactionStore ProductQueryAvailabilityController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/queryAvailability", method=RequestMethod.POST)
	public QueryAvailabilityResponse queryAvailabilityExt(@RequestBody QueryAvailabilitySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		String txnType = "queryAvailability";
		String request=null;
		QueryAvailabilityResponse response=null;
		try{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, searchInput);
		response=queryAvailabilityService.queryAvailability(searchInput,allRequestParams);
		}
		catch (Exception e ) {
			logger.error("#interfaceException: " + e.getMessage());
			throw new EPCException(e.getMessage());
		}
		finally{
		ePCTxnInterceptor.postTxn(txnType, request, response);
		}
		return response;
	}
	
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/queryAvailability", method=RequestMethod.POST)
	public QueryAvailabilityResponse queryAvailability(@RequestBody QueryAvailabilitySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		return queryAvailabilityService.queryAvailability(searchInput,allRequestParams);
	}
	
}
