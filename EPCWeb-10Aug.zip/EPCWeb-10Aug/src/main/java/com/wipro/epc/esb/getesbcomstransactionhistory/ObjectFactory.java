
package com.wipro.epc.esb.getesbcomstransactionhistory;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.wipro.epc.esb.getesbcomstransactionhistory package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetOrderStatusbyCustOldMSISDNRequest_QNAME = new QName("http://www.telenor.com.mm/GetESBCOMSTransactionHistory", "GetOrderStatusbyCustOldMSISDNRequest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.wipro.epc.esb.getesbcomstransactionhistory
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetOrderStatusbyCustOldMSISDNResponse }
     * 
     */
    public GetOrderStatusbyCustOldMSISDNResponse createGetOrderStatusbyCustOldMSISDNResponse() {
        return new GetOrderStatusbyCustOldMSISDNResponse();
    }

    /**
     * Create an instance of {@link OrderStatusResponseListType }
     * 
     */
    public OrderStatusResponseListType createOrderStatusResponseListType() {
        return new OrderStatusResponseListType();
    }

    /**
     * Create an instance of {@link GetOrderStatusbyCustOldMSISDNRequestType }
     * 
     */
    public GetOrderStatusbyCustOldMSISDNRequestType createGetOrderStatusbyCustOldMSISDNRequestType() {
        return new GetOrderStatusbyCustOldMSISDNRequestType();
    }

    /**
     * Create an instance of {@link OrderStatusResponseListItemType }
     * 
     */
    public OrderStatusResponseListItemType createOrderStatusResponseListItemType() {
        return new OrderStatusResponseListItemType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetOrderStatusbyCustOldMSISDNRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.telenor.com.mm/GetESBCOMSTransactionHistory", name = "GetOrderStatusbyCustOldMSISDNRequest")
    public JAXBElement<GetOrderStatusbyCustOldMSISDNRequestType> createGetOrderStatusbyCustOldMSISDNRequest(GetOrderStatusbyCustOldMSISDNRequestType value) {
        return new JAXBElement<GetOrderStatusbyCustOldMSISDNRequestType>(_GetOrderStatusbyCustOldMSISDNRequest_QNAME, GetOrderStatusbyCustOldMSISDNRequestType.class, null, value);
    }

}
