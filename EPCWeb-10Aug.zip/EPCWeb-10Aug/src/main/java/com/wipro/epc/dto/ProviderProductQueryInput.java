package com.wipro.epc.dto;

import java.util.List;

/**
 * @author Developer
 * @version 1.0
 * type ProviderProductQueryInput
 */
public class ProviderProductQueryInput {

	/**
	 * List<ProviderProductListInput> ProviderProductQueryInput.java
	 */
	private List<ProviderProductListInput> providerList;
	/**
	 * String ProviderProductQueryInput.java
	 */
	private String initiatingChannel;
	/**
	 * String ProviderProductQueryInput.java
	 */
	private String actionType;
	
	/**
	 * String ProviderProductQueryInput.java
	 */
	private String category;
	
	/**
	 * String ProviderProductQueryInput.java
	 */
	private String filterCriteria;
	
	
	/**
	 * @return
	 */
	public List<ProviderProductListInput> getProviderList() {
		return providerList;
	}
	/**
	 * @param providerList
	 */
	public void setProviderList(List<ProviderProductListInput> providerList) {
		this.providerList = providerList;
	}
	/**
	 * @return
	 */
	public String getInitiatingChannel() {
		return initiatingChannel;
	}
	/**
	 * @param initiatingChannel
	 */
	public void setInitiatingChannel(String initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}
	/**
	 * @return
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	/**
	 * @return the filterCriteria
	 */
	public String getFilterCriteria() {
		return filterCriteria;
	}
	/**
	 * @param filterCriteria the filterCriteria to set
	 */
	public void setFilterCriteria(String filterCriteria) {
		this.filterCriteria = filterCriteria;
	}
	
	

}
