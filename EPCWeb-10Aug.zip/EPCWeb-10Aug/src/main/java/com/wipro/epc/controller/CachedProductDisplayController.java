package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.services.CachedProductDisplayService;


@RestController
public class CachedProductDisplayController {
	
	@Autowired
	CachedProductDisplayService cachedProductDisplayService;

	@RequestMapping(value="/rest/extapi/v1/cache/product/dump", method=RequestMethod.GET)
	public List<EpcProductSpecification> DisplayList(@RequestParam(value="id",required=true)  String ids){
	String[] id=ids.split(",");
	//System.out.println(id[0]+" : "+id[1]);
		return cachedProductDisplayService.DisplayList( id);
	}
	
	@RequestMapping(value="/rest/extapi/v1/cache/product", method=RequestMethod.GET)
	public String DisplayCachedProductInfo(){
		return cachedProductDisplayService.cachedProductInfo();
	}

}
