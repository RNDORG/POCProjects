package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductHeirarchy;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductHeirarchyRepository;
import com.wipro.epc.uam.definitions.MetaInfo;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductHeirarchyService
 */
@Service
public class EpcProductHeirarchyService {
	private static Logger logger = LoggerFactory.getLogger(EpcProductHeirarchy.class);
	/**
	 * EpcProductHeirarchyRepository EpcProductHeirarchyService.java
	 */
	@Autowired
	EpcProductHeirarchyRepository epcProductHeirarchyRepository;
	
	/**
	 * @param productHeirarchyList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductHeirarchy> manageProductHeirarchies(List<EpcProductHeirarchy> productHeirarchyList,String createdBy){
		
		List<EpcProductHeirarchy> retProductHeirarchyList=new ArrayList<EpcProductHeirarchy>();
		
			for (EpcProductHeirarchy productHeirarchy : productHeirarchyList) {
				productHeirarchy=manageProductHeirarchy(productHeirarchy, createdBy);
				if (productHeirarchy.getMetaInfo().get("STATUS") == null) {
					productHeirarchy.getMetaInfo().put(MetaInfo.STATUS,
							MetaInfo.SUCCESS);
				}
				retProductHeirarchyList.add(productHeirarchy);

			}
			return retProductHeirarchyList;
			
		}
		
		/**
		 * @param productHeirarchy
		 * @param createdBy
		 * @return
		 */
		public EpcProductHeirarchy manageProductHeirarchy(EpcProductHeirarchy productHeirarchy,String createdBy){
			
			 EpcProductHeirarchy retProductHeirarchy = null;
			 
			switch(productHeirarchy.getMetaInfo().get("OPERATION")){		
				
					case "CREATE":
						retProductHeirarchy=createProductHeirarchy(productHeirarchy,createdBy);
							break;
					case "UPDATE":
						logger.info("UPDATE 1");
						retProductHeirarchy=modifyProductHeirarchy(productHeirarchy, createdBy);
						break;
					case "DELETE":
						retProductHeirarchy=deleteProductHeirarchy(productHeirarchy);
							break;
					default:
							throw new EPCException("not supported");
			}
			
			return retProductHeirarchy;
		}
		
		/**
		 * @param productHeirarchy
		 * @param createdBy
		 * @return
		 */
		public EpcProductHeirarchy createProductHeirarchy(EpcProductHeirarchy  productHeirarchy, String createdBy){
			
			productHeirarchy.setCreatedBy(createdBy);
			productHeirarchy.setCreatedDate(new Date());
			
			epcProductHeirarchyRepository.save(productHeirarchy);
			
			return productHeirarchy;
			
		}
		
		/**
		 * @param productHeirarchy
		 * @param lastUpdatedBy
		 * @return
		 */
		EpcProductHeirarchy modifyProductHeirarchy(EpcProductHeirarchy productHeirarchy, String lastUpdatedBy) {
			epcProductHeirarchyRepository.modifyProductHeirarchy(productHeirarchy);
			logger.info("UPDATE 2");
			return productHeirarchy;
		}
		
		/**
		 * @param productHeirarchy
		 * @return
		 */
		public EpcProductHeirarchy deleteProductHeirarchy(EpcProductHeirarchy productHeirarchy){
			
			epcProductHeirarchyRepository.delete(productHeirarchy.getProductHeirarchyId());
			return productHeirarchy;
		}
//****************************************SEARCH*************************************************************
		
		/**
		 * @param allRequestParams
		 * @return
		 */
		public List<EpcProductHeirarchy> searchEpcProductHeirarchy(Map<String, List<String>> allRequestParams){
			
			String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,EpcProductHeirarchy.class.getName(), null);
			
			List<EpcProductHeirarchy> retProductHeirarchyList=null;
			//retEpcProductHeirarchyList=epcProductHeirarchyRepository.getEpcProductHeirarchyList(queryBuilder.toString());
			try {
				retProductHeirarchyList = epcProductHeirarchyRepository.getEpcProductHeirarchyList(queryBuilder.toString());
			} catch (Exception e) {
				throw new EPCException(
						"Error occurred while fetching results from database.\n"
								+ " Query: " + queryBuilder.toString() + "\n"
								+ " Exception: " + e.getMessage(), e);
			}
			
			return retProductHeirarchyList;
			
		}

}
