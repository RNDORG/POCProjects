package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductAttribute;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductAttributeRepositoryCustom
 */
public interface EpcProductAttributeRepositoryCustom {
	
	
	/**
	 * @param query
	 * @return
	 */
	List<EpcProductAttribute> getEpcProductAttributeList(String query);
	
	
	/**
	 * @param productAttribute
	 * @return
	 */
	EpcProductAttribute modifyProductAttribute(EpcProductAttribute productAttribute);
	

}
