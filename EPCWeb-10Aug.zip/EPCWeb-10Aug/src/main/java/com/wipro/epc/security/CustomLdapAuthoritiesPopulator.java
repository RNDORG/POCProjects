package com.wipro.epc.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;
import org.springframework.stereotype.Component;

import com.wipro.epc.uam.repositories.AuthorityRepository;

@Component
public class CustomLdapAuthoritiesPopulator implements LdapAuthoritiesPopulator {
	@Autowired
	AuthorityRepository authRepo;;
	
	@Override
	public Collection<? extends GrantedAuthority> getGrantedAuthorities(
			DirContextOperations userData, String username) {

		System.out.println("CustomLdapAuthoritiesPopulator.getGrantedAuthorities( " + username + " ) invoked ---------- ");

		Collection<GrantedAuthority> retVal = new ArrayList<GrantedAuthority>();
		List<String> listOfAuthorities = new ArrayList<String>();
		
		listOfAuthorities = authRepo.getAuthoritiesForUser(username);
		
		for (String s : listOfAuthorities) {
				retVal.add(new SimpleGrantedAuthority(s));
		}

		System.out.println("CustomLdapAuthorititesPopulator.getGrantedAuthorities( "+ username + ") returning >> " + retVal.toString());
		return retVal;
	}
}