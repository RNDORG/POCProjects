package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcNotificationTemplate;


/**
 * @author KE334465
 *
 */
@Repository
public interface EpcNotificationTemplateRepository extends CrudRepository<EpcNotificationTemplate, Integer>,
EpcNotificationTemplateRepositoryCustom{

	 /**
	 * @param notificationTemplateId
	 * @return
	 */
	@Query(value="select * from epc_notification_template where notification_template_id =:notificationTemplateId", nativeQuery=true)
		List<EpcNotificationTemplate> findNotificationByTemplateId(@Param("notificationTemplateId") Integer notificationTemplateId);
	 
	 
	 
	 /**
	 * @param templateType
	 * @param templateName
	 * @param status
	 * @return
	 */
	@Query(value="select notification_template_id from epc_notification_template where template_type=:templateType and template_name=:templateName "
	 		+ "and status=:status", nativeQuery=true)
		Integer getNotificationTemplateId(@Param("templateType")String templateType, @Param("templateName")String templateName, @Param("status")String status);

	 /**
	 * @param templateName
	 * @param templateType
	 * @return
	 */
	EpcNotificationTemplate findByTemplateNameAndTemplateType(String templateName,String templateType);
	 
	 /**
	 * @param templateName
	 * @param templateType
	 * @param sourceSystem
	 * @param modeOFDelivery
	 * @return
	 */
	EpcNotificationTemplate findByTemplateNameAndTemplateTypeAndSourceSystemAndModeOfDelivery(String templateName,String templateType, String sourceSystem,String modeOFDelivery);
	
	 /**
	 * @return
	 */
	@Query(value = "select * from epc_notification_template ", nativeQuery=true)
	 List<EpcNotificationTemplate> getAllListofValues();
	 
	 /**
	 * @param templateType
	 * @param templateLanguage
	 * @param sourceSystem
	 * @param mOD
	 * @return
	 */
	@Query(value="select * from epc_notification_template where template_type = :templateType and source_system = :sourceSystem and "
	 		+ " notification_template_id in (select notification_template_id from epc_notification_template_detail where template_language = :templateLanguage) and mode_of_delivery = :mOD", nativeQuery = true)
	 List<EpcNotificationTemplate> getListOfValidation(@Param("templateType") String templateType, @Param("templateLanguage") String templateLanguage,
			 											@Param("sourceSystem") String sourceSystem, @Param("mOD") String mOD);

}
