package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcTriggerOrderRule;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
@Repository
public interface EpcOrderTriggerRuleRepositoryCustom {
	
	/**
	 * Modifies the data in DB
	 * @param orderTrigger
	 * @return
	 */
	EpcTriggerOrderRule modifyOrderTriggerRule(EpcTriggerOrderRule orderTrigger);
    
	/**
	 * get the list of data
	 * @param query
	 * @return List<EpcTriggerOrderRule>
	 */
	List<EpcTriggerOrderRule> getList(String query);
}
