package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.services.EpcProductDecompositionService;

/**
 * Controller class for 
 * EpcProductDecomposition
 * 
 * @author VI251443
 * @version 1.0
 */
@RestController
public class EpcProductDecompositionController {
	
	@Autowired
	EpcProductDecompositionService epcProductDecompositionService;

	/**
	 * 
	 * @param productsDecompositionList
	 * @param txn
	 * @param allRequestParams
	 * @return the list of EpcProductDecomposition
	 */
	@RequestMapping(value="/rest/extapi/v1/decompositions",method=RequestMethod.POST)
	public List<EpcProductDecomposition> updateProductDecompositionExt(@RequestBody List<EpcProductDecomposition> productsDecompositionList, 
			@RequestParam(value="txn",defaultValue="true")boolean txn, @RequestParam MultiValueMap allRequestParams)
			
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		return epcProductDecompositionService.updateProductDecomposition(productsDecompositionList, txn, allRequestParams,user);
	}
	
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/decompositions", method=RequestMethod.GET)
	public List<EpcProductDecomposition> searchProductDecompositionExt(@RequestParam MultiValueMap allRequestParams)
	{
 			return epcProductDecompositionService.searchProductDecompositionUI(allRequestParams);
	}
	
	/**
	 * 
	 * @param productsDecompositionList
	 * @param txn
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/decompositions",method=RequestMethod.POST)
	public List<EpcProductDecomposition> updateProductDecomposition(@RequestBody List<EpcProductDecomposition> productsDecompositionList, 
			@RequestParam(value="txn",defaultValue="true")boolean txn, @RequestParam MultiValueMap allRequestParams)
			
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		for(EpcProductDecomposition decomposition: productsDecompositionList){
		////System.out.println("The decomposition task type is "+decomposition.getTaskType());
		}
		return epcProductDecompositionService.updateProductDecomposition(productsDecompositionList, txn, allRequestParams,user);
	}
	
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/decompositions", method=RequestMethod.GET)
	public List<EpcProductDecomposition> searchProductDecomposition(@RequestParam MultiValueMap allRequestParams)
	{
           return epcProductDecompositionService.searchProductDecompositionUI(allRequestParams);
	}
	
	/**
	 * To get the decomposition rules for the orderType = OFFER_SUBS, 
	 * in Product_View page
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/decompositionsSubscription", method=RequestMethod.GET)
	public List<EpcProductDecomposition> searchProductDecompositionForSubscription(@RequestParam MultiValueMap allRequestParams)
	{
		boolean isOfferSubs = true;
           return epcProductDecompositionService.searchProductDecompositionForSubscription(allRequestParams, isOfferSubs);
	}
	
	/**
	 * To get the decomposition rules for the orderType = OFFER_UNSU, 
	 * in Product_View page
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/decompositionsUnsubscription", method=RequestMethod.GET)
	public List<EpcProductDecomposition> searchProductDecompositionForUnsubscription(@RequestParam MultiValueMap allRequestParams)
	{
		   boolean isOfferSubs = false;
           return epcProductDecompositionService.searchProductDecompositionForSubscription(allRequestParams, isOfferSubs);
	}

}
