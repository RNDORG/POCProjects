package com.wipro.epc.services;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductNetworkTpl;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductNetworkTplRepository;
/**
 * @author KE334465
 *
 */
@Service

public class EpcProductNetworkTplService {

	private static Logger logger = LoggerFactory.getLogger(EpcProductNetworkTplService.class);
	
	/**
	 * 
	 */
	@Autowired
	private EpcProductNetworkTplRepository epcProductNetworkTplRepository;
	
	/**
	 * 
	 */
	private List<EpcProductNetworkTpl> epcProductNetworkTplCache;
	
/*	public String getTemplateId(String tempateName) {
		if (epcProductNetworkTplCache == null) {
			epcProductNetworkTplCache = getNetworkProfiles();
		}
		for (EpcProductNetworkTpl epcProductNetwork : epcProductNetworkTplCache) {
			if (epcProductNetwork != null
					&& tempateName.equals(epcProductNetwork.getTemplateName())) {
				return epcProductNetwork.getTemplateId();
			}

		}
		return null;
	}*/
		
		

		/**
		 * @param allRequestParams
		 * @return
		 */
		public List<EpcProductNetworkTpl> searchNetworkServices(Map<String, List<String>> allRequestParams) {
			
			 String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,EpcProductNetworkTpl.class.getName(), null);
			
			List<EpcProductNetworkTpl> returnedChar = null;
			try {
				returnedChar = epcProductNetworkTplRepository.getNetworkProfileList(queryBuilder.toString());
			} catch (Exception e) {
				throw new EPCException(
						"Error occurred while fetching results from database.\n"
								+ " Query: " + queryBuilder.toString() + "\n"
								+ " Exception: " + e.getMessage(), e);
			}
			 
			
			//System.out.println(returnedChar);		
			
			
				return returnedChar;
		}

		/**
		 * @return
		 */
		public List<EpcProductNetworkTpl> getNetworkProfiles() {
			//String query = "select distinct template_name from epc_product_network_tpl ";
			List<EpcProductNetworkTpl> returnedChar = null;
			try {
				returnedChar = epcProductNetworkTplRepository.getNetworkProfiles();
				
			} catch (Exception e) {
				throw new EPCException(
						"Error occurred while fetching results from database.\n", e);
								//+ " Query: " + query + "\n"
								//+ " Exception: " + e.getMessage());
			}
			 
			
			//System.out.println(returnedChar);		
			
			
				return returnedChar;
		}

		/**
		 * @return
		 */
		public static Logger getLogger() {
			return logger;
		}

		/**
		 * @param logger
		 */
		public static void setLogger(Logger logger) {
			EpcProductNetworkTplService.logger = logger;
		}

		/**
		 * @return
		 */
		public EpcProductNetworkTplRepository getEpcProductNetworkTplRepository() {
			return epcProductNetworkTplRepository;
		}

		/**
		 * @param epcProductNetworkTplRepository
		 */
		public void setEpcProductNetworkTplRepository(
				EpcProductNetworkTplRepository epcProductNetworkTplRepository) {
			this.epcProductNetworkTplRepository = epcProductNetworkTplRepository;
		}

		/**
		 * @return
		 */
		public List<EpcProductNetworkTpl> getEpcProductNetworkTplCache() {
			return epcProductNetworkTplCache;
		}

		/**
		 * @param epcProductNetworkTplCache
		 */
		public void setEpcProductNetworkTplCache(
				List<EpcProductNetworkTpl> epcProductNetworkTplCache) {
			this.epcProductNetworkTplCache = epcProductNetworkTplCache;
		}

}
