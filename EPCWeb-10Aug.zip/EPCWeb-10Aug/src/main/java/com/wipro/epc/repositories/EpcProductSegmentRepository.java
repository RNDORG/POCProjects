package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcProductSegment;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductSegmentRepository
 */
@Repository
public interface EpcProductSegmentRepository extends CrudRepository<EpcProductSegment, Integer>, EpcProductSegmentRepositoryCustom{

	
	/**
	 * @param productId
	 * @return
	 */
	@Query(value="select * from epc_product_segment where product_id=:productId", nativeQuery = true)
	List<EpcProductSegment> findSegmentsByProductId(@Param("productId") Integer productId);
	
	/**
	 * @param productId
	 */
	@Modifying
	@Query(value="delete from epc_product_segment where product_id=:productId", nativeQuery=true)
	void deleteProductFromSegment(@Param("productId") Integer productId);
}
