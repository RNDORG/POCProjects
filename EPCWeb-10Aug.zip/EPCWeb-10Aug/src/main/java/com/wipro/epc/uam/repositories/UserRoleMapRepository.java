package com.wipro.epc.uam.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.uam.domain.UserRoleMap;


/**
 * @author KE334465
 *
 */
public interface UserRoleMapRepository extends CrudRepository<UserRoleMap, Long>{

	/**
	 * @param username
	 */
	@Modifying
	@Query(value="delete from user_role_map where user_name=:username", nativeQuery=true)
	@Transactional
	void deleteFromUserRoleMap(@Param("username") String username);
	
	/**
	 * @param username
	 * @return
	 */
	@Query(value="select * from user_role_map where user_name=:username", nativeQuery= true)
	List<UserRoleMap> findByUserName(@Param("username") String username);
	
	/**
	 * @param username
	 * @return
	 */
	@Query(value="select count(user_name) from user_role_map where user_name=:username", nativeQuery=true)
	long countRolesForAnUser(@Param("username") String username);
}
