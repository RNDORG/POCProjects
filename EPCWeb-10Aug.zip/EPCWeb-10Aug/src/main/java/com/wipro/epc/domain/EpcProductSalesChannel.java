package com.wipro.epc.domain;



import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;


/**
 * @author Developer
 * @version 1.0
 * The persistent class for the epc_product_sales_channel database table.
 * 
 */
@Entity
@Table(name="epc_product_sales_channel")
public class EpcProductSalesChannel  implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Integer EpcProductSalesChannel.java
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_sales_channel_id")
	private Integer productSalesChannelId;

	/**
	 * String EpcProductSalesChannel.java
	 */
	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	/**
	 * Date EpcProductSalesChannel.java
	 */
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;

	/**
	 * String EpcProductSalesChannel.java
	 */
	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	/**
	 * Date EpcProductSalesChannel.java
	 */
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;

	/**
	 * String EpcProductSalesChannel.java
	 */
	@Column(name="partner_type")
	private String partnerType;
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String partnerTypeValue;*/

	/**
	 * String EpcProductSalesChannel.java
	 */
	@Column(name="partners_list")
	private String partnersList;

	/**
	 * Integer EpcProductSalesChannel.java
	 */
	@Column(name="product_id")
	private Integer productId;
	
	/**
	 * String EpcProductSalesChannel.java
	 */
	@Column(name="status")
	private String status;

	/**
	 * Map<String,String> EpcProductSalesChannel.java
	 */
	@Transient
	private Map<String,String> metaInfo;	

/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;*/
	
/*	public String getPartnerTypeValue() {
		this.partnerTypeValue = partnerType;
		return partnerTypeValue;
	}

	public void setPartnerTypeValue(String partnerTypeValue) {
		this.partnerTypeValue = partnerTypeValue;
	}

	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}*/



	/**
	 * @return
	 */
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}
	

	/**
	 * @param MetaInfo
	 */
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}

	/**
	 * 
	 */
	public EpcProductSalesChannel() {
	}

	/**
	 * @return
	 */
	public Integer getProductSalesChannelId() {
		return this.productSalesChannelId;
	}

	/**
	 * @param productSalesChannelId
	 */
	public void setProductSalesChannelId(Integer productSalesChannelId) {
		this.productSalesChannelId = productSalesChannelId;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return
	 */
	public String getPartnerType() {
		return this.partnerType;
	}

	/**
	 * @param partnerType
	 */
	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}

	/**
	 * @return
	 */
	public String getPartnersList() {
		return this.partnersList;
	}

	/**
	 * @param partnersList
	 */
	public void setPartnersList(String partnersList) {
		this.partnersList = partnersList;
	}

	/**
	 * @return
	 */
	public Integer getProductId() {
		return this.productId;
	}

	/**
	 * @param productId
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EpcProductSalesChannel [productSalesChannelId="
				+ productSalesChannelId + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", modifiedBy=" + modifiedBy
				+ ", modifiedDate=" + modifiedDate + ", partnerType="
				+ partnerType + ", partnersList=" + partnersList
				+ ", productId=" + productId + ", status=" + status
				+ ", metaInfo=" + metaInfo + "]";
	}

	

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result
				+ ((metaInfo == null) ? 0 : metaInfo.hashCode());
		result = prime * result
				+ ((modifiedBy == null) ? 0 : modifiedBy.hashCode());
		result = prime * result
				+ ((modifiedDate == null) ? 0 : modifiedDate.hashCode());
		result = prime * result
				+ ((partnerType == null) ? 0 : partnerType.hashCode());
		result = prime * result
				+ ((partnersList == null) ? 0 : partnersList.hashCode());
		result = prime * result
				+ ((productId == null) ? 0 : productId.hashCode());
		result = prime
				* result
				+ ((productSalesChannelId == null) ? 0 : productSalesChannelId
						.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		EpcProductSalesChannel other = (EpcProductSalesChannel) obj;
		if (createdBy == null) {
			if (other.createdBy != null){
				return false;
			}
		} else if (!createdBy.equals(other.createdBy)){
			return false;
		}
		if (createdDate == null) {
			if (other.createdDate != null){
				return false;
			}
		} else if (!createdDate.equals(other.createdDate)){
			return false;
		}
		if (metaInfo == null) {
			if (other.metaInfo != null){
				return false;
			}
		} else if (!metaInfo.equals(other.metaInfo)){
			return false;
		}
		if (modifiedBy == null) {
			if (other.modifiedBy != null){
				return false;
			}
		} else if (!modifiedBy.equals(other.modifiedBy)){
			return false;
		}
		if (modifiedDate == null) {
			if (other.modifiedDate != null){
				return false;
			}
		} else if (!modifiedDate.equals(other.modifiedDate)){
			return false;
		}
		if (partnerType == null) {
			if (other.partnerType != null){
				return false;
			}
		} else if (!partnerType.equals(other.partnerType)){
			return false;
		}
		if (partnersList == null) {
			if (other.partnersList != null){
				return false;
			}
		} else if (!partnersList.equals(other.partnersList)){
			return false;
		}
		if (productId == null) {
			if (other.productId != null){
				return false;
			}
		} else if (!productId.equals(other.productId)){
			return false;
		}
		if (productSalesChannelId == null) {
			if (other.productSalesChannelId != null){
				return false;
			}
		} else if (!productSalesChannelId.equals(other.productSalesChannelId)){
			return false;
		}
		if (status == null) {
			if (other.status != null){
				return false;
			}
		} else if (!status.equals(other.status)){
			return false;
		}
		return true;
	}
	
	

}