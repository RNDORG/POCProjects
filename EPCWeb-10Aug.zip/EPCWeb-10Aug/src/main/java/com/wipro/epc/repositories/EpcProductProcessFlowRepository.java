/**
 * 
 */
package com.wipro.epc.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductProcessFlow;


/**
 * @author Developer
 * @version 1.0
 * type EpcProductProcessFlowRepository
 */
public interface EpcProductProcessFlowRepository  extends CrudRepository <EpcProductProcessFlow, Integer>{
	
	//List<EpcProductProcessFlow> findByFromStatusAndToStatusAndStatus(Integer fromStatus, Integer toStatus, Integer status);
	/**
	 * @param fromStatus
	 * @param toStatus
	 * @param status
	 * @return
	 */
	@Query(value = "select * from epc_product_process_flow where from_status=:from_status"
			+ " and to_status=:to_status and status=:status", nativeQuery=true)
	EpcProductProcessFlow getProcessTransition(@Param("from_status") String fromStatus,@Param("to_status") String toStatus,@Param("status") String status);

}
