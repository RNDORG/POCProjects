package com.wipro.epc.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;


/**
 * @author Developer
 * @version 1.0
 * type QueryAvailabilitySearchInput
 */
public class QueryAvailabilitySearchInput {
	
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String productSubCategory;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String orderType;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String initiatingChannel;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String salesChannel;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String communityId;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String segment;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String segmentType;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String area;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String region;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String territory;
	/**
	 * List<String> QueryAvailabilitySearchInput.java
	 */
	private List<String> subFamily;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String productCategory;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	private String startDate;
	/**
	 * List<String> QueryAvailabilitySearchInput.java
	 */
	private List<String> classification;
	/**
	 * String QueryAvailabilitySearchInput.java
	 */
	private String clientRequestId;
	
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String customerRatePlanId;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String subscribedAddOnIds;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String slabId;
	
	private Boolean a2aCompatibilityFlag;
	private Boolean nonNetworkVASCompatibilityFlag;
	private Boolean roamingMigrationRuleFlag;
	
	private String excludeSubProducts;
	
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String otherProductId1;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String otherProductId2;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String otherProductId3;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String otherProductId4;
	/**
	 * @return
	 */
	public String getProductSubCategory() {
		return productSubCategory;
	}
	/**
	 * @param productSubCategory
	 */
	public void setProductSubCategory(String productSubCategory) {
		this.productSubCategory = productSubCategory;
	}
	/**
	 * @return
	 */
	public String getOrderType() {
		return orderType;
	}
	/**
	 * @param orderType
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	/**
	 * @return
	 */
	public String getInitiatingChannel() {
		return initiatingChannel;
	}
	/**
	 * @param initiatingChannel
	 */
	public void setInitiatingChannel(String initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}
	/**
	 * @return
	 */
	public String getSalesChannel() {
		return salesChannel;
	}
	/**
	 * @param salesChannel
	 */
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	/**
	 * @return
	 */
	public String getCommunityId() {
		return communityId;
	}
	/**
	 * @param communityId
	 */
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
	/**
	 * @return
	 */
	public String getSegment() {
		return segment;
	}
	/**
	 * @param segment
	 */
	public void setSegment(String segment) {
		this.segment = segment;
	}
	/**
	 * @return
	 */
	public String getSegmentType() {
		return segmentType;
	}
	/**
	 * @param segmentType
	 */
	public void setSegmentType(String segmentType) {
		this.segmentType = segmentType;
	}
	/**
	 * @return
	 */
	public String getArea() {
		return area;
	}
	/**
	 * @param area
	 */
	public void setArea(String area) {
		this.area = area;
	}
	/**
	 * @return
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return
	 */
	public String getTerritory() {
		return territory;
	}
	/**
	 * @param territory
	 */
	public void setTerritory(String territory) {
		this.territory = territory;
	}
	/**
	 * @return
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return
	 */
	public List<String> getClassification() {
		return classification;
	}
	/**
	 * @param classification
	 */
	public void setClassification(List<String> classification) {
		this.classification = classification;
	}
	/**
	 * @return
	 */
	public List<String> getSubFamily() {
		return subFamily;
	}
	/**
	 * @param subFamily
	 */
	public void setSubFamily(List<String> subFamily) {
		this.subFamily = subFamily;
	}
	/**
	 * @return
	 */
	public String getProductCategory() {
		return productCategory;
	}
	/**
	 * @param productCategory
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	/**
	 * 
	 * @return
	 */
	public String getClientRequestId() {
		return clientRequestId;
	}
	/**
	 * 
	 * @param clientRequestId
	 */
	public void setClientRequestId(String clientRequestId) {
		this.clientRequestId = clientRequestId;
	}
	
	/**
	 * @return the customerRatePlanId
	 */
	public String getCustomerRatePlanId() {
		return customerRatePlanId;
	}
	/**
	 * @param customerRatePlanId the customerRatePlanId to set
	 */
	public void setCustomerRatePlanId(String customerRatePlanId) {
		this.customerRatePlanId = customerRatePlanId;
	}
	/**
	 * @return the subscribedAddOnIds
	 */
	public String getSubscribedAddOnIds() {
		return subscribedAddOnIds;
	}
	/**
	 * @param subscribedAddOnIds the subscribedAddOnIds to set
	 */
	public void setSubscribedAddOnIds(String subscribedAddOnIds) {
		this.subscribedAddOnIds = subscribedAddOnIds;
	}
	/**
	 * @return the slabId
	 */
	public String getSlabId() {
		return slabId;
	}
	/**
	 * @param slabId the slabId to set
	 */
	public void setSlabId(String slabId) {
		this.slabId = slabId;
	}
	/**
	 * @return the a2aCompatibilityFlag
	 */
	public Boolean getA2aCompatibilityFlag() {
		return a2aCompatibilityFlag;
	}
	/**
	 * @param a2aCompatibilityFlag the a2aCompatibilityFlag to set
	 */
	public void setA2aCompatibilityFlag(Boolean a2aCompatibilityFlag) {
		this.a2aCompatibilityFlag = a2aCompatibilityFlag;
	}
	/**
	 * @return the nonNetworkVASCompatibilityFlag
	 */
	public Boolean getNonNetworkVASCompatibilityFlag() {
		return nonNetworkVASCompatibilityFlag;
	}
	/**
	 * @param nonNetworkVASCompatibilityFlag the nonNetworkVASCompatibilityFlag to set
	 */
	public void setNonNetworkVASCompatibilityFlag(
			Boolean nonNetworkVASCompatibilityFlag) {
		this.nonNetworkVASCompatibilityFlag = nonNetworkVASCompatibilityFlag;
	}
	/**
	 * @return the roamingMigrationRuleFlag
	 */
	public Boolean getRoamingMigrationRuleFlag() {
		return roamingMigrationRuleFlag;
	}
	/**
	 * @param roamingMigrationRuleFlag the roamingMigrationRuleFlag to set
	 */
	public void setRoamingMigrationRuleFlag(Boolean roamingMigrationRuleFlag) {
		this.roamingMigrationRuleFlag = roamingMigrationRuleFlag;
	}
	/**
	 * @return the excludeSubProducts
	 */
	public String getExcludeSubProducts() {
		return excludeSubProducts;
	}
	/**
	 * @param excludeSubProducts the excludeSubProducts to set
	 */
	public void setExcludeSubProducts(String excludeSubProducts) {
		this.excludeSubProducts = excludeSubProducts;
	}
	/**
	 * @return the otherProductId1
	 */
	public String getOtherProductId1() {
		return otherProductId1;
	}
	/**
	 * @param otherProductId1 the otherProductId1 to set
	 */
	public void setOtherProductId1(String otherProductId1) {
		this.otherProductId1 = otherProductId1;
	}
	/**
	 * @return the otherProductId2
	 */
	public String getOtherProductId2() {
		return otherProductId2;
	}
	/**
	 * @param otherProductId2 the otherProductId2 to set
	 */
	public void setOtherProductId2(String otherProductId2) {
		this.otherProductId2 = otherProductId2;
	}
	/**
	 * @return the otherProductId3
	 */
	public String getOtherProductId3() {
		return otherProductId3;
	}
	/**
	 * @param otherProductId3 the otherProductId3 to set
	 */
	public void setOtherProductId3(String otherProductId3) {
		this.otherProductId3 = otherProductId3;
	}
	/**
	 * @return the otherProductId4
	 */
	public String getOtherProductId4() {
		return otherProductId4;
	}
	/**
	 * @param otherProductId4 the otherProductId4 to set
	 */
	public void setOtherProductId4(String otherProductId4) {
		this.otherProductId4 = otherProductId4;
	}
}
