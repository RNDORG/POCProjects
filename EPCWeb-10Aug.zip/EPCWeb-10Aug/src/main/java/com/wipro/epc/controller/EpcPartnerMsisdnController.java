package com.wipro.epc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.repositories.EpcPartnerMsisdnRepository;


/**
 * @author Developer
 * @version 1.0
 * type EpcPartnerMsisdnController
 */
@RestController
public class EpcPartnerMsisdnController {

	/**
	 * EpcPartnerMsisdnRepository EpcPartnerMsisdnController.java
	 */
	@Autowired
	EpcPartnerMsisdnRepository partnerRepository;
	
	
	/**
	 * @param partnerMsisdn
	 * @return
	 */
	@RequestMapping(value="rest/extapi/v1/partner_msisdn",method=RequestMethod.GET)
	public boolean updateProductExt(@RequestParam(value="partner_msisdn")String partnerMsisdn)
	{
	
		if(partnerRepository.getListOfPartnerMsisdn(partnerMsisdn).size()>0){
			return true;
		}
		else return false;
	}
}
