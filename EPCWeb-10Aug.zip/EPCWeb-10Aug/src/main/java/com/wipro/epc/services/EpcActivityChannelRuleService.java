package com.wipro.epc.services;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcActivityChannelRule;
import com.wipro.epc.domain.EpcActivityCharge;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcActivityChannelRuleRepository;
import com.wipro.epc.repositories.EpcActivityChargeRepository;

/**
 * @version 1.0
 * @author VI251443
 *
 */
@Service
public class EpcActivityChannelRuleService {
	
private static Logger logger = LoggerFactory.getLogger(EpcActivityChannelRuleService.class);
	
	@Autowired
	EpcActivityChannelRuleRepository epcActivityChannelRuleRepository;
	
	@Autowired
	EpcActivityChargeRepository epcActivityChargeRepository;
	
	@Autowired
	EpcNotificationTemplateService epcNotificationTemplateService;
	
    /**
     * 
     * @param allRequestParams
     * @return List<EpcActivityChannelRule>
     */
	public List<EpcActivityChannelRule> searchEpcActivityChannelRule(
			Map<String, List<String>> allRequestParams) {
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,EpcActivityChannelRule.class.getName(), null);
		List<EpcActivityChannelRule> listOfActivityReturned = null;
		try {
			listOfActivityReturned = epcActivityChannelRuleRepository.getSearchResult(queryBuilder.toString());
			if(listOfActivityReturned != null){
				for (EpcActivityChannelRule epcActivityChannelRule :listOfActivityReturned){
					epcActivityChannelRule.setEpcActivityCharge(epcActivityChargeRepository.findActivityChargeByactivityChannelRuleId(epcActivityChannelRule.getActivityChannelRuleId()));
				}
			}
			
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}

		//Code added for Notification template value ------ 
				for(EpcActivityChannelRule activity : listOfActivityReturned){
					activity.setEpcNotificationTemplate(epcNotificationTemplateService.getLookupValue(activity.getNotificationTemplateId()));
				}
				
		return listOfActivityReturned;
	}
	
	/**
	 * 
	 * @param orderList
	 * @param createdBy
	 * @return List<EpcActivityChannelRule>
	 */
	@Transactional
	public List<EpcActivityChannelRule> manageActivity(List<EpcActivityChannelRule> orderList,String createdBy)
			{
				///List<EpcActivityChannelRule> retListOfEpcActivityChannelRule=new ArrayList<EpcActivityChannelRule>();
				
				for(EpcActivityChannelRule order:orderList)
				{
					manageactivity(order,createdBy);
					
					if((order.getMetaInfo().get("STATUS")==null))
					{
						order.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
					}
				//retListOfEpcActivityChannelRule.add(order);
			}
		     	return orderList;
			}
	/**
	 * 
	 * @param order
	 * @param createdBy
	 * @return
	 */
	EpcActivityChannelRule manageactivity(EpcActivityChannelRule order,
			String createdBy)
			{
		EpcActivityChannelRule retOrder=null;
			
			switch(order.getMetaInfo().get("OPERATION"))
			{
			case "CREATE":retOrder = createActivity(order, createdBy);
						  break;
			case "UPDATE":retOrder = modifyActivity(order, createdBy);
						  break;
			case "DELETE":retOrder = deleteActivity(order);
						  break;
			default:
				throw new EPCException("not supported");
			}
			return retOrder;
			}
	/**
	 * 
	 * @param order
	 * @return
	 */
		EpcActivityChannelRule deleteActivity(EpcActivityChannelRule order) {
			epcActivityChannelRuleRepository.delete(order.getActivityChannelRuleId());
			
			logger.debug("epcActivityCharge .....:"+order.getActivityChannelRuleId());
			epcActivityChargeRepository.deleteActivityFromChannel(order.getActivityChannelRuleId());
	        
			return order;
		}
		
		/**
		 * 
		 * @param order
		 * @param modifiedBy
		 * @return
		 */
		EpcActivityChannelRule modifyActivity(EpcActivityChannelRule order, String modifiedBy) {
			order.setModifiedBy(modifiedBy);
			order.setModifiedDate(new Date());
		
			EpcActivityCharge epcActivityCharge = order.getEpcActivityCharge();
			//System.out.println(epcActivityCharge.getOccCode());
			epcActivityCharge.setModifiedBy(modifiedBy);
			epcActivityCharge.setModifiedDate(new Date());
			epcActivityCharge.setActivityChannelRuleId(order.getActivityChannelRuleId());
			epcActivityChargeRepository.modifyOrder(epcActivityCharge);
			 
			return epcActivityChannelRuleRepository.modifyActivity(order);
	    }
		
        /**
         * 
         * @param order
         * @param createdBy
         * @return
         */
		EpcActivityChannelRule createActivity(EpcActivityChannelRule order, String createdBy) {
			order.setCreatedBy(createdBy);
			order.setCreatedDate(new Date());
			EpcActivityChannelRule activityId = epcActivityChannelRuleRepository.save(order);

           EpcActivityCharge epcActivityCharge = order.getEpcActivityCharge();
           
           //System.out.println(epcActivityCharge.getOccCode());

           epcActivityCharge.setActivityChannelRuleId(activityId.getActivityChannelRuleId());
           epcActivityCharge.setCreatedBy(createdBy);
           epcActivityCharge.setCreatedDate(new Date());
           epcActivityCharge.setStatus(order.getStatus());
           
           epcActivityChargeRepository.save(epcActivityCharge);


									
		return order;
	}

}
