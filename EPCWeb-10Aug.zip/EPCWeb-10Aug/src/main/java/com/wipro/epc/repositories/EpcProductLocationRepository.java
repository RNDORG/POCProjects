package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductLocation;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductLocationRepository
 */
public interface EpcProductLocationRepository extends CrudRepository<EpcProductLocation, Integer> ,
EpcProductLocationRepositoryCustom{
	
	/**
	 * @param productId
	 * @return
	 */
	@Query(value="select * from epc_product_location where product_id=:productId", nativeQuery = true)
	List<EpcProductLocation> findLocationsByProductId(@Param("productId") Integer productId);
	
	/**
	 * @param productId
	 */
	@Modifying
	@Query(value="delete from epc_product_location where product_id=:productId", nativeQuery=true)
	void deleteProductFromLocation(@Param("productId") Integer productId);
}
