/**
 * 
 */
package com.wipro.epc.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Component;


/**
 * @author KE334465
 *
 */
@Component
public class SimpleDateConvertion {

	/**
	 * @param date
	 * @param Pattern
	 * @return
	 */
	public String getDateInFormat(Date date, String Pattern){
		
		DateFormat sdf = new SimpleDateFormat(Pattern);
		return sdf.format(date);
	}
}
