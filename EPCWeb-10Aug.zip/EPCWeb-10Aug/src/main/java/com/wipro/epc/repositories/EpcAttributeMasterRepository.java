package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcAttributeMaster;

/**
 * @author Developer
 * @version 1.0
 * type EpcAttributeMasterRepository
 */
@Repository
public interface EpcAttributeMasterRepository extends CrudRepository<EpcAttributeMaster, Integer>, EpcAttributeMasterRepositoryCustom {
	
	/**
	 * @param attributeName
	 * @return
	 */
	List<EpcAttributeMaster> findByAttributeName(String attributeName);
	
	/**
	 * @param attributeId
	 * @return
	 */
	EpcAttributeMaster findByAttributeId(Integer attributeId);
	
}
 