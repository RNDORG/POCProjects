
package com.wipro.epc.esb.queryvasservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Current_SubscriptionsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Current_SubscriptionsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Subscription_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Offer_Id" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MarketingName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CircleID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfferProvider" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Price" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Subscription_Start_Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Renewal_Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Subscription_End_Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Channel_Type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Subscription_Charge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Renewal_Charge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Subscription_Charge_Applied" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Renewal_Charge_Applied" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="last_charge_amount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="next_billing_date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="next_charging_date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="activated_by" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="last_transaction_type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CPID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CPNAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="subscription_class" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Current_SubscriptionsType", propOrder = {
    "subscriptionID",
    "offerId",
    "marketingName",
    "circleID",
    "offerProvider",
    "price",
    "subscriptionStartDate",
    "renewalDate",
    "subscriptionEndDate",
    "channelType",
    "subscriptionCharge",
    "renewalCharge",
    "subscriptionChargeApplied",
    "renewalChargeApplied",
    "endDate",
    "lastChargeAmount",
    "status",
    "nextBillingDate",
    "nextChargingDate",
    "activatedBy",
    "lastTransactionType",
    "cpid",
    "cpname",
    "subscriptionClass"
})
public class CurrentSubscriptionsType {

    @XmlElement(name = "Subscription_ID")
    protected String subscriptionID;
    @XmlElement(name = "Offer_Id", required = true)
    protected String offerId;
    @XmlElement(name = "MarketingName", required = true)
    protected String marketingName;
    @XmlElement(name = "CircleID")
    protected String circleID;
    @XmlElement(name = "OfferProvider", required = true)
    protected String offerProvider;
    @XmlElement(name = "Price")
    protected String price;
    @XmlElement(name = "Subscription_Start_Date")
    protected String subscriptionStartDate;
    @XmlElement(name = "Renewal_Date")
    protected String renewalDate;
    @XmlElement(name = "Subscription_End_Date")
    protected String subscriptionEndDate;
    @XmlElement(name = "Channel_Type")
    protected String channelType;
    @XmlElement(name = "Subscription_Charge")
    protected String subscriptionCharge;
    @XmlElement(name = "Renewal_Charge")
    protected String renewalCharge;
    @XmlElement(name = "Subscription_Charge_Applied")
    protected String subscriptionChargeApplied;
    @XmlElement(name = "Renewal_Charge_Applied")
    protected String renewalChargeApplied;
    @XmlElement(name = "EndDate")
    protected String endDate;
    @XmlElement(name = "last_charge_amount")
    protected String lastChargeAmount;
    protected String status;
    @XmlElement(name = "next_billing_date")
    protected String nextBillingDate;
    @XmlElement(name = "next_charging_date")
    protected String nextChargingDate;
    @XmlElement(name = "activated_by")
    protected String activatedBy;
    @XmlElement(name = "last_transaction_type")
    protected String lastTransactionType;
    @XmlElement(name = "CPID")
    protected String cpid;
    @XmlElement(name = "CPNAME")
    protected String cpname;
    @XmlElement(name = "subscription_class")
    protected String subscriptionClass;

    /**
     * Gets the value of the subscriptionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionID() {
        return subscriptionID;
    }

    /**
     * Sets the value of the subscriptionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionID(String value) {
        this.subscriptionID = value;
    }

    /**
     * Gets the value of the offerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferId() {
        return offerId;
    }

    /**
     * Sets the value of the offerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferId(String value) {
        this.offerId = value;
    }

    /**
     * Gets the value of the marketingName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarketingName() {
        return marketingName;
    }

    /**
     * Sets the value of the marketingName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarketingName(String value) {
        this.marketingName = value;
    }

    /**
     * Gets the value of the circleID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCircleID() {
        return circleID;
    }

    /**
     * Sets the value of the circleID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCircleID(String value) {
        this.circleID = value;
    }

    /**
     * Gets the value of the offerProvider property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferProvider() {
        return offerProvider;
    }

    /**
     * Sets the value of the offerProvider property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferProvider(String value) {
        this.offerProvider = value;
    }

    /**
     * Gets the value of the price property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrice(String value) {
        this.price = value;
    }

    /**
     * Gets the value of the subscriptionStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionStartDate() {
        return subscriptionStartDate;
    }

    /**
     * Sets the value of the subscriptionStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionStartDate(String value) {
        this.subscriptionStartDate = value;
    }

    /**
     * Gets the value of the renewalDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRenewalDate() {
        return renewalDate;
    }

    /**
     * Sets the value of the renewalDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRenewalDate(String value) {
        this.renewalDate = value;
    }

    /**
     * Gets the value of the subscriptionEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionEndDate() {
        return subscriptionEndDate;
    }

    /**
     * Sets the value of the subscriptionEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionEndDate(String value) {
        this.subscriptionEndDate = value;
    }

    /**
     * Gets the value of the channelType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelType() {
        return channelType;
    }

    /**
     * Sets the value of the channelType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelType(String value) {
        this.channelType = value;
    }

    /**
     * Gets the value of the subscriptionCharge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionCharge() {
        return subscriptionCharge;
    }

    /**
     * Sets the value of the subscriptionCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionCharge(String value) {
        this.subscriptionCharge = value;
    }

    /**
     * Gets the value of the renewalCharge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRenewalCharge() {
        return renewalCharge;
    }

    /**
     * Sets the value of the renewalCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRenewalCharge(String value) {
        this.renewalCharge = value;
    }

    /**
     * Gets the value of the subscriptionChargeApplied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionChargeApplied() {
        return subscriptionChargeApplied;
    }

    /**
     * Sets the value of the subscriptionChargeApplied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionChargeApplied(String value) {
        this.subscriptionChargeApplied = value;
    }

    /**
     * Gets the value of the renewalChargeApplied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRenewalChargeApplied() {
        return renewalChargeApplied;
    }

    /**
     * Sets the value of the renewalChargeApplied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRenewalChargeApplied(String value) {
        this.renewalChargeApplied = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDate(String value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the lastChargeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastChargeAmount() {
        return lastChargeAmount;
    }

    /**
     * Sets the value of the lastChargeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastChargeAmount(String value) {
        this.lastChargeAmount = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the nextBillingDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextBillingDate() {
        return nextBillingDate;
    }

    /**
     * Sets the value of the nextBillingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextBillingDate(String value) {
        this.nextBillingDate = value;
    }

    /**
     * Gets the value of the nextChargingDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextChargingDate() {
        return nextChargingDate;
    }

    /**
     * Sets the value of the nextChargingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextChargingDate(String value) {
        this.nextChargingDate = value;
    }

    /**
     * Gets the value of the activatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActivatedBy() {
        return activatedBy;
    }

    /**
     * Sets the value of the activatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActivatedBy(String value) {
        this.activatedBy = value;
    }

    /**
     * Gets the value of the lastTransactionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastTransactionType() {
        return lastTransactionType;
    }

    /**
     * Sets the value of the lastTransactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastTransactionType(String value) {
        this.lastTransactionType = value;
    }

    /**
     * Gets the value of the cpid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPID() {
        return cpid;
    }

    /**
     * Sets the value of the cpid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPID(String value) {
        this.cpid = value;
    }

    /**
     * Gets the value of the cpname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPNAME() {
        return cpname;
    }

    /**
     * Sets the value of the cpname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPNAME(String value) {
        this.cpname = value;
    }

    /**
     * Gets the value of the subscriptionClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionClass() {
        return subscriptionClass;
    }

    /**
     * Sets the value of the subscriptionClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionClass(String value) {
        this.subscriptionClass = value;
    }

}
