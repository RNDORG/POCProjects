package com.wipro.epc.services;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcOrderCharge;
import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcOrderChannelRuleRepository;
import com.wipro.epc.repositories.EpcOrderChargeRepository;
import com.wipro.epc.repositories.EpcProductDecompositionRepository;

/**
 * This is the service class for EpcOrderChannelRule 
 * We can search and modify the data which is there in DB.
 * @author VI251443
 * @version 1.0
 */
@Service
public class EpcOrderChannelRuleService {
	
	private static Logger logger = LoggerFactory.getLogger(EpcOrderChannelRuleService.class);
	
	@Autowired
	EpcOrderChannelRuleRepository epcOrderChannelRuleRepository;
	
	@Autowired
	EpcOrderChargeRepository epcOrderChargeRepository;
	
	@Autowired
	EpcProductDecompositionRepository epcOrderDecompositionRepository;
	
	@Autowired
	EntityManager em;
	
	@Autowired
	EpcNotificationTemplateService epcNotificationTemplateService;
	
	/**
	 * This searches the data in DB and returns the list
	 * @param allRequestParams
	 * @return List<EpcOrderChannelRule>
	 */
	public List<EpcOrderChannelRule> searchEpcOrderChannelRule(
			Map<String, List<String>> allRequestParams) {

		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcOrderChannelRule.class.getName(), null);
		List<EpcOrderChannelRule> listOfOrdersReturned = null;
		try {
			listOfOrdersReturned = epcOrderChannelRuleRepository
					.getList(queryBuilder.toString());
			
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}

		return listOfOrdersReturned;
	}
	
	/**
	 * This searches the data in DB and returns the list
	 * @param allRequestParams
	 * @return List<EpcOrderChannelRule>
	 */
	public List<EpcOrderChannelRule> searchEpcOrderChannelRuleInt(
			Map<String, List<String>> allRequestParams) {
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcOrderChannelRule.class.getName(), null);
		//System.out.println("");
		List<EpcOrderChannelRule> listOfOrdersReturned = null;
		try {
			listOfOrdersReturned = epcOrderChannelRuleRepository
					.getList(queryBuilder.toString());
			if(listOfOrdersReturned != null){
				for (EpcOrderChannelRule epcOrderChannelRule :listOfOrdersReturned){
					epcOrderChannelRule.setEpcOrderCharge(epcOrderChargeRepository.findOrderChargeByOrderChannelRuleId(epcOrderChannelRule.getOrderChannelRuleId()));
				}
			}
			
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		//Code added for Notification template value ------ 
		for(EpcOrderChannelRule order : listOfOrdersReturned){
			order.setEpcNotificationTemplate(epcNotificationTemplateService.getLookupValue(order.getNotificationTemplateId()));
		}
		
		return listOfOrdersReturned;
		
	}
	
	/**
	 * This modifies the already exists data in DB 
	 * @param orderList
	 * @param txn
	 * @param mix_op
	 * @param createdBy
	 * @return List<EpcOrderChannelRule>
	 */
	@Transactional
	public List<EpcOrderChannelRule> manageOrders(List<EpcOrderChannelRule> orderList,
			boolean txn,boolean mix_op, String createdBy)
			{
				//List<EpcOrderChannelRule> retListOfEpcOrderChannelRule=new ArrayList<EpcOrderChannelRule>();
				
				for(EpcOrderChannelRule order:orderList)
				{
					manageorder(order,createdBy);
					if((order.getMetaInfo().get("STATUS")==null))
					{
						order.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
					}
				//retListOfEpcOrderChannelRule.add(order);
			}
		     	return orderList;
			}
	/**
	 * This modifies the existing data in DB
	 * @param order
	 * @param createdBy
	 * @return
	 */
	EpcOrderChannelRule manageorder(EpcOrderChannelRule order,
			String createdBy) 
			{
			EpcOrderChannelRule retOrder=null;
			
			switch(order.getMetaInfo().get("OPERATION"))
			{
			case "CREATE":retOrder = createOrders(order, createdBy);
						  break;
			case "UPDATE":retOrder = modifyOrders(order, createdBy);
						  break;
			case "DELETE":retOrder = deleteOrders(order);
						  break;
			default:
				throw new EPCException("not supported");
			}
			return retOrder;
			}
	/**
	 * This deletes the data from DB
	 * @param order
	 * @return
	 */
	  EpcOrderChannelRule deleteOrders(EpcOrderChannelRule order){
		String query = "select * from epc_product_decomposition where order_type= '"+order.getOrderType()+"' ";
		logger.info("subfamily is "+order.getProductSubFamily());
		logger.info("classification is "+order.getProductClassification());
		if(order.getProductSubFamily()!=null){
				query = query +  " and product_sub_family = '"+order.getProductSubFamily()+"'";
		}
		if(order.getProductClassification()!=null) {
			query = query + " and product_classification = '"+order.getProductClassification()+"'";
		}
		
		List<EpcProductDecomposition> decomposition = em.createNativeQuery(query,EpcProductDecomposition.class).getResultList();
		//logger.info("query is "+query);
		logger.info("list is "+decomposition);
		
		
		
		if(!decomposition.isEmpty()) {
			throw new EPCException("Please Delete correspoding Decomposition rule records");
		} else {
			epcOrderChannelRuleRepository.delete(order.getOrderChannelRuleId());
		}
			
		
			
        
		logger.debug("epcOrderCharge .....:"+order.getOrderChannelRuleId());
		epcOrderChargeRepository.deleteOrderFromChannel(order.getOrderChannelRuleId());
	
		return order;
	}
		/**
		 * Modifies the data from  DB
		 * @param order
		 * @param modifiedBy
		 * @return
		 */
		EpcOrderChannelRule modifyOrders(EpcOrderChannelRule order, String modifiedBy) {
			order.setModifiedBy(modifiedBy);
			order.setModifiedDate(new Date());
			
			EpcOrderCharge epcOrderCharge = order.getEpcOrderCharge();
			 epcOrderCharge.setOrderChannelRuleId(order.getOrderChannelRuleId());
			 if(epcOrderChargeRepository.findOrderChargeByOrderChannelRule(order.getOrderChannelRuleId()).isEmpty())
			 {
				 epcOrderCharge.setCreatedBy("admin");
				 epcOrderCharge.setCreatedDate( new Date() );
				 epcOrderCharge.setStatus(order.getStatus());
				 epcOrderChargeRepository.save(epcOrderCharge);
				
				 
			 }
			 else
			 {
			 epcOrderCharge.setModifiedBy(modifiedBy);
				epcOrderCharge.setModifiedDate(new Date());
			epcOrderChargeRepository.modifyOrder(epcOrderCharge);
			 }
			
		return epcOrderChannelRuleRepository.modifyOrder(order);
	    }
        /**
         * This creates the new data in to the DB
         * @param order
         * @param createdBy
         * @return
         */
		EpcOrderChannelRule createOrders(EpcOrderChannelRule order, String createdBy) {
			order.setCreatedBy(createdBy);
			order.setCreatedDate(new Date());


			EpcOrderChannelRule orderId = epcOrderChannelRuleRepository.save(order);

			// EpcOrderChannelRule  o = epcOrderChannelRuleRepository.save(order);
			 

            EpcOrderCharge epcOrderCharge = order.getEpcOrderCharge();
            //System.out.println(epcOrderCharge.getOccCode());

          
            epcOrderCharge.setOrderChannelRuleId(orderId.getOrderChannelRuleId());
            epcOrderCharge.setCreatedBy(createdBy);
            epcOrderCharge.setCreatedDate(new Date());
            epcOrderCharge.setStatus(order.getStatus());

           // epcOrderCharge.setOrderChannelRuleId(o.getOrderChannelRuleId());

			epcOrderChargeRepository.save(epcOrderCharge);


									
		return order;
	}
		/**
		 * searchEpcActivityChargeByChannelRuleId
		 * @param allRequestParams
		 * @return List<EpcOrderCharge>
		 */
		public List<EpcOrderCharge> searchEpcActivityChargeByChannelRuleId(
				Map<String, List<String>> allRequestParams) {

			String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
					EpcOrderCharge.class.getName(), null);
			List<EpcOrderCharge> listOfOrdersReturned = null;
			try {
				listOfOrdersReturned = epcOrderChargeRepository
						.getList(queryBuilder.toString());
				
			} catch (Exception e) {
				throw new EPCException(
						"Error occurred while fetching results from database.\n"
								+ " Query: " + queryBuilder.toString() + "\n"
								+ " Exception: " + e.getMessage(), e);
			}

			return listOfOrdersReturned;
		}
		
		
		/**
		 * getOrderChannelRulesByWhereClause
		 * @param queryBuilder
		 * @return List<EpcOrderChannelRule>
		 */
		public List<EpcOrderChannelRule> getOrderChannelRulesByWhereClause(String queryBuilder){
			queryBuilder = "select * from epc_order_channel_rule "+queryBuilder;
			//logger.info("#Query :"+queryBuilder);
			List<EpcOrderChannelRule> list = null;
			try {
				list = epcOrderChannelRuleRepository.getList(queryBuilder);
			} catch (Exception e) {
				throw new EPCException(
						"Error occurred while fetching results from database.\n"
								+ " Query: " + queryBuilder.toString() + "\n"
								+ " Exception: " + e.getMessage(), e);
			}
			
			return list;
		}

		/**
		 * This searches the data from DB and returns the list
		 * @param allRequestParams
		 * @return List<EpcOrderChannelRule>
		 */
		public List<EpcOrderChannelRule> searchEpcOrderChannelRuleValidation(
				Map<String, List<String>> allRequestParams) {
			String query = "select * from epc_order_channel_rule where order_type = '"+allRequestParams.get("order_type").get(0)+"'";
			
			
			if(allRequestParams.get("product_sub_family")!=null) {
				if(allRequestParams.get("product_sub_family").size()>0 ) {
					if(!allRequestParams.get("product_sub_family").get(0).equals("null") && !allRequestParams.get("product_sub_family").get(0).equals("")){
						query = query + " and product_sub_family = '"+allRequestParams.get("product_sub_family").get(0)+"'";
					}
					else {
						query = query + " and product_sub_family IS NULL";
					}
				}
				else {
					query = query + " and product_sub_family IS NULL";
				}
			}
			else {
				query = query + " and product_sub_family IS NULL";
			}
			
			if(allRequestParams.get("product_classification")!=null) {
				if(allRequestParams.get("product_classification").size()>0) {
					if(!allRequestParams.get("product_classification").get(0).equals("null") && !allRequestParams.get("product_classification").get(0).equals("")){
						query = query + " and product_classification = '"+allRequestParams.get("product_classification").get(0)+"'";
					}
					else {
						query = query + " and product_classification IS NULL";
					}
				}
				else {
					query = query + " and product_classification IS NULL";
				}
			}
			else {
				query = query + " and product_classification IS NULL";
			}
			//logger.info("The query generated is "+query);
			List<EpcOrderChannelRule> list = null;
			try {
				list = epcOrderChannelRuleRepository.getList(query);
			} catch (Exception e) {
				throw new EPCException(
						"Error occurred while fetching results from database.\n"
								+ " Query: " + query.toString() + "\n"
								+ " Exception: " + e.getMessage(), e);
			}
			
			return list;
		}

}
