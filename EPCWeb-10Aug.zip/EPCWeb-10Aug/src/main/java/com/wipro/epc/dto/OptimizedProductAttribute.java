package com.wipro.epc.dto;


import java.io.Serializable;

public class OptimizedProductAttribute  implements Serializable {

	private String attributeValue1;

	private String attributeValue2;

	private String defaultValue1;

	private String defaultValue2;

	private String attributeName;

	/**
	 * @return the attributeValue1
	 */
	public String getAttributeValue1() {
		return attributeValue1;
	}

	/**
	 * @param attributeValue1 the attributeValue1 to set
	 */
	public void setAttributeValue1(String attributeValue1) {
		this.attributeValue1 = attributeValue1;
	}

	/**
	 * @return the attributeValue2
	 */
	public String getAttributeValue2() {
		return attributeValue2;
	}

	/**
	 * @param attributeValue2 the attributeValue2 to set
	 */
	public void setAttributeValue2(String attributeValue2) {
		this.attributeValue2 = attributeValue2;
	}

	/**
	 * @return the defaultValue1
	 */
	public String getDefaultValue1() {
		return defaultValue1;
	}

	/**
	 * @param defaultValue1 the defaultValue1 to set
	 */
	public void setDefaultValue1(String defaultValue1) {
		this.defaultValue1 = defaultValue1;
	}

	/**
	 * @return the defaultValue2
	 */
	public String getDefaultValue2() {
		return defaultValue2;
	}

	/**
	 * @param defaultValue2 the defaultValue2 to set
	 */
	public void setDefaultValue2(String defaultValue2) {
		this.defaultValue2 = defaultValue2;
	}

	/**
	 * @return the attributeName
	 */
	public String getAttributeName() {
		return attributeName;
	}

	/**
	 * @param attributeName the attributeName to set
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	
	
}