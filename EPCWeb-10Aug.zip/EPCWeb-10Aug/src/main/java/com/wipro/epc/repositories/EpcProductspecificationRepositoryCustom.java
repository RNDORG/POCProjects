package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductSpecification;


/**
 * @author KE334465
 *
 */
public interface EpcProductspecificationRepositoryCustom {
	
	/**
	 * @param product
	 * @return
	 */
	EpcProductSpecification modifyProductSpec(EpcProductSpecification product);
	
	/**
	 * @param product
	 * @return
	 */
	EpcProductSpecification modifyProductAvail(EpcProductSpecification product);

	/**
	 * @param query
	 * @return
	 */
	List<EpcProductSpecification> getList(String query);

	/**
	 * @param communityName
	 * @return
	 */
	List<String> getMarketingNamesForCommunityNames(String communityName);
	
	/**
	 * @param targetProductId
	 * @param filterCriteria_targetProdCategory
	 * @param filterCriteria_targetProdSubCategory
	 * @param filterCriteria_targetCommuId
	 * @return
	 */
	List<String> needsToBeFilteredForMigration ( List<String> targetProductId,  
			String filterCriteria_targetProdSubCategory, String filterCriteria_targetCommuId);

	List<Object[]> getListOfObjects(String query);
	
	public String getProcedureForPTtest(String name,String msgType) ;
}
