package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.domain.EpcActivityDetail;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.uam.definitions.MetaInfo;
import com.wipro.epc.util.Constants;
/**
 * @author Developer
 * @version 1.0
 * type EpcActivityDetailsService
 */
@Service
public class EpcActivityDetailsService {
	
	private static Logger logger = LoggerFactory.getLogger(EpcActivityDetailsService.class);
	/**
	 * com.wipro.epc.repositories.EpcActivityDetailRepository EpcActivityDetailsService.java
	 */
	@Autowired
	com.wipro.epc.repositories.EpcActivityDetailRepository epcActivityDetailRepository;
	
	
	
	/**
	 * @param activityDetailsList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcActivityDetail> manageActivitiesDetail(List<EpcActivityDetail> activityDetailsList,
			String createdBy)
			{
			logger.info("Activity Details list sent is "+activityDetailsList);
				List<EpcActivityDetail> retListOfActivities=new ArrayList<EpcActivityDetail>();
				
				for(EpcActivityDetail epcActivityDetail:activityDetailsList)
				{
					if(epcActivityDetail!=null)
					{
						epcActivityDetail=manageActivity(epcActivityDetail,createdBy);
						if((epcActivityDetail.getMetaInfo().get("STATUS")==null))
						{
							epcActivityDetail.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
						}
					}
						retListOfActivities.add(epcActivityDetail);
			}
		     	return retListOfActivities;
			}
	
	/**
	 * @param productActivity
	 * @param createdBy
	 * @return
	 */
	EpcActivityDetail manageActivity(EpcActivityDetail productActivity,
			String createdBy)
			{
		EpcActivityDetail retActivity=null;
			productActivity.setStatus(Constants.COMMON_STATUS_ACTIVE);
			//System.out.println("---------------------------------------------------------------------------------------------------------");
			//System.out.println(productActivity.getMetaInfo());
			switch(productActivity.getMetaInfo().get("OPERATION"))
			{
			case "CREATE":logger.info("indside create" + productActivity.getActivityId());
			retActivity = createActivity(productActivity, createdBy);
						  break;
			case "UPDATE":retActivity = modifyActivity(productActivity);
						  break;
			case "DELETE":retActivity = deleteActivity(productActivity);
						  break;
			default:
				throw new EPCException("not supported");
			}
			return retActivity;
			}
	
	

		/**
		 * @param productActivity
		 * @return
		 */
		private EpcActivityDetail modifyActivity(EpcActivityDetail productActivity) {
			//System.out.println("---------------------------------------------------------------------------------------------------------");
			//logger.info(productActivity.toString());
			 epcActivityDetailRepository.updateDetail(
					productActivity.getActivityDetailId(), productActivity.getActivityKey(), productActivity.getActivityValue());
			 return productActivity;
	}

		/**
		 * @param activityDetail
		 * @return
		 */
		private EpcActivityDetail deleteActivity(
				EpcActivityDetail activityDetail) {
			epcActivityDetailRepository.delete(activityDetail.getActivityDetailId());
		
		return activityDetail;
		}


		/**
		 * @param activityDetail
		 * @param createdBy
		 * @return
		 */
		EpcActivityDetail createActivity(EpcActivityDetail activityDetail, String createdBy) {
			activityDetail.setCreatedBy(createdBy);
			activityDetail.setCreatedDate(new Date());
			epcActivityDetailRepository.save(activityDetail);
			return activityDetail;
	}
}
