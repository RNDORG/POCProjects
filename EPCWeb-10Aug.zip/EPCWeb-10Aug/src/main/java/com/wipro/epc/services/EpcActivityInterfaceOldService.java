package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcActivityChannelRule;
import com.wipro.epc.domain.EpcActivityMaster;
import com.wipro.epc.domain.EpcNotificationTemplate;
import com.wipro.epc.domain.EpcNotificationTemplateDetail;
import com.wipro.epc.dto.ActivitySearchInput;
import com.wipro.epc.dto.ActivitySearchOutputOld;
import com.wipro.epc.repositories.EpcActivityChannelRuleRepository;
import com.wipro.epc.repositories.EpcNotificationTemplateDetailRepository;
import com.wipro.epc.repositories.EpcNotificationTemplateRepository;

@Service
public class EpcActivityInterfaceOldService {
	
	private static Logger logger = LoggerFactory.getLogger(EpcActivityInterfaceOldService.class);

	@Autowired
	com.wipro.epc.repositories.EpcActivityMasterRepository epcActivityMasterRepository;
	
	@Autowired
	com.wipro.epc.services.EpcActivityDetailsService epcActivityDetailService;

	@Autowired
	com.wipro.epc.repositories.EpcActivityDetailRepository epcActivityDetailRepository;
	
	@Autowired
	EpcActivityChannelRuleRepository epcActivityChannelRuleRepository;
	
	@Autowired
	EpcNotificationTemplateRepository epcNotificationTemplateRepository;
	
	@Autowired
	EpcNotificationTemplateDetailRepository epcNotificationTemplateDetailRepository;
	
	List<EpcActivityMaster> epcActivityMasterCache;
	
	@PersistenceContext
	EntityManager em;
	
	public ActivitySearchOutputOld updateActivityExt(
			ActivitySearchInput searchInput, Map<String, List<String>> allRequestParams) {
		if(StringUtils.isBlank(searchInput.getActivityName())  ){
				throw new GenericException("InvalidSearch", "Mandatory Fields are missing. "
						+ "Please provide all mandatory fields (acivityName)", "Mandatory Fields are missing.");
			}
		String activityName=searchInput.getActivityName();
		
		ActivitySearchOutputOld activityResponse=searchActivitiesExt(activityName,searchInput.getActivityKey(),searchInput.getActivityValue());
		List<String> with = allRequestParams.get("with");
		
		if(with == null){
			with = new ArrayList<String>();
		}
		if(with.contains("activity_channel_rule"))
		{
			
			List<EpcActivityChannelRule> channelRuleList=null;
			try {
				channelRuleList = epcActivityChannelRuleRepository.getActivityChannel(activityName);
			} catch (Exception e) {
				throw new RuntimeException(
						"Error occurred while fetching results from database.\n"
								+ " Query: " + "Select * from epc_activity_channel_rule." + "\n"
								+ " Exception: " + e.getMessage());
			}
			activityResponse.setEpcActivityChannelRule(channelRuleList);
			if(with.contains("notification"))
			{
				for(int i=0;i<channelRuleList.size();i++)
				{
					EpcNotificationTemplate epcNotificationTemplate1=new EpcNotificationTemplate();
					List<EpcNotificationTemplate> epcNotificationTemplate=new ArrayList<EpcNotificationTemplate>();;
				    epcNotificationTemplate=epcNotificationTemplateRepository.findNotificationByTemplateId(channelRuleList.get(i).getNotificationTemplateId());
				    if(epcNotificationTemplate.size()>0){
				    	channelRuleList.get(i).setEpcNotificationTemplate(epcNotificationTemplate.get(0));
				    	List<EpcNotificationTemplateDetail> epcNotificationTemplateDetail=null;
						epcNotificationTemplateDetail=epcNotificationTemplateDetailRepository.findByNotificationTemplateId(channelRuleList.get(i).getNotificationTemplateId());
						epcNotificationTemplate1.setEpcNotificationTemplateDetail(epcNotificationTemplateDetail);
				    	channelRuleList.get(i).getEpcNotificationTemplate().setEpcNotificationTemplateDetail(epcNotificationTemplateDetail);
				    }
					
					
					}
				activityResponse.setEpcActivityChannelRule(channelRuleList);
			}
			
		}
		if((!with.contains("activity_channel_rule")) && with.contains("notification"))
		{
			throw new GenericException("InvalidSearch", " with=activity_channel_rule is missing. "
					+ "Please provide with=activity_channel_rule", "with=activity_channel_rule is missing.");
		
		}
		return activityResponse;
	}
	
	public ActivitySearchOutputOld searchActivitiesExt(
			String activityName, List<String> keys, String activityValue) {
		String query = "select activity_key, activity_value from    "+
          " epc_activity_master left join epc_activity_detail on  "+
          " epc_activity_master.activity_id = epc_activity_detail.activity_id ";
//	logger.info("#Query "+query);
	if(activityName!=null && !activityName.equals("")) {
			query = query + "where activity_name ='"+activityName+"'";
		}
//		if(key!=null && !key.equals(""))
//			query = query + "and activity_key ='"+key+"'";
		if(keys!=null ){
			if(keys.size()>0){
						query = query + " and ";
					
					int i=0;
					for(String key:keys){
						i++;
						query = query + "  activity_key = '"+key+"'";
						if(i!=keys.size()){
							query = query + " OR ";
						}
					}
			}
		}
		
		if(StringUtils.isNotBlank(activityValue)){
			query = query + " and activity_value like '"+activityValue+"'";
		}
		List<Object[]> listOfObjects = epcActivityMasterRepository.getList(query);
	
		ActivitySearchOutputOld detail=new ActivitySearchOutputOld();
		Map<String, String> map = new HashMap<String, String>();
	List<String> validKeys=new ArrayList<String>();
		for(Object object[]: listOfObjects) 
		{
			map.put(object[0].toString(), object[1].toString());
			validKeys.add(object[0].toString().toLowerCase());
		}
		if( keys!=null){
		for(String key:keys)
			{
				if(validKeys.size()<1 || validKeys==null)
				{
					map.put(key,"ERROR_INVALID_KEY");
				}
				else if(validKeys.size()>0)
				{
					if(!validKeys.contains(key.toLowerCase()))
					{
						map.put(key,"ERROR_INVALID_KEY");
					}
				}
			}
		}
		detail.setActivityDetail(map);
	
	return detail;
	
		
	}
	

}
