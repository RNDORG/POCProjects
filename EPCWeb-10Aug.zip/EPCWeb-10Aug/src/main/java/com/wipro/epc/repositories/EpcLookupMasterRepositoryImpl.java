package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcLookupMaster;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
@Repository
public class EpcLookupMasterRepositoryImpl implements EpcLookupMasterRepositoryCustom {
	
	private static Logger logger =LoggerFactory.getLogger(EpcLookupMasterRepositoryImpl.class);
	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<EpcLookupMaster> getListofValues(String query){
		logger.debug("#Query: "+query);
			return em.createNativeQuery(query, EpcLookupMaster.class).getResultList();
		}

}
