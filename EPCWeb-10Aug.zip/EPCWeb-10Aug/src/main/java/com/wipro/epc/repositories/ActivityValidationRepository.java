package com.wipro.epc.repositories;

import org.springframework.data.repository.CrudRepository;

import com.wipro.epc.domain.EpcActivityChannelRule;

/**
 * @author Developer
 * @version 1.0
 * type ActivityValidationRepository
 */
public interface ActivityValidationRepository extends CrudRepository<EpcActivityChannelRule, Integer>,ActivityValidationRepositoryCustom{

}

