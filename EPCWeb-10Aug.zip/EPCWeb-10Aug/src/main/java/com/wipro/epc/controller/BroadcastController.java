package com.wipro.epc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.BroadcastLogs;
import com.wipro.epc.repositories.BroadcastLogsRepository;
import com.wipro.epc.services.BroadcastLogsService;
import com.wipro.epc.services.BroadcastService;


@RestController
public class BroadcastController {


	private static Logger logger = LoggerFactory.getLogger(BroadcastController.class);

	@Autowired
	BroadcastService broadcastService;
	
	@RequestMapping(value = "rest/extapi/v1/broadcast/logs/list", method=RequestMethod.GET)
	public List<String> getBroadcasts() {
		return broadcastService.getBroadcastsService();
	}

	@RequestMapping(value = "rest/extapi/v1/broadcast/logs", method=RequestMethod.GET)
	public List<BroadcastLogs> getBroadcastsById(@RequestParam MultiValueMap allRequestParams) {
		return broadcastService.getBroadcastsByIdService(allRequestParams);
	}

	@RequestMapping(value="/rest/extapi/v1/broadcast", method=RequestMethod.GET)
	public Map<String,String> getReply(@RequestParam MultiValueMap allRequestParams){
		return broadcastService.getReplyService(allRequestParams);
	}
	
	
}
