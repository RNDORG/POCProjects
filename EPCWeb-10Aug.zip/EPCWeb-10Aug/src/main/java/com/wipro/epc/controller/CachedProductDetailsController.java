package com.wipro.epc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.CachedProductDetails;
import com.wipro.epc.repositories.CachedProductDetailsRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.services.CachedProductDetailsService;

@RestController
public class CachedProductDetailsController {
	@Autowired
	EpcProductSpecificationRepository epcProductSpecificationRepository;

	@Autowired
	CachedProductDetailsRepository cachedProductRepository;
	
	@Autowired
	private CachedProductDetailsService cachedProductService;
	
	@RequestMapping(value="/rest/extapi/v1/cachedProductDetails/reload", method=RequestMethod.GET)
	public String updateProductDetailsCache(@RequestParam MultiValueMap allRequestParams){
		
		CachedProductDetails cpd=new CachedProductDetails();
		List<String> failedIds=new ArrayList<String>();
		List<String> successIds=new ArrayList<String>();
		String[] ids={};
		if(allRequestParams.get("id")==null || ((List<String>)allRequestParams.get("id")).get(0).isEmpty() ){
			throw new RuntimeException("#ERROR: Missing Mandatory field to API. Mandatory fields [ id ] ");
		}else{
			if(((List<String>)allRequestParams.get("id")).get(0).equalsIgnoreCase( "all" ) ){
				ids=epcProductSpecificationRepository.getProductId();
				System.out.println("ids for all : "+ids.length);
			}else{
				ids=((List<String>) allRequestParams.get("id")).get(0).split(",");
			}
			
			for(int i=0;i<ids.length;i++){
				CachedProductDetails detail=cachedProductRepository.getById(Integer.valueOf(ids[i]));
				if(detail != null){
					try{
						cachedProductRepository.delete(Integer.valueOf(ids[i]));
						cachedProductService.cacheProduct(cachedProductService.cacheProduct(Integer.valueOf(ids[i]) ));
						successIds.add( ids[i] );
					}catch(RuntimeException e){
						failedIds.add( ids[i] );
						System.out.println("#ERROR Runtime: "+e.getMessage());
					} 
				}
				/*if(detail!=null){
					try{
						//BytesUtil.toByteArray(prodSpec)
					detail.setValue(BytesUtil.toByteArray( cachedProductService.cacheProduct(Integer.valueOf(ids[i]) ) ) );
					detail.setId( Integer.valueOf(ids[i]) );
					System.out.println("#Value : "+detail.getValue());
					cachedProductRepository.updateCachedProductDetails( detail );
					successIds.add( ids[i] );
					
					}catch(RuntimeException e){
						failedIds.add( ids[i] );
						System.out.println("#ERROE Runtime: "+e.getMessage());
					} catch (IOException e) {
						failedIds.add( ids[i] );
						System.out.println("#ERROR IO : "+e.getMessage());
						e.printStackTrace();
					}
				}else{
					
					cachedProductService.cacheProduct(cachedProductService.cacheProduct(Integer.valueOf(ids[i]) ));
					successIds.add(ids[i]);
				}*/
				
			}
			return "productCache is failed for products "+failedIds.toString()
					+ " and succeed for "+successIds.toString();
		}
	
	}
	
}
