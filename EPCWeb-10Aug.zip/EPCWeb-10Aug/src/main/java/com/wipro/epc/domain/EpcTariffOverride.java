package com.wipro.epc.domain;


import javax.persistence.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;


/**
 * @author Developer
 * @version 1.0
 * The persistent class for the epc_tariff_override database table.
 */
@Entity
@Table(name="epc_tariff_override")
public class EpcTariffOverride   implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Integer EpcTariffOverride.java
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tariff_override_id")
	private Integer tariffOverrideId;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="addon_product_id")
	private String addonProductId;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name")
	private String attributeName;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_0")
	private String attributeName0;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_1")
	private String attributeName1;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_2")
	private String attributeName2;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_3")
	private String attributeName3;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_4")
	private String attributeName4;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_5")
	private String attributeName5;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_6")
	private String attributeName6;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_7")
	private String attributeName7;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_8")
	private String attributeName8;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_name_9")
	private String attributeName9;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_0")
	private String attributeValue0;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_1")
	private String attributeValue1;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_2")
	private String attributeValue2;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_3")
	private String attributeValue3;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_4")
	private String attributeValue4;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_5")
	private String attributeValue5;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_6")
	private String attributeValue6;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_7")
	private String attributeValue7;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_8")
	private String attributeValue8;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="attribute_value_9")
	private String attributeValue9;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="created_by")
	private String createdBy;

	/**
	 * Date EpcTariffOverride.java
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="modified_by")
	private String modifiedBy;

	/**
	 * Date EpcTariffOverride.java
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	private Date modifiedDate;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="other_product_id_1")
	private String otherProductId1;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="other_product_id_2")
	private String otherProductId2;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="other_product_id_3")
	private String otherProductId3;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="other_product_id_4")
	private String otherProductId4;

	/**
	 * BigDecimal EpcTariffOverride.java
	 */
	@Column(name="override_tariff_amount")
	private BigDecimal overrideTariffAmount;

	/**
	 * Integer EpcTariffOverride.java
	 */
	private Integer priority;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="rateplan_product_id")
	private String rateplanProductId;

	/**
	 * String EpcTariffOverride.java
	 */
	private String status;

	/**
	 * String EpcTariffOverride.java
	 */
	@Column(name="tariff_currency")
	private String tariffCurrency;

	
	@Transient
	private Map<String,String> metaInfo;	
	/**
	 * 
	 */
	public EpcTariffOverride() {
	}

	/**
	 * @return
	 */
	public Integer getTariffOverrideId() {
		return this.tariffOverrideId;
	}

	/**
	 * @param tariffOverrideId
	 */
	public void setTariffOverrideId(Integer tariffOverrideId) {
		this.tariffOverrideId = tariffOverrideId;
	}

	/**
	 * @return
	 */
	public String getAddonProductId() {
		return this.addonProductId;
	}

	/**
	 * @param addonProductId
	 */
	public void setAddonProductId(String addonProductId) {
		this.addonProductId = addonProductId;
	}

	/**
	 * @return
	 */
	public String getAttributeName() {
		return this.attributeName;
	}

	/**
	 * @param attributeName
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	/**
	 * @return
	 */
	public String getAttributeName0() {
		return this.attributeName0;
	}

	/**
	 * @param attributeName0
	 */
	public void setAttributeName0(String attributeName0) {
		this.attributeName0 = attributeName0;
	}

	/**
	 * @return
	 */
	public String getAttributeName1() {
		return this.attributeName1;
	}

	/**
	 * @param attributeName1
	 */
	public void setAttributeName1(String attributeName1) {
		this.attributeName1 = attributeName1;
	}

	/**
	 * @return
	 */
	public String getAttributeName2() {
		return this.attributeName2;
	}

	/**
	 * @param attributeName2
	 */
	public void setAttributeName2(String attributeName2) {
		this.attributeName2 = attributeName2;
	}

	/**
	 * @return
	 */
	public String getAttributeName3() {
		return this.attributeName3;
	}

	/**
	 * @param attributeName3
	 */
	public void setAttributeName3(String attributeName3) {
		this.attributeName3 = attributeName3;
	}

	/**
	 * @return
	 */
	public String getAttributeName4() {
		return this.attributeName4;
	}

	/**
	 * @param attributeName4
	 */
	public void setAttributeName4(String attributeName4) {
		this.attributeName4 = attributeName4;
	}

	/**
	 * @return
	 */
	public String getAttributeName5() {
		return this.attributeName5;
	}

	/**
	 * @param attributeName5
	 */
	public void setAttributeName5(String attributeName5) {
		this.attributeName5 = attributeName5;
	}

	/**
	 * @return
	 */
	public String getAttributeName6() {
		return this.attributeName6;
	}

	/**
	 * @param attributeName6
	 */
	public void setAttributeName6(String attributeName6) {
		this.attributeName6 = attributeName6;
	}

	/**
	 * @return
	 */
	public String getAttributeName7() {
		return this.attributeName7;
	}

	/**
	 * @param attributeName7
	 */
	public void setAttributeName7(String attributeName7) {
		this.attributeName7 = attributeName7;
	}

	/**
	 * @return
	 */
	public String getAttributeName8() {
		return this.attributeName8;
	}

	/**
	 * @param attributeName8
	 */
	public void setAttributeName8(String attributeName8) {
		this.attributeName8 = attributeName8;
	}

	/**
	 * @return
	 */
	public String getAttributeName9() {
		return this.attributeName9;
	}

	/**
	 * @param attributeName9
	 */
	public void setAttributeName9(String attributeName9) {
		this.attributeName9 = attributeName9;
	}

	/**
	 * @return
	 */
	public String getAttributeValue0() {
		return this.attributeValue0;
	}

	/**
	 * @param attributeValue0
	 */
	public void setAttributeValue0(String attributeValue0) {
		this.attributeValue0 = attributeValue0;
	}

	/**
	 * @return
	 */
	public String getAttributeValue1() {
		return this.attributeValue1;
	}

	/**
	 * @param attributeValue1
	 */
	public void setAttributeValue1(String attributeValue1) {
		this.attributeValue1 = attributeValue1;
	}

	/**
	 * @return
	 */
	public String getAttributeValue2() {
		return this.attributeValue2;
	}

	/**
	 * @param attributeValue2
	 */
	public void setAttributeValue2(String attributeValue2) {
		this.attributeValue2 = attributeValue2;
	}

	/**
	 * @return
	 */
	public String getAttributeValue3() {
		return this.attributeValue3;
	}

	/**
	 * @param attributeValue3
	 */
	public void setAttributeValue3(String attributeValue3) {
		this.attributeValue3 = attributeValue3;
	}

	/**
	 * @return
	 */
	public String getAttributeValue4() {
		return this.attributeValue4;
	}

	/**
	 * @param attributeValue4
	 */
	public void setAttributeValue4(String attributeValue4) {
		this.attributeValue4 = attributeValue4;
	}

	/**
	 * @return
	 */
	public String getAttributeValue5() {
		return this.attributeValue5;
	}

	/**
	 * @param attributeValue5
	 */
	public void setAttributeValue5(String attributeValue5) {
		this.attributeValue5 = attributeValue5;
	}

	/**
	 * @return
	 */
	public String getAttributeValue6() {
		return this.attributeValue6;
	}

	/**
	 * @param attributeValue6
	 */
	public void setAttributeValue6(String attributeValue6) {
		this.attributeValue6 = attributeValue6;
	}

	/**
	 * @return
	 */
	public String getAttributeValue7() {
		return this.attributeValue7;
	}

	/**
	 * @param attributeValue7
	 */
	public void setAttributeValue7(String attributeValue7) {
		this.attributeValue7 = attributeValue7;
	}

	/**
	 * @return
	 */
	public String getAttributeValue8() {
		return this.attributeValue8;
	}

	/**
	 * @param attributeValue8
	 */
	public void setAttributeValue8(String attributeValue8) {
		this.attributeValue8 = attributeValue8;
	}

	/**
	 * @return
	 */
	public String getAttributeValue9() {
		return this.attributeValue9;
	}

	/**
	 * @param attributeValue9
	 */
	public void setAttributeValue9(String attributeValue9) {
		this.attributeValue9 = attributeValue9;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return
	 */
	public String getOtherProductId1() {
		return this.otherProductId1;
	}

	/**
	 * @param otherProductId1
	 */
	public void setOtherProductId1(String otherProductId1) {
		this.otherProductId1 = otherProductId1;
	}

	/**
	 * @return
	 */
	public String getOtherProductId2() {
		return this.otherProductId2;
	}

	/**
	 * @param otherProductId2
	 */
	public void setOtherProductId2(String otherProductId2) {
		this.otherProductId2 = otherProductId2;
	}

	/**
	 * @return
	 */
	public String getOtherProductId3() {
		return this.otherProductId3;
	}

	/**
	 * @param otherProductId3
	 */
	public void setOtherProductId3(String otherProductId3) {
		this.otherProductId3 = otherProductId3;
	}

	/**
	 * @return
	 */
	public String getOtherProductId4() {
		return this.otherProductId4;
	}

	/**
	 * @param otherProductId4
	 */
	public void setOtherProductId4(String otherProductId4) {
		this.otherProductId4 = otherProductId4;
	}

	/**
	 * @return
	 */
	public BigDecimal getOverrideTariffAmount() {
		return this.overrideTariffAmount;
	}

	/**
	 * @param overrideTariffAmount
	 */
	public void setOverrideTariffAmount(BigDecimal overrideTariffAmount) {
		this.overrideTariffAmount = overrideTariffAmount;
	}

	/**
	 * @return
	 */
	public Integer getPriority() {
		return this.priority;
	}

	/**
	 * @param priority
	 */
	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	/**
	 * @return
	 */
	public String getRateplanProductId() {
		return this.rateplanProductId;
	}

	/**
	 * @param rateplanProductId
	 */
	public void setRateplanProductId(String rateplanProductId) {
		this.rateplanProductId = rateplanProductId;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return
	 */
	public String getTariffCurrency() {
		return this.tariffCurrency;
	}

	/**
	 * @param tariffCurrency
	 */
	public void setTariffCurrency(String tariffCurrency) {
		this.tariffCurrency = tariffCurrency;
	}
	
	
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}

	@Override
	public String toString() {
		return "EpcTariffOverride [tariffOverrideId=" + tariffOverrideId
				+ ", addonProductId=" + addonProductId + ", attributeName="
				+ attributeName + ", attributeName0=" + attributeName0
				+ ", attributeName1=" + attributeName1 + ", attributeName2="
				+ attributeName2 + ", attributeName3=" + attributeName3
				+ ", attributeName4=" + attributeName4 + ", attributeName5="
				+ attributeName5 + ", attributeName6=" + attributeName6
				+ ", attributeName7=" + attributeName7 + ", attributeName8="
				+ attributeName8 + ", attributeName9=" + attributeName9
				+ ", attributeValue0=" + attributeValue0 + ", attributeValue1="
				+ attributeValue1 + ", attributeValue2=" + attributeValue2
				+ ", attributeValue3=" + attributeValue3 + ", attributeValue4="
				+ attributeValue4 + ", attributeValue5=" + attributeValue5
				+ ", attributeValue6=" + attributeValue6 + ", attributeValue7="
				+ attributeValue7 + ", attributeValue8=" + attributeValue8
				+ ", attributeValue9=" + attributeValue9 + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + ", modifiedBy="
				+ modifiedBy + ", modifiedDate=" + modifiedDate
				+ ", otherProductId1=" + otherProductId1 + ", otherProductId2="
				+ otherProductId2 + ", otherProductId3=" + otherProductId3
				+ ", otherProductId4=" + otherProductId4
				+ ", overrideTariffAmount=" + overrideTariffAmount
				+ ", priority=" + priority + ", rateplanProductId="
				+ rateplanProductId + ", status=" + status
				+ ", tariffCurrency=" + tariffCurrency + "]";
	}

	
}