package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductDecomposition;

/**
 * This is Interface for 
 * EpcProductDecompositionRepositoryCustom
 * @author VI251443
 * @version 1.0
 */
public interface EpcProductDecompositionRepositoryCustom {
	
	/**
	 * 
	 * @param decomposition
	 * @return list of EpcProductDecomposition
	 */
	EpcProductDecomposition modifyProductDecomposition(EpcProductDecomposition decomposition);
	
	/**
	 * 
	 * @param query
	 * @return list of EpcProductDecomposition
	 */
	List<EpcProductDecomposition> getList(String query);


}
