package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductMigration;

/**
 * 
 * @author KE334465
 *
 */
public interface EpcProductMigrationRepository extends CrudRepository<EpcProductMigration, Integer>, 
EpcProductMigrationRepositorycCustom {

	/**
	 * @param sourceProductId
	 * @return
	 */
	@Query(value="select * from epc_product_migration where source_product_id =:sourceProductId", nativeQuery=true)
	List<EpcProductMigration> findMigrationBysourceProductId(@Param("sourceProductId") Integer sourceProductId);
   
	/**
	 * 
	 * @param sourceProductId
	 */
	@Modifying
	@Query(value="delete from epc_product_migration where source_product_id=:sourceProductId", nativeQuery=true)
	void deleteProductFromMigration(@Param("sourceProductId") Integer sourceProductId);
}
