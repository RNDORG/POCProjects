package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductSegment;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductSegmentRepositoryCustom
 */
public interface EpcProductSegmentRepositoryCustom {

	 /**
	 * @param query
	 * @return
	 */
	List<EpcProductSegment> getList(String query);

	/**
	 * @param segment
	 * @return
	 */
	EpcProductSegment modifyProductSegment(EpcProductSegment segment);
	 
	 
}
