package com.wipro.epc.repositories;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.domain.EpcProductAvailability;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.util.Constants;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductSpecificationRepositoryImpl
 */
public class EpcProductSpecificationRepositoryImpl implements EpcProductspecificationRepositoryCustom{
	
	private static Logger logger =LoggerFactory.getLogger(EpcProductSpecificationRepositoryImpl.class);
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@PersistenceContext
	private EntityManager em;

	/*@Autowired
	EpcProductNetworkTplMapRepository tplMapRepo  ;*/
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductspecificationRepositoryCustom#modifyProductSpec(com.wipro.epc.domain.EpcProductSpecification)
	 */
	@Override
	public EpcProductSpecification modifyProductSpec(EpcProductSpecification product)
	{
		StringBuilder queryBuilder = new StringBuilder("update epc_product_specification set product_id="+product.getProductId());
		
		if(product.getProductShortCode()!=null){
			queryBuilder.append(",").append(" product_short_code = '").append(product.getProductShortCode()).append("'");
		}
		if(product.getProductDescription()!=null){
			queryBuilder.append(",").append(" product_description = '").append(product.getProductDescription()).append("'");
		}
		if(product.getProductMarketingName()!=null){
			queryBuilder.append(",").append(" product_marketing_name = '").append(product.getProductMarketingName()).append("'");
		}
		/*if(product.getProviderSystemCode()!=null)
			queryBuilder.append(",").append(" provider_system_code = '").append(product.getProviderSystemCode()).append("'");
		if(product.getProviderProductId()!=null)
			queryBuilder.append(",").append(" provider_product_id = ").append(product.getProviderProductId());
		if(product.getProviderProductDescription()!=null)
			queryBuilder.append(",").append(" provider_product_description = '").append(product.getProviderProductDescription()).append("'");*/
		if(product.getProductQuota()!=null){
			queryBuilder.append(",").append(" product_quota = '").append(product.getProductQuota()).append("'");
		}
		if(product.getProductQuotaDuration()!=null){
			queryBuilder.append(",").append(" product_quota_duration = '").append(product.getProductQuotaDuration()).append("'");
		}
		if(product.getProductQuotaDurationUom()!=null){
			queryBuilder.append(",").append(" product_quota_duration_uom = '").append(product.getProductQuotaDurationUom()).append("'");
		}
		if(product.getProductQuotaUom()!=null){
			queryBuilder.append(",").append(" product_quota_uom = '").append(product.getProductQuotaUom()).append("'");
		}
		if(product.getIsBundle()!=null){
			queryBuilder.append(",").append(" is_bundle = '").append(product.getIsBundle()).append("'");
		}
		if(product.getIsHybrid()!=null){
			queryBuilder.append(",").append(" is_hybrid = '").append(product.getIsHybrid()).append("'");
		}
		if(product.getApiIndicator()!=null){
			queryBuilder.append(",").append(" api_indicator = '").append(product.getApiIndicator()).append("'");
		}
		if(product.getIsSpecialProduct()!=null){
			queryBuilder.append(",").append(" is_special_product = '").append(product.getIsSpecialProduct()).append("'");
		}
		if(product.getProductStatus()!=null){
			queryBuilder.append(",").append(" product_status = '").append(product.getProductStatus()).append("'");
		}
		if(product.getMinSubscription()!=null){
			queryBuilder.append(",").append(" min_subscription = '").append(product.getMinSubscription()).append("'");
		}
		if(product.getMaxSubscription()!=null){
			queryBuilder.append(",").append(" max_subscription = '").append(product.getMaxSubscription()).append("'");
		}
		if(product.getProductAssociationLevel()!=null){
			queryBuilder.append(",").append(" product_association_level = '").append(product.getProductAssociationLevel()).append("'");
		}
		if(product.getIsUsageProduct()!=null){
			queryBuilder.append(",").append(" is_usage_product = '").append(product.getIsUsageProduct()).append("'");
		}
		if(product.getIsDiscountProduct()!=null){
			queryBuilder.append(",").append(" is_discount_product = '").append(product.getIsDiscountProduct()).append("'");
		}
		if(product.getIsContractProduct()!=null){
			queryBuilder.append(",").append(" is_contract_product = '").append(product.getIsContractProduct()).append("'");
		}
		if(product.getIsAutoRenewalAllowed()!=null){
			queryBuilder.append(",").append(" is_auto_renewal_allowed = '").append(product.getIsAutoRenewalAllowed()).append("'");
		}
		if(product.getIsTemplateProduct()!=null){
			queryBuilder.append(",").append(" is_template_product = '").append(product.getIsTemplateProduct()).append("'");
		}
		if(product.getProductFamily()!=null){
			queryBuilder.append(",").append(" product_family = '").append(product.getProductFamily()).append("'");
		}
		if(product.getProductSubFamily()!=null){
			queryBuilder.append(",").append(" product_sub_family = '").append(product.getProductSubFamily()).append("'");
		}
		if(product.getProductClassification()!=null){
			queryBuilder.append(",").append(" product_classification = '").append(product.getProductClassification()).append("'");
		}
		if(product.getProductCategory()!=null){
			queryBuilder.append(",").append(" product_category = '").append(product.getProductCategory()).append("'");
		}
		if(product.getProductSubCategory()!=null){
			queryBuilder.append(",").append(" product_sub_category = '").append(product.getProductSubCategory()).append("'");
		}
		if(product.getProductType()!=null){
			queryBuilder.append(",").append(" product_type = '").append(product.getProductType()).append("'");
		}
		if(product.getCreatedDate()!=null){
			queryBuilder.append(",").append(" created_date = '").append(new SimpleDateFormat().format(new Date())).append("'");
		}
		if(product.getCreatedBy()!=null){
			queryBuilder.append(",").append(" created_by = '").append(product.getCreatedBy()).append("'");
		}
		if(product.getModifiedDate()!=null){
			queryBuilder.append(",").append(" modify_date = '").append(new SimpleDateFormat().format(new Date())).append("'");
		}
		if(product.getModifiedBy()!=null){
			queryBuilder.append(",").append(" modified_by = '").append(product.getModifiedBy()).append("'");
		}
		if(product.getDownstreamSystem()!=null){
			queryBuilder.append(",").append("downstream_system ='").append(product.getDownstreamSystem()).append("'");
		}
		if(product.getIsRoamingProduct()!=null){
			queryBuilder.append(",").append(" is_roaming_product = '").append(product.getIsRoamingProduct()).append("'");
		}
		if(product.getIsOtcAllowed()!=null){
			queryBuilder.append(",").append(" is_otc_allowed = ").append(product.getIsOtcAllowed());
		}
		if(product.getIsRcAllowed()!=null){
			queryBuilder.append(",").append(" is_rc_allowed = ").append(product.getIsRcAllowed());
		}
		if(product.getIsUcAllowed()!=null){
			queryBuilder.append(",").append(" is_uc_allowed = ").append(product.getIsUcAllowed());
		}
		if(product.getIsProductPaused()!=null){
			queryBuilder.append(",").append(" is_product_paused = ").append(product.getIsProductPaused());
		}
		if(product.getIsCorporateSpecific()!=null){
			queryBuilder.append(",").append(" is_corporate_specific = ").append(product.getIsCorporateSpecific());
		}
		if(product.getRetirePreviousProduct()!=null){
			queryBuilder.append(",").append(" retire_previous_product = '").append(product.getRetirePreviousProduct()).append("'");
		}
		queryBuilder.append(" where product_id=").append(product.getProductId());
		String query = queryBuilder.toString();
		//System.out.println(query);
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		
		/*EpcProductNetworkTplMap networkMap = new EpcProductNetworkTplMap();
		networkMap.setProductId(product.getProductId());
		//networkMap.setTemplateId(product.getNetworkProfileId());
		tplMapRepo.modifyNetworkId(networkMap);*/
		return product;
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductspecificationRepositoryCustom#modifyProductAvail(com.wipro.epc.domain.EpcProductSpecification)
	 */
	@Override
	public EpcProductSpecification modifyProductAvail(EpcProductSpecification product)
	{
		List<EpcProductAvailability> availList=new ArrayList<EpcProductAvailability>();
		if(product.getEpcProductAvailability()!=null) {
			availList = product.getEpcProductAvailability();
		}
		for(EpcProductAvailability avail: availList) {
			StringBuilder queryBuilder = new StringBuilder("update epc_product_availability set product_id="+product.getProductId());
			
			if(avail.getLifeValidityStartDate()!=null) {
				queryBuilder.append(",").append(" life_validity_start_date = '").append(new SimpleDateFormat().format(new Date())).append("'");
			}
			if(avail.getLifeValidityEndDate()!=null) {
				queryBuilder.append(",").append(" life_validity_end_date = '").append(avail.getLifeValidityEndDate()).append("'");
			}
			if(avail.getSellingStartDate()!=null) {
				queryBuilder.append(",").append(" selling_start_date = '").append(avail.getSellingStartDate()).append("'");
			}
			if(avail.getSellingEndDate()!=null) {
				queryBuilder.append(",").append(" selling_end_date = '").append(avail.getSellingEndDate()).append("'");
			}
			if(avail.getSubscriptionStartDate()!=null) {
				queryBuilder.append(" subscription_start_date= '").append(avail.getSubscriptionStartDate()).append("'");
			}
			if(avail.getSubscriptionDuration()!=null) {
				queryBuilder.append(" subscription_duration= '").append(avail.getSubscriptionDuration()).append("'");
			}
			if(avail.getSubscriptionDurationUom()!=null) {
				queryBuilder.append(" subscription_duration_uom= '").append(avail.getSubscriptionDurationUom()).append("'");
			}
			if(avail.getSubscriptionEndDate()!=null) {
				queryBuilder.append(",").append(" subscription_end_date = '").append(avail.getSubscriptionEndDate()).append("'");
			}
			if(avail.getActiveBusinessHourFrom()!=null) {
				queryBuilder.append(" active_business_hour_from = ").append(avail.getActiveBusinessHourFrom());
			}
			if(avail.getActiveBusinessHourTo()!=null) {
				queryBuilder.append(" active_business_hour_to = ").append(avail.getActiveBusinessHourTo());
			}
			
			queryBuilder.append(" where product_id=").append(product.getProductId());
			String query = queryBuilder.toString();
			logger.debug("#Query: "+query);
			em.createNativeQuery(query).executeUpdate();
		}
		return product;
	}

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductspecificationRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	public List<EpcProductSpecification> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductSpecification.class).getResultList();
	}
	
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	public List<Object[]> getListOfObjects(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query).getResultList();
	}

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductspecificationRepositoryCustom#getMarketingNamesForCommunityNames(java.lang.String)
	 */
	@Override
	public List<String> getMarketingNamesForCommunityNames(String communityName) {
		StringBuilder queryBuilder = new StringBuilder("select distinct product_marketing_name  from epc_product_specification e1,epc_product_community e2"+
			" where  e1.product_id=e2.product_id");
		
		if(communityName!=null && !communityName.equals("")) {
			queryBuilder.append(" and community_name = '").append(communityName).append("'");
		}
		logger.debug("#Query: "+queryBuilder.toString());
		return em.createNativeQuery(queryBuilder.toString()).getResultList();
	}

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductspecificationRepositoryCustom#needsToBeFilteredForMigration(java.util.List, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<String> needsToBeFilteredForMigration(List<String> targetProductId,
			String filterCriteria_targetProdSubCategory, String filterCriteria_targetCommuId) {
		
		StringBuilder queryBuilder = new StringBuilder("select product_id from epc_product_specification where 1=1 ");
		
		if(!Constants.PRODUCT_SUB_CATEGORY_ALL.equalsIgnoreCase(filterCriteria_targetProdSubCategory)){
			queryBuilder.append(" and ( product_sub_category= '").append(filterCriteria_targetProdSubCategory).append("' ");
			queryBuilder.append(" or product_sub_category= '").append(Constants.PRODUCT_SUB_CATEGORY_ALL).append("' )");
		}
		
		if(filterCriteria_targetCommuId!=null && (Constants.PRODUCT_SUB_CATEGORY_ALL.equalsIgnoreCase(filterCriteria_targetProdSubCategory) 
				|| Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equalsIgnoreCase(filterCriteria_targetProdSubCategory))) {
			
			queryBuilder.append(" and ((is_corporate_specific = 1 and product_id  in(select distinct product_id from epc_product_community"
					+ " where is_employee_allowed_to_purchase =1 and product_id in(").append(String.join(",", targetProductId)).append(") ").append(" and community_id = '").append(filterCriteria_targetCommuId).append("' ))");
			queryBuilder.append(" or (product_id  in(select distinct product_id from epc_product_community"
					+ " where is_employee_allowed_to_purchase =0 and product_id in(").append(String.join(",", targetProductId)).append(") ").append(" and community_id = '").append(filterCriteria_targetCommuId).append("' )))");
		}
		
		else if(filterCriteria_targetCommuId!=null) {
			queryBuilder.append(" and product_id  in(select distinct product_id from epc_product_community"
						+ " where product_id in(").append(String.join(",", targetProductId)).append(") ").append(" and community_id = '").append(filterCriteria_targetCommuId).append("' )");
		}
		else {
			queryBuilder.append(" and product_id  in(").append(String.join(",", targetProductId)).append(") ");
		}
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		List<String> ids = em.createNativeQuery(query).getResultList();
		////System.out.println(query+"\ncount is "+ids);
		
		return ids;
	}

	//------------------------------------temporary code for PT testing---------------------------------
		@Override
		public String getProcedureForPTtest(String name,String msgType)  {
			String out="";
			try { 
				SimpleJdbcCall procRead = new SimpleJdbcCall(jdbcTemplate).withProcedureName(
					 name);
			    SqlParameterSource in = new MapSqlParameterSource();
			    java.util.Map<String, Object> output =  procRead.execute(in);
			    if(msgType.equalsIgnoreCase("true"))
			    {
			    	 out=output.toString();
			    }
			    else
			    {
			    	out="success";
			    }
			   // System.out.println("out"+out);
			}
			catch(Exception e)
			{
				out="error"+"\n"+e.getMessage()+"\n"+e.getClass();
			}
			  
			return out;
		}
		
		//------------------------------------temporary code for PT testing---------------------------------
		
	/**
	 * @return
	 */
	public EntityManager getEm() {
		return em;
	}

	/**
	 * @param em
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}
}
