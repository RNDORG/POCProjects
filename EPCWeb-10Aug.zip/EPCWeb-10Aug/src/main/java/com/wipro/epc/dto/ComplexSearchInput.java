package com.wipro.epc.dto;

import java.lang.reflect.Field;


import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Developer
 * @version 1.0
 * type ComplexSearchInput
 */
public class ComplexSearchInput {

	/**
	 * String ComplexSearchInput.java
	 */
	private String productId;
	/**
	 * String ComplexSearchInput.java
	 */
	private String productShortCode;
	/**
	 * String ComplexSearchInput.java
	 */
	private String productMarketingName;
	/**
	 * String ComplexSearchInput.java
	 */
	private String productStatus;
	/**
	 * String ComplexSearchInput.java
	 */
	private String productFamily;
	/**
	 * String ComplexSearchInput.java
	 */
	private String productSubfamily;
	/**
	 * String ComplexSearchInput.java
	 */
	private String productCategory;
	/**
	 * String ComplexSearchInput.java
	 */
	private String productSubCategory;
	/**
	 * String ComplexSearchInput.java
	 */
	private String productType;
	
	/**
	 * String ComplexSearchInput.java
	 */
	private String isTemplateProduct;
	/**
	 * String ComplexSearchInput.java
	 */
	private String  lifeValidityStartDate;
	/**
	 * String ComplexSearchInput.java
	 */
	private String  lifeValidityEndDate;
	/**
	 * String ComplexSearchInput.java
	 */
	private String  sellingStartDate;
	/**
	 * String ComplexSearchInput.java
	 */
	private String  sellingEndDate;
	/**
	 * String ComplexSearchInput.java
	 */
	private String launchDate;
	/**
	 * String ComplexSearchInput.java
	 */
	private String initiatingChannel;
	/**
	 * String ComplexSearchInput.java
	 */
	private String initiatingChannelLevelMarketingName;
	/**
	 * String ComplexSearchInput.java
	 */
	private String initiatingChannelProductId;
	/**
	 * String ComplexSearchInput.java
	 */
	private String subscriptionStartDate;
	/**
	 * String ComplexSearchInput.java
	 */
	private String subscriptionEndDate;

	/**
	 * String ComplexSearchInput.java
	 */
	private String salesChannel;
	/**
	 * String ComplexSearchInput.java
	 */
	private String region;
	/**
	 * String ComplexSearchInput.java
	 */
	private String area;
	/**
	 * String ComplexSearchInput.java
	 */
	private String territory;
	/**
	 * String ComplexSearchInput.java
	 */
	private String segmentType;
	/**
	 * String ComplexSearchInput.java
	 */
	private String segment;
	/**
	 * String ComplexSearchInput.java
	 */
	private String providerProductId;

	/**
	 * String ComplexSearchInput.java
	 */
	private String productClassification;
	/**
	 * String ComplexSearchInput.java
	 */
	private String providerSystemCode;
	/**
	 * String ComplexSearchInput.java
	 */
	private String providerProductDescription;
	/**
	 * String ComplexSearchInput.java
	 */
	private String downstreamSystem;
	/**
	 * String ComplexSearchInput.java
	 */
	private String isAutoRenewalAllowed;
	/**
	 * String ComplexSearchInput.java
	 */
	private String isBundle;
	/**
	 * String ComplexSearchInput.java
	 */
	private String isHybrid;
	/**
	 * String ComplexSearchInput.java
	 */
	private String isOmOrchestrationRequired;
	/**
	 * String ComplexSearchInput.java
	 */
	private String isRoamingProduct;
	/**
	 * String ComplexSearchInput.java
	 */
	private String isProductPaused;
	/**
	 * String ComplexSearchInput.java
	 */
	private String communityName;
	/**
	 * String ComplexSearchInput.java
	 */
	private String communityId;
	/**
	 * String ComplexSearchInput.java
	 */
	private String orderType;
	
	/**
	 * String ComplexSearchInput.java
	 */
	private String networkTemplateName;
	
	/**
	 * String ComplexSearchInput.java
	 */
	private String attributeName;
	/**
	 * String ComplexSearchInput.java
	 */
	private String attributeValue; 
	
	
	/**
	 * @return
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	public String getSubscriptionStartDate() {
		return subscriptionStartDate;
	}

	
	/**
	 * @param productsubscriptionStartDate
	 */
	public void setSubscriptionStartDate(String subscriptionStartDate) {
		this.subscriptionStartDate = subscriptionStartDate;
	}

	
	/**
	 * @return
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	public String getSubscriptionEndDate() {
		return subscriptionEndDate;
	}

	
	/**
	 * @param productSubscriptionEndDate
	 */
	public void setSubscriptionEndDate(String subscriptionEndDate) {
		this.subscriptionEndDate = subscriptionEndDate;
	}

	
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getInitiatingChannelProductId() {
		return initiatingChannelProductId;
	}

	
	/**
	 * @param initiatingChannelProductId
	 */
	/**
	 * @param initiatingChannelProductId
	 */
	public void setInitiatingChannelProductId(String initiatingChannelProductId) {
		this.initiatingChannelProductId = initiatingChannelProductId;
	}


	
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getAttributeName() {
		return attributeName;
	}

	
	/**
	 * @param attributeName
	 */
	/**
	 * @param attributeName
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getAttributeValue() {
		return attributeValue;
	}

	
	/**
	 * @param attributeValue
	 */
	/**
	 * @param attributeValue
	 */
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}


	/**
	 * String ComplexSearchInput.java
	 */
	private String specCreatedDateFrom;
	/**
	 * String ComplexSearchInput.java
	 */
	private String specCreatedDateTo;
	
	
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProviderProductId() {
		return providerProductId;
	}

	
	/**
	 * @param providerProductId
	 */
	/**
	 * @param providerProductId
	 */
	public void setProviderProductId(String providerProductId) {
		this.providerProductId = providerProductId;
	}

	
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductShortCode() {
		return productShortCode;
	}
	/**
	 * @param productShortCode
	 */
	/**
	 * @param productShortCode
	 */
	public void setProductShortCode(String productShortCode) {
		this.productShortCode = productShortCode;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductMarketingName() {
		return productMarketingName;
	}
	/**
	 * @param productMarketingName
	 */
	/**
	 * @param productMarketingName
	 */
	public void setProductMarketingName(String productMarketingName) {
		this.productMarketingName = productMarketingName;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductStatus() {
		return productStatus;
	}
	/**
	 * @param productStatus
	 */
	/**
	 * @param productStatus
	 */
	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductFamily() {
		return productFamily;
	}
	/**
	 * @param productFamily
	 */
	/**
	 * @param productFamily
	 */
	public void setProductFamily(String productFamily) {
		this.productFamily = productFamily;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductSubfamily() {
		return productSubfamily;
	}
	/**
	 * @param productSubFamily
	 */
	/**
	 * @param productSubFamily
	 */
	public void setProductSubfamily(String productSubFamily) {
		this.productSubfamily = productSubFamily;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductCategory() {
		return productCategory;
	}
	/**
	 * @param productCategory
	 */
	/**
	 * @param productCategory
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductSubCategory() {
		return productSubCategory;
	}
	/**
	 * @param productSubCategory
	 */
	/**
	 * @param productSubCategory
	 */
	public void setProductSubCategory(String productSubCategory) {
		this.productSubCategory = productSubCategory;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductType() {
		return productType;
	}
	/**
	 * @param productType
	 */
	/**
	 * @param productType
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getIsTemplateProduct() {
		return isTemplateProduct;
	}
	/**
	 * @param isProductTemplate
	 */
	/**
	 * @param isProductTemplate
	 */
	public void setIsTemplateProduct(String isProductTemplate) {
		this.isTemplateProduct = isProductTemplate;
	}
	/**
	 * @return
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	public String getLifeValidityStartDate() {
		return lifeValidityStartDate;
	}
	/**
	 * @param productLifeValidityDateFrom
	 */
	/**
	 * @param productLifeValidityDateFrom
	 */
	public void setLifeValidityStartDate(String productLifeValidityDateFrom) {
		this.lifeValidityStartDate = productLifeValidityDateFrom;
	}
	/**
	 * @return
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	public String getLifeValidityEndDate() {
		return lifeValidityEndDate;
	}
	/**
	 * @param productLifeValidityDateTo
	 */
	/**
	 * @param productLifeValidityDateTo
	 */
	public void setLifeValidityEndDate(String productLifeValidityDateTo) {
		this.lifeValidityEndDate = productLifeValidityDateTo;
	}
	/**
	 * @return
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	public String getSellingStartDate() {
		return sellingStartDate;
	}
	/**
	 * @param productSellingDateFrom
	 */
	/**
	 * @param productSellingDateFrom
	 */
	public void setSellingStartDate(String productSellingDateFrom) {
		this.sellingStartDate = productSellingDateFrom;
	}
	/**
	 * @return
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	public String getSellingEndDate() {
		return sellingEndDate;
	}
	/**
	 * @param productSellingDateTo
	 */
	/**
	 * @param productSellingDateTo
	 */
	public void setSellingEndDate(String productSellingDateTo) {
		this.sellingEndDate = productSellingDateTo;
	}
	/**
	 * @return
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	public String getLaunchDate() {
		return launchDate;
	}
	/**
	 * @param productLaunchDate
	 */
	/**
	 * @param productLaunchDate
	 */
	public void setLaunchDate(String productLaunchDate) {
		this.launchDate = productLaunchDate;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getInitiatingChannel() {
		return initiatingChannel;
	}
	/**
	 * @param initiatingChannel
	 */
	/**
	 * @param initiatingChannel
	 */
	public void setInitiatingChannel(String initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getInitiatingChannelLevelMarketingName() {
		return initiatingChannelLevelMarketingName;
	}
	/**
	 * @param initiatingChannelLevelMarketingName
	 */
	/**
	 * @param initiatingChannelLevelMarketingName
	 */
	public void setInitiatingChannelLevelMarketingName(
			String initiatingChannelLevelMarketingName) {
		this.initiatingChannelLevelMarketingName = initiatingChannelLevelMarketingName;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getSalesChannel() {
		return salesChannel;
	}
	/**
	 * @param salesChannel
	 */
	/**
	 * @param salesChannel
	 */
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param regionName
	 */
	/**
	 * @param regionName
	 */
	public void setRegion(String regionName) {
		this.region = regionName;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getArea() {
		return area;
	}
	/**
	 * @param areaName
	 */
	/**
	 * @param areaName
	 */
	public void setArea(String areaName) {
		this.area = areaName;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getTerritory() {
		return territory;
	}
	/**
	 * @param territoryName
	 */
	/**
	 * @param territoryName
	 */
	public void setTerritory(String territoryName) {
		this.territory = territoryName;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getSegmentType() {
		return segmentType;
	}
	/**
	 * @param segmentType
	 */
	/**
	 * @param segmentType
	 */
	public void setSegmentType(String segmentType) {
		this.segmentType = segmentType;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getSegment() {
		return segment;
	}
	/**
	 * @param segment
	 */
	/**
	 * @param segment
	 */
	public void setSegment(String segment) {
		this.segment = segment;
	}
	/**
	 * @param productId
	 */
	/**
	 * @param productId
	 */
	public void setProductId(String productId){
		this.productId = productId;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductId(){
		return productId;
	}
	
	
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProductClassification() {
		return productClassification;
	}


	/**
	 * @param productClassification
	 */
	/**
	 * @param productClassification
	 */
	public void setProductClassification(String productClassification) {
		this.productClassification = productClassification;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProviderSystemCode() {
		return providerSystemCode;
	}


	/**
	 * @param providerSystemCode
	 */
	/**
	 * @param providerSystemCode
	 */
	public void setProviderSystemCode(String providerSystemCode) {
		this.providerSystemCode = providerSystemCode;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getProviderProductDescription() {
		return providerProductDescription;
	}


	/**
	 * @param providerProductDescription
	 */
	/**
	 * @param providerProductDescription
	 */
	public void setProviderProductDescription(String providerProductDescription) {
		this.providerProductDescription = providerProductDescription;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getDownstreamSystem() {
		return downstreamSystem;
	}


	/**
	 * @param downstreamSystem
	 */
	/**
	 * @param downstreamSystem
	 */
	public void setDownstreamSystem(String downstreamSystem) {
		this.downstreamSystem = downstreamSystem;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getIsAutoRenewalAllowed() {
		return isAutoRenewalAllowed;
	}


	/**
	 * @param isAutoRenewalAllowed
	 */
	/**
	 * @param isAutoRenewalAllowed
	 */
	public void setIsAutoRenewalAllowed(String isAutoRenewalAllowed) {
		this.isAutoRenewalAllowed = isAutoRenewalAllowed;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getIsBundle() {
		return isBundle;
	}


	/**
	 * @param isBundle
	 */
	/**
	 * @param isBundle
	 */
	public void setIsBundle(String isBundle) {
		this.isBundle = isBundle;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getIsHybrid() {
		return isHybrid;
	}


	/**
	 * @param isHybrid
	 */
	/**
	 * @param isHybrid
	 */
	public void setIsHybrid(String isHybrid) {
		this.isHybrid = isHybrid;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getIsOmOrchestrationRequired() {
		return isOmOrchestrationRequired;
	}


	/**
	 * @param isOmOrchestrationRequired
	 */
	/**
	 * @param isOmOrchestrationRequired
	 */
	public void setIsOmOrchestrationRequired(String isOmOrchestrationRequired) {
		this.isOmOrchestrationRequired = isOmOrchestrationRequired;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getIsRoamingProduct() {
		return isRoamingProduct;
	}


	/**
	 * @param isRoamingProduct
	 */
	/**
	 * @param isRoamingProduct
	 */
	public void setIsRoamingProduct(String isRoamingProduct) {
		this.isRoamingProduct = isRoamingProduct;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getIsProductPaused() {
		return isProductPaused;
	}


	/**
	 * @param isProductPaused
	 */
	/**
	 * @param isProductPaused
	 */
	public void setIsProductPaused(String isProductPaused) {
		this.isProductPaused = isProductPaused;
	}


	

	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getCommunityName() {
		return communityName;
	}


	/**
	 * @param communityName
	 */
	/**
	 * @param communityName
	 */
	public void setCommunityName(String communityName) {
		this.communityName = communityName;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getOrderType() {
		return orderType;
	}


	/**
	 * @param orderType
	 */
	/**
	 * @param orderType
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}


	/**
	 * @return
	 * @throws IllegalAccessException
	 */
	public boolean checkNull() throws IllegalAccessException {
	    for (Field f : getClass().getDeclaredFields()) {
	        if (f.get(this) != null) {
	            return false;
	        }
	    }
	    return true;            
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getNetworkTemplateName() {
		return networkTemplateName;
	}


	/**
	 * @param networkTemplateName
	 */
	/**
	 * @param networkTemplateName
	 */
	public void setNetworkTemplateName(String networkTemplateName) {
		this.networkTemplateName = networkTemplateName;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getSpecCreatedDateFrom() {
		return specCreatedDateFrom;
	}


	/**
	 * @param specCreatedDateFrom
	 */
	/**
	 * @param specCreatedDateFrom
	 */
	public void setSpecCreatedDateFrom(String specCreatedDateFrom) {
		this.specCreatedDateFrom = specCreatedDateFrom;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getSpecCreatedDateTo() {
		return specCreatedDateTo;
	}


	/**
	 * @param specCreatedDateTo
	 */
	/**
	 * @param specCreatedDateTo
	 */
	public void setSpecCreatedDateTo(String specCreatedDateTo) {
		this.specCreatedDateTo = specCreatedDateTo;
	}


	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getCommunityId() {
		return communityId;
	}


	/**
	 * @param communityId
	 */
	/**
	 * @param communityId
	 */
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ComplexSearchInput [productId=" + productId
				+ ", productShortCode=" + productShortCode
				+ ", productMarketingName=" + productMarketingName
				+ ", productStatus=" + productStatus + ", productFamily="
				+ productFamily + ", productSubfamily=" + productSubfamily
				+ ", productCategory=" + productCategory
				+ ", productSubCategory=" + productSubCategory
				+ ", productType=" + productType + ", isTemplateProduct="
				+ isTemplateProduct + ", lifeValidityStartDate="
				+ lifeValidityStartDate + ", lifeValidityEndDate="
				+ lifeValidityEndDate + ", sellingStartDate="
				+ sellingStartDate + ", sellingEndDate=" + sellingEndDate
				+ ", launchDate=" + launchDate + ", initiatingChannel="
				+ initiatingChannel + ", initiatingChannelLevelMarketingName="
				+ initiatingChannelLevelMarketingName
				+ ", initiatingChannelProductId=" + initiatingChannelProductId
				+ ", productsubscriptionStartDate="
				+ subscriptionStartDate + ", productSubscriptionEndDate="
				+ subscriptionEndDate + ", salesChannel=" + salesChannel
				+ ", region=" + region + ", area=" + area + ", territory="
				+ territory + ", segmentType=" + segmentType + ", segment="
				+ segment + ", providerProductId=" + providerProductId
				+ ", productClassification=" + productClassification
				+ ", providerSystemCode=" + providerSystemCode
				+ ", providerProductDescription=" + providerProductDescription
				+ ", downstreamSystem=" + downstreamSystem
				+ ", isAutoRenewalAllowed=" + isAutoRenewalAllowed
				+ ", isBundle=" + isBundle + ", isHybrid=" + isHybrid
				+ ", isOmOrchestrationRequired=" + isOmOrchestrationRequired
				+ ", isRoamingProduct=" + isRoamingProduct
				+ ", isProductPaused=" + isProductPaused + ", communityName="
				+ communityName + ", communityId=" + communityId
				+ ", orderType=" + orderType + ", networkTemplateName="
				+ networkTemplateName + ", attributeName=" + attributeName
				+ ", attributeValue=" + attributeValue
				+ ", specCreatedDateFrom=" + specCreatedDateFrom
				+ ", specCreatedDateTo=" + specCreatedDateTo + "]";
	}
	
	
	
}
