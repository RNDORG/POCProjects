package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcActivityMaster;

/**
 * @version 1.0
 * @author VI251443
 *
 */
public interface EpcActivityMasterRepositoryCustom {
	/**
	 * 
	 * @param query
	 * @return
	 */
	List<Object[]> getList(String query);

	//EpcActivityMaster modifyActivity(EpcActivityMaster activity);
	/**
	 * 
	 * @param query
	 * @return
	 */
	List<EpcActivityMaster> getSearchResult (String query);

	

}
