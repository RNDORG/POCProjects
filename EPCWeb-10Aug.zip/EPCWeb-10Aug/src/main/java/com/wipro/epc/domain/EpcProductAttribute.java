package com.wipro.epc.domain;


import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;



/**
 * The persistent class for the epc_product_attribute database table.
 * @author VI251443
 * @version 1.0
 */
@Entity
@Table(name="epc_product_attribute")
public class EpcProductAttribute  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_attribute_id")
	private Integer productAttributeId;

	@Column(name="attribute_id")
	private Integer attributeId;

	@Column(name="attribute_uom")
	private String attributeUom;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String attributeUomValue;*/

	@Column(name="attribute_value1")
	private String attributeValue1;

	@Column(name="attribute_value2")
	private String attributeValue2;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;

	@Column(name="default_value1")
	private String defaultValue1;

	@Column(name="default_value2")
	private String defaultValue2;

	@Column(name="is_child_product_attribute",columnDefinition = "bit")
	private Byte isChildProductAttribute;

	@Column(name="is_mandatory",columnDefinition = "bit")
	private Byte isMandatory;
	
	@Column(name = "is_input_req_from_channel", columnDefinition = "bit", length = 1)
	private Byte isInputReqFromChannel;

	@Column(name="is_otc_attribute",columnDefinition = "bit")
	private Byte isOtcAttribute;

	@Column(name="is_priceing_attribute",columnDefinition = "bit")
	private Byte isPriceingAttribute;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;

	@Column(name="product_id")
	private Integer productId;

	@Column(name="status")
	private String status;
	
	@Transient
	private String reservedC;
	
	@Transient
	private String reservedCT;

	@Transient
	private Map<String,String> metaInfo;
	
	@Transient
	private EpcAttributeMaster epcAttributeMaster;
	
	
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;
	
		
	public String getAttributeUomValue() {
		this.attributeUomValue = attributeUom;
		return attributeUomValue;
	}

	public void setAttributeUomValue(String attributeUomValue) {
		this.attributeUomValue = attributeUomValue;
	}

	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}
*/

	
	/**
	 * @param metaInfo
	 */
	
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}

	/**
	 * @return
	 */
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}

	/**
	 * 
	 */
	public EpcProductAttribute() {
	}

	/**
	 * @return
	 */
	public Integer getProductAttributeId() {
		return this.productAttributeId;
	}

	/**
	 * @param productAttributeId
	 */
	public void setProductAttributeId(Integer productAttributeId) {
		this.productAttributeId = productAttributeId;
	}

	/**
	 * @return
	 */
	public Integer getAttributeId() {
		return this.attributeId;
	}

	/**
	 * @param attributeId
	 */
	public void setAttributeId(Integer attributeId) {
		this.attributeId = attributeId;
	}

	/**
	 * @return
	 */
	public String getAttributeUom() {
		return this.attributeUom;
	}

	/**
	 * @param attributeUom
	 */
	public void setAttributeUom(String attributeUom) {
		this.attributeUom = attributeUom;
	}

	/**
	 * @return
	 */
	public String getAttributeValue1() {
		return this.attributeValue1;
	}

	/**
	 * @param attributeValue1
	 */
	public void setAttributeValue1(String attributeValue1) {
		this.attributeValue1 = attributeValue1;
	}

	/**
	 * @return
	 */
	public String getAttributeValue2() {
		return this.attributeValue2;
	}

	/**
	 * @param attributeValue2
	 */
	public void setAttributeValue2(String attributeValue2) {
		this.attributeValue2 = attributeValue2;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getDefaultValue1() {
		return this.defaultValue1;
	}

	/**
	 * @param defaultValue1
	 */
	public void setDefaultValue1(String defaultValue1) {
		this.defaultValue1 = defaultValue1;
	}

	/**
	 * @return
	 */
	public String getDefaultValue2() {
		return this.defaultValue2;
	}

	/**
	 * @param defaultValue2
	 */
	public void setDefaultValue2(String defaultValue2) {
		this.defaultValue2 = defaultValue2;
	}

	/**
	 * @return
	 */
	public Byte getIsChildProductAttribute() {
		return this.isChildProductAttribute;
	}

	/**
	 * @param isChildProductAttribute
	 */
	public void setIsChildProductAttribute(Byte isChildProductAttribute) {
		this.isChildProductAttribute = isChildProductAttribute;
	}

	/**
	 * @return
	 */
	public Byte getIsMandatory() {
		return this.isMandatory;
	}

	/**
	 * @param isMandatory
	 */
	public void setIsMandatory(Byte isMandatory) {
		this.isMandatory = isMandatory;
	}
	
	/**
	 * @return
	 */
	public Byte getIsInputReqFromChannel() {
		return isInputReqFromChannel;
	}

	/**
	 * @param isInputReqFromChannel
	 */
	public void setIsInputReqFromChannel(Byte isInputReqFromChannel) {
		this.isInputReqFromChannel = isInputReqFromChannel;
	}
	
	/**
	 * @return
	 */
	public Byte getIsOtcAttribute() {
		return this.isOtcAttribute;
	}

	/**
	 * @param isOtcAttribute
	 */
	public void setIsOtcAttribute(Byte isOtcAttribute) {
		this.isOtcAttribute = isOtcAttribute;
	}

	/**
	 * @return
	 */
	public Byte getIsPriceingAttribute() {
		return this.isPriceingAttribute;
	}

	/**
	 * @param isPriceingAttribute
	 */
	public void setIsPriceingAttribute(Byte isPriceingAttribute) {
		this.isPriceingAttribute = isPriceingAttribute;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return
	 */
	public Integer getProductId() {
		return this.productId;
	}

	/**
	 * @param productId
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	
	
	/**
	 * @return
	 */
	public EpcAttributeMaster getEpcAttributeMaster() {
		return epcAttributeMaster;
	}

	/**
	 * @param epcAttributeMaster
	 */
	public void setEpcAttributeMaster(EpcAttributeMaster epcAttributeMaster) {
		this.epcAttributeMaster = epcAttributeMaster;
	}

	@Override
	public String toString() {
		return "EpcProductAttribute [productAttributeId=" + productAttributeId
				+ ", attributeId=" + attributeId + ", attributeUom=" + attributeUom
				+ ", attributeValue1=" + attributeValue1 + ", attributeValue2=" + attributeValue2
				+ ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", defaultValue1=" + defaultValue1
				+ ", defaultValue2=" + defaultValue2 + ", isChildProductAttribute="
				+ isChildProductAttribute + ", isMandatory=" + isMandatory + ", isOtcAttribute="
				+ isOtcAttribute + ", isPriceingAttribute=" + isPriceingAttribute + ", modifiedBy=" + modifiedBy
				+ ", modifiedDate="+modifiedDate+", productId="+productId+", status="+status+", metaInfo=" + metaInfo + "]";
	}

	/**
	 * @return
	 */
	public String getReservedC() {
		return reservedC;
	}

	/**
	 * @param reservedC
	 */
	public void setReservedC(String reservedC) {
		this.reservedC = reservedC;
	}

	/**
	 * @return
	 */
	public String getReservedCT() {
		return reservedCT;
	}

	/**
	 * @param reservedCT
	 */
	public void setReservedCT(String reservedCT) {
		this.reservedCT = reservedCT;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((attributeId == null) ? 0 : attributeId.hashCode());
		result = prime * result
				+ ((attributeUom == null) ? 0 : attributeUom.hashCode());
		result = prime * result
				+ ((attributeValue1 == null) ? 0 : attributeValue1.hashCode());
		result = prime * result
				+ ((attributeValue2 == null) ? 0 : attributeValue2.hashCode());
		result = prime * result
				+ ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result
				+ ((defaultValue1 == null) ? 0 : defaultValue1.hashCode());
		result = prime * result
				+ ((defaultValue2 == null) ? 0 : defaultValue2.hashCode());
		result = prime
				* result
				+ ((isChildProductAttribute == null) ? 0
						: isChildProductAttribute.hashCode());
		result = prime
				* result
				+ ((isInputReqFromChannel == null) ? 0 : isInputReqFromChannel
						.hashCode());
		result = prime * result
				+ ((isMandatory == null) ? 0 : isMandatory.hashCode());
		result = prime * result
				+ ((isOtcAttribute == null) ? 0 : isOtcAttribute.hashCode());
		result = prime
				* result
				+ ((isPriceingAttribute == null) ? 0 : isPriceingAttribute
						.hashCode());
		result = prime * result
				+ ((modifiedBy == null) ? 0 : modifiedBy.hashCode());
		result = prime * result
				+ ((modifiedDate == null) ? 0 : modifiedDate.hashCode());
		result = prime
				* result
				+ ((productAttributeId == null) ? 0 : productAttributeId
						.hashCode());
		result = prime * result
				+ ((productId == null) ? 0 : productId.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EpcProductAttribute other = (EpcProductAttribute) obj;
		if (attributeId == null) {
			if (other.attributeId != null)
				return false;
		} else if (!attributeId.equals(other.attributeId))
			return false;
		if (attributeUom == null) {
			if (other.attributeUom != null)
				return false;
		} else if (!attributeUom.equals(other.attributeUom))
			return false;
		if (attributeValue1 == null) {
			if (other.attributeValue1 != null)
				return false;
		} else if (!attributeValue1.equals(other.attributeValue1))
			return false;
		if (attributeValue2 == null) {
			if (other.attributeValue2 != null)
				return false;
		} else if (!attributeValue2.equals(other.attributeValue2))
			return false;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (defaultValue1 == null) {
			if (other.defaultValue1 != null)
				return false;
		} else if (!defaultValue1.equals(other.defaultValue1))
			return false;
		if (defaultValue2 == null) {
			if (other.defaultValue2 != null)
				return false;
		} else if (!defaultValue2.equals(other.defaultValue2))
			return false;
		if (isChildProductAttribute == null) {
			if (other.isChildProductAttribute != null)
				return false;
		} else if (!isChildProductAttribute
				.equals(other.isChildProductAttribute))
			return false;
		if (isInputReqFromChannel == null) {
			if (other.isInputReqFromChannel != null)
				return false;
		} else if (!isInputReqFromChannel.equals(other.isInputReqFromChannel))
			return false;
		if (isMandatory == null) {
			if (other.isMandatory != null)
				return false;
		} else if (!isMandatory.equals(other.isMandatory))
			return false;
		if (isOtcAttribute == null) {
			if (other.isOtcAttribute != null)
				return false;
		} else if (!isOtcAttribute.equals(other.isOtcAttribute))
			return false;
		if (isPriceingAttribute == null) {
			if (other.isPriceingAttribute != null)
				return false;
		} else if (!isPriceingAttribute.equals(other.isPriceingAttribute))
			return false;
		if (modifiedBy == null) {
			if (other.modifiedBy != null)
				return false;
		} else if (!modifiedBy.equals(other.modifiedBy))
			return false;
		if (modifiedDate == null) {
			if (other.modifiedDate != null)
				return false;
		} else if (!modifiedDate.equals(other.modifiedDate))
			return false;
		if (productAttributeId == null) {
			if (other.productAttributeId != null)
				return false;
		} else if (!productAttributeId.equals(other.productAttributeId))
			return false;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}
}