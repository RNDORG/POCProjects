package com.wipro.epc.repositories;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcProductNetworkTplMap;


/**
 * @author KE334465
 *
 */
public class EpcProductNetworkTplMapRepositoryImpl implements EpcProductNetworkTplMapRepositoryCustom{
	
	private static Logger logger =LoggerFactory.getLogger(EpcProductNetworkTplMapRepositoryImpl.class);
	
	@PersistenceContext
	private EntityManager em;

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductNetworkTplMapRepositoryCustom#modifyNetworkId(com.wipro.epc.domain.EpcProductNetworkTplMap)
	 */
	@Override
	public void modifyNetworkId(EpcProductNetworkTplMap networkMap)
	{
		StringBuilder queryBuilder = new StringBuilder("update epc_product_network_tpl_map set product_id="+networkMap.getProductId());
		////System.out.println("networkMap.getTemplateName() IN MODIFY"+networkMap.getTemplateName());
		/*if(networkMap.getTemplateId()!=null)
			queryBuilder.append(",").append(" template_id = '").append(networkMap.getTemplateId()).append("'");*/
		if(networkMap.getTemplateName()!=null) {
			queryBuilder.append(",").append(" template_name = '").append(networkMap.getTemplateName()).append("'");
		}
		if(networkMap.getModifiedDate()!=null){
			queryBuilder.append(",").append(" modify_date = '").append(new SimpleDateFormat().format(new Date())).append("'");
		}
		if(networkMap.getModifiedBy()!=null){
			queryBuilder.append(",").append(" modified_by = '").append(networkMap.getModifiedBy()).append("'");
		}
		
		queryBuilder.append(" where product_id=").append(networkMap.getProductId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		//System.out.println(query);
		em.createNativeQuery(query).executeUpdate();
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductNetworkTplMapRepositoryCustom#getNetworkTemplateMapList(java.lang.String)
	 */
	@Override
	public List<EpcProductNetworkTplMap> getNetworkTemplateMapList(String query){
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductNetworkTplMap.class).getResultList();
	
	}

	/**
	 * @return
	 */
	public EntityManager getEm() {
		return em;
	}

	/**
	 * @param em
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}
}
