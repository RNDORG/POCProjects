package com.wipro.epc.repositories;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcProductAvailability;

public class EpcProductAvailabilityRepositoryImpl implements EpcProductAvailabilityRepositoryCustom{

	private static Logger logger =LoggerFactory.getLogger(EpcProductAvailabilityRepositoryImpl.class);
	
	@PersistenceContext
	private EntityManager em; 
	
	private DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
	private DateFormat sdfTime = new SimpleDateFormat("kk:mm:ss");
	
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductAvailabilityRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcProductAvailability> getList(String query) {
		logger.debug("#Query: "+query);
		////System.out.println((List<EpcProductAvailability>)em.createNativeQuery(query, EpcProductAvailability.class).getResultList());
		return em.createNativeQuery(query, EpcProductAvailability.class).getResultList();
	}

	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductAvailabilityRepositoryCustom#modifyProductAvailability(com.wipro.epc.domain.EpcProductAvailability)
	 */
	@Override
	public EpcProductAvailability modifyProductAvailability(EpcProductAvailability productAvailability)
	{		
			//sdf.setTimeZone(TimeZone.getDefault());
			//sdfTime.setTimeZone(TimeZone.getDefault());
			StringBuilder queryBuilder = new StringBuilder("update epc_product_availability set product_availability_id="+productAvailability.getProductAvailabilityId());
			//System.out.println("productAvailability.getLifeValidityStartDate() >>>>"+productAvailability.getLifeValidityStartDate());
			if(productAvailability.getStatus()!=null){
				queryBuilder.append(",").append(" status = '").append(productAvailability.getStatus()).append("'");
			}
			if(productAvailability.getLifeValidityStartDate()!=null){
				queryBuilder.append(",").append(" life_validity_start_date = '").append(rectifyHourComponent(sdf.format(productAvailability.getLifeValidityStartDate()))).append("'");
			}
			if(productAvailability.getLifeValidityEndDate()!=null){
				queryBuilder.append(",").append(" life_validity_end_date = '").append(rectifyHourComponent(sdf.format(productAvailability.getLifeValidityEndDate()))).append("'");
			}
			if(productAvailability.getSellingStartDate()!=null){
				queryBuilder.append(",").append(" selling_start_date = '").append(rectifyHourComponent(sdf.format(productAvailability.getSellingStartDate()))).append("'");
			}
			if(productAvailability.getSellingEndDate()!=null){
				queryBuilder.append(",").append(" selling_end_date = '").append(rectifyHourComponent(sdf.format(productAvailability.getSellingEndDate()))).append("'");
			}
			if(productAvailability.getSubscriptionStartDate()!=null){
				queryBuilder.append(",").append(" subscription_start_date= '").append(rectifyHourComponent(sdf.format(productAvailability.getSubscriptionStartDate()))).append("'");
			}
			if(productAvailability.getSubscriptionEndDate()!=null){
				queryBuilder.append(",").append(" subscription_end_date = '").append(rectifyHourComponent(sdf.format(productAvailability.getSubscriptionEndDate()))).append("'");
			}
			if(productAvailability.getActiveBusinessHourFrom()!=null){
				queryBuilder.append(",").append(" active_business_hour_from = '").append(sdfTime.format(productAvailability.getActiveBusinessHourFrom())).append("'");
			}
			if(productAvailability.getActiveBusinessHourTo()!=null){
				queryBuilder.append(",").append(" active_business_hour_to = '").append(sdfTime.format(productAvailability.getActiveBusinessHourTo())).append("'");
			}
			if(productAvailability.getLaunchDate()!=null){
				queryBuilder.append(",").append(" launch_date= '").append(rectifyHourComponent(sdf.format(productAvailability.getLaunchDate()))).append("'");
			}
			if(productAvailability.getSubscriptionDuration()!=null){
				queryBuilder.append(",").append(" subscription_duration= '").append(productAvailability.getSubscriptionDuration()).append("'");
			}
			if(productAvailability.getSubscriptionDurationUom()!=null){
				queryBuilder.append(",").append(" subscription_duration_uom= '").append(productAvailability.getSubscriptionDurationUom()).append("'");
			}
			queryBuilder.append(" where product_availability_id=").append(productAvailability.getProductAvailabilityId());
			String query = queryBuilder.toString();
			logger.debug("#Query: "+query);
			em.createNativeQuery(query).executeUpdate();
		return productAvailability;
	}
	
	/**
	 * @param str
	 * @return
	 */
	private String rectifyHourComponent(String str){
		str = str.replaceFirst(" 24:"," 00:");
		return str;
	}


	/**
	 * @return
	 */
	public EntityManager getEm() {
		return em;
	}


	/**
	 * @param em
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}


	/**
	 * @return
	 */
	public DateFormat getSdf() {
		return sdf;
	}


	/**
	 * @param sdf
	 */
	public void setSdf(DateFormat sdf) {
		this.sdf = sdf;
	}


	/**
	 * @return
	 */
	public DateFormat getSdfTime() {
		return sdfTime;
	}


	/**
	 * @param sdfTime
	 */
	public void setSdfTime(DateFormat sdfTime) {
		this.sdfTime = sdfTime;
	}


}
