
package com.wipro.epc.esb.getesbcomstransactionhistory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrderStatusResponseListItemType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderStatusResponseListItemType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Circle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrderCreationTimeStamp" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustNewIMSI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustNewMSISDN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustOldIMSI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustMSISDN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OrderID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrderStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrderType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestorMSISDN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Source" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="System" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransactionRemarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransactionStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MarketingName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="offerId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VanityPrice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderStatusResponseListItemType", propOrder = {
    "circle",
    "orderCreationTimeStamp",
    "custNewIMSI",
    "custNewMSISDN",
    "custOldIMSI",
    "custMSISDN",
    "orderID",
    "orderStatus",
    "orderType",
    "requestorMSISDN",
    "source",
    "system",
    "transactionRemarks",
    "transactionStatus",
    "marketingName",
    "offerId",
    "vanityPrice"
})
public class OrderStatusResponseListItemType {

    @XmlElement(name = "Circle")
    protected String circle;
    @XmlElement(name = "OrderCreationTimeStamp", required = true)
    protected String orderCreationTimeStamp;
    @XmlElement(name = "CustNewIMSI")
    protected String custNewIMSI;
    @XmlElement(name = "CustNewMSISDN")
    protected String custNewMSISDN;
    @XmlElement(name = "CustOldIMSI")
    protected String custOldIMSI;
    @XmlElement(name = "CustMSISDN", required = true)
    protected String custMSISDN;
    @XmlElement(name = "OrderID")
    protected String orderID;
    @XmlElement(name = "OrderStatus")
    protected String orderStatus;
    @XmlElement(name = "OrderType")
    protected String orderType;
    @XmlElement(name = "RequestorMSISDN")
    protected String requestorMSISDN;
    @XmlElement(name = "Source")
    protected String source;
    @XmlElement(name = "System")
    protected String system;
    @XmlElement(name = "TransactionRemarks")
    protected String transactionRemarks;
    @XmlElement(name = "TransactionStatus")
    protected String transactionStatus;
    @XmlElement(name = "MarketingName")
    protected String marketingName;
    protected String offerId;
    @XmlElement(name = "VanityPrice")
    protected String vanityPrice;

    /**
     * Gets the value of the circle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCircle() {
        return circle;
    }

    /**
     * Sets the value of the circle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCircle(String value) {
        this.circle = value;
    }

    /**
     * Gets the value of the orderCreationTimeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderCreationTimeStamp() {
        return orderCreationTimeStamp;
    }

    /**
     * Sets the value of the orderCreationTimeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderCreationTimeStamp(String value) {
        this.orderCreationTimeStamp = value;
    }

    /**
     * Gets the value of the custNewIMSI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustNewIMSI() {
        return custNewIMSI;
    }

    /**
     * Sets the value of the custNewIMSI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustNewIMSI(String value) {
        this.custNewIMSI = value;
    }

    /**
     * Gets the value of the custNewMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustNewMSISDN() {
        return custNewMSISDN;
    }

    /**
     * Sets the value of the custNewMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustNewMSISDN(String value) {
        this.custNewMSISDN = value;
    }

    /**
     * Gets the value of the custOldIMSI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustOldIMSI() {
        return custOldIMSI;
    }

    /**
     * Sets the value of the custOldIMSI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustOldIMSI(String value) {
        this.custOldIMSI = value;
    }

    /**
     * Gets the value of the custMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustMSISDN() {
        return custMSISDN;
    }

    /**
     * Sets the value of the custMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustMSISDN(String value) {
        this.custMSISDN = value;
    }

    /**
     * Gets the value of the orderID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderID() {
        return orderID;
    }

    /**
     * Sets the value of the orderID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderID(String value) {
        this.orderID = value;
    }

    /**
     * Gets the value of the orderStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderStatus() {
        return orderStatus;
    }

    /**
     * Sets the value of the orderStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderStatus(String value) {
        this.orderStatus = value;
    }

    /**
     * Gets the value of the orderType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderType() {
        return orderType;
    }

    /**
     * Sets the value of the orderType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderType(String value) {
        this.orderType = value;
    }

    /**
     * Gets the value of the requestorMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestorMSISDN() {
        return requestorMSISDN;
    }

    /**
     * Sets the value of the requestorMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestorMSISDN(String value) {
        this.requestorMSISDN = value;
    }

    /**
     * Gets the value of the source property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSource() {
        return source;
    }

    /**
     * Sets the value of the source property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSource(String value) {
        this.source = value;
    }

    /**
     * Gets the value of the system property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystem() {
        return system;
    }

    /**
     * Sets the value of the system property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystem(String value) {
        this.system = value;
    }

    /**
     * Gets the value of the transactionRemarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionRemarks() {
        return transactionRemarks;
    }

    /**
     * Sets the value of the transactionRemarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionRemarks(String value) {
        this.transactionRemarks = value;
    }

    /**
     * Gets the value of the transactionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Sets the value of the transactionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionStatus(String value) {
        this.transactionStatus = value;
    }

    /**
     * Gets the value of the marketingName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarketingName() {
        return marketingName;
    }

    /**
     * Sets the value of the marketingName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarketingName(String value) {
        this.marketingName = value;
    }

    /**
     * Gets the value of the offerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferId() {
        return offerId;
    }

    /**
     * Sets the value of the offerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferId(String value) {
        this.offerId = value;
    }

    /**
     * Gets the value of the vanityPrice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVanityPrice() {
        return vanityPrice;
    }

    /**
     * Sets the value of the vanityPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVanityPrice(String value) {
        this.vanityPrice = value;
    }

}
