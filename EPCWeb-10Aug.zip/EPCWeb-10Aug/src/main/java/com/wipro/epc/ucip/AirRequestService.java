package com.wipro.epc.ucip;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.epc.ucip.domains.ArrayType;
import com.wipro.epc.ucip.domains.DataType;
import com.wipro.epc.ucip.domains.MemberType;
import com.wipro.epc.ucip.domains.MethodResponseType;
import com.wipro.epc.ucip.domains.ParamType;
import com.wipro.epc.ucip.domains.ParamsType;
import com.wipro.epc.ucip.domains.StructType;
import com.wipro.epc.ucip.domains.ValueType;

/**
 * @author Developer
 * @version 1.0
 * type AirRequestService
 */
@Service
public class AirRequestService
{
  /**
 * StringBuilder AirRequestService.java
 */
private static StringBuilder airInput;
  /**
 * Logger AirRequestService.java
 */
private static Logger logger = LoggerFactory.getLogger(AirRequestService.class);
  
  /**
 * String AirRequestService.java
 */
private static String userName = "wipro";
  /**
 * String AirRequestService.java
 */
private static String password = "wipro@123";
  /**
 * String AirRequestService.java
 */
private static String urlInput = "http://10.171.33.37:10010/Air";
  /**
 * String AirRequestService.java
 */
private static String auth = "basic";
  /**
 * String AirRequestService.java
 */
private static String reqMethod = "POST";
  /**
 * String AirRequestService.java
 */
private static String userAgent = "IVR/4.3/1.0";
  /**
 * String AirRequestService.java
 */
private static String contentType = "text/xml";
  /**
 * String AirRequestService.java
 */
private static String host = "RMS_ESB1:7001";
  /**
 * SimpleDateFormat AirRequestService.java
 */
private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss");

/**
 * ObjectMapper AirRequestService.java
 */
@Autowired
ObjectMapper mapper;
  
  /**
 * @param msisdn
 * @return
 * @throws SQLException
 * @throws XmlException
 */
public String getRatePlan(String msisdn) throws SQLException, XmlException {
	
		StringBuilder xmlRequestAir = new StringBuilder();
		xmlRequestAir.append("<methodCall><methodName>GetBalanceAndDate</methodName><params><param><value><struct><member><name>originNodeType</name><value><string>BSCSCX</string></value></member><member><name>originHostName</name><value><string>BSCSCX</string></value></member><member><name>originTransactionID</name><value><string>12345</string></value></member><member><name>originTimeStamp</name><value><dateTime.iso8601>");
		xmlRequestAir.append(sdf.format(new Date()));
		xmlRequestAir.append("+0050</dateTime.iso8601></value></member><member><name>subscriberNumberNAI</name><value><int>1</int></value></member><member><name>subscriberNumber</name><value><string>");
		xmlRequestAir.append(msisdn);
		xmlRequestAir.append("</string></value></member><member><name>requestPamInformationFlag</name><value><boolean>1</boolean></value></member></struct></value></param></params></methodCall>");
		//System.out.println(xmlRequestAir);				
		airInput = xmlRequestAir;
		
		String str =  processAIROrder(airInput, userName, password, urlInput, auth, reqMethod, userAgent, contentType, host, msisdn);
		if(str != null && str.indexOf("serviceClassCurrent</name><value><i4>") != -1){
			str = str.substring(str.indexOf("serviceClassCurrent</name><value><i4>")+37, str.indexOf("</i4></value></member><member><name>serviceFeeExpiryDate"));
		}
		logger.info("primaryProviderId from CBIO >>>>" + str);
		return str;
		
	}
  
  
  /**
 * @param msisdn
 * @return
 * @throws SQLException
 * @throws XmlException
 * @throws JAXBException
 */
public List<String> getSubscribedOffers(String msisdn) throws SQLException, XmlException, JAXBException {
		StringBuilder xmlRequestAir = new StringBuilder();
		xmlRequestAir.append("<methodCall><methodName>GetOffers</methodName><params><param><value><struct><member><name>originNodeType</name><value><string>EXT</string></value></member><member><name>originHostName</name><value><string>tbair1</string></value></member><member><name>originTransactionID</name><value><string>12345</string></value></member><member><name>originTimeStamp</name><value><dateTime.iso8601>");
		xmlRequestAir.append(sdf.format(new Date()));
		xmlRequestAir.append("+0200</dateTime.iso8601></value></member><member><name>subscriberNumber</name><value><string>");
		xmlRequestAir.append(msisdn);
		xmlRequestAir.append("</string></value></member></struct></value></param></params></methodCall>");
		//System.out.println(xmlRequestAir);				
		airInput = xmlRequestAir;
		
		String str =  processAIROrder(airInput, userName, password, urlInput, auth, reqMethod, userAgent, contentType, host, msisdn);
		//"<methodCall><methodName>GetOffers</methodName><params><param><value><struct><member><name>originNodeType</name><value><string>EXT</string></value></member><member><name>originHostName</name><value><string>tbair1</string></value></member><member><name>originTransactionID</name><value><string>12345</string></value></member><member><name>originTimeStamp</name><value><dateTime.iso8601>20160811T12:11:39+0200</dateTime.iso8601></value></member><member><name>subscriberNumber</name><value><string>1700734939</string></value></member></struct></value></param></params></methodCall>"
		//String str = "<methodResponse><params><param><value><struct><member><name>offerInformation</name><value><array><data><value><struct><member><name>expiryDate</name><value><dateTime.iso8601>99991231T00:00:00+1200</dateTime.iso8601></value></member><member><name>offerID</name><value><i4>1100</i4></value></member><member><name>offerType</name><value><i4>0</i4></value></member><member><name>startDate</name><value><dateTime.iso8601>20161017T12:00:00+0000</dateTime.iso8601></value></member></struct></value><value><struct><member><name>expiryDate</name><value><dateTime.iso8601>99991231T00:00:00+1200</dateTime.iso8601></value></member><member><name>offerID</name><value><i4>1101</i4></value></member><member><name>offerType</name><value><i4>0</i4></value></member><member><name>startDate</name><value><dateTime.iso8601>20161017T12:00:00+0000</dateTime.iso8601></value></member></struct></value><value><struct><member><name>expiryDate</name><value><dateTime.iso8601>99991231T00:00:00+1200</dateTime.iso8601></value></member><member><name>offerID</name><value><i4>1102</i4></value></member><member><name>offerType</name><value><i4>0</i4></value></member><member><name>startDate</name><value><dateTime.iso8601>20161017T12:00:00+0000</dateTime.iso8601></value></member></struct></value><value><struct><member><name>expiryDate</name><value><dateTime.iso8601>99991231T00:00:00+1200</dateTime.iso8601></value></member><member><name>offerID</name><value><i4>1103</i4></value></member><member><name>offerType</name><value><i4>0</i4></value></member><member><name>startDate</name><value><dateTime.iso8601>20161017T12:00:00+0000</dateTime.iso8601></value></member></struct></value><value><struct><member><name>expiryDate</name><value><dateTime.iso8601>99991231T00:00:00+1200</dateTime.iso8601></value></member><member><name>offerID</name><value><i4>6010</i4></value></member><member><name>offerType</name><value><i4>0</i4></value></member><member><name>startDate</name><value><dateTime.iso8601>20161019T12:00:00+0000</dateTime.iso8601></value></member></struct></value></data></array></value></member><member><name>originTransactionID</name><value><string>12345</string></value></member><member><name>responseCode</name><value><i4>0</i4></value></member></struct></value></param></params></methodResponse>";
		List<String> productShortCodes = new ArrayList<String>();
		if(str != null){
			JAXBContext jaxbContext = JAXBContext.newInstance(MethodResponseType.class);
	        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();    
	        StringReader reader = new StringReader(str);
	        MethodResponseType methodResponseType=(MethodResponseType) jaxbUnmarshaller.unmarshal(reader);
	        ParamsType paramsType = null;
	        ParamType paramType = null;
	        ValueType valueType = null;
	        StructType  structType = null;
	        List<MemberType> memberList = null;
	        MemberType memberType = null;
	        ValueType mValueType = null;
	        ArrayType arrayType = null;
	        DataType dataType = null;
	        List<ValueType> valueList = null;
	        StructType  vStructType = null;
	        List<MemberType> vMemberList = null;
	        ValueType vValueType = null;
	        
	        if(methodResponseType != null){
	        	paramsType = methodResponseType.getParams();
	        	if(paramsType != null){
	        		paramType = paramsType.getParam();
	        		if(paramType != null){
	        			valueType = paramType.getValue();
	        			if(valueType != null){
	        				structType = valueType.getStruct();
	        				if (structType != null){
	        					memberList =structType.getMember();
	        					if(memberList != null && !memberList.isEmpty()){
	        						for (MemberType member : memberList){
	        							if("offerInformation".equals(member.getName())){
	        								memberType = member;
	        							}
	        							break;
	        						}
	        						if(memberType != null){
	        							mValueType  = memberType.getValue();
	        							if(mValueType != null){
	        								arrayType = mValueType.getArray();
	        								if(arrayType != null){
	        									dataType  = arrayType.getData();
	        									if(dataType != null){
	        										valueList = dataType.getValue();
	        										if(valueList != null && !valueList.isEmpty()){
	        											for (ValueType value : valueList){
	        												vStructType = value.getStruct();
	        												if(vStructType != null){
	        													vMemberList = vStructType.getMember();
	        													if (vMemberList != null && !vMemberList.isEmpty()){
	        														for (MemberType vMember : vMemberList){
	        															if("offerID".equals(vMember.getName())){
	        																vValueType = vMember.getValue();
	        																if(vValueType != null){
	        																	productShortCodes.add(String.valueOf(vValueType.getI4()));
	        																}
	        															}
	        														}
	        													}
	        												}
	        											}
	        										}
	        									}
	        								}
	        							}
	        						}
	        					}
	        				}
	        			}
	        		}
	        	}
	        }
		}
		if(!productShortCodes.isEmpty()){
			try {
				logger.info("Subscribed Products from CBIO >>>>" + mapper.writeValueAsString(productShortCodes));
			} catch (JsonProcessingException e) {
				logger.info("Exception during JSON conversion >>"+ExceptionUtils.getStackTrace(e));
			}
			return productShortCodes;
		}
		else{
			logger.info("No Subscribed Product returned from CBIO.");
			return null;
		}
		
	}
  
  
  /**
 * @param airInput
 * @param userName
 * @param password
 * @param urlInput
 * @param auth
 * @param reqMethod
 * @param userAgent
 * @param contentType
 * @param host
 * @param msisdn
 * @return
 */
private String processAIROrder(StringBuilder airInput, String userName, String password, String urlInput, String auth, String reqMethod, String userAgent, String contentType, String host, String msisdn )
  {
    HttpURLConnection conn = null;
    BufferedReader br = null;
    OutputStream os = null;
    
    logger.debug("[host]" + host + "[userName]" + userName + "[password]" + password + "[urlInput]" + urlInput + "[reqMethod]" + reqMethod + "[userAgent]" + userAgent + "[contentType]" + contentType + "[host]" + host);
     
    try
    {
      String input = "<?xml version=\"1.0\"?>" + airInput;
      
      String authString = userName + " : " + password;
      logger.debug("username--->" + userName);
      //logger.debug("Password--->" + password);
      
      byte[] authEncBytes = Base64.encodeBase64(authString.getBytes());
      String authStringEnc = new String(authEncBytes);
      logger.debug("Base64 encoded auth string--->" + authStringEnc);    
      
      
      URL url = new URL(urlInput);
      conn = (HttpURLConnection)url.openConnection();
      conn.setRequestProperty("Authorization", auth + " " + authStringEnc);
      conn.setDoOutput(true);
      conn.setRequestMethod(reqMethod);
      conn.setRequestProperty("Content-Type", contentType);
      conn.setRequestProperty("Content-Length", Integer.toString(input.length()));
      conn.setRequestProperty("User-Agent", userAgent);
      conn.setRequestProperty("Host", host);
      
      logger.debug(conn.getRequestProperty("Content-Type") + " : " + 
        conn.getRequestProperty("Content-Length") + " : " + 
        conn.getRequestProperty("User-Agent") + " : " + 
        conn.getRequestProperty("Host"));
      
      logger.info("Input to CBIO--->" + input);
      os = conn.getOutputStream();
      os.write(input.getBytes());
      os.flush();
     
      logger.debug("Fetching output--->");
      br = new BufferedReader(new InputStreamReader(conn.getInputStream()));  
     
      logger.debug("output fetched--->");      
      String output = "";
      String finalOutput = "";
      logger.debug("Printing output--->");
      
      while ((output = br.readLine()) != null) 
      {
        finalOutput = finalOutput.concat(output);
      }
      
      logger.info("final output from CBIO--->" + finalOutput);
      
      if(finalOutput.contains("<name>responseCode</name><value><i4>0</i4></value>")) {
    	  return finalOutput;
      }
      return null;
    }
    
    catch (Exception e)
    {
    	logger.error(ExceptionUtils.getStackTrace(e));
      logger.debug("Exception is--->" + e.getMessage());
      return null;
    }
 
    finally
    {
      try
      {
        logger.debug("Closing I/O Streams");        
        if (br != null)
        {
          br.close();
          os.close();
        }
        else
        {
          logger.debug("Connection not established with AIR");
        }
        logger.debug("Closed");        
      }
      catch (IOException e)
      {
        logger.debug("Exception while closing I/O stream is--->" + e.getMessage());
      }      
      logger.debug("disconnecting from AIR");      
      conn.disconnect();      
      logger.debug("Connection Disconnected");      
    }
  }
  
}

