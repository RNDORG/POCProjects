package com.wipro.epc.repositories;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcActivityDetail;

/**
 * @author Developer
 * @version 1.0
 * type EpcActivityDetailRepository
 */
@Repository
public interface EpcActivityDetailRepository extends CrudRepository<EpcActivityDetail, Integer>
{
	/**
	 * @param activityName
	 */
	@Modifying
	@Query(value="delete from epc_activity_detail where activity_id = (select activity_id from epc_activity_master where activity_name = :name)", nativeQuery = true)
	void deleteFromDetail(@Param(value="name") String activityName);
	
	/**
	 * @param id
	 * @param key
	 * @param value
	 */
	@Modifying
	@Query(value="update epc_activity_detail set activity_key = :key ,activity_value = :value where activity_detail_id = :id", nativeQuery = true)
	void updateDetail(@Param(value="id") Integer id, @Param(value="key") String key, @Param(value="value") String value);
}
