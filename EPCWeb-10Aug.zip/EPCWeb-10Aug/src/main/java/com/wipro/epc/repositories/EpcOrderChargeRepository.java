
package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcOrderCharge;

/**
 * @author Developer
 * @version 1.0
 * type EpcOrderChargeRepository
 */
public interface EpcOrderChargeRepository extends CrudRepository<EpcOrderCharge, Integer>,EpcOrderChargeRepositoryCustom{

	 /**
	 * @param orderChannelRuleId
	 */
	@Modifying
		@Query(value="delete from epc_order_charge where order_channel_rule_id=:orderChannelRuleId", nativeQuery=true)
		void deleteOrderFromChannel(@Param("orderChannelRuleId") Integer orderChannelRuleId);
	    
	   /**
	 * @param orderChannelRuleId
	 * @return
	 */
	@Query(value="select * from epc_order_charge where order_channel_rule_id =:orderChannelRuleId", nativeQuery=true)
		EpcOrderCharge findOrderChargeByOrderChannelRuleId(@Param("orderChannelRuleId") Integer orderChannelRuleId);
	   
	   /**
	 * @param orderChannelRuleId
	 * @return
	 */
	@Query(value="select * from epc_order_charge where order_channel_rule_id =:orderChannelRuleId", nativeQuery=true)
	 		List<EpcOrderCharge> findOrderChargeByOrderChannelRule(@Param("orderChannelRuleId") Integer orderChannelRuleId);
	
}
