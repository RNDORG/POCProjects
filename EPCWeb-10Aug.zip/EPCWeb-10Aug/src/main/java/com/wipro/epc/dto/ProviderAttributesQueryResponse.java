package com.wipro.epc.dto;

import java.util.List;

/**
 * @author Developer
 * @version 1.0
 * type ProviderProductResponse
 */
public class ProviderAttributesQueryResponse {

	private List<FNFCallblockAttribute> fnf;
	private List<FNFCallblockAttribute> callblock;
	private List<FNFCallblockAttribute> fnfTariff;
	private List<FNFCallblockAttribute> callblockTariff;
	/**
	 * @return the fnf
	 */
	public List<FNFCallblockAttribute> getFnf() {
		return fnf;
	}
	/**
	 * @param fnf the fnf to set
	 */
	public void setFnf(List<FNFCallblockAttribute> fnf) {
		this.fnf = fnf;
	}
	/**
	 * @return the callblock
	 */
	public List<FNFCallblockAttribute> getCallblock() {
		return callblock;
	}
	/**
	 * @param callblock the callblock to set
	 */
	public void setCallblock(List<FNFCallblockAttribute> callblock) {
		this.callblock = callblock;
	}
	/**
	 * @return the fnfTariff
	 */
	public List<FNFCallblockAttribute> getFnfTariff() {
		return fnfTariff;
	}
	/**
	 * @param fnfTariff the fnfTariff to set
	 */
	public void setFnfTariff(List<FNFCallblockAttribute> fnfTariff) {
		this.fnfTariff = fnfTariff;
	}
	/**
	 * @return the callblockTariff
	 */
	public List<FNFCallblockAttribute> getCallblockTariff() {
		return callblockTariff;
	}
	/**
	 * @param callblockTariff the callblockTariff to set
	 */
	public void setCallblockTariff(List<FNFCallblockAttribute> callblockTariff) {
		this.callblockTariff = callblockTariff;
	}
}
