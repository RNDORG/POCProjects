package com.wipro.epc.security;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.wipro.common.config.service.ConfigService;

/**
 * @author Developer
 * @version 1.0
 * type EPCWebSecurityConfigurationAdapter
 */
public class EPCWebSecurityConfigurationAdapter extends WebSecurityConfigurerAdapter {
	
	private static Logger logger = LoggerFactory.getLogger(EPCWebSecurityConfigurationAdapter.class);
	/**
	 * DataSource EPCWebSecurityConfigurationAdapter.java
	 */
	@Autowired
	private DataSource dataSource;
/*
	 (non-Javadoc)
	 * @see org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter#configure(org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder)
	 
	@Override
	public void configure(AuthenticationManagerBuilder auth)
			throws Exception {
		auth.jdbcAuthentication().dataSource(this.dataSource);

	}
	*/
	@Autowired
	private CustomAuthenticationProvider customAuthenticationProvider;
	
 
    @Autowired
    ConfigService config;
	
    @Autowired
    CustomUserDetailsService customUserService;
    
    @Autowired
    public CustomLdapAuthoritiesPopulator ldapAuthoritiesPopulator;
	
    @Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		String config_value=config.getConfigValueFromDb("Authentication","AuthenticationType"); //This is before cache creation
		if ( !config_value.equals("LDAP") && !config_value.equals("CUSTOM") && !config_value.equals("JDBC_CUSTOM") && !config_value.equals("JDBC_BASIC") )
		{logger.warn("Please enter the correct Authentication type. Config Key given: "+config_value);
			config_value="JDBC_BASIC";
			
		}
		
			logger.warn("Incorrect Authentication ");
		
		try {
		logger.info("in configure() method ========================");
		
		//auth.inMemoryAuthentication().withUser(user).password("nocuser").authorities(listOfRoles); //.roles(listOfRoles );

		// ===================  LDAP Authentication  ===================================
		if(config_value.equals("LDAP"))
			{System.out.println("inside ldap config------------------------------------------------------>>>");
			String contextSource =config.searchConfigKey("LDAPConfig","contextSource").getConfigValue();
			String managerDn =config.searchConfigKey("LDAPConfig","managerDn").getConfigValue();
			String managerPassword =config.searchConfigKey("LDAPConfig","managerPassword").getConfigValue();
			String userSearchFilter =config.searchConfigKey("LDAPConfig","userSearchFilter").getConfigValue();
			
			if(contextSource == null || managerDn == null || managerPassword == null || userSearchFilter == null)
			{
				logger.error("searchConfigKey returned Null For one of the LDAPConfig Values. Please check Config Table");
			}
			
			auth.ldapAuthentication().contextSource().url(contextSource)
            		.managerDn(managerDn).managerPassword(managerPassword).and()
            	.userSearchFilter(userSearchFilter)
            	.ldapAuthoritiesPopulator(ldapAuthoritiesPopulator);
			
			}
		
		
		// =================== Custom Authentication ======================================	
		else if(config_value.equals("CUSTOM")){	
		auth.authenticationProvider(customAuthenticationProvider); // CustomAuthentication Worked well !! 
		}
		// =================== JDBC Authentication ======================================

		// Spring uses its own User POJO and assumes you have a Users and Authorities Table!	
		else if(config_value.equals("JDBC_BASIC")){System.out.println("inside jdbc-------------------------------------->>>>");
		auth.jdbcAuthentication().dataSource(this.dataSource); 
		}
		else if(config_value.equals("JDBC_CUSTOM")) {
				
		auth.userDetailsService(customUserService); // Use this for JDBC, if your table name/structure is different. 			
		}
		
		logger.info("after jdbc ===========================");
		} catch ( Exception e ) {System.out.println("security jdbc custom");
			logger.info("Hmm.. Caught Exception : " + e.getClass().getName() + " " + e.getMessage() );
			throw e;
		}
	}
}
