package com.wipro.epc.repositories;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcProductHeirarchy;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductHeirarchyRepositoryImpl
 */
public class EpcProductHeirarchyRepositoryImpl implements EpcProductHeirarchyRepositoryCustom{


	private static Logger logger =LoggerFactory.getLogger(EpcProductHeirarchyRepositoryImpl.class);
	
	
	/**
	 * EntityManager EpcProductHeirarchyRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductHeirarchyRepositoryCustom#getEpcProductHeirarchyList(java.lang.String)
	 */
	@Override
	public List<EpcProductHeirarchy> getEpcProductHeirarchyList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductHeirarchy.class).getResultList();

	}
	
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductHeirarchyRepositoryCustom#modifyProductHeirarchy(com.wipro.epc.domain.EpcProductHeirarchy)
	 */
	@Override
	public EpcProductHeirarchy modifyProductHeirarchy(EpcProductHeirarchy heirarchy) {
		
		////System.out.println("UPDATE 3");
		//System.out.println(heirarchy);
		StringBuilder queryBuilder = new StringBuilder("update epc_product_heirarchy set  product_heirarchy_id='"+heirarchy.getProductHeirarchyId()+"'");
		
		if(heirarchy.getParentProductId()!=null)
			queryBuilder.append(",").append(" parent_product_id = ").append(heirarchy.getParentProductId());
		if(heirarchy.getChildProductId()!=null )
			queryBuilder.append(",").append(" child_product_id = ").append(heirarchy.getChildProductId());
		if(heirarchy.getStatus()!=null)
			queryBuilder.append(",").append(" status = '").append(heirarchy.getStatus()).append("'");
		if(heirarchy.getModifiedBy()!=null)
			queryBuilder.append(",").append(" modified_by = '").append(heirarchy.getModifiedBy()).append("'");
		if(heirarchy.getModifiedDate()!=null)
			queryBuilder.append(",").append(" modified_date = '").append(new SimpleDateFormat().format(new Date())).append("'");
		
		////System.out.println("UPDATE 4");
		queryBuilder.append(" where product_heirarchy_id =").append(heirarchy.getProductHeirarchyId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		////System.out.println("UPDATE 5");
		//System.out.println(query);
		em.createNativeQuery(query).executeUpdate();
		
		return heirarchy;
	}

/*	StringBuilder queryBuilder = new StringBuilder("update epc_product_heirarchy set  product_heirarchy_id='"+heirarchy.getProductHeirarchyId()+"'");
		
		if(heirarchy.getParentProductId()!=0 && heirarchy.getParentProductId()!=null)
			queryBuilder.append(",").append(" parent_product_id = ").append(heirarchy.getParentProductId());
		if(heirarchy.getChildProductId()!=null && heirarchy.getChildProductId()!=0)
			queryBuilder.append(",").append(" child_product_id = ").append(heirarchy.getChildProductId());
		if(heirarchy.getStatus()!=null)
			queryBuilder.append(",").append(" status = '").append(heirarchy.getStatus()).append("'");
		if(heirarchy.getModifiedBy()!=null)
			queryBuilder.append(",").append(" modified_by = '").append(heirarchy.getModifiedBy()).append("'");
		//needs clarification
		if(heirarchy.getModifiedDate()!=null)
			queryBuilder.append(",").append(" modified_date = '").append(new SimpleDateFormat().format(new Date())).append("'");
		//System.out.println("UPDATE 4");
		queryBuilder.append(" where product_heirarchy_id =").append(heirarchy.getProductHeirarchyId());
		String query = queryBuilder.toString();
		//System.out.println("UPDATE 5");
		//System.out.println(query);
		em.createNativeQuery(query).executeUpdate();*/
	

}
