/**
 * EPC Application - EpcFlexiPlanRepository.java
 */
package com.wipro.epc.repositories;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcFlexiPlan;

/**
 * @author Developer
 * @version 1.0
 * type EpcFlexiPlanRepository
 */
public interface EpcFlexiPlanRepository extends CrudRepository<EpcFlexiPlan, Integer>{
	
	@Query(value="select price from epc_flexi_plan where lower(flexi_plan_type)=lower(:planType) and validity_in_days=:validity and :DataPack "
			+ "between data_range_start and data_range_end and :voicePack between voice_range_start and voice_range_end and :smsPack  between "
			+ "sms_range_start and sms_range_end and status=:stat",nativeQuery=true)
	BigDecimal getFlexiPlanPriceRate(@Param("planType") String planType, @Param("validity") Integer validity, @Param("DataPack") Integer dataPack,
			@Param("voicePack") Integer voicePack, @Param("smsPack") Integer smsPack, @Param("stat") String status);
	
	@Query(value="select * from epc_flexi_plan ",nativeQuery=true)
	List<EpcFlexiPlan> getFlexiPlanDetail();
	
	
}
