package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcOrderChannelRule;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
public interface EpcOrderChannelRuleRepositoryCustom {
	
	/**
	 * This get the list of EpcOrderChannelRule
	 * @param query
	 * @return List<EpcOrderChannelRule>
	 */
	List<EpcOrderChannelRule> getList(String query);
	
	/**
	 * This modifies the order data
	 * @param order
	 * @return
	 */
	EpcOrderChannelRule modifyOrder (EpcOrderChannelRule order);

}
