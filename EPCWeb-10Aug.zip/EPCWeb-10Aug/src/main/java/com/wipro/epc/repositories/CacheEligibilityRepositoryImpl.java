package com.wipro.epc.repositories;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.CacheEligibility;

public class CacheEligibilityRepositoryImpl implements CacheEligibilityRepositoryCustom {
	
private static Logger logger =LoggerFactory.getLogger(CacheEligibilityRepositoryImpl.class);
	
	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<CacheEligibility> getList(String query) {
		logger.debug("#Query :"+query);
		return em.createNativeQuery(query,CacheEligibility.class).getResultList();
	}

}
