package com.wipro.epc.uam.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.wipro.epc.uam.domain.Role;
import com.wipro.epc.uam.domain.Users;
import com.wipro.epc.uam.services.UserService;




/**
 * @author KE334465
 *
 */
@RestController
public class UserController {
	
	private static Logger logger = LoggerFactory.getLogger(UserService.class);
	
	/**
	 * 
	 */
	@Autowired
	private UserService service;
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/extapi/v1/users", method=RequestMethod.GET)
	public List<Users> searchUserSimpleExt(@RequestParam MultiValueMap allRequestParams)
	{//esb.getVASAddons("dsf");
 			return service.searchUserSimple(allRequestParams);
	}
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/users", method=RequestMethod.GET)
	public List<Users> searchUserSimple(@RequestParam MultiValueMap allRequestParams)
	{
 			return service.searchUserSimple(allRequestParams);
	}
	//*******************************************************************************

	/**
	 * @param userList
	 * @param txn
	 * @param mix_op
	 * @return
	 */
	@RequestMapping(value="rest/extapi/v1/users", method=RequestMethod.POST)
	public List<Users> updateUserExt(@RequestBody List<Users> userList, @RequestParam(value="txn", defaultValue="true")boolean txn, 
			@RequestParam(value="mix_op",defaultValue="true")boolean mix_op)
	{
		if(txn) {
			return service.updateUser(userList, txn, mix_op, "restclient");
		} else {
			return service.updateUserNonTxn(userList, txn, mix_op, "restclient");
		}
	}
	
	
	/**
	 * @param userList
	 * @param txn
	 * @param mix_op
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/users", method=RequestMethod.POST)
	public List<Users> updateUser(@RequestBody List<Users> userList, @RequestParam(value="txn", defaultValue="true")boolean txn, 
			@RequestParam(value="mix_op",defaultValue="true")boolean mix_op)
	{
		//System.out.println("list is "+userList.get(0));
		String user = SecurityContextHolder.getContext().getAuthentication().getName();
		logger.info("username is "+user);
		if(txn){
			List<Users> users = service.updateUser(userList, txn, mix_op, user);
			//System.out.println("Return list is "+users);
			return users;
		} else {
			return service.updateUserNonTxn(userList, txn, mix_op, user);
		}
	}
	//****************************************************************************************
	/**
	 * @return
	 */
	@RequestMapping(value="rest/extapi/v1/users/roles", method=RequestMethod.GET)
	public List<Role> getAllRolesExt()
	{
 			return service.getAllRoles();
	}
	
	
	/**
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/users/roles", method=RequestMethod.GET)
	public List<Role> getAllRoles()
	{
 			return service.getAllRoles();
	}

	/**
	 * @return
	 */
	public static Logger getLogger() {
		return logger;
	}

	/**
	 * @param logger
	 */
	public static void setLogger(Logger logger) {
		UserController.logger = logger;
	}

	/**
	 * @return
	 */
	public UserService getService() {
		return service;
	}

	/**
	 * @param service
	 */
	public void setService(UserService service) {
		this.service = service;
	}
}