package com.wipro.epc.domain;



import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;


/**
 * The persistent class for the epc_product_compatibility database table.
 * @author VI251443
 * @version 1.0
 * 
 */
@Entity
@Table(name="epc_product_compatibility")
public class EpcProductCompatibility   implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_compatibility_id")
	private Integer productCompatibilityId;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;
	
	@Column(name="inclusive_or_exclusive")
	private String inclusiveOrExclusive;
	
/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String inclusiveOrExclusiveValue;*/

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;

	@Column(name="other_product_id")
	private Integer otherProductId;

	@Column(name="product_id")
	private Integer productId;

	@Column(name="status")
	private String status;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;*/
	

	@Transient
	private Map<String,String> metaInfo;	
	
	@Transient
	private EpcProductSpecification otherProductSpecification;
	
	public EpcProductCompatibility() {
	}

	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}

	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}
	
	public Integer getProductCompatibilityId() {
		return this.productCompatibilityId;
	}

	public void setProductCompatibilityId(Integer productCompatibilityId) {
		this.productCompatibilityId = productCompatibilityId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getInclusiveOrExclusive() {
		return this.inclusiveOrExclusive;
	}

	public void setInclusiveOrExclusive(String inclusiveOrExclusive) {
		this.inclusiveOrExclusive = inclusiveOrExclusive;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getOtherProductId() {
		return this.otherProductId;
	}

	public void setOtherProductId(Integer otherProductId) {
		this.otherProductId = otherProductId;
	}

	public Integer getProductId() {
		return this.productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/*public String getInclusiveOrExclusiveValue() {
		this.inclusiveOrExclusiveValue = inclusiveOrExclusive;
		return inclusiveOrExclusiveValue;
	}

	public void setInclusiveOrExclusiveValue(String inclusiveOrExclusiveValue) {
		this.inclusiveOrExclusiveValue = inclusiveOrExclusiveValue;
	}

	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}*/



	public EpcProductSpecification getOtherProductSpecification() {
		return otherProductSpecification;
	}

	public void setOtherProductSpecification(
			EpcProductSpecification otherProductSpecification) {
		this.otherProductSpecification = otherProductSpecification;
	}
	
	

}