package com.wipro.epc.services;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.util.ServerDetails;
import com.wipro.epc.domain.EpcProductSpecification;

@Service
public class CachedProductDisplayFromMemoryService {

	private static Logger logger =LoggerFactory.getLogger(CachedProductDisplayFromMemoryService.class);
	
	@Autowired
	MCachedProductService mCachedProductService;
	
	@Autowired
	ServerDetails serverDetails;
	
	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	BroadcastService broadcastService;
	
	public String DisplayFromMemory(String[] ids) {
		
		// To get the DateTime in 'yyyyMMddHHmmss' formate
			Date curDate = new Date();
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
			String DateToStr = format.format(curDate);
			format = new SimpleDateFormat("yyyyMMddHHmmss");
			DateToStr = format.format(curDate);
			
			String uniqueMSName = serverDetails.getManagedSeverName();
			String NewuniqueMSName = uniqueMSName.replace(":", "-");
			String NewUniqueMSName = NewuniqueMSName.replace("@", "-");
						
			FileWriter file;
			List<EpcProductSpecification> returnList = new ArrayList<EpcProductSpecification>();
			
			String fName = "";
			String MSDate = "";
			
			try {
				//file = new FileWriter("./logs/MemDump_"+uniqueMSName+"_"+DateToStr+".txt");
				MSDate = "MemDump_"+NewUniqueMSName+"_"+DateToStr+".txt";
			    fName = "."+File.separator+"logs"+File.separator+MSDate;
				
				for(String id:ids){
					EpcProductSpecification prodSpec = mCachedProductService.find(id);
					String str;
					
						str = mapper.writeValueAsString(prodSpec);
						FileWriter fw = new FileWriter(fName, true);
						BufferedWriter out = new BufferedWriter(fw);
						out.write(str);
						out.newLine();
						out.close();
						
						//BufferedWriter bw = new BufferedWriter(file);
						//bw.write(str);
						
					returnList.add(prodSpec);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return MSDate;
	}

	public Map<String,String> memoryInfo() {

		MultiValueMap<String, String > map = new LinkedMultiValueMap<String, String >();
		List<String> api = new ArrayList<String>();
		List<String> ports = new ArrayList<String>();
		
		api.add("cache/product/memoryLocal");
		ports.add("non-ui");
		
		map.put("api", api);
		map.put("to", ports);
		
		Map<String,String> broadcastResults = broadcastService.getReplyService( map);		
		logger.info("#DisplayMemoryInfo: broadcastResults = " + broadcastResults.toString() );
	
		
		return broadcastResults;
	}

	public String memoryLocalInfo() {
		Set<Integer> ids=mCachedProductService.getReply().keySet();
		int count=ids.size();
		
		logger.info("#DisplayMemoryLocalInfo:Result = " +" Count = "+count+" \n Ids = "+ids.toString() );
		return "Count = "+count+" \n Ids = "+ids.toString();
	}
}