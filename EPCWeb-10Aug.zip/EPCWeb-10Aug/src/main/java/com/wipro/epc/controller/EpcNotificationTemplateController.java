package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcNotificationTemplate;
import com.wipro.epc.services.EpcNotificationTemplateService;

@RestController
public class EpcNotificationTemplateController {

	@Autowired
	private EpcNotificationTemplateService notificationService;
	
	/**
	 * @param notificationList
	 * @param txn
	 * @param mix_op
	 * @return
	 */
	@RequestMapping(value="rest/extapi/v1/notifications", method=RequestMethod.POST)
	public List<EpcNotificationTemplate> manageNotificationsExt(@RequestBody List<EpcNotificationTemplate> notificationList,
			@RequestParam(value="txn",defaultValue="true")boolean txn,
			@RequestParam(value="mix_op",defaultValue="true")boolean mix_op)
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		return notificationService.manageNotifications(notificationList, txn, mix_op,user);
	}
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/extapi/v1/notifications", method=RequestMethod.GET)
	public List<EpcNotificationTemplate> searchNotificationsExt(@RequestParam MultiValueMap allRequestParams)
	{
 			return notificationService.searchEpcNotificationTemplate(allRequestParams);
	}
	
	/**
	 * @param notificationList
	 * @param txn
	 * @param mix_op
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/notifications", method=RequestMethod.POST)
	public List<EpcNotificationTemplate> manageNotifications(@RequestBody List<EpcNotificationTemplate> notificationList,
			@RequestParam(value="txn",defaultValue="true")boolean txn,
			@RequestParam(value="mix_op",defaultValue="true")boolean mix_op)
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		return notificationService.manageNotifications(notificationList, txn, mix_op,user);
	}
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/notifications", method=RequestMethod.GET)
	public List<EpcNotificationTemplate> searchNotifications(@RequestParam MultiValueMap allRequestParams)
	{
 			return notificationService.searchEpcNotificationTemplateFromUI(allRequestParams);
	}

	/**
	 * @return
	 */
	public EpcNotificationTemplateService getNotificationService() {
		return notificationService;
	}

	/**
	 * @param notificationService
	 */
	public void setNotificationService(
			EpcNotificationTemplateService notificationService) {
		this.notificationService = notificationService;
	}
}
