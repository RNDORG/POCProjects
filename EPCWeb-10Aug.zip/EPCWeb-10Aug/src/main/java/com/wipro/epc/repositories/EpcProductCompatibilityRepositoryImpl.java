package com.wipro.epc.repositories;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.wipro.epc.domain.EpcProductCompatibility;
import com.wipro.epc.util.SimpleDateConvertion;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductCompatibilityRepositoryImpl
 */
public class EpcProductCompatibilityRepositoryImpl implements  EpcProductCompatibilityRepositoryCustom{
	
	
	private static Logger logger =LoggerFactory.getLogger(EpcProductCompatibilityRepositoryImpl.class);
	
	
	/**
	 * EntityManager EpcProductCompatibilityRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em; 
	
	/**
	 * SimpleDateConvertion EpcProductCompatibilityRepositoryImpl.java
	 */
	@Autowired
	SimpleDateConvertion convert; 
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductCompatibilityRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	public List<EpcProductCompatibility> getList(String query) {
		logger.debug("#Query: "+query);
		////System.out.println((List<EpcProductAvailability>)em.createNativeQuery(query, EpcProductAvailability.class).getResultList());
		return em.createNativeQuery(query, EpcProductCompatibility.class).getResultList();
	}

	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductCompatibilityRepositoryCustom#modifyProductCompatibility(com.wipro.epc.domain.EpcProductCompatibility)
	 */
	@Override
	public EpcProductCompatibility modifyProductCompatibility(EpcProductCompatibility productCompatibility)
	{
			StringBuilder queryBuilder = new StringBuilder("update epc_product_compatibility set product_compatibility_id="+productCompatibility.getProductCompatibilityId());
			
			if(productCompatibility.getStatus()!=null && !productCompatibility.getStatus().isEmpty())
				queryBuilder.append(",").append(" status = '").append(productCompatibility.getStatus()).append("'");
			if(productCompatibility.getOtherProductId()!=null && productCompatibility.getOtherProductId()!=0)
				queryBuilder.append(",").append(" other_product_id = '").append(productCompatibility.getOtherProductId()).append("'");
			
			if(productCompatibility.getProductId()!=null && productCompatibility.getProductId()!=0)
				queryBuilder.append(",").append(" product_id = '").append(productCompatibility.getProductId()).append("'");
			 

			/*if(productCompatibility.getStartDate()!=null)
				queryBuilder.append(",").append(" start_date = '").append(productCompatibility.getStartDate()).append("'");*/
			/*if(productCompatibility.getEndDate()!=null)
				queryBuilder.append(",").append(" end_date = '").append(productCompatibility.getEndDate()).append("'");*/
			if(productCompatibility.getInclusiveOrExclusive()!=null)
				queryBuilder.append(",").append(" inclusive_or_exclusive = '").append(productCompatibility.getInclusiveOrExclusive()).append("'");
			queryBuilder.append(",").append(" modified_by='").append(productCompatibility.getModifiedBy()).append("'");
			queryBuilder.append(",").append(" modified_date='").append(convert.getDateInFormat(new Date(),"yyyy-MM-dd kk:mm:ss")).append("'");
			
			queryBuilder.append(" where product_compatibility_id=").append(productCompatibility.getProductCompatibilityId());
			String query = queryBuilder.toString();
			em.createNativeQuery(query).executeUpdate();
			logger.debug("#Query: "+query);
			//System.out.println(queryBuilder);
		return productCompatibility;
	}



}
