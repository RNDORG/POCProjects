package com.wipro.epc.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.Writer;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



import com.wipro.common.config.service.ConfigService;
import com.wipro.common.gs.mailnotification.SmtpMailSender;
import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.dto.ComplexSearchInput;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.ComplexSearchInputService;
import com.wipro.epc.util.SimpleDateConvertion;

/**
 * @author Developer
 * @version 1.0
 * type EpcPublishProductController
 */
@RestController
public class EpcPublishProductController {

	/**
	 * ComplexSearchInputService EpcPublishProductController.java
	 */
	@Autowired
	ComplexSearchInputService searchService ;
	
	/**
	 * ConfigRepository EpcPublishProductController.java
	 */
	@Autowired
	ConfigService configService;
	
	/**
	 * CommonUtils EpcPublishProductController.java
	 */
	@Autowired
	CommonUtils xmlConversion;
	
	/**
	 * SimpleDateConvertion EpcPublishProductController.java
	 */
	@Autowired
	SimpleDateConvertion dateConvert;
	
	/**
	 * SmtpMailSender EpcPublishProductController.java
	 */
	@Autowired
	SmtpMailSender mailSender;
	
	/**
	 * Logger EpcPublishProductController.java
	 */
	private static Logger logger = LoggerFactory.getLogger(EpcPublishProductController.class);
	
	/**
	 * @param productIds
	 */
	@RequestMapping(value="rest/extapi/v1/toFile", method=RequestMethod.GET)
	public void convert(@RequestParam String[] productIds){
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String user=auth.getName();
		
		////System.out.println("Controller reached");
		int j=0;
		ComplexSearchInput searchDomain = new ComplexSearchInput();
		try{
			for(String productId : productIds)
			{
				if(!"".equals(productId) && !" ".equals(productId)) {
					String fileName = "" + Paths.get(".").toAbsolutePath().normalize() + File.separator + "Product"+productId+".xml";
					////System.out.println("fullfilename=(" + fileName + ")");
					
					
		            FileWriter fr= new FileWriter(new File( fileName ));
		            Writer br= new BufferedWriter(fr);
		            searchDomain.setProductId(productId);
		            MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		
		    		map.add("with", "all");
		            br.write(xmlConversion.convertToXml(searchService.searchComplex(searchDomain, map, true).get(0)));
		            
		            br.close();
		            logger.info("File written success"+productId);
		            j++;
				}
			}  
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(new Date());
			Long fileCreationTime=calendar.getTimeInMillis();//dateConvert.getDateInFormat(calendar.getTime(),"yyyy-MM-dd_kk-mm-ss");  
			
			String zipFile = "PublishedBy_"+user+"_"+fileCreationTime.toString()+".zip";
	            String[] sourceFiles = new String[j];
	            for(int i=0; i<productIds.length; i++)
	            {
	            	if(!"".equals(productIds[i]) && !" ".equals(productIds)) {
						sourceFiles[i]= "Product"+productIds[i]+".xml";
					}
	            }
               
                //create byte buffer
                byte[] buffer = new byte[1024];
               
                
                 //create object of FileOutputStream
                 FileOutputStream fout = new FileOutputStream(zipFile);
                 
                 //create object of ZipOutputStream from FileOutputStream
                 ZipOutputStream zout = new ZipOutputStream(fout);
                 
                 for(int i=0; i < sourceFiles.length; i++)
                 {
                       
                        logger.debug("Adding " + sourceFiles[i]);
                        //create object of FileInputStream for source file
                        FileInputStream fin = new FileInputStream(sourceFiles[i]);
                        zout.putNextEntry(new ZipEntry(sourceFiles[i]));

                        int length;

                        while((length = fin.read(buffer)) > 0)
                        {
                           zout.write(buffer, 0, length);
                        }

                         zout.closeEntry();
                         
                         fin.close();
                       
                 }
               FileSystemResource[] file = new FileSystemResource[1]; 
               String fileName = "" + Paths.get(".").toAbsolutePath().normalize() + File.separator + zipFile;
				File fileOne = new File(fileName);
				file[0] = new FileSystemResource(fileOne);
               int i=0;
                 for(String productId : productIds)
     			{
                	 if(!"".equals(productId) && !" ".equals(productId)) {
	     				String filename = "" + Paths.get(".").toAbsolutePath().normalize() + File.separator + "Product"+productId+".xml";
	     				File fileone = new File(filename);
	     				fileone.delete();
	     				i++;
                	 }
     			}
              
                  //close the ZipOutputStream
                  zout.close();
                 
                  logger.info("Zip file has been created!");
			String mailId = configService.searchConfigKey("Publish Product", "To").getConfigValue();
			String subject = configService.searchConfigKey("Publish Product", "Subject").getConfigValue();
			String body = configService.searchConfigKey("Publish Product", "Body").getConfigValue();
			// MailService.sendMail ( toMailID, file[] , subject, body );
			logger.info("Sending mail to :"+mailId+" with subject :"+subject+" and body :"+body+" and file name :"+zipFile);
			mailSender.send(mailId, null, null, subject, body, file);
			
			
           // return "Sucess";            
        }
        catch(Exception e)
        {
        	throw new EPCException("Publish failed "+e);
        }
	}
}
