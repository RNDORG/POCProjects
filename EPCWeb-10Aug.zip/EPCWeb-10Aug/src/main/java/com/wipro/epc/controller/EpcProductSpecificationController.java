package com.wipro.epc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.ApplicationContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcOrderChannelRuleRepository;
import com.wipro.epc.repositories.EpcProductDecompositionRepository;
import com.wipro.epc.repositories.EpcProductInitChannelRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.services.EpcProductInitChannelService;
import com.wipro.epc.services.EpcProductProviderSystemService;
import com.wipro.epc.services.EpcProductSpecificationService;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductSpecificationController
 */
@RestController
public class EpcProductSpecificationController {
	
	/**
	 * EpcProductDecompositionRepository EpcProductSpecificationController.java
	 */
	
	private static Logger logger = LoggerFactory.getLogger(EpcProductSpecificationController.class);
	
	
	@Autowired
	private EpcProductDecompositionRepository epcProductDecompositionRepository;
	
	@Autowired
	private EpcProductProviderSystemService epcProductProviderSystemService;
	/**
	 * EpcProductSpecificationRepository EpcProductSpecificationController.java
	 */
	@Autowired
	private EpcProductSpecificationRepository epcProductSpecificationRepository;
	
	/**
	 * EpcOrderChannelRuleRepository EpcProductSpecificationController.java
	 */
	@Autowired
	private EpcOrderChannelRuleRepository epcOrderChannelRuleRepository;
	
	/**
	 * EpcProductInitChannelRepository EpcProductSpecificationController.java
	 */
	@Autowired
	private EpcProductInitChannelRepository epcInitChannelRepository;
	
	/**
	 * EpcProductSpecificationService EpcProductSpecificationController.java
	 */
	@Autowired 
	private EpcProductSpecificationService epcProductSpecificationService;
	
	/**
	 * EpcProductInitChannelService EpcProductSpecificationController.java
	 */
	@Autowired
	private EpcProductInitChannelService epcProductInitChannelService;
	
	/**
	 * TransactionStore EpcProductSpecificationController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	/**
	 * TransactionsService EpcProductSpecificationController.java
	 */
	@Autowired
	private TransactionsService transactionsLogging ;
	
	/**
	 * ObjectMapper EpcProductSpecificationController.java
	 */
	@Autowired
	private ObjectMapper mapper;
	

	/**
	 * @param productsList
	 * @param txn
	 * @param mix_op
	 * @param values
	 * @return
	 */
	@RequestMapping(value="rest/extapi/v1/products",method=RequestMethod.POST)
	public List<EpcProductSpecification> updateProductExt(@RequestBody List<EpcProductSpecification> productsList,
			@RequestParam(value="txn",defaultValue="true")boolean txn,
			@RequestParam(value="mix_op",defaultValue="true")boolean mix_op, @RequestParam MultiValueMap values)
	{
		//System.out.println("productsList(in product Controller):"+productsList);
		//System.out.println("Migration is : "+productsList.get(0).getEpcProductMigration());
		return epcProductSpecificationService.updateProduct(productsList, txn, mix_op,"restclient", values);
	}
	
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/extapi/v1/products", method=RequestMethod.GET)
	public List<EpcProductSpecification> searchProductsSimpleExt(@RequestParam MultiValueMap allRequestParams)
	{
		String txnType="products";
		String request=null;
		List<EpcProductSpecification> resultProductSpec=null;
		try{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams,null);
		resultProductSpec=epcProductSpecificationService.searchProducts(allRequestParams);
		}
		catch (Exception e ) {
			logger.error("#interfaceException: " + e.getMessage());
			throw new EPCException(e.getMessage());
		}
		finally{
		ePCTxnInterceptor.postTxn(txnType, request, resultProductSpec);
		}
		return resultProductSpec;
	}
	
	
	
	//values will have with(values) including other request params
	/**
	 * @param productsList
	 * @param txn
	 * @param mix_op
	 * @param values
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/products",method=RequestMethod.POST)
	public List<EpcProductSpecification> updateProduct(@RequestBody List<EpcProductSpecification> productsList,
			@RequestParam(value="txn",defaultValue="true")boolean txn,
			@RequestParam(value="mix_op",defaultValue="true")boolean mix_op, @RequestParam MultiValueMap values)
	{
		//System.out.println("Values are "+values);
		//System.out.println("productsList(in product Controller):"+productsList.get(0).getMetaInfo());
		//System.out.println("Availability sent is "+productsList.get(0).getEpcProductAvailability());
		////System.out.println("Migration is : "+productsList.get(0).getEpcProductMigration());*/
		
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		return epcProductSpecificationService.updateProduct(productsList, txn, mix_op,user, values);
	}
	
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/products", method=RequestMethod.GET)
	public List<EpcProductSpecification> searchProductsSimple(@RequestParam MultiValueMap allRequestParams)
	{
		
 			return epcProductSpecificationService.searchProducts(allRequestParams);
	}
	
	@RequestMapping(value="rest/api/v1/productsUI", method=RequestMethod.GET)
	public List<EpcProductSpecification> searchProductSimpleUI(@RequestParam MultiValueMap allRequestParams)
	{
		String query  = " select * from epc_product_specification where ";
		if(allRequestParams.get("productType")!=null) {
			if(!((List<String>)allRequestParams.get("productType")).get(0).equals("")) {
				for(String type: (List<String>)allRequestParams.get("productType")){
					query = query + " product_type = '"+type+"' ";
				}
			}
			
			if(allRequestParams.get("productShortCode")!=null) {
				if(!((List<String>)allRequestParams.get("productShortCode")).get(0).equals("")) {
					for(String shortCode: (List<String>)allRequestParams.get("productShortCode")){
						query = query + " and product_short_code LIKE '"+shortCode.replace("*", "%")+"' ";
					}
				}
			}
		}
		else if(allRequestParams.get("productShortCode")!=null) {
				for(String shortCode: (List<String>)allRequestParams.get("productShortCode")){
					query = query + " product_short_code LIKE '"+shortCode.replace("*", "%")+"' ";
				}
			
		}
		return epcProductSpecificationRepository.getList(query);
	}
	
	@RequestMapping(value="rest/api/v1/productsUIMigration", method=RequestMethod.GET)
	public List<EpcProductSpecification> searchProductSimpleUIMigration(@RequestParam MultiValueMap allRequestParams)
	{
		String query  = " select * from epc_product_specification where ";
		query = query + " is_bundle=0 and is_hybrid=0 and is_roaming_product = "+((List<String>)allRequestParams.get("isRoamingProduct")).get(0)+" and ";
		query = query + " product_type = '"+((List<String>)allRequestParams.get("productType")).get(0)+"'";
		
		if(allRequestParams.get("productCategory")!=null){
			if(!((List<String>)allRequestParams.get("productCategory")).get(0).equals("")) {
				for(String category: (List<String>)allRequestParams.get("productCategory")){
					query = query + " and product_category = '"+category+"' ";
				} 
			}
		}
		
		if(allRequestParams.get("productShortCode")!=null) {
			if(!((List<String>)allRequestParams.get("productShortCode")).get(0).equals("")) {
				for(String shortCode: (List<String>)allRequestParams.get("productShortCode")){
					query = query + " and product_short_code LIKE '"+shortCode.replace("*", "%")+"' ";
				} 
			}
		}
		List<EpcProductSpecification> specificationList = epcProductSpecificationRepository.getList(query);
		List<String> withValues = (List<String>) allRequestParams.get("with");
		Map<String, List<String>> childParams = new HashMap<String, List<String>>();
		
		if (withValues.contains("all")|| withValues.contains("provider")) {
			for(EpcProductSpecification product: specificationList)
			{
				List<String> prodId = new ArrayList<String>();
				prodId.add(product.getProductId().toString());
				childParams.put("productId", prodId);
				product.setEpcProductProvider(epcProductProviderSystemService.searchProvider(childParams));
			}
		}
		return specificationList;
	}
	
	
	/**
	 * @param communityName
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/marketingNames" , method=RequestMethod.GET)
	public List<String> getMarketingNames(@RequestParam(required=false, defaultValue="") String communityName)
	{
		
				return epcProductSpecificationService.getMarketingNames(communityName);
			
	}
	/**
	 * @param productList
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/compatibilityCheck" , method=RequestMethod.POST)
	public List<String> getCompatabilityCheck(@RequestBody List<Integer> productList)
	{
		List<Integer> productArray = new ArrayList<Integer>();
		//Integer prod = new Integer();
		int prod=0;
		int i=0;
		for(Integer product: productList) {
			
			if(i<(productList.size()-1)) {
				productArray.add(product);
			} else {
				prod = product;
			} 
			i++;
		}
		return epcProductSpecificationService.compatibilityCheck(productArray, prod);
			
	}
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/uniqueName", method=RequestMethod.GET)
	public List<EpcProductInitChannel> marketingNameUnique(@RequestParam MultiValueMap allRequestParams) {
		//System.out.println("function called");
		return epcProductInitChannelService.searchEpcProductInitChannel(allRequestParams);
	}
	
	/**
	 * @param marketName
	 * @param productId
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/initiatingValidationMarketName", method=RequestMethod.GET)
	public List<String> getMarketingName(@RequestParam(value="marketName") String marketName, @RequestParam(value="productId") String productId)
	{
		////System.out.println("The values are channel id, product shortcode is "+marketName+", "+productId);
		//String shortcode = productId;
		productId = epcProductSpecificationRepository.findByShortCode(productId);
		////System.out.println("Product id is "+productId);
		int i=1;
		while(epcProductInitChannelService.marketingNameCorrect(productId, marketName).size()>0){
			marketName = marketName + "_" +i;
			i++;
		}
		////System.out.println("channel product id is "+marketName);
		List<String> returnList = new ArrayList<String>();
		returnList.add(marketName);
		return returnList;
	}
	
	/**
	 * @param channelProductId
	 * @param productId
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/initiatingValidationProductId", method=RequestMethod.GET)
	public List<String> getProductId(@RequestParam(value="channelProductId") String channelProductId, @RequestParam(value="productId") String productId)
	{
		////System.out.println("The values are channel id, product id is "+channelProductId+", "+productId);
		String shortcode = productId;
		productId = epcProductSpecificationRepository.findByShortCode(productId);
		////System.out.println("Product id is "+productId);
		int i=1;
		while(epcProductInitChannelService.productIdCorrect(productId, channelProductId).size()>0){
			channelProductId = shortcode + "_" +i;
			i++;
		}
		////System.out.println("channel product id is "+channelProductId);
		//returning a list as that turns out to be the only way to reach success callback method in angular js, 
		List<String> returnList =  new ArrayList<String>();
		returnList.add(channelProductId);
		return returnList;
	}
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/notificationDeleteConstraint", method=RequestMethod.GET)
	public List<String> isConstraintVoilated(@RequestParam MultiValueMap allRequestParams) {
		
		Iterator it = allRequestParams.entrySet().iterator();
	   
	        Map.Entry pair = (Map.Entry)it.next(); 
	        List<String> ids =  (List<String>) (pair.getValue());
		
		List<String> returnList = new ArrayList<String>();
		
		
		for(String id : ids) {
			//System.out.println("id is "+id);
			
			if(!("".equals(id)) && epcInitChannelRepository.searchEpcProductInitChannel(Integer.parseInt(id)).size()>0) {
				returnList.add("false");
			}
			else if(!("".equals(id)) && epcProductDecompositionRepository.getDecompositionByNotificationTemplate(Integer.parseInt(id)).size()>0) {
				returnList.add("false");
			}
			else if(!("".equals(id)) && epcOrderChannelRuleRepository.searchEpcOrderChannelRule(Integer.parseInt(id)).size()>0) {
				returnList.add("false");
			} else {
				returnList.add("true");
			}
		}
		return returnList;
	}
	/**
	 * 
	 */
	@RequestMapping(value="rest/api/v1/dummyCall",method=RequestMethod.GET)
	public void dummyCall(){
		//System.out.println("Dummy Call");
		//return "Session Continue";
		
	}


	/**
	 * @return
	 */
	public EpcProductDecompositionRepository getEpcProductDecompositionRepository() {
		return epcProductDecompositionRepository;
	}


	/**
	 * @param epcProductDecompositionRepository
	 */
	public void setEpcProductDecompositionRepository(
			EpcProductDecompositionRepository epcProductDecompositionRepository) {
		this.epcProductDecompositionRepository = epcProductDecompositionRepository;
	}


	/**
	 * @return
	 */
	public EpcProductSpecificationRepository getEpcProductSpecificationRepository() {
		return epcProductSpecificationRepository;
	}


	/**
	 * @param epcProductSpecificationRepository
	 */
	public void setEpcProductSpecificationRepository(
			EpcProductSpecificationRepository epcProductSpecificationRepository) {
		this.epcProductSpecificationRepository = epcProductSpecificationRepository;
	}


	/**
	 * @return
	 */
	public EpcOrderChannelRuleRepository getEpcOrderChannelRuleRepository() {
		return epcOrderChannelRuleRepository;
	}


	/**
	 * @param epcOrderChannelRuleRepository
	 */
	public void setEpcOrderChannelRuleRepository(
			EpcOrderChannelRuleRepository epcOrderChannelRuleRepository) {
		this.epcOrderChannelRuleRepository = epcOrderChannelRuleRepository;
	}


	/**
	 * @return
	 */
	public EpcProductInitChannelRepository getEpcInitChannelRepository() {
		return epcInitChannelRepository;
	}


	/**
	 * @param epcInitChannelRepository
	 */
	public void setEpcInitChannelRepository(
			EpcProductInitChannelRepository epcInitChannelRepository) {
		this.epcInitChannelRepository = epcInitChannelRepository;
	}


	/**
	 * @return
	 */
	public EpcProductSpecificationService getEpcProductSpecificationService() {
		return epcProductSpecificationService;
	}


	/**
	 * @param epcProductSpecificationService
	 */
	public void setEpcProductSpecificationService(
			EpcProductSpecificationService epcProductSpecificationService) {
		this.epcProductSpecificationService = epcProductSpecificationService;
	}


	/**
	 * @return
	 */
	public EpcProductInitChannelService getEpcProductInitChannelService() {
		return epcProductInitChannelService;
	}


	/**
	 * @param epcProductInitChannelService
	 */
	public void setEpcProductInitChannelService(
			EpcProductInitChannelService epcProductInitChannelService) {
		this.epcProductInitChannelService = epcProductInitChannelService;
	}


	/**
	 * @return
	 */
	public EPCTxnInterceptor getEPCTxnInterceptor() {
		return ePCTxnInterceptor;
	}


	/**
	 * @param transactionStore
	 */
	public void setEPCTxnInterceptor(EPCTxnInterceptor ePCTxnInterceptor) {
		this.ePCTxnInterceptor = ePCTxnInterceptor;
	}


	/**
	 * @return
	 */
	public TransactionsService getTransactionsLogging() {
		return transactionsLogging;
	}


	/**
	 * @param transactionsLogging
	 */
	public void setTransactionsLogging(TransactionsService transactionsLogging) {
		this.transactionsLogging = transactionsLogging;
	}


	/**
	 * @return
	 */
	public ObjectMapper getMapper() {
		return mapper;
	}


	/**
	 * @param mapper
	 */
	public void setMapper(ObjectMapper mapper) {
		this.mapper = mapper;
	}
}
