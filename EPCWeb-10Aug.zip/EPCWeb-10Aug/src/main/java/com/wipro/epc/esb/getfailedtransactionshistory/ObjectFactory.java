
package com.wipro.epc.esb.getfailedtransactionshistory;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.wipro.epc.esb.getfailedtransactionshistory package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetFailedTransactionsHistoryRequest_QNAME = new QName("http://www.telenor.com.mm/getFailedTransactionsHistory", "getFailedTransactionsHistoryRequest");
    private final static QName _GetFailedTransactionsHistoryResponse_QNAME = new QName("http://www.telenor.com.mm/getFailedTransactionsHistory", "getFailedTransactionsHistoryResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.wipro.epc.esb.getfailedtransactionshistory
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetFailedTransactionsHistoryResponseType }
     * 
     */
    public GetFailedTransactionsHistoryResponseType createGetFailedTransactionsHistoryResponseType() {
        return new GetFailedTransactionsHistoryResponseType();
    }

    /**
     * Create an instance of {@link GetFailedTransactionsHistoryRequestType }
     * 
     */
    public GetFailedTransactionsHistoryRequestType createGetFailedTransactionsHistoryRequestType() {
        return new GetFailedTransactionsHistoryRequestType();
    }

    /**
     * Create an instance of {@link LogInfo }
     * 
     */
    public LogInfo createLogInfo() {
        return new LogInfo();
    }

    /**
     * Create an instance of {@link FieldType }
     * 
     */
    public FieldType createFieldType() {
        return new FieldType();
    }

    /**
     * Create an instance of {@link QueryDownFailReportResp }
     * 
     */
    public QueryDownFailReportResp createQueryDownFailReportResp() {
        return new QueryDownFailReportResp();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFailedTransactionsHistoryRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.telenor.com.mm/getFailedTransactionsHistory", name = "getFailedTransactionsHistoryRequest")
    public JAXBElement<GetFailedTransactionsHistoryRequestType> createGetFailedTransactionsHistoryRequest(GetFailedTransactionsHistoryRequestType value) {
        return new JAXBElement<GetFailedTransactionsHistoryRequestType>(_GetFailedTransactionsHistoryRequest_QNAME, GetFailedTransactionsHistoryRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFailedTransactionsHistoryResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.telenor.com.mm/getFailedTransactionsHistory", name = "getFailedTransactionsHistoryResponse")
    public JAXBElement<GetFailedTransactionsHistoryResponseType> createGetFailedTransactionsHistoryResponse(GetFailedTransactionsHistoryResponseType value) {
        return new JAXBElement<GetFailedTransactionsHistoryResponseType>(_GetFailedTransactionsHistoryResponse_QNAME, GetFailedTransactionsHistoryResponseType.class, null, value);
    }

}
