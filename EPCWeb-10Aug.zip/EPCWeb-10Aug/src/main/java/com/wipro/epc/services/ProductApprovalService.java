package com.wipro.epc.services;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.config.service.ConfigService;
import com.wipro.common.gs.mailnotification.SmtpMailSender;
import com.wipro.epc.domain.EpcNotificationTemplateDetail;
import com.wipro.epc.domain.EpcProductProcessFlow;
import com.wipro.epc.domain.EpcProductStatusHistory;
import com.wipro.epc.dto.ProductApprovalInput;
import com.wipro.epc.repositories.EpcNotificationTemplateDetailRepository;
import com.wipro.epc.repositories.EpcNotificationTemplateRepository;
import com.wipro.epc.repositories.EpcProductProcessFlowRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.repositories.EpcProductStatusHistoryRepository;
import com.wipro.epc.uam.repositories.AuthorityRepository;
import com.wipro.epc.uam.repositories.FunctionRepository;
import com.wipro.epc.uam.repositories.UsersRepository;
import com.wipro.epc.util.Constants;

/**
 * @author Developer
 * @version 1.0
 * type ProductApprovalService
 */
@Service
public class ProductApprovalService {

	/**
	 * Logger ProductApprovalService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(ProductApprovalService.class);
	
	/**
	 * EpcProductSpecificationRepository ProductApprovalService.java
	 */
	@Autowired
	private EpcProductSpecificationRepository specRepo;
	
	/**
	 * FunctionRepository ProductApprovalService.java
	 */
	@Autowired
	private FunctionRepository funcRepo;
	
	/**
	 * EpcProductProcessFlowRepository ProductApprovalService.java
	 */
	@Autowired
	private EpcProductProcessFlowRepository processFlowRepo;
	
	/**
	 * ConfigService ProductApprovalService.java
	 */
	@Autowired
	private ConfigService configService;
	
	/**
	 * EpcLookupMasterService ProductApprovalService.java
	 */
	@Autowired
	private EpcLookupMasterService lookupService;
	
	/**
	 * AuthorityRepository ProductApprovalService.java
	 */
	@Autowired
	private AuthorityRepository authRepo;
	
	/**
	 * EpcNotificationTemplateRepository ProductApprovalService.java
	 */
	@Autowired
	private EpcNotificationTemplateRepository notifiRepo;
	
	/**
	 * EpcNotificationTemplateDetailRepository ProductApprovalService.java
	 */
	@Autowired
	private EpcNotificationTemplateDetailRepository tempDetailRepo;
	
	/**
	 * EpcProductStatusHistoryRepository ProductApprovalService.java
	 */
	@Autowired
	private EpcProductStatusHistoryRepository productStatusHistoryRepo;
	
	/**
	 * SmtpMailSender ProductApprovalService.java
	 */
	@Autowired
	private SmtpMailSender mailSender;
	
	@Autowired
	private UsersRepository userRepo;
	
/**
 * Function to read Input Status of a specific product(product_short_code) and expected output status
 * Depending on process_flow validation it will allow to change product specification status.
 * On successful update epc_notfication_template to be updated.(Notification to send)
 */
	/**
	 * @param approvalInputList
	 * @param transitionFunctions
	 * @param user
	 * @return
	 */
	@Transactional
	synchronized public String updateProductStatus(List<ProductApprovalInput> approvalInputList, List<String> transitionFunctions,String user){
		
		List<String> returnValue = new ArrayList<String>();
		
		List<Integer> TranistionFunctionIds = new ArrayList<Integer>();
		List<HashMap<String,String>> successProducts = new ArrayList<HashMap<String,String>>();
		List<String> failedProducts = new ArrayList<String>();		
		
		try{
			
			if(approvalInputList.isEmpty() || approvalInputList.get(0).getFromStatus()==null || approvalInputList.get(0).getToStatus() == null){
				return "Invalid Inputs, please provide all mandatory fields";
			}
		
		//String activeStatusId= lookupService.getLookupId("common_status", "status", "Active");
		
		
		EpcProductProcessFlow processFlow = processFlowRepo.getProcessTransition(approvalInputList.get(0).getFromStatus(), approvalInputList.get(0).getToStatus(), Constants.COMMON_STATUS_ACTIVE);
		String stateTransition = processFlow!=null ? processFlow.getStateTransitionRemarks() : "changed";
		Integer specificFlowId = processFlow!=null ? processFlow.getFunctionId() : 0;
		if(specificFlowId == null || specificFlowId==0){
			return "Not A valid Process Flow";}
		
		for(String s : transitionFunctions){
			TranistionFunctionIds.add(funcRepo.getFunctionId(s));
		}
		logger.info("Got allowed Transition Function Ids for the user"+TranistionFunctionIds.toString());
		
		
		
		
		if(TranistionFunctionIds.contains(specificFlowId)){
			
			logger.info( "An authorized Transaction");
			for(ProductApprovalInput approvalInput : approvalInputList ){
				Integer count = 0;
				String copiedFromProductShortCode="";
			if( Constants.PRODUCT_STATUS_LAUNCH.equalsIgnoreCase(approvalInput.getToStatus()) && !StringUtils.isBlank(approvalInput.getRetirePreviousProduct()) 
					&& Constants.RETIRE_PREVIOUS_PRODUCT.equalsIgnoreCase(approvalInput.getRetirePreviousProduct()))	{
				if(approvalInput.getCopiedFromProductId()==null){
					logger.error("Copied from product not found. May be corrupted data");}
				else{/*
						//check from bundle hierarchy if any parent is there for this copied from product
					Integer bundleProductCount = 0;
					if(bundleProductCount>0){
						logger.info("CopiedFromProduct can not be retired as it is not detached from bundle products");	}				
					else{
						//if this check returns no data then make the copiedfromProduct retire and count for updating the requested product
						Integer copiedProoductRetireCount = specRepo.ForceUpdateProductStatus(approvalInput.getCopiedFromProductId(), Constants.PRODUCT_STATUS_RETIRE, user);
						if (copiedProoductRetireCount>0){
							EpcProductStatusHistory epcProductStatusHistry = new EpcProductStatusHistory();
							epcProductStatusHistry.setCreatedBy(user);
							epcProductStatusHistry.setProductId(approvalInput.getCopiedFromProductId());
							epcProductStatusHistry.setProductStatus(approvalInput.getToStatus());
							epcProductStatusHistry.setReason("Retired because of launch of "+approvalInput.getProductShortCode());
							epcProductStatusHistry.setCreatedDate(new Date());
							productStatusHistoryRepo.save(epcProductStatusHistry);
							logger.debug("Inserted into EpcProductStatusHistory table for copied from product");
						count = specRepo.ApprovalUpdateCount(approvalInput.getProductShortCode(), approvalInput.getFromStatus(), approvalInput.getToStatus(), user);
						}
					}
						
					*/
				//Above code discarded as requirement changed, accordingly below else loop also discarded, n new addition came below	
					
					//need to send mail notification, to retire the product
					
					copiedFromProductShortCode=specRepo.findOne(approvalInput.getCopiedFromProductId()).getProductShortCode();
				/*	if(usermailId!=null && copiedFromProductShortCode!=null) {
					Thread backgroudCall = new Thread(new Runnable(){
						String linkAdrs = configService.searchConfigKey("Product Approval", "UrlLink").getConfigValue();
						String link =StringUtils.isNotBlank(linkAdrs) ? linkAdrs : "http://10.10.21.27:8090/EPCWeb/#/ProductApproval";
						@Override
						public void run() {
							String newLine = System.getProperty("line.separator");
							mailSender.send(usermailId, null, null,"EPC - Need to Retire Previous Product - "+copiedFromProductShortCode,
									"Dear Concern,"
									+ newLine+newLine+"Product "+approvalInput.getProductShortCode()+" got Launched, So Copied from Product "+copiedFromProductShortCode+ " need to be Retired as per retire request."
									+newLine+newLine+ "To proceed, click the below link"
									+newLine+link+newLine+newLine+"Regards,"+newLine+"GP EPC", null);
						}
					});	
					backgroudCall.start();
					logger.info("Mail sent to "+usermailId+" Retire product "+copiedFromProductShortCode+" because of launch of "+approvalInput.getProductShortCode()+" with Retire previous pproduct status : "+approvalInput.getRetirePreviousProduct());
					}*/
					
				}
				
				
			}//else{
			
			 count = specRepo.ApprovalUpdateCount(approvalInput.getProductShortCode(), approvalInput.getFromStatus(), approvalInput.getToStatus(), user);
			//}
			
			if(count>0){
				//returnValue.add(approvalInput.getProductShortCode()+" Approval Processed");
				HashMap<String,String> successProduct = new HashMap<String,String>();
				successProduct.put("stateTransition", stateTransition);
				successProduct.put("productShortCode",approvalInput.getProductShortCode());	
				successProduct.put("productClassification",approvalInput.getProductClassification()!=null ? approvalInput.getProductClassification() : "");
				successProduct.put("remarks",approvalInput.getSuspensionReason()!=null ? approvalInput.getSuspensionReason() : "");	
				successProduct.put("copiedFromProductShortCode",copiedFromProductShortCode);
				EpcProductStatusHistory epcProductStatusHistory = new EpcProductStatusHistory();
				epcProductStatusHistory.setCreatedBy(user);
				epcProductStatusHistory.setProductId(approvalInput.getProductId());
				epcProductStatusHistory.setProductStatus(approvalInput.getToStatus());
				epcProductStatusHistory.setReason(approvalInput.getSuspensionReason());
				epcProductStatusHistory.setCreatedDate(new Date());				
				productStatusHistoryRepo.save(epcProductStatusHistory);
				logger.debug("Inserted into EpcProductStatusHistory table");
				
				successProducts.add(successProduct);
			}
			else{
				//returnValue.add(approvalInput.getProductShortCode()+ " Not Approved");
				failedProducts.add(approvalInput.getProductShortCode());
				}
			
			}
			
			
			if(!successProducts.isEmpty()){
				List<String> successProductShortCodes = new ArrayList<String>();
				for(HashMap<String,String> ProductShortCode : successProducts){
					successProductShortCodes.add(ProductShortCode.get("productShortCode"));
				}
				logger.info("Successfully updated products: "+String.join(",",successProductShortCodes));
				String outputStatusValue =approvalInputList.get(0).getToStatus(); //lookupService.getLookupValue(approvalInputList.get(0).getToStatus());
				String inputStatusValue =approvalInputList.get(0).getFromStatus();// lookupService.getLookupValue(approvalInputList.get(0).getFromStatus());
				returnValue.add(String.join(",",successProductShortCodes) +" "+stateTransition+" and Successfully changed from '"+inputStatusValue+"' to '"+outputStatusValue+ "'. ");
				
				
				Thread backgroudCall = new Thread(new Runnable(){
					@Override
					public void run() {
						
						formTemplateNotification(inputStatusValue,outputStatusValue,successProducts,user);
					}
					
				});	
				backgroudCall.start();
				}
				
				
		if(!failedProducts.isEmpty())	{
			returnValue.add(String.join(",",failedProducts)+" status Transition Failed");
			}
			
		}
		else {
			return "Sorry! You are not allowed for this Transaction";
		}
		
		
		}
		catch(Exception e){
			logger.error(e.getMessage());
			logger.error(ExceptionUtils.getStackTrace(e));
			returnValue.clear();
			returnValue.add("Approval Flow Failed. Something went wrong! Please contact with backend Team");					
			throw e;
		}
		return "Product(s) "+ String.join(",", returnValue);
		
	}


	/**
	 * @param fromState
	 * @param toState
	 * @param products
	 * @param user
	 */
	synchronized public void formTemplateNotification(String fromState, String toState, List<HashMap<String,String>> products, String user){
		
		//String teplateTypeId = lookupService.getLookupId("epc_notification_template","notification_type", "Product Approval");
		//String activeStatusId= lookupService.getLookupId("common_status", "status", "Active");//	
	//	String templateLanguageId = lookupService.getLookupId("epc_notification_template", "language", "English");
		
		String usermailId=userRepo.findOne(user).getEmail();
		logger.debug("Got user mail id as : "+usermailId);
		
		
		logger.info("Getting mail user list from authorities who will do the next step for authority with Transition_"+toState);
		List<String> usersMails = authRepo.getAuthUsersMails("Transition_"+toState+"_");
		
		if(toState.equalsIgnoreCase(Constants.PRODUCT_STATUS_SUBMITTED) || toState.equalsIgnoreCase(Constants.PRODUCT_STATUS_APPROVED) 
				|| toState.equalsIgnoreCase(Constants.PRODUCT_STATUS_LAUNCH)){
		logger.info("Getting mail user list for RAFM users");
		List<String> specificMailIds = authRepo.getUserMailsForSpecificRole("role_rafm_team");
		if (specificMailIds!= null && !specificMailIds.isEmpty()){
		usersMails.remove(specificMailIds);
		usersMails.addAll(specificMailIds);
		}
		}
		
		if(toState.equalsIgnoreCase(Constants.PRODUCT_STATUS_RETIRE)){
		logger.info("Getting mail user list for Product Approver users to retire a product");
		List<String> specificMailIds = authRepo.getUserMailsForSpecificRole("role_product_approver");
		if (specificMailIds!= null && !specificMailIds.isEmpty()){
		usersMails.remove(specificMailIds);
		usersMails.addAll(specificMailIds);
		}
		}
		
		
		if (usersMails!= null && !usersMails.isEmpty()){
		Integer notificationTemplateId = notifiRepo.getNotificationTemplateId("Product Approval","Product_Approval_NotificationTemplate",Constants.COMMON_STATUS_ACTIVE);
		String notificationEngSubject = null;
		String notificationEngBody =null;
		if(notificationTemplateId==null || notificationTemplateId==0){
			logger.error("No Notification Template found");}
		else{
			List<EpcNotificationTemplateDetail> langSpecificTemplate = tempDetailRepo.findByNotificationTemplateIdAndTemplateLanguageAndStatus(notificationTemplateId,  "English", Constants.COMMON_STATUS_ACTIVE);
			if(langSpecificTemplate.isEmpty())
				{logger.error("Template Details in English not Found");}
			else{
			//for (EpcNotificationTemplateDetail s : langSpecificTemplate){
				notificationEngSubject = langSpecificTemplate.get(0).getTemplateSubject();
				notificationEngBody = langSpecificTemplate.get(0).getTemplateBody();
			//}
			
			/*if(notificationEngBody!=null){
				String out =notificationEngBody.replace("<fromState>", "1----1").replace("<toState>", "2----2").replace("<productShortCodes>", "3----3");
				logger.info(out);*/
			//Discarded above as ugly code.
			String linkAdrs = configService.searchConfigKey("Product Approval", "UrlLink").getConfigValue();
			List<String> successProductShortCodes = new ArrayList<String>();
			List<String> productsDetail = new ArrayList<String>();
			List<String> shortCodesToRetire = new ArrayList<String>();
			List<String> shortCodesToRetireDetails = new ArrayList<String>();
			int counter = 1; int cnt=1;
			for(HashMap<String,String> product : products){
				successProductShortCodes.add(product.get("productShortCode"));
				productsDetail.add(counter+".  "+product.get("productShortCode")+" ("+product.get("productClassification")+") "+(StringUtils.isNotBlank(product.get("remarks")) ? " |  Remarks : "+product.get("remarks") : "" ));
				counter++;
				if(StringUtils.isNotBlank(product.get("copiedFromProductShortCode"))) {
					shortCodesToRetire.add(product.get("copiedFromProductShortCode"));
					shortCodesToRetireDetails.add(cnt+".  Launched Product ("+product.get("productShortCode")+"), corresponding Products to Retire ("+product.get("copiedFromProductShortCode")+")");
					cnt++;
				}
			}
				//System.out.println(productsDetail);
				Map<String, String> replacements = new HashMap<String, String>() {{
				    put("<fromState>", fromState);
				    put("<toState>", toState);
				    put("<productShortCodes>", String.join(",", successProductShortCodes));
				    put("<linkAdrs>",StringUtils.isNotBlank(linkAdrs) ? linkAdrs : "http://10.10.21.27:8090/EPCWeb/#/ProductApproval");
				    put("<productsDetail>",String.join("\n  ", productsDetail));
				    put("<userBy>", StringUtils.isBlank(usermailId) ? user : user+" ("+usermailId+")");
				    put("<stateRemarks>",products.get(0).get("stateTransition"));
				    put("<toRetireProducts>",String.join(",", shortCodesToRetire));
				    put("<toRetireProductDetails>",String.join("\n  ", shortCodesToRetireDetails));
				}};
				
				String regexp = "<fromState>|<toState>|<productShortCodes>|<linkAdrs>|<productsDetail>|<userBy>|<stateRemarks>|<toRetireProducts>|<toRetireProductDetails>";
				StringBuffer sb = new StringBuffer();
				StringBuffer subject = new StringBuffer();
				Pattern p = Pattern.compile(regexp);
				Matcher m = p.matcher(notificationEngBody);
				Matcher n = p.matcher(notificationEngSubject);

				while (m.find()){
				    m.appendReplacement(sb, replacements.get(m.group()));
				}
				m.appendTail(sb);
				
				while (n.find()){
					 n.appendReplacement(subject, replacements.get(n.group()));}
				n.appendTail(subject);

				logger.info("#MAIL : Sending to notification Module: "+sb +" with Subject "+subject+ "\n To this user Mail list "+ usersMails.toString());
				
				mailSender.send(String.join(",", usersMails), null, usermailId, subject.toString(), sb.toString(), null);
				
				//retire previous product notification
				if(!shortCodesToRetire.isEmpty()) {
					 notificationTemplateId = notifiRepo.getNotificationTemplateId("Clone Product","Retire_Product_NotificationTemplate",Constants.COMMON_STATUS_ACTIVE);
					 notificationEngSubject = "";
					 notificationEngBody ="";
					if(notificationTemplateId==null || notificationTemplateId==0){
						logger.error("No Notification Template found for clone product notification");}
					else{
						langSpecificTemplate = tempDetailRepo.findByNotificationTemplateIdAndTemplateLanguageAndStatus(notificationTemplateId,  "English", Constants.COMMON_STATUS_ACTIVE);
						if(langSpecificTemplate.isEmpty())
							{logger.error("clone product Template Details in English not Found");}
						else{
						
							notificationEngSubject = langSpecificTemplate.get(0).getTemplateSubject();
							notificationEngBody = langSpecificTemplate.get(0).getTemplateBody();
							
							sb = new StringBuffer();
							 subject = new StringBuffer();
							 m = p.matcher(notificationEngBody);
							 n = p.matcher(notificationEngSubject);

							while (m.find()){
							    m.appendReplacement(sb, replacements.get(m.group()));
							}
							m.appendTail(sb);
							
							while (n.find()){
								 n.appendReplacement(subject, replacements.get(n.group()));}
							n.appendTail(subject);
							logger.info("#MAIL : Sending to notification Module: "+sb +" with Subject "+subject+ "\n To this user Mail list "+ usersMails.toString() 
									+" keeping user "+usermailId +" in CC");
							
							mailSender.send(String.join(",", usersMails), null, usermailId, subject.toString(), sb.toString(), null);
						}						
					}
				}
				
			}
			
			}
		
		}
		else {
			logger.error("No mail Id found to send approval notfication mail");}
		
		}
	}
	

	

