package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcActivityChannelRule;
import com.wipro.epc.services.EpcActivityChannelRuleService;

/**
 * @version 1.0
 * @author VI251443
 *
 */
@RestController
public class EpcActivityChannelRuleController {
	
	@Autowired
	EpcActivityChannelRuleService service;
	
	/**
	 * 
	 * @param orderList
	 * @param txn
	 * @param mix_op
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/activity", method=RequestMethod.POST)
	public List<EpcActivityChannelRule> manageActivity(@RequestBody List<EpcActivityChannelRule> orderList,
			@RequestParam(value="txn",defaultValue="true")boolean txn,
			@RequestParam(value="mix_op",defaultValue="true")boolean mix_op)
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		return service.manageActivity(orderList, user);
	}
	
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/activity", method=RequestMethod.GET)
	public List<EpcActivityChannelRule> searchActivity(@RequestParam MultiValueMap allRequestParams)
	{
 			return service.searchEpcActivityChannelRule(allRequestParams);
	}

}
