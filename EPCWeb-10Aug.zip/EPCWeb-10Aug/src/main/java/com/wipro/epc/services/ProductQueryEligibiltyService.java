package com.wipro.epc.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.config.domain.Config;
import com.wipro.common.config.service.ConfigService;
import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.CacheEligibility;
import com.wipro.epc.domain.EpcActivityMaster;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductAvailability;
import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.domain.EpcProductCompatibility;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductLocation;
import com.wipro.epc.domain.EpcProductMigration;
import com.wipro.epc.domain.EpcProductProviderSystem;
import com.wipro.epc.domain.EpcProductSalesChannel;
import com.wipro.epc.domain.EpcProductSegment;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.ComplexSearchInput;
import com.wipro.epc.dto.FlexiPlanInput;
import com.wipro.epc.dto.QueryEligibilityResponse;
import com.wipro.epc.dto.QueryEligibiltySearchInput;
import com.wipro.epc.esb.EsbRequestService;
import com.wipro.epc.ucip.AirRequestService;
import com.wipro.epc.util.Constants;
import com.wipro.epc.util.EPCUtils;


/**
 * @author Developer
 * @version 1.0
 * type ProductQueryEligibiltyService
 */
@Service
public class ProductQueryEligibiltyService {
	
	private static Logger logger = LoggerFactory.getLogger(ProductQueryEligibiltyService.class);
	/**
	 * EpcLookupMasterService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcLookupMasterService epcLookupMasterService;
	
	/**
	 * EpcProductInitChannelService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductInitChannelService epcProductInitChannelService;
	
	/**
	 * EpcProductAttributeService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductAttributeService epcProductAttributeService;
	
	/**
	 * EpcLocationService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcLocationService epcLocationService;
	
	/**
	 * EpcOrderChannelRuleService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcOrderChannelRuleService epcOrderChannelRuleService;

	/**
	 * EpcAttributeMasterService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcAttributeMasterService epcAttributeMasterService;
	
	/**
	 * ComplexSearchInputService ProductQueryEligibiltyService.java
	 */
	@Autowired
	ComplexSearchInputService complexSearchInputService;
	
	/**
	 * AirRequestService ProductQueryEligibiltyService.java
	 */
	@Autowired
	AirRequestService airRequestService;
	
	/**
	 * ConfigService ProductQueryEligibiltyService.java
	 */
	@Autowired
	ConfigService configService;
	
	/**
	 * EpcProductSpecificationService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	
	/**
	 * EsbRequestService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EsbRequestService esbRequestService;

    /**
     * EpcTariffOverrideService ProductQueryEligibiltyService.java
     */
    @Autowired
	EpcTariffOverrideService epcTariffOverrideService;
    
    /**
     * EpcProductProviderSystemService ProductQueryEligibiltyService.java
     */
    @Autowired
	EpcProductProviderSystemService epcProductProviderSystemService;
	
	/**
	 * DateFormat ProductQueryEligibiltyService.java
	 */
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	
	/**
	 * ObjectMapper ProductQueryEligibiltyService.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * EpcProductMigrationService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductMigrationService epcProductMigrationService;
	
	/**
	 * EpcProductCommunityService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductCommunityService epcProductCommunityService;
	
	@Autowired
	EpcFlexiPlanService epcFlexiPlanService;
	
	@Autowired
	EpcActivityMasterService epcActivityMasterService;
	
	@Autowired
	CacheEligibilityService cacheEligibilityService;
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@Transactional
	public QueryEligibilityResponse checkEligibility(QueryEligibiltySearchInput searchInput, Map<String, List<String>> allRequestParams)
	{
			QueryEligibilityResponse checkEligibilityResponse = new QueryEligibilityResponse();
			if( StringUtils.isBlank(searchInput.getOptionalProductId()) || StringUtils.isBlank(searchInput.getOrderType()) 
				|| StringUtils.isBlank(searchInput.getCustomerRatePlanId()) || StringUtils.isBlank(searchInput.getActionType())
				|| StringUtils.isBlank(searchInput.getInitiatingChannel()) || StringUtils.isBlank(searchInput.getStartDate())
				|| StringUtils.isBlank(searchInput.getSubscribedAddOnIds()) || StringUtils.isBlank(searchInput.getSourceSystem())){
				checkEligibilityResponse.setRemarks("Mandatory Fields are missing. Please provide all mandatory fields ( optionalProductId, orderType, initiatingChannel, actionType, customerRatePlanId, subscribedAddOnIds, sourceSystem, startDate).");
				return checkEligibilityResponse;
			}
			
			boolean hasTariff = false;
			boolean hasChar = false ;
			String ntaWithValue = null;
			String taWithValue = null;
			String withChar = null, withDecomposition = null, withInitChannel = null,withNotification = null, withOcr = null, withProvider = null, withTariff = null, withTor = null;
			List<String> supportedWith = Arrays.asList(new String []{"characteristic", "tariff", "provider", "triggerOrderRule", "decomposition", "notification", "orderChannelRule", "initiatingChannel", "all"});
			List<String> with = allRequestParams.get("with");
			if(with != null && !with.isEmpty()){
				for(String str : with){
					if(!supportedWith.contains(str)){
						if(!(str.contains("ta-") || str.contains("nta-") ) ){
							checkEligibilityResponse.setRemarks("Unsupported with parameter ("+ str +") provided.");
							return checkEligibilityResponse;
						}else if(str.contains("ta-") && !str.contains("nta-")){
							hasTariff = true;
							taWithValue = str;
						}else if(str.contains("nta-")){
							hasChar = true;
							ntaWithValue = str;
						}
					}else{
						switch(str){
							case "characteristic":
								withChar = str; break;
							case "tariff":
								withTariff = str; break;
							case "provider":
								withProvider = str; break;
							case "triggerOrderRule":
								withTor = str; break;
							case "decomposition":
								withDecomposition = str; break;
							case "notification":
								withNotification = str; break;
							case "orderChannelRule":
								withOcr = str; break;
							case "initiatingChannel":
								withInitChannel = str; break;
						}
					}
				}
			}
			
			
			boolean cacheFound = false;
			Config config = configService.searchConfigKey("ext_api","cache_eligibility_flag");
			if(config != null && Boolean.parseBoolean(config.getConfigValue())){
				StringBuilder query = new StringBuilder("select * from cache_eligibility where 1=1 ");
				if(StringUtils.isNotBlank(searchInput.getActionType())){
					query.append(" and action_type = '").append(searchInput.getActionType()).append("'");
				}else{
					query.append(" and action_type is null");
				}
				if(StringUtils.isNotBlank(searchInput.getBypassEligibilityCheck())){
					query.append(" and bypass_eligibility_check = '").append(searchInput.getBypassEligibilityCheck()).append("'");
				}else{
					query.append(" and bypass_eligibility_check is null");
				}
				if(StringUtils.isNotBlank(searchInput.getCommunityId())){
					query.append(" and community_id = '").append(searchInput.getCommunityId()).append("'");
				}else{
					query.append(" and community_id is null");
				}
				if(StringUtils.isNotBlank(searchInput.getCustomerRatePlanId())){
					query.append(" and customer_rate_plan_id = '").append(searchInput.getCustomerRatePlanId()).append("'");
				}else{
					query.append(" and customer_rate_plan_id is null");
				}
				if(searchInput.getData() != null){
					query.append(" and data = ").append(searchInput.getData());
				}else{
					query.append(" and data is null");
				}
				if(StringUtils.isNotBlank(searchInput.getDataUnit())){
					query.append(" and data_unit = '").append(searchInput.getDataUnit()).append("'");
				}else{
					query.append(" and data_unit is null");
				}
				if(searchInput.getFlexiPrice() != null){
					query.append(" and flexi_price = ").append(searchInput.getFlexiPrice());
				}else{
					query.append(" and flexi_price is null");
				}
				if(StringUtils.isNotBlank(searchInput.getInitiatingChannel())){
					query.append(" and initiating_channel = '").append(searchInput.getInitiatingChannel()).append("'");
				}else{
					query.append(" and initiating_channel is null");
				}
				if(StringUtils.isNotBlank(searchInput.getOptionalProductId())){
					query.append(" and optional_product_id = '").append(searchInput.getOptionalProductId()).append("'");
				}else{
					query.append(" and optional_product_id is null");
				}
				if(StringUtils.isNotBlank(searchInput.getOrderType())){
					query.append(" and order_type = '").append(searchInput.getOrderType()).append("'");
				}else{
					query.append(" and order_type is null");
				}
				if(StringUtils.isNotBlank(searchInput.getOtherProductId1())){
					query.append(" and other_product_id1 = '").append(searchInput.getOtherProductId1()).append("'");
				}else{
					query.append(" and other_product_id1 is null");
				}
				if(StringUtils.isNotBlank(searchInput.getOtherProductId2())){
					query.append(" and other_product_id2 = '").append(searchInput.getOtherProductId2()).append("'");
				}else{
					query.append(" and other_product_id2 is null");
				}
				if(StringUtils.isNotBlank(searchInput.getOtherProductId3())){
					query.append(" and other_product_id3 = '").append(searchInput.getOtherProductId3()).append("'");
				}else{
					query.append(" and other_product_id3 is null");
				}
				if(StringUtils.isNotBlank(searchInput.getOtherProductId4())){
					query.append(" and other_product_id4 = '").append(searchInput.getOtherProductId4()).append("'");
				}else{
					query.append(" and other_product_id4 is null");
				}
				if(StringUtils.isNotBlank(searchInput.getSalesChannel())){
					query.append(" and sales_channel = '").append(searchInput.getSalesChannel()).append("'");
				}else{
					query.append(" and sales_channel is null");
				}
				if(StringUtils.isNotBlank(searchInput.getSlabId())){
					query.append(" and slab_id = '").append(searchInput.getSlabId()).append("'");
				}else{
					query.append(" and slab_id is null");
				}
				if(searchInput.getSms() != null){
					query.append(" and sms = ").append(searchInput.getSms());
				}else{
					query.append(" and sms is null");
				}
				if(StringUtils.isNotBlank(searchInput.getSourceSystem())){
					query.append(" and source_system = '").append(searchInput.getSourceSystem()).append("'");
				}else{
					query.append(" and source_system is null");
				}
				if(StringUtils.isNotBlank(searchInput.getStartDate())){
					query.append(" and start_date = '").append(searchInput.getStartDate()).append("'");
				}else{
					query.append(" and start_date is null");
				}
				if(StringUtils.isNotBlank(searchInput.getSubscribedAddOnIds())){
					query.append(" and subscribed_add_on_id = '").append(searchInput.getSubscribedAddOnIds()).append("'");
				}else{
					query.append(" and subscribed_add_on_id is null");
				}
				if(searchInput.getValidity() != null){
					query.append(" and validity = ").append(searchInput.getValidity());
				}else{
					query.append(" and validity is null");
				}
				if(searchInput.getVoice() != null){
					query.append(" and voice = ").append(searchInput.getVoice());
				}else{
					query.append(" and voice is null");
				}
				if(StringUtils.isNotBlank(searchInput.getVoiceType())){
					query.append(" and voice_type = '").append(searchInput.getVoiceType()).append("'");
				}else{
					query.append(" and voice_type is null");
				}
				if(StringUtils.isNotBlank(searchInput.getVoiceUnit())){
					query.append(" and voice_unit = '").append(searchInput.getVoiceUnit()).append("'");
				}else{
					query.append(" and voice_unit is null");
				}
				if(StringUtils.isNotBlank(withChar)){
					query.append(" and with_char = '").append(withChar).append("'");
				}else{
					query.append(" and with_char is null");
				}
				if(StringUtils.isNotBlank(withDecomposition)){
					query.append(" and with_decomposition = '").append(withDecomposition).append("'");
				}else{
					query.append(" and with_decomposition is null");
				}
				if(StringUtils.isNotBlank(withInitChannel)){
					query.append(" and with_init_channel = '").append(withInitChannel).append("'");
				}else{
					query.append(" and with_init_channel is null");
				}
				if(StringUtils.isNotBlank(withNotification)){
					query.append(" and with_notification = '").append(withNotification).append("'");
				}else{
					query.append(" and with_notification is null");
				}
				if(StringUtils.isNotBlank(ntaWithValue)){
					query.append(" and with_nta = '").append(ntaWithValue).append("'");
				}else{
					query.append(" and with_nta is null");
				}
				if(StringUtils.isNotBlank(taWithValue)){
					query.append(" and with_ta = '").append(taWithValue).append("'");
				}else{
					query.append(" and with_ta is null");
				}
				if(StringUtils.isNotBlank(withOcr)){
					query.append(" and with_ocr = '").append(withOcr).append("'");
				}else{
					query.append(" and with_ocr is null");
				}
				if(StringUtils.isNotBlank(withProvider)){
					query.append(" and with_provider = '").append(withProvider).append("'");
				}else{
					query.append(" and with_provider is null");
				}
				if(StringUtils.isNotBlank(withTariff)){
					query.append(" and with_tariff = '").append(withTariff).append("'");
				}else{
					query.append(" and with_tariff is null");
				}
				if(StringUtils.isNotBlank(withTor)){
					query.append(" and with_tor = '").append(withTor).append("'");
				}else{
					query.append(" and with_tor is null");
				}
				
			//	logger.debug("Cache Eligibility Search query is : {}",query.toString() );
				List<CacheEligibility> eligibilities = cacheEligibilityService.searchEligibility(query.toString());
				ObjectMapper mapper = new ObjectMapper();
				if(eligibilities != null && !eligibilities.isEmpty()){
					try {
						checkEligibilityResponse = mapper.readValue(eligibilities.get(0).getResponse(), QueryEligibilityResponse.class);
						cacheFound = true;
					} catch (JsonParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (JsonMappingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}					
				}
				//search in cache table
				//if found send the response
				
			}
			if(!cacheFound){
				checkEligibilityResponse = checkEligibilityWOCache(searchInput, allRequestParams, checkEligibilityResponse, hasTariff, hasChar, with);
				if(config != null && Boolean.parseBoolean(config.getConfigValue())){
					try {
						CacheEligibility cacheEligibility = new CacheEligibility(searchInput.getActionType(),searchInput.getBypassEligibilityCheck(), searchInput.getCommunityId(),searchInput.getCustomerRatePlanId(), searchInput.getData(),
								searchInput.getDataUnit(), searchInput.getFlexiPrice(), searchInput.getInitiatingChannel(), searchInput.getOptionalProductId(), searchInput.getOrderType(), searchInput.getOtherProductId1(),
						 		searchInput.getOtherProductId2(), searchInput.getOtherProductId3(), searchInput.getOtherProductId4(), EPCUtils.objectToJson(checkEligibilityResponse), searchInput.getSalesChannel(), searchInput.getSlabId(),
						 		searchInput.getSms(), searchInput.getSourceSystem(), searchInput.getStartDate(), searchInput.getSubscribedAddOnIds(), searchInput.getValidity(), searchInput.getVoice(), searchInput.getVoiceType(), searchInput.getVoiceUnit(),
						 		withChar, withDecomposition, withInitChannel,withNotification, ntaWithValue, withOcr, withProvider, taWithValue, withTariff, withTor);
						cacheEligibilityService.saveEligibility(cacheEligibility);
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			return checkEligibilityResponse;
	}
	
	
	private QueryEligibilityResponse checkEligibilityWOCache(QueryEligibiltySearchInput searchInput, Map<String, List<String>> allRequestParams, QueryEligibilityResponse checkEligibilityResponse, boolean hasTariff, boolean hasChar, List<String> with){
		
			BigDecimal flexiPrice = null;
			boolean isFlexi = false;
			if( StringUtils.isBlank(searchInput.getDataUnit()) && searchInput.getData()==null && StringUtils.isBlank(searchInput.getVoiceType()) && searchInput.getVoice()==null
					&& StringUtils.isBlank(searchInput.getVoiceUnit()) && searchInput.getSms() == null && searchInput.getValidity()==null && searchInput.getFlexiPrice()==null ){
				//do nothing
			}else if( StringUtils.isNotBlank(searchInput.getDataUnit()) && searchInput.getData()!=null && StringUtils.isNotBlank(searchInput.getVoiceType()) && searchInput.getVoice()!=null
					&& StringUtils.isNotBlank(searchInput.getVoiceUnit()) && searchInput.getSms() != null && searchInput.getValidity()!=null && searchInput.getFlexiPrice()!=null ){
				FlexiPlanInput input = new FlexiPlanInput();
				input.setData(searchInput.getData());
				input.setDataUnit(searchInput.getDataUnit());
				input.setVoice(searchInput.getVoice());
				input.setVoiceUnit(searchInput.getVoiceUnit());
				input.setVoiceType(searchInput.getVoiceType());
				input.setSms(searchInput.getSms());
				input.setValidity(searchInput.getValidity());
				isFlexi = true;
				flexiPrice = epcFlexiPlanService.flexiPlanPrice(input);
			}else {
				throw new GenericException("Either ALL or NONE of these fields(data,dataUnit,voice,voiceUnit,voiceType,sms,validity,flexiPrice) need to be provided.", 
						"Either all or none of these fields(data, dataUnit,voice,voiceUnit,voiceType,sms,validity,flexiPrice) need to be provided.", 
						"Either all or none of these fields(data, dataUnit,voice,voiceUnit,voiceType,sms,validity,flexiPrice) need to be provided.");
			}
			if( StringUtils.isNotBlank(searchInput.getSlabId()) && StringUtils.isBlank(searchInput.getCommunityId()) ){
					throw new GenericException("InvalidSearch", "slabId cann't be provided without communityId.", "slabId cann't be provided without communityId.");
			}
			
			String discountedPrice = null;
			boolean slabPriceFound =  false;
			boolean bypassEligibilityCheck = false;
			if(StringUtils.isNotBlank(searchInput.getBypassEligibilityCheck()) && "1".equals(searchInput.getBypassEligibilityCheck())){
				bypassEligibilityCheck = true;
			}			
			
			checkEligibilityResponse.setEligible(false);
			boolean isOCREligible = false;
			boolean isBasicEligible = false;
			boolean isProductCompatible = false;
			boolean isCommunityEligible = false;
			boolean isAreaEligible = false;
			boolean isTerritoryEligible = false;
			boolean isRegionEligible = false;
			boolean isAvailabilityEligible = false;
			boolean isSegmentEligible = false;
			boolean isMsisdnEligible = false;
		
			Integer addOnProdId = fetchAddOnProductId(searchInput);
			logger.info("Add on Product Id : "+addOnProdId);
			EpcProductSpecification addOnProd = null;
			if (addOnProdId != null) {
				ComplexSearchInput complexSearchInput = new ComplexSearchInput();
				complexSearchInput.setProductId(String.valueOf(addOnProdId));
				MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
				criteria.add("with", "segment");
				criteria.add("with", "location");
				criteria.add("with", "community");
				criteria.add("with", "availability");
				criteria.add("with", "compatibility");
				criteria.add("with", "initiatingChannel");
				criteria.add("with", "salesChannel");
				criteria.add("with", "migration");
				List<EpcProductSpecification> prodList = complexSearchInputService.searchComplex(complexSearchInput, criteria, false);
				
				if(prodList != null && !prodList.isEmpty()) {
					addOnProd = prodList.get(0);
				} else{
					checkEligibilityResponse.setRemarks("Product not found for the Addon Product Id : "+addOnProdId);
					return checkEligibilityResponse;
				}
			}else{
				List<String> initChannelLookups = epcLookupMasterService.getLookUpValuesByGroupAndName("epc_product_init_channel", "channel_id");
				if(!initChannelLookups.contains(searchInput.getInitiatingChannel())){
					checkEligibilityResponse.setRemarks("Invalid Initiating Channel provided.");
					return checkEligibilityResponse;
				}
				List<String> lookups = epcLookupMasterService.getLookUpValuesByGroupAndName("epc_product_init_channel", "action_type");
				if(!lookups.contains(searchInput.getActionType())){
					checkEligibilityResponse.setRemarks("Invalid Action Type provided.");
					return checkEligibilityResponse;
				}
				checkEligibilityResponse.setRemarks("No Optional Product Id found for requested combination ("+searchInput.getOptionalProductId()+", "+searchInput.getInitiatingChannel()+", "+searchInput.getActionType()+").");
				return checkEligibilityResponse;
			}
			
			if(Constants.SOURCE_SYSTEM_ESB.equals(searchInput.getSourceSystem()) && Constants.DOWNSTREAM_SYSTEM_COMS.equals(addOnProd.getDownstreamSystem())){
				checkEligibilityResponse.setRemarks("Downstream System requested.");
				checkEligibilityResponse.setDownStream(addOnProd.getDownstreamSystem());
				return checkEligibilityResponse;
			}
			
			
			//logic to fetch primary product from CBIO.	
			String [] primaryIds = searchInput.getCustomerRatePlanId().split(":");
			String providerProdId = null;
			String providerSysCd = null;
			if (primaryIds.length == 2) {
				providerProdId = primaryIds[1];
				providerSysCd = primaryIds[0];
			}
			String prodId = null;
			EpcProductSpecification primaryProduct = null;
			if (StringUtils.isNotBlank(providerProdId) && StringUtils.isNotBlank(providerSysCd)) {
				
				Map<String, List<String>> providerSystemParams = new HashMap<String, List<String>>();
				providerSystemParams.put("providerProductId", Arrays.asList(new String []{providerProdId}));
				providerSystemParams.put("providerSystemCode", Arrays.asList(new String []{providerSysCd}));
				List<EpcProductProviderSystem> providers = epcProductProviderSystemService.searchProvider(providerSystemParams);
				if(providers != null && !providers.isEmpty()){
					prodId = String.valueOf(providers.get(0).getProductId());
				}else{
					checkEligibilityResponse.setRemarks("Product id not mapped for the provider product id : "+providerProdId);
					return checkEligibilityResponse;
				}
				ComplexSearchInput complexSearchInput = new ComplexSearchInput();
				complexSearchInput.setProductId(prodId);
				MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
				criteria.add("with", "segment");
				criteria.add("with", "location");
				criteria.add("with", "community");
				criteria.add("with", "availability");
				criteria.add("with", "compatibility");
				List<EpcProductSpecification> prodList = complexSearchInputService.searchComplex(complexSearchInput, criteria, false);
				if(prodList != null && !prodList.isEmpty()) {
					primaryProduct = prodList.get(0);
				} else{
					checkEligibilityResponse.setRemarks("Product not found for the epc product id : "+prodId);
					return checkEligibilityResponse;
				}
			}else{
				checkEligibilityResponse.setRemarks("Invalid customerRatePlanId provided.");
				return checkEligibilityResponse;
			}
			
			if (!(primaryProduct.getProductStatus().equals(Constants.PRODUCT_STATUS_LAUNCH))) {
				checkEligibilityResponse
						.setRemarks("Rate plan is not in Launch status.");
				return checkEligibilityResponse;
			}
			
			if(Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(primaryProduct.getProductSubCategory()) && StringUtils.isBlank(searchInput.getCommunityId())){
				checkEligibilityResponse.setRemarks("Community Id is not provided for the Rate Plan whose subCategory is Corporate.");
				return checkEligibilityResponse;
			}else if(Constants.PRODUCT_SUB_CATEGORY_REGULAR.equals(primaryProduct.getProductSubCategory()) && StringUtils.isNotBlank(searchInput.getCommunityId())){
				checkEligibilityResponse.setRemarks("Community Id is provided whereas subCategory of Rate Plan is not Corporate.");
				return checkEligibilityResponse;
			}
			
			if (!bypassEligibilityCheck) {
				//logic for OCR check
				if (!validateOrderChannelRule(searchInput.getOrderType(),
						searchInput.getInitiatingChannel(),
						searchInput.getSalesChannel())) {
					checkEligibilityResponse
							.setRemarks("Failed for Order Channel Rule check.");
					return checkEligibilityResponse;
				}
				String nonNetworkVASClassifications = configService.searchConfigKey("ext_api","non_network_vas_classifications").getConfigValue();
				if (nonNetworkVASClassifications == null) {
					checkEligibilityResponse
							.setRemarks("Non Network VAS Classifications is not defined in config table.");
					return checkEligibilityResponse;
				}
				String nonNetworkVASCompatibility = configService.searchConfigKey("ext_api","non_network_vas_compatibility_flag").getConfigValue();
				if (nonNetworkVASCompatibility == null) {
					checkEligibilityResponse
							.setRemarks("Non Network VAS Compatibility Flag is not defined in config table.");
					return checkEligibilityResponse;
				}
				
				String A2ACompatibility = configService.searchConfigKey("ext_api","a2a_compatibility_flag").getConfigValue();
				if (A2ACompatibility == null) {
					checkEligibilityResponse
							.setRemarks("Addon to Addon Compatibility Flag is not defined in config table.");
					return checkEligibilityResponse;
				}
				boolean A2ACompatibilityFlag = Boolean.parseBoolean(A2ACompatibility);
				
				boolean nonNetworkVASCompatibilityFlag = Boolean
						.parseBoolean(nonNetworkVASCompatibility);
				
				List<String> nonNetworkVASCompatibilitylist = new ArrayList<String>();
				
				String[] nonNetworkVASClassificationsList = nonNetworkVASClassifications
						.split(",");
				for (String str : nonNetworkVASClassificationsList) {
					nonNetworkVASCompatibilitylist.add(str.trim());
				}
				Set<Integer> safccList = new HashSet<Integer>();//Subscribed add ons for compatibility check
				if (!nonNetworkVASCompatibilityFlag && nonNetworkVASCompatibilitylist.contains(addOnProd
						.getProductClassification())) {
					//do nothing
				}else {
					List<Map<String, String>> subscriptionVASList = fetchSubscribedAddons(searchInput.getSubscribedAddOnIds());
					if (subscriptionVASList != null) {
						safccList.addAll(getAddOnIds(subscriptionVASList));
					}
				}
					
				try {
					logger.debug("SAFCC list is :"+mapper.writeValueAsString(safccList));
				} catch (JsonProcessingException e1) {
					logger.warn("Exception during JSON conversion >>"+ExceptionUtils.getStackTrace(e1));
				}
				//logic for compatible check
				List<EpcProductCompatibility> addOnCompatibilities = addOnProd
						.getEpcProductCompatibility();
				if (addOnCompatibilities != null) {
					List<Integer> addOnCompatibilityIds = new ArrayList<Integer>();
					for (EpcProductCompatibility epcProductCompatibility : addOnCompatibilities) {
						addOnCompatibilityIds.add(epcProductCompatibility
								.getOtherProductId());
					}
					if (!nonNetworkVASCompatibilityFlag && nonNetworkVASCompatibilitylist.contains(addOnProd
							.getProductClassification())) {
						isProductCompatible = true;
					}else{
						if(addOnCompatibilityIds.contains(primaryProduct.getProductId())){
							isProductCompatible = true;
						}
					}
					List<String> aOIds = new ArrayList<String>();
					for(Integer id : addOnCompatibilityIds){
						aOIds.add(String.valueOf(id));
					}
					Map<String, List<String>> addOnCompIdsParams = new HashMap<String, List<String>>();
					addOnCompIdsParams.put("productId", aOIds);
					List<EpcProductSpecification>  addOnCompProds = epcProductSpecificationService.getBasicProductSpecByID(addOnCompIdsParams);
					List<Integer> finalAOIds = new ArrayList<Integer>();
					if (addOnCompProds != null && !addOnCompProds.isEmpty()) {
						for (EpcProductSpecification prd : addOnCompProds) {
							if (Constants.PRODUCT_TYPE_OPTIONAL.equalsIgnoreCase(prd
									.getProductType())) {
								finalAOIds.add(prd.getProductId());
							}
						}
					}
					if (A2ACompatibilityFlag && !finalAOIds.isEmpty()) {
						finalAOIds.retainAll(safccList);
						if (finalAOIds.isEmpty()) {
							isProductCompatible = false;
						}
					}
				} else {
					if (!nonNetworkVASCompatibilityFlag && nonNetworkVASCompatibilitylist.contains(addOnProd
							.getProductClassification())) {
						isProductCompatible = true;
					}
				}
				if (!isProductCompatible) {
					checkEligibilityResponse
							.setRemarks("Failed for Compatibility level check.");
					return checkEligibilityResponse;
				}
				
				if(Constants.ACTION_TYPE_SUBSCRIPTION.equals(searchInput.getActionType())){
					List<EpcProductSpecification> subscribedRoamingProds = null;
					if(!safccList.isEmpty()){
						List<String> safccProdIds = new ArrayList<String>();
						for(Integer id : safccList){
							safccProdIds.add(String.valueOf(id));
						}
						Map<String, List<String>> safccParams = new HashMap<String, List<String>>();
						safccParams.put("productId", safccProdIds);
						safccParams.put("isRoamingProduct", Arrays.asList(new String []{"1"}));
						subscribedRoamingProds = epcProductSpecificationService.getBasicProductSpecByID(safccParams);
					}
					if(addOnProd.getIsRoamingProduct() == 1 && (subscribedRoamingProds != null && subscribedRoamingProds.size() == 1)){
						if(addOnProd.getProductId().equals(subscribedRoamingProds.get(0).getProductId())){
							checkEligibilityResponse.setResponseCode("RES_ELI_RoamProdAlreadySubs");
							checkEligibilityResponse.setRemarks("Eligibility fails as requested roaming product is same as subscribed roaming product.");
							return checkEligibilityResponse;
						}
						Map<String, List<String>> migParams = new HashMap<String, List<String>>();
						migParams.put("sourceProductId", Arrays.asList(new String []{String.valueOf(subscribedRoamingProds.get(0).getProductId())}));
						List<EpcProductMigration> migrations = epcProductMigrationService.searchEpcProductMigration(migParams);
						if(migrations != null && !migrations.isEmpty()){
							Set<Integer> commonMig = new HashSet<Integer>();
							for(EpcProductMigration migration : migrations){
								commonMig.add(migration.getTargetProductId());
							}
							
							if(!commonMig.contains(addOnProd.getProductId())){
								checkEligibilityResponse.setResponseCode("RES_ELI_NoMigRuleDefinedForOptProd");
								checkEligibilityResponse.setRemarks("For the subscribed roaming product :"+subscribedRoamingProds.get(0).getProductShortCode()+", no migration rule defined for optional product :"+addOnProd.getProductShortCode());
								return checkEligibilityResponse;
							}
						}else{
							checkEligibilityResponse.setResponseCode("RES_ELI_NoMigRuleDefinedForSubsRoamProd");
							checkEligibilityResponse.setRemarks("No migration rule defined for the subscribed roaming product :"+subscribedRoamingProds.get(0).getProductShortCode());
							return checkEligibilityResponse;
						}
					}else if(addOnProd.getIsRoamingProduct() == 1 && (subscribedRoamingProds != null && subscribedRoamingProds.size() > 1)){
						checkEligibilityResponse.setResponseCode("RES_ELI_MoreThnOneRoamProdSubs");
						checkEligibilityResponse.setRemarks("More than one roaming products have been subscribed.");
						return checkEligibilityResponse;
					}
				}
				
				//logic for basicinfo check
				if (primaryProduct.getProductAssociationLevel().equals(
						addOnProd.getProductAssociationLevel())
						&& primaryProduct.getProductFamily().equals(
								addOnProd.getProductFamily())
						&& EPCUtils.validateCategory(
								primaryProduct.getProductCategory(),
								addOnProd.getProductCategory())
						&& EPCUtils.validateSubCategory(primaryProduct.getProductSubCategory(),
								addOnProd.getProductSubCategory())) {
					isBasicEligible = true;
				} else {
					checkEligibilityResponse
							.setRemarks("Failed for Family/Category/SubCategory/Association level check.");
					return checkEligibilityResponse;
				}
				//logic for segment check
				if (StringUtils.isNotBlank(searchInput.getSegment())) {
					boolean pFound = false;
					boolean aFound = false;
					List<EpcProductSegment> primaryProductSegments = primaryProduct
							.getEpcProductSegment();
					List<EpcProductSegment> addOnProdSegments = addOnProd
							.getEpcProductSegment();
					if (primaryProductSegments != null
							&& addOnProdSegments != null) {
						for (EpcProductSegment epcProductSegment : primaryProductSegments) {
							if (epcProductSegment.getSegment().equals(
									searchInput.getSegment())) {
								pFound = true;
								break;
							}
						}
						for (EpcProductSegment epcProductSegment : addOnProdSegments) {
							if (epcProductSegment.getSegment().equals(
									searchInput.getSegment())) {
								aFound = true;
								break;
							}
						}
						if (pFound && aFound) {
							isSegmentEligible = true;
						}
					}

				} else {
					isSegmentEligible = true;
				}
				if (!isSegmentEligible) {
					checkEligibilityResponse
							.setRemarks("Failed for Segment level check.");
					return checkEligibilityResponse;
				}
				//logic for community check
				
				if (StringUtils.isNotBlank(searchInput.getCommunityId()) &&  Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(primaryProduct.getProductSubCategory())) {
					if (Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(addOnProd.getProductSubCategory()) || Constants.PRODUCT_SUB_CATEGORY_ALL.equals(addOnProd.getProductSubCategory())) {
						boolean pFound = false;
						byte isEmployeeAllowedToPurchase = 0;
						List<EpcProductCommunity> primaryProductCommunities = primaryProduct
								.getEpcProductCommunity();
						List<EpcProductCommunity> addOnProdCommunities = addOnProd
								.getEpcProductCommunity();
						if (primaryProductCommunities != null) {
							for (EpcProductCommunity epcProductCommunity : primaryProductCommunities) {
								if (String.valueOf(
										epcProductCommunity.getCommunityId())
										.equals(searchInput.getCommunityId())  && 
										Constants.COMMUNITY_APPLICABLE_EMP_Band_ALL
										.equals(epcProductCommunity.getApplicableEmpBand())) {
									isEmployeeAllowedToPurchase = epcProductCommunity.getIsEmployeeAllowedToPurchase();
									pFound = true;
									break;
								}
							}
							if(!pFound){
								checkEligibilityResponse
								.setRemarks("Community id not mapped for the given rate plan :"+primaryProduct.getProductShortCode());
								return checkEligibilityResponse;
							}
							if(isEmployeeAllowedToPurchase == 1){
										if(addOnProd.getIsCorporateSpecific() != null && addOnProd.getIsCorporateSpecific() == 1){
											if (addOnProdCommunities != null) {
												for (EpcProductCommunity epcProductCommunity : addOnProdCommunities) {
													if (searchInput.getCommunityId().equals(
															String.valueOf(epcProductCommunity
																	.getCommunityId()))) {
														isCommunityEligible = true;
														break;
													}
												}
											}
										}else{
											isCommunityEligible = true;
										}		
							}else{
								if (addOnProdCommunities != null) {
									for (EpcProductCommunity epcProductCommunity : addOnProdCommunities) {
										if (searchInput
												.getCommunityId()
												.equals(String
														.valueOf(epcProductCommunity
																.getCommunityId()))) {
											isCommunityEligible = true;
											break;
										}
									}
								}
							}
							if((with!= null && (with.contains("all") ||with.contains("tariff") || hasTariff )) &&
									StringUtils.isNotBlank(searchInput.getSlabId()) && addOnProdCommunities != null && isCommunityEligible){	
								for (EpcProductCommunity epcProductCommunity : addOnProdCommunities) {
									if (String.valueOf(
											epcProductCommunity.getCommunityId())
											.equals(searchInput.getCommunityId())
											&& 
											searchInput.getSlabId()
											.equals(epcProductCommunity.getSlabId())
											&& Constants.COMMUNITY_STATUS_ACTIVE.equals(epcProductCommunity.getCommunityStatus())) {
											discountedPrice = String.valueOf(epcProductCommunity.getDiscountedPrice());
											slabPriceFound=true;
									}
								}
							}
						}
					}
					
					if (!isCommunityEligible) {
						checkEligibilityResponse
								.setRemarks("Failed for Community level check.");
						return checkEligibilityResponse;
					}
				} 
				
				//logic for init channel check
				boolean initChannelCheck = false;
				List<EpcProductInitChannel> initChannels = addOnProd
						.getEpcProductInitChannel();
				if (initChannels != null) {
					for (EpcProductInitChannel initChannel : initChannels) {
						if (searchInput.getInitiatingChannel().equals(
								initChannel.getChannelId())
								&& initChannel.getStatus().equals(Constants.INIT_CHANNEL_STATUS_ACTIVE)) {
							initChannelCheck = true;
							break;
						}
					}
				}
				if (!initChannelCheck) {
					checkEligibilityResponse
							.setRemarks("Failed for Init Channel level check.");
					return checkEligibilityResponse;
				}
				if (StringUtils.isNotBlank(searchInput.getSalesChannel())) {
					//logic for sales channel check			
					boolean salesChannelCheck = false;
					List<EpcProductSalesChannel> saleChannels = addOnProd
							.getEpcProductSalesChannel();
					if (saleChannels != null) {
						for (EpcProductSalesChannel salesChannel : saleChannels) {
							if (searchInput.getSalesChannel().equals(
									salesChannel.getPartnerType())) {
								salesChannelCheck = true;
								break;
							}
						}
					}
					if (!salesChannelCheck) {
						checkEligibilityResponse
								.setRemarks("Failed for Sales Channel level check.");
						return checkEligibilityResponse;
					}
				}
				List<EpcProductLocation> primaryProductLocations = primaryProduct
						.getEpcProductLocation();
				List<EpcProductLocation> addOnProdLocations = addOnProd
						.getEpcProductLocation();
				//logic for Region check
				if (StringUtils.isNotBlank(searchInput.getRegion())) {
					boolean pFound = false;
					boolean aFound = false;
					if (primaryProductLocations != null
							&& addOnProdLocations != null) {
						for (EpcProductLocation epcProductLoc : primaryProductLocations) {
							if (searchInput.getRegion().equals(epcProductLoc.getLocationCode2())) {
								pFound = true;
								break;
							}
						}
						for (EpcProductLocation epcProductLoc : addOnProdLocations) {
							if (searchInput.getRegion().equals(epcProductLoc.getLocationCode2())) {
								aFound = true;
								break;
							}
						}
						if (pFound && aFound) {
							isRegionEligible = true;
						}
					}

				} else {
					isRegionEligible = true;
				}
				if (!isRegionEligible) {
					checkEligibilityResponse
							.setRemarks("Failed for Region level check.");
					return checkEligibilityResponse;
				}
				//logic for Area check
				if (StringUtils.isNotBlank(searchInput.getArea())) {
					boolean pFound = false;
					boolean aFound = false;
					if (primaryProductLocations != null
							&& addOnProdLocations != null) {
						for (EpcProductLocation epcProductLoc : primaryProductLocations) {
							if (searchInput.getArea().equals(epcProductLoc.getLocationCode3())) {
								pFound = true;
								break;
							}
						}
						for (EpcProductLocation epcProductLoc : addOnProdLocations) {
							if (searchInput.getArea().equals(epcProductLoc.getLocationCode3())) {
								aFound = true;
								break;
							}
						}
						if (pFound && aFound) {
							isAreaEligible = true;
						}
					}

				} else {
					isAreaEligible = true;
				}
				if (!isAreaEligible) {
					checkEligibilityResponse
							.setRemarks("Failed for Area level check.");
					return checkEligibilityResponse;
				}
				//logic for Territory check
				if (StringUtils.isNotBlank(searchInput.getTerritory())) {
					boolean pFound = false;
					boolean aFound = false;
					if (primaryProductLocations != null
							&& addOnProdLocations != null) {
						for (EpcProductLocation epcProductLoc : primaryProductLocations) {
							if (searchInput.getTerritory().equals(epcProductLoc.getLocationCode4())) {
								pFound = true;
								break;
							}
						}
						for (EpcProductLocation epcProductLoc : addOnProdLocations) {
							if (searchInput.getTerritory().equals(epcProductLoc.getLocationCode4())) {
								aFound = true;
								break;
							}
						}
						if (pFound && aFound) {
							isTerritoryEligible = true;
						}
					}

				} else {
					isTerritoryEligible = true;
				}
				if (!isTerritoryEligible) {
					checkEligibilityResponse
							.setRemarks("Failed for Territory level check.");
					return checkEligibilityResponse;
				}
				if (addOnProd.getIsProductPaused() == 1) {
					checkEligibilityResponse
							.setRemarks("Failed for add on product isPaused check.");
					return checkEligibilityResponse;
				}
				if (!(addOnProd.getProductStatus().equals(Constants.PRODUCT_STATUS_LAUNCH))) {
					checkEligibilityResponse
							.setRemarks("Failed for add on product status check.");
					return checkEligibilityResponse;
				}
				//start date check
				Date startDate;
				try {
					startDate = df.parse(searchInput.getStartDate());
				} catch (ParseException e) {
					logger.warn(e.getMessage());
					checkEligibilityResponse
							.setRemarks("Start Date is not provided in proper format.");
					return checkEligibilityResponse;
				}
				EpcProductAvailability availability = addOnProd
						.getEpcProductAvailability().get(0);
				if (availability.getLifeValidityStartDate().before(startDate)
						&& availability.getLifeValidityEndDate().after(
								startDate)
						&& availability.getSubscriptionStartDate().before(
								startDate)
						&& availability.getSubscriptionEndDate().after(
								startDate)
						&& availability.getSellingStartDate().before(startDate)
						&& availability.getSellingEndDate().after(startDate)) {
					isAvailabilityEligible = true;
				} else {
					checkEligibilityResponse
							.setRemarks("Failed for Start Date check.");
					return checkEligibilityResponse;
				}
			}
			//sending success response.			
			ComplexSearchInput complexSearchInput = new ComplexSearchInput();
			complexSearchInput.setProductId(String.valueOf(addOnProdId));
			if(StringUtils.isNotBlank(searchInput.getOrderType())){
				complexSearchInput.setOrderType(searchInput.getOrderType());
			}
			
			EpcProductSpecification addonEligibleProduct = SerializationUtils.clone(complexSearchInputService.searchComplex(complexSearchInput, allRequestParams, true).get(0));
			//-----------------------------------logic to check tariff override amount starts--------------------------------
			if (with!= null && (with.contains("all") || with.contains("tariff") || hasTariff )) {
				boolean isSubFeeDefined = false;
				if(addonEligibleProduct.getEpcProductTariff() != null && addonEligibleProduct.getEpcProductTariff() .size() >0 ){
					for(EpcProductAttribute attr : addonEligibleProduct.getEpcProductTariff()){
						if(Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr.getEpcAttributeMaster().getAttributeCtg()) && 
								Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr.getEpcAttributeMaster().getAttributeCtgType()) &&
								Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							isSubFeeDefined = true;
							break;
						}
					}
				}
				if (!isSubFeeDefined) {
					checkEligibilityResponse
							.setRemarks("SUBSCRIPTION_FEE for OneTime Charge is not defined for Addon :"
									+ addonEligibleProduct
											.getProductShortCode());
					return checkEligibilityResponse;
				}
			}
			if(with!= null && (with.contains("all") || with.contains("tariff") || hasTariff ) && isFlexi){
					if(addonEligibleProduct.getEpcProductTariff() != null && addonEligibleProduct.getEpcProductTariff() .size() >0 ){
						for(EpcProductAttribute attr : addonEligibleProduct.getEpcProductTariff()){
							if(Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr.getEpcAttributeMaster().getAttributeCtg()) && 
									Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr.getEpcAttributeMaster().getAttributeCtgType()) &&
									Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
								attr.setAttributeValue1(String.valueOf(flexiPrice));
								break;
							}
						}
					}
			}else{
				if(with!= null && (with.contains("all") || with.contains("tariff") || hasTariff ) 
						&& Constants.OPT_PROD_CALL_BLOCK_SERVICE_POSTPAID.equals(addOnProd.getProductShortCode())  
						&& (Arrays.asList(Constants.XPLORE_LEGEND_PROVIDER_PROD_IDS).contains(providerProdId)
								|| (Constants.PRODUCT_CATEGORY_POSTPAID.equals(primaryProduct.getProductCategory())
						&& Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(primaryProduct.getProductSubCategory())))){
					if(addonEligibleProduct.getEpcProductTariff() != null && addonEligibleProduct.getEpcProductTariff() .size() >0 ){
						for(EpcProductAttribute attr : addonEligibleProduct.getEpcProductTariff()){
							if(Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr.getEpcAttributeMaster().getAttributeCtg()) && 
									Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr.getEpcAttributeMaster().getAttributeCtgType()) &&
									Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
								attr.setAttributeValue1("0");
								break;
							}
						}
					}
				}else{
				
					if (with!= null && (with.contains("all") || with.contains("tariff") || hasTariff ) && StringUtils.isBlank(discountedPrice)) {
						List<BigDecimal> attributeValueList = epcTariffOverrideService
									.getTariffOverrideAmountCached(searchInput.getOtherProductId1(),
											searchInput.getOtherProductId2(), searchInput.getOtherProductId3(),
											searchInput.getOtherProductId4(), primaryProduct
													.getProductShortCode(),
											addonEligibleProduct
													.getProductShortCode());
						if(attributeValueList != null && !attributeValueList.isEmpty()){
							discountedPrice = String.valueOf(attributeValueList.get(0));
						}
					}
					
					if (StringUtils.isNotBlank(discountedPrice)){
						if(addonEligibleProduct.getEpcProductTariff() != null && addonEligibleProduct.getEpcProductTariff() .size() >0 ){
							for(EpcProductAttribute attr : addonEligibleProduct.getEpcProductTariff()){
								if(Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr.getEpcAttributeMaster().getAttributeCtg()) && 
										Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr.getEpcAttributeMaster().getAttributeCtgType()) &&
										Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
									attr.setAttributeValue1(discountedPrice);
									break;
								}
							}
						}
					}
				}
			}
			
			//-----------------------------------logic to check tariff override amount ends----------------------------------
			
			//------------------Logic to override characteristics for flexi price - starts-------------------------------
			if(with != null && (with.contains("all") || with.contains("characteristic") || hasChar ) && isFlexi){
				
				String key = null;
				String transactionType = "";
				if (searchInput.getData().equals(0)){
					key = "N"+searchInput.getValidity();
				}else{
					key = "Y"+searchInput.getValidity();
				}
				String externalData = "";
				List<EpcActivityMaster> activities = epcActivityMasterService.searchActivities("FLEXIPLAN_EXTERNAL_DATA_MASTER", key);
				if(activities != null && !activities.isEmpty()){
					if(activities.get(0).getEpcActivityDetail() != null && !activities.get(0).getEpcActivityDetail().isEmpty()){
						externalData = activities.get(0).getEpcActivityDetail().get(0).getActivityValue();
					}
				}
				if(searchInput.getDataUnit().equals(Constants.DATA_UNIT_MB)){
					searchInput.setData(searchInput.getData()*1);
				}
				else if(searchInput.getDataUnit().equals(Constants.DATA_UNIT_GB)){
					searchInput.setData(searchInput.getData()*1024);
				}
				if(searchInput.getVoiceUnit().equals(Constants.VOICE_UNIT_MINUTES)){
					searchInput.setVoice(searchInput.getVoice()*1);
				}
				else if(searchInput.getVoiceUnit().equals(Constants.VOICE_UNIT_HOURS)){
					searchInput.setVoice(searchInput.getVoice()*60);
				}
				//for converting flexi price into paisa.
				Long priceInPaisa = flexiPrice.multiply(new BigDecimal(100)).longValue();
				if(searchInput.getVoiceType().equals(Constants.VOICE_TYPE_ANYNET)){
					transactionType = String.format("FLXOF%04d%05d%04d%06d", searchInput.getData(),searchInput.getVoice(), searchInput.getSms(), priceInPaisa );
				}else if(searchInput.getVoiceType().equals(Constants.VOICE_TYPE_ONNET)){
					transactionType = String.format("FLXON%04d%05d%04d%06d", searchInput.getData(),searchInput.getVoice(), searchInput.getSms(), priceInPaisa );
				}
				if(addonEligibleProduct.getEpcProductCharacteristic() != null && addonEligibleProduct.getEpcProductCharacteristic().size() >0 ){
					for(EpcProductAttribute attr : addonEligibleProduct.getEpcProductCharacteristic()){
						if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							attr.setAttributeValue1(externalData);
						}else if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1ARON.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							attr.setAttributeValue1(externalData);
						}else if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1SLAB.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							attr.setAttributeValue1(externalData);
						}else if(Constants.ATTRIBUTE_NAME_TRANSACTIONTYPENEW.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							attr.setAttributeValue1(transactionType);
						}
					}
				}
			}else{
				if(with != null && (with.contains("all") || with.contains("characteristic") || hasChar ) && StringUtils.isNotBlank(searchInput.getSlabId()) && (with.contains("all") || with.contains("tariff") || hasTariff ) && !slabPriceFound && Constants.PRODUCT_SUB_FAMILY_DATA.equals(addonEligibleProduct.getProductSubFamily())){
					
					EpcProductAttribute extData1 = null;
					EpcProductAttribute extData1Slab = null;
					if(addonEligibleProduct.getEpcProductCharacteristic() != null && addonEligibleProduct.getEpcProductCharacteristic().size() >0 ){
						for(EpcProductAttribute attr : addonEligibleProduct.getEpcProductCharacteristic()){
							if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
								extData1 = attr;
							}else if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1SLAB.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
								extData1Slab = attr;
							}
						}
					}
					if(extData1 != null && extData1Slab != null){
						extData1Slab.setDefaultValue1(extData1.getDefaultValue1());
						extData1Slab.setAttributeValue1(extData1.getAttributeValue1());
						extData1Slab.setDefaultValue2(extData1.getDefaultValue2());
						extData1Slab.setAttributeValue2(extData1.getAttributeValue2());
					}else{
						checkEligibilityResponse.setRemarks("EXTERNAL_DATA_1/EXTERNAL_DATA_1_SLAB not defined for the product :"+addonEligibleProduct.getProductShortCode()+".");
						return checkEligibilityResponse;
					}
				}
			}
			//------------------Logic to override characteristics for flexi price - end-------------------------------
			
			
			
			
			
			//to filter initChannel beased on initChannel Value provided.			
			if(with != null && (with.contains("all") || with.contains("initiatingChannel"))){
				for( Iterator<EpcProductInitChannel> iterator = addonEligibleProduct.getEpcProductInitChannel().iterator(); iterator.hasNext();  ){
					EpcProductInitChannel epcProductInitChannel = iterator.next();
					if(!((searchInput.getInitiatingChannel().equals(epcProductInitChannel.getChannelId())) && (searchInput.getActionType().equals(epcProductInitChannel.getActionType())))){
						iterator.remove();
					}
				}
			}
			checkEligibilityResponse.setEligible(true);
			if(isFlexi && searchInput.getFlexiPrice().doubleValue() != flexiPrice.doubleValue()){
				checkEligibilityResponse.setRemarks("EPC calculated flexi price does not match with the provided flexi price.");
			}else{
				checkEligibilityResponse.setRemarks("NA");
			}
			checkEligibilityResponse.setAddonEligibleProduct(addonEligibleProduct);
			return checkEligibilityResponse;
	}
	
	/**
	 * @param msisdn
	 * @return
	 */
	private List<Map<String,String>> fetchSubscribedAddons(String addons) {
		List<Map<String,String>> subscriptionVASList = null;
		logger.warn("stub_subscribed_vas_addons used: " + addons );
		subscriptionVASList = new ArrayList<Map<String,String>>();
		String [] addOnArray = addons.split(",");
		Map<String,String> map = null;
		if (addOnArray != null && addOnArray.length > 0) {
			for (String str : addOnArray) {
				map = new HashMap<String, String>();
				String[] addOn = str.split(":");
				if (addOn != null && addOn.length == 2) {
					map.put("providerSystemCode", addOn[0].trim());
					map.put("providerProductId", addOn[1].trim());
					subscriptionVASList.add(map);
				}
			}
		}
		return subscriptionVASList;
	}

	/**
	 * @param msisdn
	 * @return
	 * @throws SQLException
	 * @throws XmlException
	 */
	private String getProviderProductId(String msisdn) throws SQLException, XmlException {
		String providerProdId = configService.searchConfigKey("ext_api", "stub_subscribed_rateplan").getConfigValue();
		if(providerProdId == null){
				providerProdId =  airRequestService.getRatePlan(msisdn);
		}else {
			logger.warn("stub_subscribed_rateplan used: " + providerProdId );
		}
		return providerProdId;
	}

	/**
	 * @param orderType
	 * @param initChannel
	 * @param SalesChannel
	 * @return
	 */
	private boolean validateOrderChannelRule(
			String orderType, String initChannel, String SalesChannel) {
		StringBuilder query = new StringBuilder();
		query.append("where order_type ='").append(orderType).append("' and initiating_channel = '").append(initChannel).append("' and ");
		if(SalesChannel == null){
			query.append(" sales_channel is null");
		}else{
			query.append(" sales_channel ='").append(SalesChannel).append("' ");
		}
		query.append(" and status='").append("Active'");
		
		List<EpcOrderChannelRule> epcOrderChannelRules = epcOrderChannelRuleService.getOrderChannelRulesByWhereClause(query.toString());
		if(epcOrderChannelRules != null && !epcOrderChannelRules.isEmpty() ){
			return true;
		}
		return false;
	}

	/**
	 * @param searchInput
	 * @return
	 */
	private Integer fetchAddOnProductId(QueryEligibiltySearchInput searchInput) {
		
		MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
		criteria.add("channelLevelProductId", searchInput.getOptionalProductId().trim());
		criteria.add("channelId", searchInput.getInitiatingChannel());
		criteria.add("actionType", searchInput.getActionType());
		List<EpcProductInitChannel> EpcProductInitChannels = epcProductInitChannelService.searchEpcProductInitChannel(criteria);
		Integer prodId = null;
		if (EpcProductInitChannels != null && EpcProductInitChannels.size() == 1){
			prodId = EpcProductInitChannels.get(0).getProductId();
		}
		return prodId;
	}
	
	
	/**
	 * @param subscribedGSMAddonList
	 * @return
	 */
	private List<Integer> getAddOnIds(List<Map<String,String>> subscribedGSMAddonList){
		List<Integer> gsmAddonIds = new ArrayList<Integer>();
		Map<String, List<String>> providerSystemParams = null;
		List<EpcProductProviderSystem> providers = null;
		for(Map<String,String> provider: subscribedGSMAddonList){
			providerSystemParams = new HashMap<String, List<String>>();
			providerSystemParams.put("providerProductId", Arrays.asList(new String []{provider.get("providerProductId")}));
			providerSystemParams.put("providerSystemCode", Arrays.asList(new String []{provider.get("providerSystemCode")}));
			providers = epcProductProviderSystemService.searchProvider(providerSystemParams);
			if(providers != null && !providers.isEmpty()){
				gsmAddonIds.add(providers.get(0).getProductId());
			}
		}
		return gsmAddonIds;
	}

}
