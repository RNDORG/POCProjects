package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcActivityChannelRule;
/**
 * @version 1.0
 * @author VI251443
 *
 */
@Repository
public interface EpcActivityChannelRuleRepository extends CrudRepository<EpcActivityChannelRule, Integer>, 
EpcActivityChannelRuleRepositoryCustom{
	/**
	 * 
	 * @param activityChannelRuleId
	 * @return
	 */
	@Query(value="select * from epc_activity_channel_rule where activity_channel_rule_id =:activityChannelRuleId", nativeQuery=true)
	List<EpcActivityChannelRule> findActivityByActivityChannelRuleId(@Param("activityChannelRuleId") Integer activityChannelRuleId);
    /**
     * 
     * @param activityName
     * @return
     */
	@Query(value="select * from  epc_activity_channel_rule , epc_activity_master where "
			+ "epc_activity_master.activity_id = epc_activity_channel_rule.activity_id "
					          + "and epc_activity_master.activity_name =:activityName",nativeQuery=true)
	List<EpcActivityChannelRule> getActivityChannel(@Param("activityName") String activityName);

	

}
