package com.wipro.epc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.dto.ActivitySearchInput;
import com.wipro.epc.dto.ActivitySearchOutputOld;
import com.wipro.epc.services.EpcActivityInterfaceOldService;

@RestController
public class EpcActivityInterfaceOldController {

	private static Logger logger = LoggerFactory.getLogger(EpcActivityMasterController.class);
	
	@Autowired
	EpcActivityInterfaceOldService epcActivityDetatilService;

	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;

	@Autowired
	ObjectMapper mapper;

	@Autowired
	TransactionsService transactionsLogging ;
	
	@RequestMapping(value="/rest/extapi/v1/activity",method=RequestMethod.POST)
	public ActivitySearchOutputOld updateActivitiesExt(@RequestBody ActivitySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		String txnType="activity";
		String request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, searchInput);
		ActivitySearchOutputOld response=epcActivityDetatilService.updateActivityExt(searchInput,allRequestParams);
		ePCTxnInterceptor.postTxn(txnType, request, response ); 
		return response;
		
	}
}
