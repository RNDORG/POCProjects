package com.wipro.epc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.dto.ProviderAttributesQueryInput;
import com.wipro.epc.dto.ProviderAttributesQueryResponse;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.ProviderAttributesQueryService;



/**
 * @author Developer
 * @version 1.0
 * type ProviderProductQueryController
 */
@RestController
public class ProviderAttributesQueryController {

	private static Logger logger = LoggerFactory.getLogger(ProviderAttributesQueryController.class);
	/**
	 * ProviderProductQueryService ProviderProductQueryController.java
	 */
	@Autowired
	ProviderAttributesQueryService providerAttributesQueryService;
	
	/**
	 * TransactionsService ProviderProductQueryController.java
	 */
	@Autowired
	TransactionsService transactionsLogging ;

	/**
	 * ObjectMapper ProviderProductQueryController.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * TransactionStore ProviderProductQueryController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/queryFnfCallblock", method=RequestMethod.POST)
	public ProviderAttributesQueryResponse queryProviderProductExt(@RequestBody ProviderAttributesQueryInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		String txnType="queryFnfCallblock";
		String request=null;
		ProviderAttributesQueryResponse response=null;
		try{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, queryInput);
		response=providerAttributesQueryService.queryProviderProduct(queryInput, allRequestParams);
		}
		catch (Exception e ) {
			logger.error("#interfaceException: " + e.getMessage());
			throw new EPCException(e.getMessage());
		}
		finally{
		ePCTxnInterceptor.postTxn(txnType,request, response);
		}
		return response;
	}
	
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/queryFnfCallblock", method=RequestMethod.POST)
	public ProviderAttributesQueryResponse queryProviderProduct(@RequestBody ProviderAttributesQueryInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		return providerAttributesQueryService.queryProviderProduct(queryInput, allRequestParams);
	}	
}
