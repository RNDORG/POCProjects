package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductProviderSystem;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductProviderSystemRepositoryCustom
 */
public interface EpcProductProviderSystemRepositoryCustom {

	
	/**
	 * @param string
	 * @return
	 */
	List<EpcProductProviderSystem> getList(String string);
	
	/**
	 * @param product
	 * @return
	 */
	EpcProductProviderSystem modifyProductProviders(EpcProductProviderSystem product);
	
	public List<Object[]> getAttributeList(String query);
}
