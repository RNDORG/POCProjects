package com.wipro.epc.domain;



import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;


/**
 * @author Developer
 * @version 1.0
 * The persistent class for the epc_product_status_history database table.
 * @author VI251443
 * @version 1.0
 */
@Entity
@Table(name="epc_product_status_history")
public class EpcProductStatusHistory  implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Integer EpcProductStatusHistory.java
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_status_history_id")
	private Integer productStatusHistoryId;

	/**
	 * String EpcProductStatusHistory.java
	 */
	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	/**
	 * Date EpcProductStatusHistory.java
	 */
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;

	/**
	 * String EpcProductStatusHistory.java
	 */
	@Column(name="more_info")
	private String moreInfo;

	/**
	 * Integer EpcProductStatusHistory.java
	 */
	@Column(name="product_id")
	private Integer productId;

	/**
	 * String EpcProductStatusHistory.java
	 */
	@Column(name="product_status")
	private String productStatus;

	/**
	 * String EpcProductStatusHistory.java
	 */
	@Column(name="reason")
	private String reason;

	/**
	 * 
	 */
	public EpcProductStatusHistory() {
	}

	/**
	 * @return
	 */
	public Integer getProductStatusHistoryId() {
		return this.productStatusHistoryId;
	}

	/**
	 * @param productStatusHistoryId
	 */
	public void setProductStatusHistoryId(Integer productStatusHistoryId) {
		this.productStatusHistoryId = productStatusHistoryId;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getMoreInfo() {
		return this.moreInfo;
	}

	/**
	 * @param moreInfo
	 */
	public void setMoreInfo(String moreInfo) {
		this.moreInfo = moreInfo;
	}

	/**
	 * @return
	 */
	public Integer getProductId() {
		return this.productId;
	}

	/**
	 * @param productId
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return
	 */
	public String getProductStatus() {
		return this.productStatus;
	}

	/**
	 * @param productStatus
	 */
	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	/**
	 * @return
	 */
	public String getReason() {
		return this.reason;
	}

	/**
	 * @param reason
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

}