package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wipro.common.config.service.ConfigService;
import com.wipro.common.fileoperations.service.GenericFileService;
import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcAttributeMaster;
import com.wipro.epc.domain.EpcNotificationTemplate;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcOrderCharge;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductAvailability;
import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.domain.EpcProductCompatibility;
import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.domain.EpcProductHeirarchy;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductLocation;
import com.wipro.epc.domain.EpcProductMigration;
import com.wipro.epc.domain.EpcProductNetworkTpl;
import com.wipro.epc.domain.EpcProductNetworkTplMap;
import com.wipro.epc.domain.EpcProductProviderSystem;
import com.wipro.epc.domain.EpcProductSalesChannel;
import com.wipro.epc.domain.EpcProductSegment;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.domain.EpcTariffOverride;
import com.wipro.epc.domain.EpcTriggerOrderRule;
import com.wipro.epc.dto.ComplexSearchInput;
import com.wipro.epc.dto.OrderType;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.ComplexSearchInputRepository;
import com.wipro.epc.repositories.EpcLookupMasterRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.repositories.EpcTariffOverrideRepository;


/**
 * @author Developer
 * @version 1.0
 * type ComplexSearchInputService
 */
@Service
public class ComplexSearchInputService {
	/**
	 * EpcProductSpecificationService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	
	private static Logger logger = LoggerFactory.getLogger(ComplexSearchInputService.class);
	/**
	 * EpcLookupMasterService ComplexSearchInputService.java
	 */
	@Autowired
	EpcLookupMasterService epcLookupMasterService;

	/**
	 * ComplexSearchInputRepository ComplexSearchInputService.java
	 */
	@Autowired
	ComplexSearchInputRepository searchRepository;
	
	/**
	 * EpcProductSpecificationRepository ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductSpecificationRepository epcProductSpecificationRepository;
	
	/**
	 * EpcProductAvailabilityService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductAvailabilityService epcProductAvailabilityService;
	
	/**
	 * EpcProductSalesChannelService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductSalesChannelService epcProductSalesChannelService;
	
	/**
	 * EpcProductInitChannelService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductInitChannelService epcProductInitChannelService;
	
	/**
	 * EpcProductLocationService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductLocationService epcProductLocationService;
	
	/**
	 * EpcProductSegmentService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductSegmentService epcProductSegmentService;

	/**
	 * EpcProductCompatibilityService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductCompatibilityService epcProductCompatibilityService;
	
	/**
	 * EpcProductAttributeService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductAttributeService epcProductAttributeService;
	
	/**
	 * EpcProductMigrationService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductMigrationService epcproductMigrationService;
	
	/**
	 * EpcLookupMasterRepository ComplexSearchInputService.java
	 */
	@Autowired
	EpcLookupMasterRepository lookUpRepository;
	
	/**
	 * EpcLocationService ComplexSearchInputService.java
	 */
	@Autowired
	EpcLocationService epcLocationService;
	
	/**
	 * EpcProductHeirarchyService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductHeirarchyService epcProductHeirarchyService;
	
	/**
	 * EpcNotificationTemplateService ComplexSearchInputService.java
	 */
	@Autowired
	EpcNotificationTemplateService epcNotificationTemplateService;
	
	/**
	 * EpcProductCommunityService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductCommunityService epcProductCommunityService;
	
	/**
	 * EpcOrderChannelRuleService ComplexSearchInputService.java
	 */
	@Autowired
	EpcOrderChannelRuleService epcOrderChannelRuleService;
	
	/**
	 * EpcProductDecompositionService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductDecompositionService epcProductDecompositionService;
	
	/**
	 * EpcOrderTriggerRuleService ComplexSearchInputService.java
	 */
	@Autowired
	EpcOrderTriggerRuleService epcOrderTriggerRuleService;
	
	/**
	 * EpcProductNetworkTplService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductNetworkTplService epcProductNetworkTplService;
	
	/**
	 * EpcAttributeMasterService ComplexSearchInputService.java
	 */
	@Autowired
	EpcAttributeMasterService epcAttributeMasterService;
	
	/**
	 * EpcProductNetworkTplMapService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductNetworkTplMapService epcProductNetworkTplMapService;
	
	/**
	 * GenericFileService ComplexSearchInputService.java
	 */
	@Autowired
	GenericFileService genericFileService;
	
	/**
	 * EpcProductProviderSystemService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductProviderSystemService epcProductProviderSystemService;
	
	/**
	 * ConfigService ComplexSearchInputService.java
	 */
	@Autowired
	ConfigService configService;
	
	@Autowired
	EpcTariffOverrideRepository epcTariffOverrideRepository;
	
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @param isTariffNeeded
	 * @return
	 */
	@Transactional
	public List<EpcProductSpecification> searchComplex(ComplexSearchInput searchInput, Map<String, List<String>> allRequestParams, boolean isTariffNeeded) {
		List<String> supportedWith = Arrays.asList(new String []{"all", "segment", "child", "parent", "community", "networkTemplate", "migration", "compatibility", "availability", "salesChannel", "location", "characteristic", "tariff", "provider", "triggerOrderRule", "decomposition", "notification", "orderChannelRule", "initiatingChannel","file","all", "tariffOverride"});
		List<String> with = allRequestParams.get("with");
		if(with != null && !with.isEmpty()){
			for(String str : with){
				if(!supportedWith.contains(str)){
					if(!(str.contains("ta-") || str.contains("nta-") ) ){
						throw new GenericException("UnsupportedWith", "Unsupported with parameter ("+ str +") provided.", "Unsupported with parameter ("+ str +") provided.");
					}
				}
			}
		}
		boolean isGlobalCorporateProductsNeeded = false;
		return searchComplex( searchInput, allRequestParams, isTariffNeeded, isGlobalCorporateProductsNeeded  );
	}
	
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @param isTariffNeeded
	 * @param isGlobalCorporateProductsNeeded
	 * @return
	 */
	@Transactional
	public List<EpcProductSpecification> searchComplex(ComplexSearchInput searchInput, Map<String, List<String>> allRequestParams, boolean isTariffNeeded, boolean isGlobalCorporateProductsNeeded )
	{
		try {
			if(searchInput.checkNull()){
				throw new GenericException("InvalidSearch", "Invalid Search Field", "Please provide a valid search field");
			}
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			logger.error(ExceptionUtils.getStackTrace(e));;
		}
						
		List<String> productids = searchRepository.findSearchResults(searchInput);
		
		/*if(searchInput.getProductSubCategory()!=null && isGlobalCorporateProductsNeeded && searchInput.getProductSubCategory().equals(Constants.CORPORATE_SUBCATEGORY)){
			if(StringUtils.isBlank(searchInput.getProductType()) || StringUtils.isBlank(searchInput.getProductCategory())){
				throw new GenericException("InvalidSearch", "To get Global_Corporate_Product, Product Type and Product Category is mandetory", "Please provide correct inputs");
			
			}
			else {
				List<String> ls = epcProductSpecificationRepository.getGlobalCorporateProductId(searchInput.getProductType(), searchInput.getProductCategory());
				if(!ls.isEmpty()){
				productids.removeAll(ls);
				productids.add(ls.toString());
				}
			}
		}*/
		
		List<EpcProductSpecification> products = null;
		
		if (productids != null && !productids.isEmpty()) {
			allRequestParams.put("productId", productids);
			products = searchProducts(allRequestParams, searchInput.getOrderType(), isTariffNeeded);
		}
		return products;
	}
	
	/**
	 * @param allRequestParams
	 * @param orderType
	 * @param isTariffNeeded
	 * @return
	 */
	public List<EpcProductSpecification> searchProducts(
			Map<String, List<String>> allRequestParams, String orderType, boolean isTariffNeeded) {
			List<String> with = allRequestParams.get("with");
			allRequestParams.remove("with");
			List<EpcProductSpecification> listOfProductsReturned = epcProductSpecificationService.getBasicProductSpecByID(allRequestParams);
			//the following is used for downstream query.
			allRequestParams.remove("productShortCode");
		if (with != null && !with.isEmpty() && listOfProductsReturned != null && !listOfProductsReturned.isEmpty()) {
			
			if ( with.contains("networkTemplate")) {
				
				Map<String, List<String>> templateIdsRequestParams = new HashMap<String, List<String>>();
				List<String> templateNames = new ArrayList<String>();
				List<EpcProductNetworkTplMap> ntplMaps =epcProductNetworkTplMapService.searchNetworkTemplateMap(allRequestParams);
				for(EpcProductSpecification prodSpec : listOfProductsReturned){
					for(EpcProductNetworkTplMap ntplMap: ntplMaps){
						if(prodSpec.getProductId() .equals( ntplMap.getProductId())){
							prodSpec.setEpcProductNetworkTplMap(ntplMap);
							templateNames.add(String.valueOf(ntplMap.getTemplateName()));
						}
					}
				}
				
				
				//for loading all the characteristics details.
				if(!templateNames.isEmpty()){
					templateIdsRequestParams.put("templateName", templateNames);
					List<EpcProductNetworkTpl> templateServices = epcProductNetworkTplService.searchNetworkServices(templateIdsRequestParams);
					for(EpcProductSpecification prodSpec : listOfProductsReturned){
						EpcProductNetworkTplMap templateMap = prodSpec.getEpcProductNetworkTplMap();
						if (templateMap != null && templateServices != null) {
								for (EpcProductNetworkTpl template : templateServices) {
									if (template.getTemplateName().equals(templateMap.getTemplateName())){
										if(templateMap.getEpcProductNetworkTpl() == null){
											templateMap.setEpcProductNetworkTpl(new ArrayList<EpcProductNetworkTpl>());
										}
										templateMap.getEpcProductNetworkTpl().add(template);
									}
								}
						}
					}
				}
			}
			if (with.contains("all")|| with.contains("segment"))
			{	
				List<EpcProductSegment> segments = epcProductSegmentService.searchEpcProductSegment(allRequestParams);
				if (segments != null) {
					for (EpcProductSegment segment : segments) {
						for (EpcProductSpecification prodSpec : listOfProductsReturned) {
							if (prodSpec.getProductId().equals(
									segment.getProductId())) {
								if (prodSpec.getEpcProductSegment() == null) {
									prodSpec.setEpcProductSegment(new ArrayList<EpcProductSegment>());
								}
								prodSpec.getEpcProductSegment().add(segment);
							}
						}
					}
				}
			}
			//Tariff override Start
			
			if(with.contains("all")|| with.contains("tariffOverride"))
			{
				for(EpcProductSpecification prodSpec : listOfProductsReturned) {
					List<EpcTariffOverride> tariffOverrides = null; 
					if(prodSpec.getProductType().equalsIgnoreCase("Primary")) {
						tariffOverrides = epcTariffOverrideRepository.getTariffOverridePrimary(prodSpec.getProductShortCode());
					} else if(prodSpec.getProductType().equalsIgnoreCase("Optional")) {
						tariffOverrides = epcTariffOverrideRepository.getTariffOverrideOptional(prodSpec.getProductShortCode());
					} 
					prodSpec.setEpcProductTariffOverride(tariffOverrides);
				}
			} 

			//tariff override End
			
			
			if (with.contains("all")|| with.contains("provider"))
			{
				List<EpcProductProviderSystem> providers = epcProductProviderSystemService.searchProvider(allRequestParams);
				if (providers != null) {
					for (EpcProductProviderSystem provider : providers) {
						for (EpcProductSpecification prodSpec : listOfProductsReturned) {
							if (provider.getProductId().equals(
									prodSpec.getProductId())) {
								if (prodSpec.getEpcProductProvider() == null) {
									prodSpec.setEpcProductProvider(new ArrayList<EpcProductProviderSystem>());
								}
								prodSpec.getEpcProductProvider().add(provider);
							}
						}
					}
				}
			}
			if (with.contains("all")|| with.contains("location")) {
				
				List<EpcProductLocation> locations = epcProductLocationService.searchEpcProductLocation(allRequestParams);
				if (locations != null) {
					for (EpcProductLocation location : locations) {
						for (EpcProductSpecification prodSpec : listOfProductsReturned) {
							if (prodSpec.getProductId().equals(
									location.getProductId())) {
								if (prodSpec.getEpcProductLocation() == null) {
									prodSpec.setEpcProductLocation(new ArrayList<EpcProductLocation>());
								}
								prodSpec.getEpcProductLocation().add(location);
							}
						}
					}
				}
			}
			if (with.contains("all")|| with.contains("salesChannel")) {
				
				List<EpcProductSalesChannel> sales = epcProductSalesChannelService.searchEpcProductSalesChannel(allRequestParams);
				if (sales != null) {
					for (EpcProductSalesChannel sale : sales) {
						for (EpcProductSpecification prodSpec : listOfProductsReturned) {
							if (prodSpec.getProductId().equals(
									sale.getProductId())) {
								if (prodSpec.getEpcProductSalesChannel() == null) {
									prodSpec.setEpcProductSalesChannel(new ArrayList<EpcProductSalesChannel>());
								}
								prodSpec.getEpcProductSalesChannel().add(sale);
							}
						}
					}
				}
			}
			if (with.contains("all")|| with.contains("availability")) {
				
				List<EpcProductAvailability> availabilities =epcProductAvailabilityService.searchAvailabilities(allRequestParams);
				if (availabilities != null) {
					for (EpcProductAvailability availability : availabilities) {
						for (EpcProductSpecification prodSpec : listOfProductsReturned) {
							if (prodSpec.getProductId().equals(
									availability.getProductId())) {
								if (prodSpec.getEpcProductAvailability() == null) {
									prodSpec.setEpcProductAvailability(new ArrayList<EpcProductAvailability>());
								}
								prodSpec.getEpcProductAvailability().add(
										availability);
							}
						}
					}
				}
			}
			if (with.contains("all")|| with.contains("initiatingChannel")) {
				List<EpcProductInitChannel> initChannels = epcProductInitChannelService.searchEpcProductInitChannel(allRequestParams);
				
				if (initChannels != null && !initChannels.isEmpty()) {
					Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
					List<String> notificationIds = new ArrayList<String>();
					List<EpcNotificationTemplate> notificationTemplates = null;
					if ( with.contains("notification")) {
						for (EpcProductInitChannel initChannel : initChannels) {
							if (initChannel
									.getNotificationTemplateId() != null) {
								notificationIds.add(String.valueOf(initChannel
										.getNotificationTemplateId()));
								
							}
						}
						if(!notificationIds.isEmpty()){
							notificationRequestParams.put(
									"notificationTemplateId", notificationIds);
							notificationTemplates = epcNotificationTemplateService
									.searchEpcNotificationTemplate(notificationRequestParams);
						}
					}
					if (initChannels != null) {
						for (EpcProductInitChannel initChannel : initChannels) {
							if (with.contains("notification")) {
								if (notificationTemplates != null) {
									for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
										if (notificationtemplate
												.getNotificationTemplateId()
												.equals(initChannel
														.getNotificationTemplateId())) {
											initChannel
													.setEpcNotificationTemplate(notificationtemplate);
										}
									}
								}
							}
							for (EpcProductSpecification prodSpec : listOfProductsReturned) {
								if (prodSpec.getProductId().equals(
										initChannel.getProductId())) {
									if (prodSpec.getEpcProductInitChannel() == null) {
										prodSpec.setEpcProductInitChannel(new ArrayList<EpcProductInitChannel>());
									}
									prodSpec.getEpcProductInitChannel().add(
											initChannel);
								}
							}
						}
					}
				}
			}

			if (with.contains("all")|| with.contains("compatibility")) {
				
				List<String> prodIds = new ArrayList<String>();
				List<EpcProductCompatibility> compatibilities =epcProductCompatibilityService.searchEpcProductCompatibility(allRequestParams);
				//Map<String, List<String>> compatibilityParams = new HashMap<String, List<String>>();
				//compatibilityParams.put("otherProductId", allRequestParams.get("productId"));
				//List<EpcProductCompatibility> otherCompatibilities =epcProductCompatibilityService.searchEpcProductCompatibility(compatibilityParams);
				if (compatibilities != null) {
					for (EpcProductSpecification prodSpec : listOfProductsReturned) {
						List<Integer> compProdIds = new ArrayList<Integer>();
						for (EpcProductCompatibility compatibility : compatibilities) {
							if (prodSpec.getProductId().equals(
									compatibility.getProductId())) {
								if (prodSpec.getEpcProductCompatibility() == null) {
									prodSpec.setEpcProductCompatibility(new ArrayList<EpcProductCompatibility>());
								}
								prodSpec.getEpcProductCompatibility().add(
										compatibility);
								prodIds.add(String.valueOf(compatibility
										.getOtherProductId()));
								compProdIds.add(compatibility.getOtherProductId());
							}
						}
						//Discarded the below logic
						/*if (otherCompatibilities != null) {
							for (EpcProductCompatibility compatibility : otherCompatibilities) {
								if (prodSpec.getProductId().equals(
										compatibility.getOtherProductId())
										&& (!(compProdIds.contains(compatibility.getProductId())))) {
									Integer tempId = compatibility
											.getOtherProductId();
									compatibility
											.setOtherProductId(compatibility
													.getProductId());
									compatibility.setProductId(tempId);
									if (prodSpec.getEpcProductCompatibility() == null) {
										prodSpec.setEpcProductCompatibility(new ArrayList<EpcProductCompatibility>());
									}
									prodSpec.getEpcProductCompatibility().add(
											compatibility);
									prodIds.add(String.valueOf(compatibility
											.getOtherProductId()));
								}
							}
						}*/
					}
				}
				//for loading all the products details.
				if(!prodIds.isEmpty()){
					Map<String, List<String>> productIdsRequestParams = new HashMap<String, List<String>>();
					productIdsRequestParams.put("productId", prodIds);
					List<EpcProductSpecification> compatibleProds = epcProductSpecificationService.getBasicProductSpecByID(productIdsRequestParams);
					for(EpcProductSpecification prodSpec : listOfProductsReturned){
						List<EpcProductCompatibility> prodComps = prodSpec.getEpcProductCompatibility();
						
						if (prodComps != null) {
							for (EpcProductCompatibility comp : prodComps) {

								if (compatibleProds != null) {
									for (EpcProductSpecification comProdSpec : compatibleProds) {
										if (comp.getOtherProductId().equals(
												comProdSpec.getProductId())) {
											comp.setOtherProductSpecification(comProdSpec);
										}
									}
								}
							}
						}
						
					}
				}
			}

			if ( !isTariffNeeded && (with.contains("all"))) {
				
				Map<String, List<String>> charIdsRequestParams = new HashMap<String, List<String>>();
				List<String> charIds = new ArrayList<String>();

				List<EpcProductAttribute> attributes =epcProductAttributeService.searchProductAttribute(allRequestParams);
				for(EpcProductSpecification prodSpec : listOfProductsReturned){
					if (attributes != null) {
						for (EpcProductAttribute attribute : attributes) {
							if (prodSpec.getProductId().equals(
									attribute.getProductId())) {
								if (prodSpec.getEpcProductAttribute() == null) {
									prodSpec.setEpcProductAttribute(new ArrayList<EpcProductAttribute>());
								}
								prodSpec.getEpcProductAttribute()
										.add(attribute);
								charIds.add(String.valueOf(attribute
										.getAttributeId()));
							}
						}
					}
				}
				
				//for loading all the characteristics details.
				if(!charIds.isEmpty()){
					charIdsRequestParams.put("attributeId", charIds);
					List<EpcAttributeMaster> chars = epcAttributeMasterService.searchChar(charIdsRequestParams);
					for(EpcProductSpecification prodSpec : listOfProductsReturned){
						List<EpcProductAttribute> prodAttrs = prodSpec.getEpcProductAttribute();
						if (prodAttrs != null) {
							for (EpcProductAttribute attr : prodAttrs) {

								if (chars != null) {
									for (EpcAttributeMaster attrMaster : chars) {
										if (attrMaster.getAttributeId().equals(
												attr.getAttributeId())) {
											attr.setEpcAttributeMaster(attrMaster);
										}
									}
								}
							}
						}
					}
				}
			}
			List<Integer> charsIds = null;
			List<Integer> tariffIds = null;
			if (isTariffNeeded){
				String charQuery = null;
				String tariffQuery = null;
				
				if(with.contains("all") || with.contains("characteristic")){
					String str  = configService.searchConfigKey("ext_api", "with_characteristic_ctg").getConfigValue();
					if(StringUtils.isNotBlank(str)) {
						charQuery = getAttributeQuery(str);
					}
				}else{
					for(String str : with){
						if(str.contains("nta-")){
							charQuery = getAttributeQuery(str);
						}
					}
				}
				if(with.contains("all") || with.contains("tariff")){
					String str  = configService.searchConfigKey("ext_api", "with_tariff_ctg").getConfigValue();
					if(StringUtils.isNotBlank(str)) {
						tariffQuery = getAttributeQuery(str);
					}
				}else{
					for(String str : with){
						if(str.contains("ta-") ){
							tariffQuery = getAttributeQuery(str);
						}
					}
				}
				if(charQuery != null){
					charsIds = epcAttributeMasterService.getAttributeIds(charQuery);
				}
				if(tariffQuery != null){
					tariffIds = epcAttributeMasterService.getAttributeIds(tariffQuery);
				}
			}
			if ( isTariffNeeded && charsIds != null ) {
				Map<String, List<String>> charIdsRequestParams = new HashMap<String, List<String>>();
				List<String> charIds = new ArrayList<String>();
				List<EpcProductAttribute> attributes =epcProductAttributeService.searchProductAttribute(allRequestParams);
				if (attributes != null) {
					for (EpcProductAttribute attribute : attributes) {
						for(EpcProductSpecification prodSpec : listOfProductsReturned){
							if (prodSpec.getProductId().equals(
									attribute.getProductId())
									 && charsIds.contains(attribute.getAttributeId())) {
								if (prodSpec.getEpcProductCharacteristic() == null) {
									prodSpec.setEpcProductCharacteristic(new ArrayList<EpcProductAttribute>());
								}
								prodSpec.getEpcProductCharacteristic().add(
										attribute);
								charIds.add(String.valueOf(attribute
										.getAttributeId()));
							}
						}
					}
				}
				
				//for loading all the characteristics details.
				if(!charIds.isEmpty()){
					charIdsRequestParams.put("attributeId", charIds);
					List<EpcAttributeMaster> chars = epcAttributeMasterService.searchChar(charIdsRequestParams);
					for(EpcProductSpecification prodSpec : listOfProductsReturned){
						List<EpcProductAttribute> prodAttrs = prodSpec.getEpcProductCharacteristic();
						if (prodAttrs != null) {
							for (EpcProductAttribute attr : prodAttrs) {

								for (EpcAttributeMaster attrMaster : chars) {
									if (attrMaster.getAttributeId() .equals( attr
											.getAttributeId())) {
										attr.setEpcAttributeMaster(attrMaster);
									}
								}
							}
						}
					}
				}
			}
			
			
			if ( isTariffNeeded && tariffIds != null) {
				
				Map<String, List<String>> charIdsRequestParams = new HashMap<String, List<String>>();
				List<String> charIds = new ArrayList<String>();
				List<EpcProductAttribute> attributes =epcProductAttributeService.searchProductAttribute(allRequestParams);
				if (attributes != null) {
					for (EpcProductAttribute attribute : attributes) {
						for(EpcProductSpecification prodSpec : listOfProductsReturned){
							if (prodSpec.getProductId().equals(
									attribute.getProductId())
									 && tariffIds.contains(attribute.getAttributeId())) {
								if (prodSpec.getEpcProductTariff() == null) {
									prodSpec.setEpcProductTariff(new ArrayList<EpcProductAttribute>());
								}
								prodSpec.getEpcProductTariff().add(attribute);
								charIds.add(String.valueOf(attribute
										.getAttributeId()));
							}
						}
					}
				}
				
				//for loading all the characteristics details.
				if(!charIds.isEmpty()){
					charIdsRequestParams.put("attributeId", charIds);
					List<EpcAttributeMaster> chars = epcAttributeMasterService.searchChar(charIdsRequestParams);
					for(EpcProductSpecification prodSpec : listOfProductsReturned){
						List<EpcProductAttribute> prodAttrs = prodSpec.getEpcProductTariff();
						if (prodAttrs != null) {
							for (EpcProductAttribute attr : prodAttrs) {

								for (EpcAttributeMaster attrMaster : chars) {
									if (attrMaster.getAttributeId() .equals( attr
											.getAttributeId())) {
										attr.setEpcAttributeMaster(attrMaster);
									}
								}
							}
						}
					}
				}
			}
			
			if (with.contains("all")|| with.contains("migration")) {
				allRequestParams.put("sourceProductId", allRequestParams.get("productId"));
				allRequestParams.remove("productId");
				List<EpcProductMigration> migrations =epcproductMigrationService.searchEpcProductMigration(allRequestParams);
				List<String> prodIds = new ArrayList<String>();
				if (migrations != null) {
					for (EpcProductMigration migration : migrations) {
						for (EpcProductSpecification prodSpec : listOfProductsReturned) {
							if (prodSpec.getProductId().equals(
									migration.getSourceProductId())) {
								if (prodSpec.getEpcProductMigration() == null) {
									prodSpec.setEpcProductMigration(new ArrayList<EpcProductMigration>());
								}
								prodSpec.getEpcProductMigration()
										.add(migration);
								prodIds.add(String.valueOf(migration
										.getTargetProductId()));
							}
						}
					}
				}
				allRequestParams.put("productId", allRequestParams.get("sourceProductId"));
				allRequestParams.remove("sourceProductId");
				
				//for loading all the products details.
				if(!prodIds.isEmpty()){
					Map<String, List<String>> productIdsRequestParams = new HashMap<String, List<String>>();
					productIdsRequestParams.put("productId", prodIds);
					List<EpcProductSpecification> migrationProds = epcProductSpecificationService.getBasicProductSpecByID(productIdsRequestParams);
					for(EpcProductSpecification prodSpec : listOfProductsReturned){
						List<EpcProductMigration> prodMigrations = prodSpec.getEpcProductMigration();
						if (prodMigrations != null) {
							for (EpcProductMigration mig : prodMigrations) {

								for (EpcProductSpecification migProdSpec : migrationProds) {
									if (mig.getTargetProductId() .equals( migProdSpec
											.getProductId())) {
										mig.setTargetProductSpec(migProdSpec);
										;
									}
								}
							}
						}
						
					}
				}
			}
			// if with contain decomposition then let with = "orderType"
			if(with.contains("triggerOrderRule") ||  with.contains("decomposition") || with.contains("orderChannelRule")){
				if(!with.contains("orderType")){
					with.add("orderType");
				}
			}
			if(with.contains("orderType")){
				if(orderType == null || orderType.equals("")){
					throw new EPCException("OrderType", "OrderType/Decomposition/OrderChannelRule/TriggerOrderRule cannot be fetched without providing orderType as search input", "OrderType/Decomposition/OrderChannelRule/TriggerOrderRule cannot be fetched without providing orderType as search input");
				}
				if(listOfProductsReturned.size() >1){
					throw new EPCException("OrderType", "OrderType/Decomposition/OrderChannelRule/TriggerOrderRule cannot be fetched for more than one products.Product Short Code/ProductID needs to be passed for fetching Order Type details", "OrderType/Decomposition/OrderChannelRule/TriggerOrderRule cannot be fetched for more than one products.Product Short Code/ProductID needs to be passed for fetching Order Type details");
				}
				EpcProductSpecification prodSpec =  listOfProductsReturned.get(0);
				OrderType orderTypeTemp = new OrderType();
				orderTypeTemp.setOrderType(orderType);
				if( with.contains("orderChannelRule")){
					MultiValueMap<String, String> searchCriteria = new LinkedMultiValueMap<String, String>();
					searchCriteria.add("orderType", orderType);
					List<EpcOrderChannelRule> epcOrderChannelRules = epcOrderChannelRuleService.searchEpcOrderChannelRule(searchCriteria);
					
					MultiValueMap<String, String> searchCriteriaActivityCharge = new LinkedMultiValueMap<String, String>();
					List<String> orderChannelRuleIds = new ArrayList<String>();
					if (epcOrderChannelRules != null && !epcOrderChannelRules.isEmpty()) {
						List<EpcNotificationTemplate> notificationTemplates = null;
						Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
						List<String> notificationIds = new ArrayList<String>();
						if ( with.contains("notification")) {
							for (EpcOrderChannelRule epcOrderChannelRule : epcOrderChannelRules) {
								notificationIds.add(String.valueOf(epcOrderChannelRule
										.getNotificationTemplateId()));
							}
							if(!notificationIds.isEmpty()){
								notificationRequestParams.put(
										"notificationTemplateId", notificationIds);
								notificationTemplates = epcNotificationTemplateService
										.searchEpcNotificationTemplate(notificationRequestParams);
							}
						}
						for (EpcOrderChannelRule epcOrderChannelRule : epcOrderChannelRules) {
							orderChannelRuleIds.add(String.valueOf(epcOrderChannelRule
									.getOrderChannelRuleId()));
						}
						searchCriteriaActivityCharge.put(
								"orderChannelRuleId", orderChannelRuleIds);
						List<EpcOrderCharge> EpcOrderCharges = epcOrderChannelRuleService.searchEpcActivityChargeByChannelRuleId(searchCriteriaActivityCharge);
												for (EpcOrderChannelRule epcOrderChannelRule : epcOrderChannelRules) {
							if (EpcOrderCharges != null) {
								for (EpcOrderCharge epcOrderCharge : EpcOrderCharges) {
									if (epcOrderCharge.getOrderChannelRuleId()
											.equals(epcOrderChannelRule
													.getOrderChannelRuleId())) {
										epcOrderChannelRule
												.setEpcOrderCharge(epcOrderCharge);
									}
								}
							}
							if ( with.contains("notification") && notificationTemplates != null) {
								for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
									if (notificationtemplate.getNotificationTemplateId() .equals( epcOrderChannelRule.getNotificationTemplateId())) {
										epcOrderChannelRule.setEpcNotificationTemplate(notificationtemplate);
									}
								}
							}
							
						}
						orderTypeTemp.setEpcOrderChannelRule(epcOrderChannelRules);
					}
					
				}
				if( with.contains("decomposition")){
					List<EpcProductDecomposition>  decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
							"where product_short_code = '"+prodSpec.getProductShortCode()
							+"' and order_type = '"+orderType+"'");
					if(decompositions == null || decompositions.isEmpty() ){
						decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
								"where product_short_code is null and order_type = '"+orderType 
								+"' and product_classification = '"+prodSpec.getProductClassification()
								+"' and product_sub_family = '"+prodSpec.getProductSubFamily()+"'");
					}
					if(decompositions == null || decompositions.isEmpty() ){
						decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
								"where product_short_code is null and order_type = '"+orderType 
								+"' and product_classification is null"
								+" and product_sub_family = '"+prodSpec.getProductSubFamily()+"'");
					}

					if(decompositions == null || decompositions.isEmpty() ){
						decompositions = epcProductDecompositionService.getDecompositionsByWhereClause(
								"where product_short_code is null and order_type = '"+orderType 
								+"' and product_classification is null "
								+" and product_sub_family is null ");
					}
					
					
					if (decompositions != null && !decompositions.isEmpty()) {
						Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
						List<String> notificationIds = new ArrayList<String>();
						List<EpcNotificationTemplate> notificationTemplates = null;

						if ( with.contains("notification")) {
							for (EpcProductDecomposition epcProductDecomposition : decompositions) {
								notificationIds.add(String.valueOf(epcProductDecomposition
										.getNotificationTemplateId()));
							}
							if(!notificationIds.isEmpty()){
								notificationRequestParams.put(
										"notificationTemplateId", notificationIds);
								notificationTemplates = epcNotificationTemplateService
										.searchEpcNotificationTemplate(notificationRequestParams);
							}
						}
						if (decompositions != null) {
							for (EpcProductDecomposition epcProductDecomposition : decompositions) {
								if (with.contains("notification") && notificationTemplates != null) {
									for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
										if (epcProductDecomposition
												.getNotificationTemplateId() != null
												&& epcProductDecomposition
														.getNotificationTemplateId()
														.equals(notificationtemplate
																.getNotificationTemplateId())) {
											epcProductDecomposition
													.setEpcNotificationTemplate(notificationtemplate);
										}
									}
								}

							}
						}
						orderTypeTemp.setEpcProductDecomposition(decompositions);
					}
					
				}
				if( with.contains("triggerOrderRule")){
					List<EpcTriggerOrderRule>  epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
							"where source_product_short_code = '"+prodSpec.getProductShortCode()
							+"' and source_order_type = '"+orderType+"'");
					if(epcTriggerOrderRules == null || epcTriggerOrderRules.isEmpty() ){
						epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
								"where source_product_short_code is null and source_order_type = '"+orderType 
								+"' and source_product_classification = '"+prodSpec.getProductClassification()
								+"' and source_product_sub_family = '"+prodSpec.getProductSubFamily()+"'");
					}
					if(epcTriggerOrderRules == null || epcTriggerOrderRules.isEmpty() ){
						epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
								"where source_product_short_code is null and source_order_type = '"+orderType 
								+"' and source_product_classification is null"
								+" and source_product_sub_family = '"+prodSpec.getProductSubFamily()+"'");
					}
					if(epcTriggerOrderRules == null || epcTriggerOrderRules.isEmpty() ){
						epcTriggerOrderRules = epcOrderTriggerRuleService.getTriggerOrderRulesByWhereClause(
								"where source_product_short_code is null and source_order_type = '"+orderType 
								+"' and source_product_classification is null "
								+" and source_product_sub_family is null ");
					}
					if(epcTriggerOrderRules != null && !epcTriggerOrderRules.isEmpty() ){
						orderTypeTemp.setEpcTriggerOrderRule(epcTriggerOrderRules);
					}
				}
				prodSpec.setOrderType(orderTypeTemp);
			}
			if (with.contains("all")|| with.contains("parent") ) {
				allRequestParams.put("childProductId", allRequestParams.get("productId"));
				allRequestParams.remove("productId");
				Set<String> productIds = new HashSet<String>();
				List<EpcProductHeirarchy> heirarchies =epcProductHeirarchyService.searchEpcProductHeirarchy(allRequestParams);
				if (heirarchies != null) {
					for (EpcProductHeirarchy heirarchy : heirarchies) {
						for (EpcProductSpecification prodSpec : listOfProductsReturned) {
							if (prodSpec.getProductId().equals(
									heirarchy.getChildProductId())) {
								productIds.add(String.valueOf(heirarchy
										.getParentProductId()));
							}
						}
					}
				}
				allRequestParams.put("productId", allRequestParams.get("childProductId"));
				allRequestParams.remove("childProductId");
				
				Map<String, List<String>> productIdsRequestParams = new HashMap<String, List<String>>();
				
				if(!productIds.isEmpty()){
					productIdsRequestParams.put("productId",new ArrayList<String>(productIds));
					List<EpcProductSpecification> parentProducts = epcProductSpecificationService.getBasicProductSpecByID(productIdsRequestParams);
					for(EpcProductSpecification prodSpec : listOfProductsReturned){
						if (heirarchies != null) {
							for (EpcProductHeirarchy heirarchy : heirarchies) {
								if (parentProducts != null) {
									for (EpcProductSpecification parentProdSpec : parentProducts) {
										if (prodSpec.getProductId().equals(
												heirarchy.getChildProductId())
												&& heirarchy
														.getParentProductId()
														.equals(parentProdSpec
																.getProductId())) {
											if (prodSpec.getParent() == null) {
												prodSpec.setParent(new ArrayList<String>());
											}
											prodSpec.getParent()
													.add(String
															.valueOf(parentProdSpec
																	.getProductShortCode()));
										}

									}
								}
							}
						}
					}
				}
				
			}
			
			if (with.contains("all")|| with.contains("child") ) {
				allRequestParams.put("parentProductId", allRequestParams.get("productId"));
				allRequestParams.remove("productId");
				Map<String, List<String>> productIdsRequestParams = new HashMap<String, List<String>>();
				Set<String> productIds = new HashSet<String>();
 				List<EpcProductHeirarchy> heirarchies =epcProductHeirarchyService.searchEpcProductHeirarchy(allRequestParams);
				if (heirarchies != null) {
					for (EpcProductHeirarchy heirarchy : heirarchies) {
						for (EpcProductSpecification prodSpec : listOfProductsReturned) {
							if (prodSpec.getProductId().equals(
									heirarchy.getParentProductId())) {
								productIds.add(String.valueOf(heirarchy
										.getChildProductId()));
							}
						}
					}
				}
				allRequestParams.put("productId", allRequestParams.get("parentProductId"));
				allRequestParams.remove("parentProductId");
				
				if(!productIds.isEmpty()){
					productIdsRequestParams.put("productId", new ArrayList<String>(productIds));
					productIdsRequestParams.put("with", Arrays.asList(new String []{"provider"}));
					List<EpcProductSpecification> childProducts = searchProducts(productIdsRequestParams,null, false);
					if (heirarchies != null) {
						for (EpcProductHeirarchy heirarchy : heirarchies) {
							for (EpcProductSpecification prodSpec : listOfProductsReturned) {
								if (childProducts != null) {
									for (EpcProductSpecification childProdSpec : childProducts) {
										if (prodSpec.getProductId().equals(
												heirarchy.getParentProductId())
												&& heirarchy
														.getChildProductId()
														.equals(childProdSpec
																.getProductId())) {
											if (prodSpec.getChild() == null) {
												prodSpec.setChild(new ArrayList<EpcProductSpecification>());
											}
											
											if (childProdSpec.getEpcProductProvider()!=null && childProdSpec.getEpcProductProvider().size() > 0){
												for(EpcProductProviderSystem providerSystem : childProdSpec.getEpcProductProvider()){
													if(providerSystem != null && providerSystem.getIsPrimaryProvider() != null &&  providerSystem.getIsPrimaryProvider() == 1) {
														childProdSpec.setPrimaryProviderSystem(providerSystem.getProviderSystemCode());

													}					
												}
											}
											childProdSpec.setEpcProductProvider(null);
											childProdSpec
													.setReservedHI(heirarchy
															.getProductHeirarchyId());
											prodSpec.getChild().add(
													childProdSpec);
										}

									}
								}
							}
						}
					}
				}
				
				
			}
			if (with.contains("all")|| with.contains("community")) {
				
				List<EpcProductCommunity> communities = epcProductCommunityService.searchProductCommunity(allRequestParams);
				if (communities != null) {
					for (EpcProductCommunity community : communities) {
						for (EpcProductSpecification prodSpec : listOfProductsReturned) {
							if (prodSpec.getProductId().equals(
									community.getProductId())) {
								//Discount price logic needs to be added later.
								//community.setDiscountedPrice(199.95);
								if (prodSpec.getEpcProductCommunity() == null) {
									prodSpec.setEpcProductCommunity(new ArrayList<EpcProductCommunity>());
								}
								prodSpec.getEpcProductCommunity()
										.add(community);
							}
						}
					}
				}
			}
			
			if (with.contains("file")) {
				List<Integer> ids = new ArrayList<Integer>();
				for(EpcProductSpecification prodSpec : listOfProductsReturned){
					ids.add(prodSpec.getProductId());
				}
				
				List<Object[]> genericFiles = epcProductSpecificationService.getFileList(ids);
					for(EpcProductSpecification prodSpec : listOfProductsReturned){
						if (genericFiles != null) {
							for (Object[] obj : genericFiles) {
								if (String.valueOf(prodSpec.getProductId())
										.equals(String.valueOf(obj[0]))) {
									if (prodSpec.getGenericFiles() == null) {
										prodSpec.setGenericFiles(new ArrayList<String>());
									}
									prodSpec.getGenericFiles().add(
											String.valueOf(obj[1]));
								}
							}
						}
					}
			}
		}
		return listOfProductsReturned;
	}
	
	
	
	/**
	 * @param orderTypeValue
	 * @param allRequestParams
	 * @return
	 */
	@Transactional
	public OrderType queryOrderRule(String orderTypeValue,Map<String, List<String>> allRequestParams){
		if(orderTypeValue != null){
			orderTypeValue = epcLookupMasterService.getLookupId(orderTypeValue);
		}
		
		List<String> with = allRequestParams.get("with");

		OrderType orderType = new OrderType();
		orderType.setOrderType(orderTypeValue);
		MultiValueMap<String, String> searchCriteria = new LinkedMultiValueMap<String, String>();
		searchCriteria.add("orderType", orderTypeValue);
		if(with!= null && (with.contains("all") || with.contains("orderChannelRule"))){
			List<EpcOrderChannelRule> epcOrderChannelRules = epcOrderChannelRuleService.searchEpcOrderChannelRule(searchCriteria);
			
			MultiValueMap<String, String> searchCriteriaActivityCharge = new LinkedMultiValueMap<String, String>();
			List<String> orderChannelRuleIds = new ArrayList<String>();
			if (epcOrderChannelRules != null && !epcOrderChannelRules.isEmpty()) {
				Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
				List<String> notificationIds = new ArrayList<String>();
				if ( with!= null && (with.contains("all") || with.contains("notification"))) {
					for (EpcOrderChannelRule epcOrderChannelRule : epcOrderChannelRules) {
						notificationIds.add(String.valueOf(epcOrderChannelRule
								.getNotificationTemplateId()));
					}
					notificationRequestParams.put(
							"notificationTemplateId", notificationIds);
				}
				for (EpcOrderChannelRule epcOrderChannelRule : epcOrderChannelRules) {
					orderChannelRuleIds.add(String.valueOf(epcOrderChannelRule
							.getOrderChannelRuleId()));
				}
				searchCriteriaActivityCharge.put(
						"orderChannelRuleId", orderChannelRuleIds);
				List<EpcOrderCharge> EpcOrderCharges = epcOrderChannelRuleService.searchEpcActivityChargeByChannelRuleId(searchCriteriaActivityCharge);
				List<EpcNotificationTemplate> notificationTemplates = epcNotificationTemplateService
						.searchEpcNotificationTemplate(notificationRequestParams);
				for (EpcOrderChannelRule epcOrderChannelRule : epcOrderChannelRules) {
					if (EpcOrderCharges != null) {
						for (EpcOrderCharge epcOrderCharge : EpcOrderCharges) {
							if (epcOrderCharge.getOrderChannelRuleId()
									.equals(epcOrderChannelRule
											.getOrderChannelRuleId())) {
								epcOrderChannelRule
										.setEpcOrderCharge(epcOrderCharge);
							}
						}
					}
					if ( with!= null && (with.contains("all") || with.contains("notification")) && notificationTemplates != null) {
						for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
							if (epcOrderChannelRule.getNotificationTemplateId() .equals( notificationtemplate
									.getNotificationTemplateId())) {
								epcOrderChannelRule.setEpcNotificationTemplate(notificationtemplate);
							}
						}
					}
					
				}
				orderType.setEpcOrderChannelRule(epcOrderChannelRules);
			}
			
		}
		if( with!= null && (with.contains("all")|| with.contains("decomposition"))){
			List<EpcProductDecomposition>  decompositions = epcProductDecompositionService.searchProductDecomposition(searchCriteria);
				
			
			if (decompositions != null && !decompositions.isEmpty()) {
				Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
				List<String> notificationIds = new ArrayList<String>();
				if ( with != null && (with.contains("all")|| with.contains("notification"))) {
					for (EpcProductDecomposition epcProductDecomposition : decompositions) {
						notificationIds.add(String.valueOf(epcProductDecomposition
								.getNotificationTemplateId()));
					}
					notificationRequestParams.put(
							"notificationTemplateId", notificationIds);
				}
				List<EpcNotificationTemplate> notificationTemplates = epcNotificationTemplateService
						.searchEpcNotificationTemplate(notificationRequestParams);
				for (EpcProductDecomposition epcProductDecomposition : decompositions) {
					if (with != null &&  (with.contains("all")|| with.contains("notification")) && notificationTemplates != null) {
						for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
							if (epcProductDecomposition.getNotificationTemplateId() .equals( notificationtemplate
									.getNotificationTemplateId())) {
								epcProductDecomposition.setEpcNotificationTemplate(notificationtemplate);
							}
						}
					}
					
				}
				orderType.setEpcProductDecomposition(decompositions);
			}
			
		}
		if(with != null &&  (with.contains("all")||  with.contains("triggerOrderRule"))){
			searchCriteria.remove("orderType");
			searchCriteria.add("sourceOrderType", orderTypeValue);
			List<EpcTriggerOrderRule>  epcTriggerOrderRules = epcOrderTriggerRuleService.searchTriggerOrderRule(searchCriteria);
			if(epcTriggerOrderRules != null && !epcTriggerOrderRules.isEmpty() ){
				orderType.setEpcTriggerOrderRule(epcTriggerOrderRules);
			}
		}
		return orderType;		
	}
	
	/**
	 * @param classification
	 * @return
	 */
	public List<Integer> getProductidsByclassification(String classification) {
		return searchRepository.getProductidsByclassification(classification);
	}
	
	/**
	 * @param str
	 * @return
	 */
	private String getAttributeQuery(String str){
		String charQuery = null;
		String [] fields = str.split("-");
		if(fields.length == 2 &&  StringUtils.isNotBlank(fields[1])){
			charQuery = " attribute_ctg in (";
			String [] ctgs = fields[1].split(",");
			for( int i=0; i< ctgs.length ; i++ ){
				charQuery  = charQuery +"'"+ctgs[i]+"'";
				if(i == ctgs.length -1){
					charQuery = charQuery +" )";
				}else{
					charQuery = charQuery +" , ";
				}
			}
		}else if(fields.length == 3){
			if(StringUtils.isNotBlank(fields[1])){
				charQuery = " attribute_ctg in (" ;
				String [] ctgs = fields[1].split(",");
				for( int i=0; i< ctgs.length ; i++ ){
					charQuery  = charQuery +"'"+ctgs[i]+"'";
					if(i == ctgs.length -1){
						charQuery = charQuery +" )";
					}else{
						charQuery = charQuery +" , ";
					}
				}
			}
			
			if(StringUtils.isNotBlank(charQuery) && StringUtils.isNotBlank(fields[2])){
				charQuery = charQuery +" and ";
			}
			
			if (StringUtils.isNotBlank(fields[2])) {
				if(StringUtils.isNotBlank(charQuery)){
					charQuery = charQuery + " attribute_ctg_type in (  ";
				}else {
					charQuery = " attribute_ctg_type in (  ";
				}
				String[] ctgTypes = fields[2].split(",");
				for (int i = 0; i < ctgTypes.length; i++) {
					charQuery = charQuery + "'" + ctgTypes[i] + "'";
					if (i == ctgTypes.length - 1) {
						charQuery = charQuery + " )";
					}else{
						charQuery = charQuery +" , ";
					}
				}
			}
		}
		return charQuery;
	}
}
