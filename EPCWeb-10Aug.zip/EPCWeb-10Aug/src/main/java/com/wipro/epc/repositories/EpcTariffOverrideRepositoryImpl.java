package com.wipro.epc.repositories;


import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcTariffOverride;
import com.wipro.epc.util.SimpleDateConvertion;

/**
 * @author Developer
 * @version 1.0
 * type EpcTariffOverrideRepositoryImpl
 */
public class EpcTariffOverrideRepositoryImpl implements EpcTariffOverrideRepositoryCustom{

	private static Logger logger =LoggerFactory.getLogger(EpcTariffOverrideRepositoryImpl.class);
	
	@Autowired
	SimpleDateConvertion convert; 
	
	/**
	 * EntityManager EpcTariffOverrideRepositoryImpl.java
	 */
	@Autowired
	EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcTariffOverrideRepositoryCustom#getList(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<EpcTariffOverride> getList(String otherProductId1,
			String otherProductId2, String otherProductId3,
			String otherProductId4, String ratePlan, String addonProdId) {
		String query = "select * from epc_tariff_override where ";
		if(ratePlan!=null){
			query = query  + " rateplan_product_id = '"+ratePlan+"'";
		}
		if(addonProdId!=null){
			query = query  + " and  addon_product_id = '"+addonProdId+"'";
		}
		if(otherProductId1!=null){
			query = query  + " and other_product_id_1 = '"+otherProductId1+"'";
		}else{
			query = query  + " and  other_product_id_1 is null ";
		}
		if(otherProductId2!=null){
			query = query  + " and other_product_id_2 = '"+otherProductId2+"'";
		}else{
			query = query  + " and  other_product_id_2 is null ";
		}
		if(otherProductId3!=null){
			query = query  + " and other_product_id_3 = '"+otherProductId3+"'";
		}else{
			query = query  + " and  other_product_id_3 is null ";
		}
		if(otherProductId4!=null){
			query = query  + " and other_product_id_4 = '"+otherProductId4+"'";
		}else{
			query = query  + " and  other_product_id_4 is null ";
		}
		query=query+" and attribute_name='SUBSCRIPTION_FEE' order by priority ";
		//System.out.println("Tariff Override Query is :->"+query);
		logger.debug("#Query: "+query);
		List<EpcTariffOverride> returnList = em.createNativeQuery(query, EpcTariffOverride.class).getResultList();
		return returnList;
	}

	
	@Override
	public EpcTariffOverride modifyTariffOverride(EpcTariffOverride override) {
		StringBuilder queryBuilder=new StringBuilder("update epc_tariff_override set tariff_override_id="+override.getTariffOverrideId());
		
		if(override.getAddonProductId()!=null) {
			queryBuilder.append(",").append(" addon_product_id = '").append(override.getAddonProductId()).append("'");
		}
		if(override.getAttributeName()!=null ) {
			queryBuilder.append(",").append(" attribute_name = '").append(override.getAttributeName()).append("'");
		}
		if(override.getAttributeName0()!=null ) {
			queryBuilder.append(",").append(" attribute_name_0 = '").append(override.getAttributeName0()).append("'");
		}
		if(override.getAttributeName1()!=null ) {
			queryBuilder.append(",").append(" attribute_name_1 = '").append(override.getAttributeName1()).append("'");
		}
		if(override.getAttributeName2()!=null ) {
			queryBuilder.append(",").append(" attribute_name_2= '").append(override.getAttributeName2()).append("'");
		}
		if(override.getAttributeName3()!=null ) {
			queryBuilder.append(",").append(" attribute_name_3 = '").append(override.getAttributeName3()).append("'");
		}
		if(override.getAttributeName4()!=null ) {
			queryBuilder.append(",").append(" attribute_name_4 = '").append(override.getAttributeName4()).append("'");
		}
		if(override.getAttributeName5()!=null ) {
			queryBuilder.append(",").append(" attribute_name_5 = '").append(override.getAttributeName5()).append("'");
		}
		if(override.getAttributeName6()!=null ) {
			queryBuilder.append(",").append(" attribute_name_6 = '").append(override.getAttributeName6()).append("'");
		}
		if(override.getAttributeName7()!=null ) {
			queryBuilder.append(",").append(" attribute_name_7 = '").append(override.getAttributeName7()).append("'");
		}
		if(override.getAttributeName8()!=null ) {
			queryBuilder.append(",").append(" attribute_name_8 = '").append(override.getAttributeName8()).append("'");
		}
		if(override.getAttributeName9()!=null ) {
			queryBuilder.append(",").append(" attribute_name_9 = '").append(override.getAttributeName9()).append("'");
		}
		if(override.getAttributeValue0()!=null ) {
			queryBuilder.append(",").append(" attribute_value_0 = '").append(override.getAttributeValue0()).append("'");
		}
		if(override.getAttributeValue1()!=null ) {
			queryBuilder.append(",").append(" attribute_value_1 = '").append(override.getAttributeValue1()).append("'");
		}
		if(override.getAttributeValue2()!=null ) {
			queryBuilder.append(",").append(" attribute_value_2 = '").append(override.getAttributeValue2()).append("'");
		}
		if(override.getAttributeValue3()!=null ) {
			queryBuilder.append(",").append(" attribute_value_3 = '").append(override.getAttributeValue3()).append("'");
		}
		if(override.getAttributeValue4()!=null ) {
			queryBuilder.append(",").append(" attribute_value_4 = '").append(override.getAttributeValue4()).append("'");
		}
		if(override.getAttributeValue5()!=null ) {
			queryBuilder.append(",").append(" attribute_value_5 = '").append(override.getAttributeValue5()).append("'");
		}
		if(override.getAttributeValue6()!=null ) {
			queryBuilder.append(",").append(" attribute_value_6 = '").append(override.getAttributeValue6()).append("'");
		}
		if(override.getAttributeValue7()!=null ) {
			queryBuilder.append(",").append(" attribute_value_7 = '").append(override.getAttributeValue7()).append("'");
		}
		if(override.getAttributeValue8()!=null ) {
			queryBuilder.append(",").append(" attribute_value_8 = '").append(override.getAttributeValue8()).append("'");
		}
		if(override.getAttributeValue9()!=null ) {
			queryBuilder.append(",").append(" attribute_value_9 = '").append(override.getAttributeValue9()).append("'");
		}
		
		if(override.getModifiedDate()!=null ) {
			queryBuilder.append(",").append(" modified_date = '").append(convert.getDateInFormat(new Date(),"yyyy-MM-dd kk:mm:ss")).append("'");
		}
		if(override.getModifiedBy()!=null ) {
			queryBuilder.append(",").append(" modified_by = '").append(override.getModifiedBy()).append("'");
		}
		
		if(override.getOtherProductId1()!=null ) {
			queryBuilder.append(",").append(" other_product_id_1 = '").append(override.getOtherProductId1()).append("'");
		}
		if(override.getOtherProductId2()!=null ) {
			queryBuilder.append(",").append(" other_product_id_2 = '").append(override.getOtherProductId2()).append("'");
		}
		if(override.getOtherProductId3()!=null ) {
			queryBuilder.append(",").append(" other_product_id_3 = '").append(override.getOtherProductId3()).append("'");
		}
		if(override.getOtherProductId4()!=null ) {
			queryBuilder.append(",").append(" other_product_id_4 = '").append(override.getOtherProductId4()).append("'");
		}
		
		if(override.getRateplanProductId()!=null ) {
			queryBuilder.append(",").append(" rateplan_product_id = '").append(override.getRateplanProductId()).append("'");
		}
		
		if(override.getStatus()!=null ) {
			queryBuilder.append(",").append(" status = '").append(override.getStatus()).append("'");
		}
		
		if(override.getTariffCurrency()!=null ) {
			queryBuilder.append(",").append(" tariff_currency = '").append(override.getTariffCurrency()).append("'");
		}
		
		if(override.getPriority()!=null && override.getPriority()!=0) {
			queryBuilder.append(",").append(" priority = ").append(override.getPriority()).append("");
		}
		
		if(override.getOverrideTariffAmount()!=null) {
			queryBuilder.append(",").append(" override_tariff_amount = ").append(override.getOverrideTariffAmount()).append("");
		}
		
		queryBuilder.append(" where tariff_override_id=").append(override.getTariffOverrideId());
		
		//queryBuilder.append(" where tariff_override_id="+override.getTariffOverrideId()); 

		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		//System.out.println(queryBuilder);
	return override;
	}
}
