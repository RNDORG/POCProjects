package com.wipro.epc.repositories;

import java.util.List;





import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductAttribute;



/**
 * @author Developer
 * @version 1.0
 * type EpcProductAttributeRepository
 */
public interface EpcProductAttributeRepository extends CrudRepository<EpcProductAttribute,Integer>,EpcProductAttributeRepositoryCustom{

	
	// method to get test data, used only for test cases
	@Query(value="select attribute_id from epc_attribute_master limit 1", nativeQuery=true)
	String findATestAttribute();
	
	/**
	 * @param i
	 * @return
	 */
	List<EpcProductAttribute> findByAttributeUom(String i);
	
	/**
	 * @param i
	 * @return
	 */
	List<EpcProductAttribute> findByProductId(Integer i);
	
	
	List<EpcProductAttribute> findByAttributeIdAndProductId(Integer productId, Integer attributeId);
	
	/**
	 * @param productId
	 */
	@Modifying
	@Query(value="delete from epc_product_attribute where product_id=:productId", nativeQuery=true)
	void deleteProductFromAttribute(@Param("productId") Integer productId);

	List<EpcProductAttribute> findByProductAttributeId(
			Integer productAttributeId);

	
	
	
}
