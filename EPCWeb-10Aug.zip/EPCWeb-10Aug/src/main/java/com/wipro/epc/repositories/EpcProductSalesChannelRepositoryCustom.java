package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductSalesChannel;


/**
 * @author Developer
 * @version 1.0
 * type EpcProductSalesChannelRepositoryCustom
 */
public interface EpcProductSalesChannelRepositoryCustom {
	
	 /**
	 * @param query
	 * @return
	 */
	List<EpcProductSalesChannel> getList(String query);
	/**
	 * @param channel
	 * @return
	 */
	EpcProductSalesChannel modifyProductSalesChannel(EpcProductSalesChannel channel);

}
