package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductMigration;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductMigrationRepositorycCustom
 */
public interface EpcProductMigrationRepositorycCustom {
	/**
	 * @param query
	 * @return
	 */
	List<EpcProductMigration> getList(String query);
	/**
	 * @param migration
	 * @return
	 */
	EpcProductMigration modifyProductMigration(EpcProductMigration migration);
}
