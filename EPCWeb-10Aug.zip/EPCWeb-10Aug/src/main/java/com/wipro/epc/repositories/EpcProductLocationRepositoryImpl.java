package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcProductLocation;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductLocationRepositoryImpl
 */
public class EpcProductLocationRepositoryImpl implements EpcProductLocationRepositoryCustom{
	
	private static Logger logger =LoggerFactory.getLogger(EpcProductLocationRepositoryImpl.class);
	
	/**
	 * EntityManager EpcProductLocationRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductLocationRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcProductLocation> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductLocation.class).getResultList();
		
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductLocationRepositoryCustom#modifyProductLocation(com.wipro.epc.domain.EpcProductLocation)
	 */
	@Override
	public EpcProductLocation modifyProductLocation(EpcProductLocation location) {
StringBuilder queryBuilder = new StringBuilder("update epc_product_location set product_location_id="+location.getProductLocationId());
		
		if(location.getStatus()!=null && !location.getStatus().isEmpty())
			queryBuilder.append(",").append(" status = '").append(location.getStatus()).append("'");
		if(location.getLocationCode1()!=null && !location.getLocationCode1().isEmpty())
	    	   queryBuilder.append(",").append(" location_code_1 = '").append(location.getLocationCode1()).append("'");
		 if(location.getLocationCode2()!=null && !location.getLocationCode2().isEmpty())
	    	   queryBuilder.append(",").append(" location_code_2 = '").append(location.getLocationCode2()).append("'");
		 if(location.getLocationCode3()!=null && !location.getLocationCode3().isEmpty())
	    	   queryBuilder.append(",").append(" location_code_3 = '").append(location.getLocationCode3()).append("'");
		 if(location.getLocationCode4()!=null && !location.getLocationCode4().isEmpty())
	    	   queryBuilder.append(",").append(" location_code_4 = '").append(location.getLocationCode4()).append("'");	 
		queryBuilder.append(" where product_location_id =").append(location.getProductLocationId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		//System.out.println(query);
		return location;
	}

}



