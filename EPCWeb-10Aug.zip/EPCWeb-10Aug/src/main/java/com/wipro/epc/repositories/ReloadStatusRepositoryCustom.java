package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.ReloadStatus;

public interface ReloadStatusRepositoryCustom {

	List<ReloadStatus> getStatus(String query);

	Integer getCount(String query);
	
}
