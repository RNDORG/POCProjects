package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcAttributeMaster;

/**
 * @author Developer
 * @version 1.0
 * type EpcAttributeMasterRepositoryCustom
 */
public interface  EpcAttributeMasterRepositoryCustom {

	/**
	 * @param query
	 * @return
	 */
	List<EpcAttributeMaster> getCharList(String query);

	/**
	 * @param query
	 * @return
	 */
	List<EpcAttributeMaster> getDataTypeList(String query);

	

	/**
	 * @param characteristic
	 * @return
	 */
	EpcAttributeMaster deleteChars(EpcAttributeMaster characteristic);

	/**
	 * @param characteristic
	 * @return
	 */
	int checkChars(EpcAttributeMaster characteristic);

	/**
	 * @return
	 */
	List<String> searchCharName();

}