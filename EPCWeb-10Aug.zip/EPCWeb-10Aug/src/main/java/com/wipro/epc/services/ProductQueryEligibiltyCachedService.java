package com.wipro.epc.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.config.domain.Config;
import com.wipro.common.config.service.ConfigService;
import com.wipro.epc.domain.EpcActivityMaster;
import com.wipro.epc.domain.EpcNotificationTemplateDetail;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductAvailability;
import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.domain.EpcProductCompatibility;
import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductLocation;
import com.wipro.epc.domain.EpcProductMigration;
import com.wipro.epc.domain.EpcProductSalesChannel;
import com.wipro.epc.domain.EpcProductSegment;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.FlexiPlanInput;
import com.wipro.epc.dto.FlexiPlanResponse;
import com.wipro.epc.dto.OrderType;
import com.wipro.epc.dto.QueryEligibilityResponse;
import com.wipro.epc.dto.QueryEligibiltySearchInput;
import com.wipro.epc.esb.EsbRequestService;
import com.wipro.epc.util.Constants;
import com.wipro.epc.util.EPCUtils;


/**
 * @author Developer
 * @version 1.0
 * type ProductQueryEligibiltyService
 */
@Service
public class ProductQueryEligibiltyCachedService {
	
	private static Logger logger = LoggerFactory.getLogger(ProductQueryEligibiltyCachedService.class);
	/**
	 * EpcLookupMasterService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcLookupMasterService epcLookupMasterService;
	
	/**
	 * EpcProductInitChannelService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductInitChannelService epcProductInitChannelService;
	
	/**
	 * EpcProductAttributeService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductAttributeService epcProductAttributeService;
	
	/**
	 * EpcLocationService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcLocationService epcLocationService;
	
	/**
	 * EpcOrderChannelRuleService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcOrderChannelRuleService epcOrderChannelRuleService;

	/**
	 * EpcAttributeMasterService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcAttributeMasterService epcAttributeMasterService;
	
	/**
	 * ComplexSearchInputService ProductQueryEligibiltyService.java
	 */
	@Autowired
	ComplexSearchInputService complexSearchInputService;
	
	/**
	 * ConfigService ProductQueryEligibiltyService.java
	 */
	@Autowired
	ConfigService configService;
	
	/**
	 * EpcProductSpecificationService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	
	/**
	 * EsbRequestService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EsbRequestService esbRequestService;

    /**
     * EpcTariffOverrideService ProductQueryEligibiltyService.java
     */
    @Autowired
	EpcTariffOverrideService epcTariffOverrideService;
    
    /**
     * EpcProductProviderSystemService ProductQueryEligibiltyService.java
     */
    @Autowired
	EpcProductProviderSystemService epcProductProviderSystemService;
	
	/**
	 * ObjectMapper ProductQueryEligibiltyService.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * EpcProductMigrationService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductMigrationService epcProductMigrationService;
	
	/**
	 * EpcProductCommunityService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductCommunityService epcProductCommunityService;
	
	@Autowired
	EpcFlexiPlanService epcFlexiPlanService;
	
	@Autowired
	EpcActivityMasterService epcActivityMasterService;
	
	@Autowired
	MCachedProductService mCachedProductService;
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@Transactional
	public QueryEligibilityResponse checkEligibility(QueryEligibiltySearchInput searchInput, Map<String, List<String>> allRequestParams)
	{
			QueryEligibilityResponse checkEligibilityResponse = new QueryEligibilityResponse();
			checkEligibilityResponse.setSubFamily("");
			checkEligibilityResponse.setEligible(false);
			if( StringUtils.isBlank(searchInput.getOptionalProductId()) || StringUtils.isBlank(searchInput.getOrderType()) 
				|| StringUtils.isBlank(searchInput.getCustomerRatePlanId()) || StringUtils.isBlank(searchInput.getActionType())
				|| StringUtils.isBlank(searchInput.getInitiatingChannel()) || StringUtils.isBlank(searchInput.getStartDate())
				|| StringUtils.isBlank(searchInput.getSubscribedAddOnIds()) || StringUtils.isBlank(searchInput.getSourceSystem())){
				checkEligibilityResponse.setResponseCode("RES_ELI_MissingFields");
				checkEligibilityResponse.setRemarks("Mandatory Fields are missing. Please provide all mandatory fields ( optionalProductId, orderType, initiatingChannel, actionType, customerRatePlanId, subscribedAddOnIds, sourceSystem, startDate).");
				return checkEligibilityResponse;
			}
			
			boolean hasTariff = false;
			boolean hasChar = false ;
			List<String> supportedWith = Arrays.asList(new String []{"characteristic", "tariff", "provider", "triggerOrderRule", "decomposition", "notification", "orderChannelRule", "initiatingChannel", "all"});
			List<String> with = allRequestParams.get("with");
			if(with != null && !with.isEmpty()){
				for(String str : with){
					if(!supportedWith.contains(str)){
						if(!(str.startsWith("ta-") || str.startsWith("nta-") ) ){
							checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectWithParameter");
							checkEligibilityResponse.setRemarks("Unsupported with parameter ("+ str +") provided.");
							return checkEligibilityResponse;
						}else if(str.startsWith("ta-") ){
							hasTariff = true;
						}else if(str.startsWith("nta-")){
							hasChar = true;
						}
					}
				}
			}
			
			if( StringUtils.isNotBlank(searchInput.getSlabId()) && StringUtils.isBlank(searchInput.getCommunityId()) ){
				checkEligibilityResponse.setResponseCode("RES_ELI_MissingSlabId");
				checkEligibilityResponse.setRemarks("slabId cann't be provided without communityId.");
				return checkEligibilityResponse;
			}
			
			String discountedPrice = null;
			boolean slabPriceFound =  false;
			boolean bypassEligibilityCheck = false;
			if(StringUtils.isNotBlank(searchInput.getBypassEligibilityCheck()) && "1".equals(searchInput.getBypassEligibilityCheck())){
				bypassEligibilityCheck = true;
			}			

			boolean isOCREligible = false;
			boolean isBasicEligible = false;
			boolean isProductCompatible = false;
			boolean isCommunityEligible = false;
			boolean isAreaEligible = false;
			boolean isTerritoryEligible = false;
			boolean isRegionEligible = false;
			boolean isAvailabilityEligible = false;
			boolean isSegmentEligible = false;
			boolean isMsisdnEligible = false;

			Integer addOnProdId = fetchAddOnProductId(searchInput); //need to change here - manas1234
			logger.info("Add on Product Id : "+addOnProdId);
			EpcProductSpecification addOnProd = null;
			
			if(addOnProdId == null){
				List<String> initChannelLookups = epcLookupMasterService.getLookUpValuesByGroupAndName("epc_product_init_channel", "channel_id");
				if(!initChannelLookups.contains(searchInput.getInitiatingChannel())){
					checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectInitChannel");
					checkEligibilityResponse.setRemarks("Invalid Initiating Channel provided.");
					return checkEligibilityResponse;
				}
				List<String> lookups = epcLookupMasterService.getLookUpValuesByGroupAndName("epc_product_init_channel", "action_type");
				if(!lookups.contains(searchInput.getActionType())){
					checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectActionType");
					checkEligibilityResponse.setRemarks("Invalid Action Type provided.");
					return checkEligibilityResponse;
				}
				checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectOptionalProductId");
				checkEligibilityResponse.setRemarks("No Optional Product Id found for requested combination ("+searchInput.getOptionalProductId()+", "+searchInput.getInitiatingChannel()+", "+searchInput.getActionType()+").");
				return checkEligibilityResponse;
			}
			
			//logic to fetch primary product from CBIO.	
			String [] primaryIds = searchInput.getCustomerRatePlanId().split(":");
			String providerProdId = null;
			String providerSysCd = null;
			if (primaryIds.length == 2) {
				providerProdId = primaryIds[1];
				providerSysCd = primaryIds[0];
			}
			Integer prodId = null;
			EpcProductSpecification primaryProduct = null;
			if (StringUtils.isNotBlank(providerProdId) && StringUtils.isNotBlank(providerSysCd)) {
				prodId = epcProductProviderSystemService.getAddOnIdCached(providerProdId, providerSysCd);
				if(prodId == null ){
					checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectProviderProductId");
					checkEligibilityResponse.setRemarks("Product id not mapped for the provider product id : "+providerProdId);
					return checkEligibilityResponse;
				}
				
			}else{
				checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectRatePlanId");
				checkEligibilityResponse.setRemarks("Invalid customerRatePlanId provided.");
				return checkEligibilityResponse;
			}
			
			String [] ids = {String.valueOf(prodId), String.valueOf(addOnProdId)};
			List<EpcProductSpecification> allProds = mCachedProductService.find(ids );
			for(EpcProductSpecification prod : allProds){
				if(prodId.equals(prod.getProductId())){
					primaryProduct = prod;
				}
				if(addOnProdId.equals(prod.getProductId())){
					addOnProd = prod;
				}
			}
			checkEligibilityResponse.setSubFamily(addOnProd.getProductSubFamily());
			if(Constants.SOURCE_SYSTEM_ESB.equals(searchInput.getSourceSystem()) && (Constants.DOWNSTREAM_SYSTEM_COMS.equals(addOnProd.getDownstreamSystem()) || Constants.DOWNSTREAM_SYSTEM_COMS_SIMPLE.equals(addOnProd.getDownstreamSystem()))){
				checkEligibilityResponse.setResponseCode("RES_ELI_DSSystemRequested");
				checkEligibilityResponse.setRemarks("Downstream System requested.");
				checkEligibilityResponse.setDownStream(addOnProd.getDownstreamSystem());
				return checkEligibilityResponse;
			}
			
			if (!bypassEligibilityCheck) {
				Config env = configService.searchConfigKey("ext_api","environment");
				if(! (primaryProduct.getProductStatus().equals(Constants.PRODUCT_STATUS_LAUNCH) || ( env !=null && "uat".equalsIgnoreCase(env.getConfigValue()) && primaryProduct.getProductStatus().equals(Constants.PRODUCT_STATUS_TESTED)))) {
					checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectRatePlanStatus");
					checkEligibilityResponse
							.setRemarks("Rate plan status check failed.");
					return checkEligibilityResponse;
				}
				
				if(Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(primaryProduct.getProductSubCategory()) && StringUtils.isBlank(searchInput.getCommunityId())){
					checkEligibilityResponse.setResponseCode("RES_ELI_MissingCommunityId");
					checkEligibilityResponse.setRemarks("Community Id is not provided for the Rate Plan whose subCategory is Corporate.");
					return checkEligibilityResponse;
				}else if(Constants.PRODUCT_SUB_CATEGORY_REGULAR.equals(primaryProduct.getProductSubCategory()) && StringUtils.isNotBlank(searchInput.getCommunityId())){
					checkEligibilityResponse.setResponseCode("RES_ELI_CommunityIdProvidedForRegularRatePlan");
					checkEligibilityResponse.setRemarks("Community Id is provided whereas subCategory of Rate Plan is not Corporate.");
					return checkEligibilityResponse;
				}
				
				//logic for OCR check
				if (!validateOrderChannelRule(searchInput.getOrderType(), //manas1234
						searchInput.getInitiatingChannel(),
						searchInput.getSalesChannel())) {
					checkEligibilityResponse.setResponseCode("RES_ELI_OCRCheckFailed");
					checkEligibilityResponse
							.setRemarks("Failed for Order Channel Rule check.");
					return checkEligibilityResponse;
				}
				
				String nonNetworkVASClassifications = configService.searchConfigKey("ext_api","non_network_vas_classifications").getConfigValue();
				if (nonNetworkVASClassifications == null) {
					checkEligibilityResponse.setResponseCode("RES_ELI_NNVCNotDefined");
					checkEligibilityResponse
							.setRemarks("Non Network VAS Classifications is not defined in config table.");
					return checkEligibilityResponse;
				}
				String nonNetworkVASCompatibility = configService.searchConfigKey("ext_api","non_network_vas_compatibility_flag").getConfigValue();
				if (nonNetworkVASCompatibility == null) {
					checkEligibilityResponse.setResponseCode("RES_ELI_NNVCompFlagNotDefined");
					checkEligibilityResponse
							.setRemarks("Non Network VAS Compatibility Flag is not defined in config table.");
					return checkEligibilityResponse;
				}
				
				String A2ACompatibility = configService.searchConfigKey("ext_api","a2a_compatibility_flag").getConfigValue();
				if (A2ACompatibility == null) {
					checkEligibilityResponse.setResponseCode("RES_ELI_A2ACompFlagNotDefined");
					checkEligibilityResponse
							.setRemarks("Addon to Addon Compatibility Flag is not defined in config table.");
					return checkEligibilityResponse;
				}
				boolean A2ACompatibilityFlag = Boolean.parseBoolean(A2ACompatibility);
				
				boolean nonNetworkVASCompatibilityFlag = Boolean
						.parseBoolean(nonNetworkVASCompatibility);
				
				List<String> nonNetworkVASCompatibilitylist = new ArrayList<String>();
				
				String[] nonNetworkVASClassificationsList = nonNetworkVASClassifications
						.split(",");
				for (String str : nonNetworkVASClassificationsList) {
					nonNetworkVASCompatibilitylist.add(str.trim());
				}
				Set<Integer> safccList = new HashSet<Integer>();//Subscribed add ons for compatibility check
				if (!nonNetworkVASCompatibilityFlag && nonNetworkVASCompatibilitylist.contains(addOnProd
						.getProductClassification())) {
					//do nothing
				}else {
					List<Map<String, String>> subscriptionVASList = fetchSubscribedAddons(searchInput.getSubscribedAddOnIds());
					if (subscriptionVASList != null) {
						safccList.addAll(getAddOnIds(subscriptionVASList));
					}
				}
					
				try {
					logger.debug("SAFCC list is :"+mapper.writeValueAsString(safccList));
				} catch (JsonProcessingException e1) {
					logger.warn("Exception during JSON conversion >>"+ExceptionUtils.getStackTrace(e1));
				}
				//logic for compatible check
				List<EpcProductCompatibility> addOnCompatibilities = addOnProd
						.getEpcProductCompatibility();
				if (addOnCompatibilities != null) {
					List<Integer> finalAOIds = new ArrayList<Integer>();
					List<Integer> addOnCompatibilityIds = new ArrayList<Integer>();
					for (EpcProductCompatibility epcProductCompatibility : addOnCompatibilities) {
						addOnCompatibilityIds.add(epcProductCompatibility
								.getOtherProductId());
						if (Constants.PRODUCT_TYPE_OPTIONAL.equalsIgnoreCase(epcProductCompatibility.getOtherProductSpecification()
								.getProductType())) {
							finalAOIds.add(epcProductCompatibility.getOtherProductSpecification().getProductId());
						}
					}
					if (!nonNetworkVASCompatibilityFlag && nonNetworkVASCompatibilitylist.contains(addOnProd
							.getProductClassification())) {
						isProductCompatible = true;
					}else{
						if(addOnCompatibilityIds.contains(primaryProduct.getProductId())){
							isProductCompatible = true;
						}
					}
					if (A2ACompatibilityFlag && !finalAOIds.isEmpty()) {
						finalAOIds.retainAll(safccList);
						if (finalAOIds.isEmpty()) {
							isProductCompatible = false;
						}
					}
				} else {
					if (!nonNetworkVASCompatibilityFlag && nonNetworkVASCompatibilitylist.contains(addOnProd
							.getProductClassification())) {
						isProductCompatible = true;
					}
				}
				if (!isProductCompatible) {
					checkEligibilityResponse.setResponseCode("RES_ELI_CompatibilityCheckFailed");
					checkEligibilityResponse
							.setRemarks("Failed for Compatibility level check.");
					return checkEligibilityResponse;
				}
				
				if(Constants.ACTION_TYPE_SUBSCRIPTION.equals(searchInput.getActionType())){
					List<EpcProductSpecification> subscribedRoamingProds = null;
					if(!safccList.isEmpty()){
						/*List<String> safccProdIds = new ArrayList<String>();
						for(Integer id : safccList){
							safccProdIds.add(String.valueOf(id));
						}
						Map<String, List<String>> safccParams = new HashMap<String, List<String>>();
						safccParams.put("productId", safccProdIds);
						safccParams.put("isRoamingProduct", Arrays.asList(new String []{"1"}));
						subscribedRoamingProds = epcProductSpecificationService.getBasicProductSpecByID(safccParams);*/
						
						//manas1234
						String [] safccIds = new String [safccList.size()];
						int i=0;
						for(Integer id : safccList){
							safccIds[i] = (String.valueOf(id));
							i++;
						}
						subscribedRoamingProds = mCachedProductService.find(safccIds );
						for( Iterator<EpcProductSpecification> iterator = subscribedRoamingProds.iterator(); iterator.hasNext();  ){
							EpcProductSpecification prod = iterator.next();
							if(!(prod.getIsRoamingProduct() == 1)){
								iterator.remove();
							}
						}
					}
					if(addOnProd.getIsRoamingProduct() == 1 && (subscribedRoamingProds != null && subscribedRoamingProds.size() == 1)){
						if(addOnProd.getProductId().equals(subscribedRoamingProds.get(0).getProductId())){
							checkEligibilityResponse.setResponseCode("RES_ELI_RoamProdAlreadySubs");
							checkEligibilityResponse.setRemarks("Eligibility fails as requested roaming product is same as subscribed roaming product.");
							return checkEligibilityResponse;
						}
						Map<String, List<String>> migParams = new HashMap<String, List<String>>();
						migParams.put("sourceProductId", Arrays.asList(new String []{String.valueOf(subscribedRoamingProds.get(0).getProductId())}));
						List<EpcProductMigration> migrations = epcProductMigrationService.searchEpcProductMigration(migParams);
						if(migrations != null && !migrations.isEmpty()){
							Set<Integer> commonMig = new HashSet<Integer>();
							for(EpcProductMigration migration : migrations){
								commonMig.add(migration.getTargetProductId());
							}
							
							if(!commonMig.contains(addOnProd.getProductId())){
								checkEligibilityResponse.setResponseCode("RES_ELI_NoMigRuleDefinedForOptProd");
								checkEligibilityResponse.setRemarks("For the subscribed roaming product :"+subscribedRoamingProds.get(0).getProductShortCode()+", no migration rule defined for optional product :"+addOnProd.getProductShortCode());
								return checkEligibilityResponse;
							}
						}else{
							checkEligibilityResponse.setResponseCode("RES_ELI_NoMigRuleDefinedForSubsRoamProd");
							checkEligibilityResponse.setRemarks("No migration rule defined for the subscribed roaming product :"+subscribedRoamingProds.get(0).getProductShortCode());
							return checkEligibilityResponse;
						}
					}else if(addOnProd.getIsRoamingProduct() == 1 && (subscribedRoamingProds != null && subscribedRoamingProds.size() > 1)){
						checkEligibilityResponse.setResponseCode("RES_ELI_MoreThnOneRoamProdSubs");
						checkEligibilityResponse.setRemarks("More than one roaming products have been subscribed.");
						return checkEligibilityResponse;
					}
				}
				
				//logic for basicinfo check
				if (primaryProduct.getProductAssociationLevel().equals(
						addOnProd.getProductAssociationLevel())
						&& primaryProduct.getProductFamily().equals(
								addOnProd.getProductFamily())
						&& EPCUtils.validateCategory(
								primaryProduct.getProductCategory(),
								addOnProd.getProductCategory())
						&& EPCUtils.validateSubCategory(primaryProduct.getProductSubCategory(),
								addOnProd.getProductSubCategory())) {
					isBasicEligible = true;
				} else {
					checkEligibilityResponse.setResponseCode("RES_ELI_FCSACheckFailed");
					checkEligibilityResponse
							.setRemarks("Failed for Family/Category/SubCategory/Association level check.");
					return checkEligibilityResponse;
				}
				//logic for segment check
				if (StringUtils.isNotBlank(searchInput.getSegment())) {
					boolean pFound = false;
					boolean aFound = false;
					List<EpcProductSegment> primaryProductSegments = primaryProduct
							.getEpcProductSegment();
					List<EpcProductSegment> addOnProdSegments = addOnProd
							.getEpcProductSegment();
					if (primaryProductSegments != null
							&& addOnProdSegments != null) {
						for (EpcProductSegment epcProductSegment : primaryProductSegments) {
							if (epcProductSegment.getSegment().equals(
									searchInput.getSegment())) {
								pFound = true;
								break;
							}
						}
						for (EpcProductSegment epcProductSegment : addOnProdSegments) {
							if (epcProductSegment.getSegment().equals(
									searchInput.getSegment())) {
								aFound = true;
								break;
							}
						}
						if (pFound && aFound) {
							isSegmentEligible = true;
						}
					}

				} else {
					isSegmentEligible = true;
				}
				if (!isSegmentEligible) {
					checkEligibilityResponse.setResponseCode("RES_ELI_SegmentCheckFailed");
					checkEligibilityResponse
							.setRemarks("Failed for Segment level check.");
					return checkEligibilityResponse;
				}
				//logic for community check
				
				if (StringUtils.isNotBlank(searchInput.getCommunityId()) &&  Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(primaryProduct.getProductSubCategory())) {
					if (Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(addOnProd.getProductSubCategory()) || Constants.PRODUCT_SUB_CATEGORY_ALL.equals(addOnProd.getProductSubCategory())) {
						boolean pFound = false;
						byte isEmployeeAllowedToPurchase = 0;
						List<EpcProductCommunity> primaryProductCommunities = primaryProduct
								.getEpcProductCommunity();
						List<EpcProductCommunity> addOnProdCommunities = addOnProd
								.getEpcProductCommunity();
						if (primaryProductCommunities != null) {
							for (EpcProductCommunity epcProductCommunity : primaryProductCommunities) {
								if (String.valueOf(
										epcProductCommunity.getCommunityId())
										.equals(searchInput.getCommunityId())  && 
										Constants.COMMUNITY_APPLICABLE_EMP_Band_ALL
										.equals(epcProductCommunity.getApplicableEmpBand())) {
									isEmployeeAllowedToPurchase = epcProductCommunity.getIsEmployeeAllowedToPurchase();
									pFound = true;
									break;
								}
							}
							if(!pFound){
								checkEligibilityResponse.setResponseCode("RES_ELI_MissingRatePlanCommunityMapping");
								checkEligibilityResponse
								.setRemarks("Community id not mapped for the given rate plan :"+primaryProduct.getProductShortCode());
								return checkEligibilityResponse;
							}
							if(isEmployeeAllowedToPurchase == 1){
										if(addOnProd.getIsCorporateSpecific() != null && addOnProd.getIsCorporateSpecific() == 1){
											if (addOnProdCommunities != null) {
												for (EpcProductCommunity epcProductCommunity : addOnProdCommunities) {
													if (searchInput.getCommunityId().equals(
															String.valueOf(epcProductCommunity
																	.getCommunityId()))) {
														isCommunityEligible = true;
														break;
													}
												}
											}
										}else{
											isCommunityEligible = true;
										}		
							}else{
								if (addOnProdCommunities != null) {
									for (EpcProductCommunity epcProductCommunity : addOnProdCommunities) {
										if (searchInput
												.getCommunityId()
												.equals(String
														.valueOf(epcProductCommunity
																.getCommunityId()))) {
											isCommunityEligible = true;
											break;
										}
									}
								}
							}
							if((with!= null && (with.contains("all") ||with.contains("tariff") || hasTariff )) &&
									StringUtils.isNotBlank(searchInput.getSlabId()) && addOnProdCommunities != null && isCommunityEligible){	
								for (EpcProductCommunity epcProductCommunity : addOnProdCommunities) {
									if (String.valueOf(
											epcProductCommunity.getCommunityId())
											.equals(searchInput.getCommunityId())
											&& 
											searchInput.getSlabId()
											.equals(epcProductCommunity.getSlabId())
											&& Constants.COMMUNITY_STATUS_ACTIVE.equals(epcProductCommunity.getCommunityStatus())) {
											discountedPrice = String.valueOf(epcProductCommunity.getDiscountedPrice());
											slabPriceFound=true;
									}
								}
							}
						}
					}
					
					if (!isCommunityEligible) {
						checkEligibilityResponse.setResponseCode("RES_ELI_CommunityCheckFailed");
						checkEligibilityResponse
								.setRemarks("Failed for Community level check.");
						return checkEligibilityResponse;
					}
				} 
				
				//logic for init channel check
				boolean initChannelCheck = false;
				List<EpcProductInitChannel> initChannels = addOnProd
						.getEpcProductInitChannel();
				if (initChannels != null) {
					for (EpcProductInitChannel initChannel : initChannels) {
						if (searchInput.getInitiatingChannel().equals(
								initChannel.getChannelId())
								&& initChannel.getStatus().equals(Constants.INIT_CHANNEL_STATUS_ACTIVE)) {
							initChannelCheck = true;
							break;
						}
					}
				}
				if (!initChannelCheck) {
					checkEligibilityResponse.setResponseCode("RES_ELI_InitChannelCheckFailed");
					checkEligibilityResponse
							.setRemarks("Failed for Init Channel level check.");
					return checkEligibilityResponse;
				}
				if (StringUtils.isNotBlank(searchInput.getSalesChannel())) {
					//logic for sales channel check			
					boolean salesChannelCheck = false;
					List<EpcProductSalesChannel> saleChannels = addOnProd
							.getEpcProductSalesChannel();
					if (saleChannels != null) {
						for (EpcProductSalesChannel salesChannel : saleChannels) {
							if (searchInput.getSalesChannel().equals(
									salesChannel.getPartnerType())) {
								salesChannelCheck = true;
								break;
							}
						}
					}
					if (!salesChannelCheck) {
						checkEligibilityResponse.setResponseCode("RES_ELI_SalesChannelCheckFailed");
						checkEligibilityResponse
								.setRemarks("Failed for Sales Channel level check.");
						return checkEligibilityResponse;
					}
				}
				List<EpcProductLocation> primaryProductLocations = primaryProduct
						.getEpcProductLocation();
				List<EpcProductLocation> addOnProdLocations = addOnProd
						.getEpcProductLocation();
				//logic for Region check
				if (StringUtils.isNotBlank(searchInput.getRegion())) {
					boolean pFound = false;
					boolean aFound = false;
					if (primaryProductLocations != null
							&& addOnProdLocations != null) {
						for (EpcProductLocation epcProductLoc : primaryProductLocations) {
							if (searchInput.getRegion().equals(epcProductLoc.getLocationCode2())) {
								pFound = true;
								break;
							}
						}
						for (EpcProductLocation epcProductLoc : addOnProdLocations) {
							if (searchInput.getRegion().equals(epcProductLoc.getLocationCode2())) {
								aFound = true;
								break;
							}
						}
						if (pFound && aFound) {
							isRegionEligible = true;
						}
					}

				} else {
					isRegionEligible = true;
				}
				if (!isRegionEligible) {
					checkEligibilityResponse.setResponseCode("RES_ELI_RegionCheckFailed");
					checkEligibilityResponse
							.setRemarks("Failed for Region level check.");
					return checkEligibilityResponse;
				}
				//logic for Area check
				if (StringUtils.isNotBlank(searchInput.getArea())) {
					boolean pFound = false;
					boolean aFound = false;
					if (primaryProductLocations != null
							&& addOnProdLocations != null) {
						for (EpcProductLocation epcProductLoc : primaryProductLocations) {
							if (searchInput.getArea().equals(epcProductLoc.getLocationCode3())) {
								pFound = true;
								break;
							}
						}
						for (EpcProductLocation epcProductLoc : addOnProdLocations) {
							if (searchInput.getArea().equals(epcProductLoc.getLocationCode3())) {
								aFound = true;
								break;
							}
						}
						if (pFound && aFound) {
							isAreaEligible = true;
						}
					}

				} else {
					isAreaEligible = true;
				}
				if (!isAreaEligible) {
					checkEligibilityResponse.setResponseCode("RES_ELI_AreaCheckFailed");
					checkEligibilityResponse
							.setRemarks("Failed for Area level check.");
					return checkEligibilityResponse;
				}
				//logic for Territory check
				if (StringUtils.isNotBlank(searchInput.getTerritory())) {
					boolean pFound = false;
					boolean aFound = false;
					if (primaryProductLocations != null
							&& addOnProdLocations != null) {
						for (EpcProductLocation epcProductLoc : primaryProductLocations) {
							if (searchInput.getTerritory().equals(epcProductLoc.getLocationCode4())) {
								pFound = true;
								break;
							}
						}
						for (EpcProductLocation epcProductLoc : addOnProdLocations) {
							if (searchInput.getTerritory().equals(epcProductLoc.getLocationCode4())) {
								aFound = true;
								break;
							}
						}
						if (pFound && aFound) {
							isTerritoryEligible = true;
						}
					}

				} else {
					isTerritoryEligible = true;
				}
				if (!isTerritoryEligible) {
					checkEligibilityResponse.setResponseCode("RES_ELI_TerritoryCheckFailed");
					checkEligibilityResponse
							.setRemarks("Failed for Territory level check.");
					return checkEligibilityResponse;
				}
				if (addOnProd.getIsProductPaused() == 1) {
					checkEligibilityResponse.setResponseCode("RES_ELI_AddOnProductIsPaused");
					checkEligibilityResponse
							.setRemarks("Failed for add on product isPaused check.");
					return checkEligibilityResponse;
				}
				if (!(addOnProd.getProductStatus().equals(Constants.PRODUCT_STATUS_LAUNCH)|| ( env !=null && "uat".equalsIgnoreCase(env.getConfigValue()) && addOnProd.getProductStatus().equals(Constants.PRODUCT_STATUS_TESTED)))) {
					checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectAddOnProductStatus");
					checkEligibilityResponse
							.setRemarks("Failed for add on product status check.");
					return checkEligibilityResponse;
				}
				//start date check
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				Date startDate;
				try {
					startDate = df.parse(searchInput.getStartDate());
				} catch (ParseException e) {
					logger.warn(e.getMessage());
					checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectStartDate");
					checkEligibilityResponse
							.setRemarks("Start Date is not provided in proper format.");
					return checkEligibilityResponse;
				}
				EpcProductAvailability availability = addOnProd
						.getEpcProductAvailability().get(0);
				if (availability.getLifeValidityStartDate().before(startDate)
						&& availability.getLifeValidityEndDate().after(
								startDate)
						&& availability.getSubscriptionStartDate().before(
								startDate)
						&& availability.getSubscriptionEndDate().after(
								startDate)
						&& availability.getSellingStartDate().before(startDate)
						&& availability.getSellingEndDate().after(startDate)) {
					isAvailabilityEligible = true;
				} else {
					checkEligibilityResponse.setResponseCode("RES_ELI_StartDateCheckFailed");
					checkEligibilityResponse
							.setRemarks("Failed for Start Date check.");
					return checkEligibilityResponse;
				}
			}
			
			EpcProductSpecification retProd  = cloneEPCProductSpec(addOnProd, searchInput, with, hasChar, hasTariff);
			FlexiPlanResponse flexiPriceRes = null;
			boolean isFlexi = false;
			BigDecimal flexiPrice = new BigDecimal(0);
			boolean priceSupressionFlag = false;
			if( StringUtils.isBlank(searchInput.getDataUnit()) && searchInput.getData()==null && StringUtils.isBlank(searchInput.getVoiceType()) && searchInput.getVoice()==null
					&& StringUtils.isBlank(searchInput.getVoiceUnit()) && searchInput.getSms() == null && searchInput.getValidity()==null && searchInput.getFlexiPrice()==null && searchInput.getFlexiPriceWithTax() == null){
				//do nothing
			}else if( StringUtils.isNotBlank(searchInput.getDataUnit()) && searchInput.getData()!=null && StringUtils.isNotBlank(searchInput.getVoiceType()) && searchInput.getVoice()!=null
					&& StringUtils.isNotBlank(searchInput.getVoiceUnit()) && searchInput.getSms() != null && searchInput.getValidity()!=null && searchInput.getFlexiPrice()!=null && searchInput.getFlexiPriceWithTax() != null ){
				FlexiPlanInput input = new FlexiPlanInput();
				input.setData(searchInput.getData());
				input.setDataUnit(searchInput.getDataUnit());
				input.setVoice(searchInput.getVoice());
				input.setVoiceUnit(searchInput.getVoiceUnit());
				input.setVoiceType(searchInput.getVoiceType());
				input.setSms(searchInput.getSms());
				
				Config flexiValidity = configService.searchConfigKey("ext_api","flexi_validity");
				if(flexiValidity == null ){
					checkEligibilityResponse.setResponseCode("RES_ELI_FlexiValidityValuesNotDefined");
					checkEligibilityResponse.setRemarks("Valid Flexi Validity values not configured in config table.");
					return checkEligibilityResponse;
				}
				List<String> fValidityList = new ArrayList<String>();
				String [] fvalidities = flexiValidity.getConfigValue().split(",");
				for(String str : fvalidities){
					fValidityList.add(str.trim());
				}
				if(!fValidityList.contains(String.valueOf(searchInput.getValidity()))){
					checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectValidity");
					checkEligibilityResponse.setRemarks("validity is not a valid value.");
					return checkEligibilityResponse;
				}
				if(StringUtils.isNotBlank(searchInput.getReceiverRatePlanId())){
					if(!Constants.FLEXI_PLAN_GIFT.equals(addOnProd.getProductShortCode())){
						checkEligibilityResponse.setResponseCode("RES_ELI_AddOnProductShouldBeFlexiPlanGift");
						checkEligibilityResponse.setRemarks("The add on product id should be FLEXI_PLAN_GIFT when receiverRatePlan is provided.");
						return checkEligibilityResponse;
					}
					String [] nrRps = searchInput.getReceiverRatePlanId().split(":");
					if(nrRps.length < 2 ){
						checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectReceiverRatePlanId");
						checkEligibilityResponse.setRemarks("Invalid receiverRatePlanId provided.");
						return checkEligibilityResponse;
					}
					Config nonReceiverRateplans = configService.searchConfigKey("ext_api","non-receiver_rateplans");
					if(nonReceiverRateplans == null ){
						checkEligibilityResponse.setResponseCode("RES_ELI_NonReceiverRateplansNotDefined");
						checkEligibilityResponse.setRemarks("Non Receiver Rateplans values not configured in config table.");
						return checkEligibilityResponse;
					}
					List<String> nonReceiverRateplansList = new ArrayList<String>();
					String [] nonReceiverRPs = nonReceiverRateplans.getConfigValue().split(",");
					for(String str : nonReceiverRPs){
						nonReceiverRateplansList.add(str.trim());
					}
					if(nonReceiverRateplansList.contains(nrRps[1])){
						checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectReceiverMSISDN");
						checkEligibilityResponse.setRemarks("Receiver MSISDN should not belong to ERS, Biometric and DMS.");
						return checkEligibilityResponse;
					}
				}
				
				input.setValidity(searchInput.getValidity());
				isFlexi = true;
				flexiPriceRes = epcFlexiPlanService.flexiPlanPriceCached(input);
				if(isFlexi && (searchInput.getFlexiPrice().doubleValue() != flexiPriceRes.getFlexiPrice().doubleValue() || searchInput.getFlexiPriceWithTax().doubleValue() != flexiPriceRes.getFlexiPriceWithTax().doubleValue())){
					checkEligibilityResponse.setResponseCode("RES_ELI_IncorrectFlexiPrices");
					checkEligibilityResponse.setRemarks("EPC calculated flexi prices don't match with the provided flexi prices.");
					return checkEligibilityResponse;
				}
				if(searchInput.getPriceSuppressionFlag() == null || !"1".equals(searchInput.getPriceSuppressionFlag())){
					if(Constants.PRODUCT_CATEGORY_PREPAID.equals(primaryProduct.getProductCategory())){
						flexiPrice = flexiPriceRes.getFlexiPriceWithTax();
					}else{
						flexiPrice = flexiPriceRes.getFlexiPrice();
					}
				}
			}else {
				checkEligibilityResponse.setResponseCode("RES_ELI_MissingFlexiParameters");
				checkEligibilityResponse.setRemarks("Either ALL or NONE of these fields(data,dataUnit,voice,voiceUnit,voiceType,sms,validity,flexiPrice,flexiPriceWithTax) need to be provided.");
				return checkEligibilityResponse;
			} 
			
			
			//EpcProductSpecification addOnProd = SerializationUtils.clone(addOnProd);
			//-----------------------------------logic to check tariff override amount starts--------------------------------
			if (with!= null && (with.contains("all") || with.contains("tariff") || hasTariff )) {
				boolean isSubFeeDefined = false;
				if(retProd.getEpcProductTariff() != null && retProd.getEpcProductTariff() .size() >0 ){
					for(EpcProductAttribute attr : retProd.getEpcProductTariff()){
						if(Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr.getEpcAttributeMaster().getAttributeCtg()) && 
								Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr.getEpcAttributeMaster().getAttributeCtgType()) &&
								Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							isSubFeeDefined = true;
							break;
						}
					}
				}
				if (!isSubFeeDefined) {
					checkEligibilityResponse.setResponseCode("RES_ELI_SubscriptionFeeNotDefinedforAddOnProduct");
					checkEligibilityResponse
							.setRemarks("SUBSCRIPTION_FEE for OneTime Charge is not defined for Addon :"
									+ retProd
											.getProductShortCode());
					return checkEligibilityResponse;
				}
			}
			if(with!= null && (with.contains("all") || with.contains("tariff") || hasTariff ) && isFlexi){
					if(retProd.getEpcProductTariff() != null && retProd.getEpcProductTariff() .size() >0 ){
						for(EpcProductAttribute attr : retProd.getEpcProductTariff()){
							if(Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr.getEpcAttributeMaster().getAttributeCtg()) && 
									Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr.getEpcAttributeMaster().getAttributeCtgType()) &&
									Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
								attr.setAttributeValue1(String.valueOf(flexiPrice));
								break;
							}
						}
					}
			}else{
				if(with!= null && (with.contains("all") || with.contains("tariff") || hasTariff ) 
						&& Constants.OPT_PROD_CALL_BLOCK_SERVICE_POSTPAID.equals(retProd.getProductShortCode())  
						&& (Arrays.asList(Constants.XPLORE_LEGEND_PROVIDER_PROD_IDS).contains(providerProdId)
								|| (Constants.PRODUCT_CATEGORY_POSTPAID.equals(primaryProduct.getProductCategory())
						&& Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(primaryProduct.getProductSubCategory())))){
					if(retProd.getEpcProductTariff() != null && retProd.getEpcProductTariff() .size() >0 ){
						for(EpcProductAttribute attr : retProd.getEpcProductTariff()){
							if(Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr.getEpcAttributeMaster().getAttributeCtg()) && 
									Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr.getEpcAttributeMaster().getAttributeCtgType()) &&
									Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
								attr.setAttributeValue1("0");
								break;
							}
						}
					}
				}else{
				
					if (with!= null && (with.contains("all") || with.contains("tariff") || hasTariff ) && StringUtils.isBlank(discountedPrice)) {
						List<BigDecimal> attributeValueList = epcTariffOverrideService
									.getTariffOverrideAmountCached(searchInput.getOtherProductId1(),
											searchInput.getOtherProductId2(), searchInput.getOtherProductId3(),
											searchInput.getOtherProductId4(), primaryProduct
													.getProductShortCode(),
													retProd
													.getProductShortCode());
						if(attributeValueList != null && !attributeValueList.isEmpty()){
							discountedPrice = String.valueOf(attributeValueList.get(0));
						}
					}
					
					if (StringUtils.isNotBlank(discountedPrice)){
						if(retProd.getEpcProductTariff() != null && retProd.getEpcProductTariff() .size() >0 ){
							for(EpcProductAttribute attr : retProd.getEpcProductTariff()){
								if(Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr.getEpcAttributeMaster().getAttributeCtg()) && 
										Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr.getEpcAttributeMaster().getAttributeCtgType()) &&
										Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
									attr.setAttributeValue1(discountedPrice);
									break;
								}
							}
						}
					}
				}
			}
			
			//-----------------------------------logic to check tariff override amount ends----------------------------------
			
			//------------------Logic to override characteristics for flexi price - starts-------------------------------
			if(with != null && (with.contains("all") || with.contains("characteristic") || hasChar ) && isFlexi){
				
				String key = null;
				String daKey = null;
				String transactionType = "";
				if (searchInput.getData().equals(0)){
					key = "N"+searchInput.getValidity();
				}else{
					key = "Y"+searchInput.getValidity();
				}
				String externalData = "";
				List<EpcActivityMaster> activities = epcActivityMasterService.searchActivities("FLEXIPLAN_EXTERNAL_DATA_MASTER", key);
				if(activities != null && !activities.isEmpty()){
					if(activities.get(0).getEpcActivityDetail() != null && !activities.get(0).getEpcActivityDetail().isEmpty()){
						externalData = activities.get(0).getEpcActivityDetail().get(0).getActivityValue();
					}
				}
				if(searchInput.getDataUnit().equals(Constants.DATA_UNIT_MB)){
					searchInput.setData(searchInput.getData()*1);
				}
				else if(searchInput.getDataUnit().equals(Constants.DATA_UNIT_GB)){
					searchInput.setData(searchInput.getData()*1024);
				}
				if(searchInput.getVoiceUnit().equals(Constants.VOICE_UNIT_MINUTES)){
					searchInput.setVoice(searchInput.getVoice()*1);
				}
				else if(searchInput.getVoiceUnit().equals(Constants.VOICE_UNIT_HOURS)){
					searchInput.setVoice(searchInput.getVoice()*60);
				}
				//for converting flexi price into paisa.
				Long priceInPaisa = flexiPrice.multiply(new BigDecimal(100)).longValue();
				if(searchInput.getVoiceType().equalsIgnoreCase(Constants.VOICE_TYPE_ANYNET)){
					transactionType = String.format("FLXPLNA%04dR%05d%04d%02d%06d",searchInput.getVoice(), searchInput.getData(), searchInput.getSms(), searchInput.getValidity(), priceInPaisa );
				}else if(searchInput.getVoiceType().equalsIgnoreCase(Constants.VOICE_TYPE_ONNET)){
					transactionType = String.format("FLXPLNO%04dR%05d%04d%02d%06d",searchInput.getVoice(), searchInput.getData(), searchInput.getSms(), searchInput.getValidity(), priceInPaisa );
				}
				
				String da = "";
				if (searchInput.getVoiceType().equalsIgnoreCase(Constants.VOICE_TYPE_ANYNET)){
					daKey = "anynet_"+searchInput.getValidity();
				}else{
					daKey = "onnet_"+searchInput.getValidity();
				}
				List<EpcActivityMaster> daActivities = epcActivityMasterService.searchActivities("FLEXIPLAN_DA_MASTER", daKey);
				if(daActivities != null && !daActivities.isEmpty()){
					if(daActivities.get(0).getEpcActivityDetail() != null && !daActivities.get(0).getEpcActivityDetail().isEmpty()){
						da = daActivities.get(0).getEpcActivityDetail().get(0).getActivityValue();
					}
				}
				if(retProd.getEpcProductCharacteristic() != null && retProd.getEpcProductCharacteristic().size() >0 ){
					for(EpcProductAttribute attr : retProd.getEpcProductCharacteristic()){
						if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							attr.setAttributeValue1(externalData);
						}else if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1ARON.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							attr.setAttributeValue1(externalData);
						}else if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1SLAB.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							attr.setAttributeValue1(externalData);
						}else if(Constants.ATTRIBUTE_NAME_TRANSACTIONTYPENEW.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							attr.setAttributeValue1(transactionType);
						}else if(Constants.ATTRIBUTE_NAME_DA.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
							attr.setAttributeValue1(da);
						}
					}
				}
			}else{
				if(with != null && (with.contains("all") || with.contains("characteristic") || hasChar ) && StringUtils.isNotBlank(searchInput.getSlabId()) && (with.contains("all") || with.contains("tariff") || hasTariff ) && !slabPriceFound && Constants.PRODUCT_SUB_FAMILY_DATA.equals(retProd.getProductSubFamily())){
					
					EpcProductAttribute extData1 = null;
					EpcProductAttribute extData1Aron = null;
					if(retProd.getEpcProductCharacteristic() != null && retProd.getEpcProductCharacteristic().size() >0 ){
						for(EpcProductAttribute attr : retProd.getEpcProductCharacteristic()){
							if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
								extData1 = attr;
							}else if(Constants.ATTRIBUTE_NAME_EXTERNALDATA1ARON.equalsIgnoreCase(attr.getEpcAttributeMaster().getAttributeName())){
								extData1Aron = attr;
							}
						}
					}
					if(extData1 != null && extData1Aron != null){
						extData1Aron.setDefaultValue1(extData1.getDefaultValue1());
						extData1Aron.setAttributeValue1(extData1.getAttributeValue1());
						extData1Aron.setDefaultValue2(extData1.getDefaultValue2());
						extData1Aron.setAttributeValue2(extData1.getAttributeValue2());
					}else{
						checkEligibilityResponse.setResponseCode("RES_ELI_ExternalDataNotDefinedforAddOnProduct");
						checkEligibilityResponse.setRemarks("EXTERNAL_DATA_1/EXTERNAL_DATA_1_ARON not defined for the product :"+retProd.getProductShortCode()+".");
						return checkEligibilityResponse;
					}
				}
			}
			//------------------Logic to override characteristics for flexi price - end-------------------------------
			
			//to filter initChannel beased on initChannel Value provided.			
			if(with != null && (with.contains("all") || with.contains("initiatingChannel"))){
				for( Iterator<EpcProductInitChannel> iterator = retProd.getEpcProductInitChannel().iterator(); iterator.hasNext();  ){
					EpcProductInitChannel epcProductInitChannel = iterator.next();
					if(!((searchInput.getInitiatingChannel().equals(epcProductInitChannel.getChannelId())) && (searchInput.getActionType().equals(epcProductInitChannel.getActionType())))){
						iterator.remove();
					}
				}
			}
			
			if(isFlexi && (with != null && (with.contains("all") || with.contains("notification")))){
				List<EpcProductAttribute> epcProdAtrs = new ArrayList<EpcProductAttribute>();
				if(addOnProd.getEpcProductCharacteristic() != null && !addOnProd.getEpcProductCharacteristic().isEmpty()){
					for ( EpcProductAttribute attr : addOnProd.getEpcProductCharacteristic()){
						if(attr != null && attr.getEpcAttributeMaster() != null && "Notification".equals(attr.getEpcAttributeMaster().getAttributeCtgType())){
							epcProdAtrs.add(attr);
						}
					}
				}
				if(StringUtils.isNotBlank(searchInput.getReceiverRatePlanId())){
					replaceForGiftFlexiPlan(retProd, flexiPrice, searchInput, epcProdAtrs);
				}else{
					replaceForFlexiPlan(retProd, flexiPrice, searchInput, epcProdAtrs);
				}
			}
			
			checkEligibilityResponse.setEligible(true);
			checkEligibilityResponse.setResponseCode("");
			checkEligibilityResponse.setRemarks("NA");
			checkEligibilityResponse.setAddonEligibleProduct(retProd);
			return checkEligibilityResponse;
	}
	




	private void replaceForFlexiPlan(EpcProductSpecification retProd,
			BigDecimal flexiPrice, QueryEligibiltySearchInput searchInput,
			List<EpcProductAttribute> epcProdAtrs) {
		if( retProd.getEpcProductInitChannel() != null && !retProd.getEpcProductInitChannel().isEmpty() ){
			for( EpcProductInitChannel channel : retProd.getEpcProductInitChannel()){
				if(channel != null && channel.getEpcNotificationTemplate() != null && channel.getEpcNotificationTemplate().getEpcNotificationTemplateDetail() != null 
						&& "VOICE_FLEXIPLAN_SUB_SUCCESS_TMPL".equals(channel.getEpcNotificationTemplate().getTemplateName())){
					for( EpcNotificationTemplateDetail notDetails : channel.getEpcNotificationTemplate().getEpcNotificationTemplateDetail()){
						replaceDetails(notDetails, searchInput, flexiPrice, epcProdAtrs, channel.getEpcNotificationTemplate().getTemplateName());
					}
				}
			}
		}
		
		if( retProd.getOrderType() != null && retProd.getOrderType().getEpcProductDecomposition() != null && !retProd.getOrderType().getEpcProductDecomposition().isEmpty() ){
			for( EpcProductDecomposition decomposition : retProd.getOrderType().getEpcProductDecomposition()){
				if(decomposition != null && decomposition.getEpcNotificationTemplate() != null && decomposition.getEpcNotificationTemplate().getEpcNotificationTemplateDetail() != null 
						&& "VOICE_FLEXIPLAN_SUB_SUCCESS_TMPL".equals(decomposition.getEpcNotificationTemplate().getTemplateName())){
					for( EpcNotificationTemplateDetail notDetails : decomposition.getEpcNotificationTemplate().getEpcNotificationTemplateDetail()){
						replaceDetails(notDetails, searchInput, flexiPrice, epcProdAtrs, decomposition.getEpcNotificationTemplate().getTemplateName());
					}
				}
			}
		}
	}

	private void replaceDetails(EpcNotificationTemplateDetail notDetails,
			QueryEligibiltySearchInput searchInput, BigDecimal flexiPrice,
			List<EpcProductAttribute> epcProdAtrs, String templateName) {
		String str = notDetails.getTemplateBody();
		str = str.replaceAll("\\[FLEXI_PRICE\\]", String.valueOf(flexiPrice));
		if (!"VOICE_GIFTFLEXIPLAN_SENDER_SUB_SUCCESS_TMPL".equals(templateName)) {
			str = str.replaceAll("\\[FLEXI_VOICE_QUOTA\\]",
					String.valueOf(searchInput.getVoice()));
			str = str.replaceAll("\\[FLEXI_DATA_QUOTA\\]",
					String.valueOf(searchInput.getData()));
			str = str.replaceAll("\\[FLEXI_DATA_UNIT\\]",
					String.valueOf(searchInput.getDataUnit()));
			str = str.replaceAll("\\[FLEXI_SMS_QUOTA\\]",
					String.valueOf(searchInput.getSms()));
			if (searchInput.getVoiceType().equalsIgnoreCase(
					Constants.VOICE_TYPE_ANYNET)) {
				str = str.replaceAll("\\[FLEXI_ANYNET_ONNET_FLAG\\]", "anynet");
			} else {
				str = str.replaceAll("\\[FLEXI_ANYNET_ONNET_FLAG\\]", "gp");
			}
			str = str.replaceAll("\\[VALIDITY\\]",
					String.valueOf(searchInput.getValidity()));
			str = replaceNotCharacteristics(str, epcProdAtrs);
		}
		notDetails.setTemplateBody(str);
	}





	private String replaceNotCharacteristics(String str,
			List<EpcProductAttribute> epcProdAtrs) {
		if(epcProdAtrs != null && !epcProdAtrs.isEmpty()){
			for( EpcProductAttribute  attr : epcProdAtrs ){
				if(attr != null && attr.getEpcAttributeMaster() != null && attr.getEpcAttributeMaster().getAttributeName() != null){
					str = str.replaceAll("\\["+attr.getEpcAttributeMaster().getAttributeName()+"\\]", attr.getAttributeValue1());
				}
			}
		}
		return str;
	}





	private void replaceForGiftFlexiPlan(EpcProductSpecification retProd,
			BigDecimal flexiPrice, QueryEligibiltySearchInput searchInput,
			List<EpcProductAttribute> epcProdAtrs) {
		if( retProd.getEpcProductInitChannel() != null && !retProd.getEpcProductInitChannel().isEmpty() ){
			for( EpcProductInitChannel channel : retProd.getEpcProductInitChannel()){
				if(channel != null && channel.getEpcNotificationTemplate() != null && channel.getEpcNotificationTemplate().getEpcNotificationTemplateDetail() != null 
						&& ("VOICE_GIFTFLEXIPLAN_SENDER_SUB_SUCCESS_TMPL".equals(channel.getEpcNotificationTemplate().getTemplateName()) ||
								"VOICE_GIFTFLEXIPLAN_RECEIVER_SUB_SUCCESS_TMPL".equals(channel.getEpcNotificationTemplate().getTemplateName()))){
					for( EpcNotificationTemplateDetail notDetails : channel.getEpcNotificationTemplate().getEpcNotificationTemplateDetail()){
						replaceDetails(notDetails, searchInput, flexiPrice, epcProdAtrs, channel.getEpcNotificationTemplate().getTemplateName());
					}
				}
			}
		}
		
		if( retProd.getOrderType() != null && retProd.getOrderType().getEpcProductDecomposition() != null && !retProd.getOrderType().getEpcProductDecomposition().isEmpty() ){
			for( EpcProductDecomposition decomposition : retProd.getOrderType().getEpcProductDecomposition()){
				if(decomposition != null && decomposition.getEpcNotificationTemplate() != null && decomposition.getEpcNotificationTemplate().getEpcNotificationTemplateDetail() != null 
						&& ("VOICE_GIFTFLEXIPLAN_SENDER_SUB_SUCCESS_TMPL".equals(decomposition.getEpcNotificationTemplate().getTemplateName()) ||
								"VOICE_GIFTFLEXIPLAN_RECEIVER_SUB_SUCCESS_TMPL".equals(decomposition.getEpcNotificationTemplate().getTemplateName()))){
					for( EpcNotificationTemplateDetail notDetails : decomposition.getEpcNotificationTemplate().getEpcNotificationTemplateDetail()){
						replaceDetails(notDetails, searchInput, flexiPrice, epcProdAtrs, decomposition.getEpcNotificationTemplate().getTemplateName());
					}
				}
			}
		}		
	}

	/**
	 * @param msisdn
	 * @return
	 */
	private List<Map<String,String>> fetchSubscribedAddons(String addons) {
		List<Map<String,String>> subscriptionVASList = null;
		logger.warn("stub_subscribed_vas_addons used: " + addons );
		subscriptionVASList = new ArrayList<Map<String,String>>();
		String [] addOnArray = addons.split(",");
		Map<String,String> map = null;
		if (addOnArray != null && addOnArray.length > 0) {
			for (String str : addOnArray) {
				map = new HashMap<String, String>();
				String[] addOn = str.split(":");
				if (addOn != null && addOn.length == 2) {
					map.put("providerSystemCode", addOn[0].trim());
					map.put("providerProductId", addOn[1].trim());
					subscriptionVASList.add(map);
				}
			}
		}
		return subscriptionVASList;
	}

	/**
	 * @param orderType
	 * @param initChannel
	 * @param SalesChannel
	 * @return
	 */
	private boolean validateOrderChannelRule(
			String orderType, String initChannel, String SalesChannel) {
		StringBuilder query = new StringBuilder();
		query.append("where order_type ='").append(orderType).append("' and initiating_channel = '").append(initChannel).append("' and ");
		if(SalesChannel == null){
			query.append(" sales_channel is null");
		}else{
			query.append(" sales_channel ='").append(SalesChannel).append("' ");
		}
		query.append(" and status='").append("Active'");
		
		List<EpcOrderChannelRule> epcOrderChannelRules = epcOrderChannelRuleService.getOrderChannelRulesByWhereClause(query.toString());
		if(epcOrderChannelRules != null && !epcOrderChannelRules.isEmpty() ){
			return true;
		}
		return false;
	}

	/**
	 * @param searchInput
	 * @return
	 */
	private Integer fetchAddOnProductId(QueryEligibiltySearchInput searchInput) {
		
		MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
		criteria.add("channelLevelProductId", searchInput.getOptionalProductId().trim());
		criteria.add("channelId", searchInput.getInitiatingChannel());
		criteria.add("actionType", searchInput.getActionType());
		List<EpcProductInitChannel> EpcProductInitChannels = epcProductInitChannelService.searchEpcProductInitChannel(criteria);
		Integer prodId = null;
		if (EpcProductInitChannels != null && EpcProductInitChannels.size() == 1){
			prodId = EpcProductInitChannels.get(0).getProductId();
		}
		return prodId;
	}
	
	
	/**
	 * @param subscribedGSMAddonList
	 * @return
	 */
	private List<Integer> getAddOnIds(List<Map<String,String>> subscribedGSMAddonList){
		List<Integer> gsmAddonIds = new ArrayList<Integer>();
		for(Map<String,String> provider: subscribedGSMAddonList){
			Integer id = epcProductProviderSystemService.getAddOnIdCached(provider.get("providerProductId"), provider.get("providerSystemCode"));
			if(id != null){
				gsmAddonIds.add(id);
			}
		}
		return gsmAddonIds;
	}

	private EpcProductSpecification cloneEPCProductSpec(EpcProductSpecification prod, QueryEligibiltySearchInput searchInput, List<String> with, boolean hasChar, boolean hasTariff){
		
		EpcProductSpecification retProd = new EpcProductSpecification();
		
		BeanUtils.copyProperties(prod, retProd,new String [] {"epcProductAvailability","epcProductSalesChannel","epcProductLocation","epcProductInitChannel","epcProductAttribute","epcProductCompatibility","epcProductMigration","epcProductHeirarchy","epcProductCommunity","epcProductNetworkTplMap","epcProductCharacteristic","epcProductTariff","epcProductProvider","epcProductSegment","parent","child","orderType","reservedHI","genericFiles","extension"});
		if(with != null && (with.contains("all") || with.contains("initiatingChannel"))){
			if(prod.getEpcProductInitChannel() != null && !prod.getEpcProductInitChannel().isEmpty()){
				retProd.setEpcProductInitChannel(EPCUtils.deepCopyInitChannels(prod.getEpcProductInitChannel()));
			}
		}
		
		if((with != null && (with.contains("all") || with.contains("characteristic")))|| hasChar){
			if(prod.getEpcProductCharacteristic() != null && !prod.getEpcProductCharacteristic().isEmpty()){
				retProd.setEpcProductCharacteristic(EPCUtils.deepCopyProdAttributes(prod.getEpcProductCharacteristic()));
			}
		}
		
		if((with != null && (with.contains("all") || with.contains("tariff")))|| hasTariff){
			if(prod.getEpcProductTariff() != null && !prod.getEpcProductTariff().isEmpty()){
				retProd.setEpcProductTariff(EPCUtils.deepCopyProdAttributes(prod.getEpcProductTariff()));
			}
		}
		
		if(with != null && (with.contains("all") || with.contains("provider"))){
			retProd.setEpcProductProvider(prod.getEpcProductProvider());
		}
		
		if(with != null && (with.contains("all") || with.contains("triggerOrderRule") ||  with.contains("decomposition") || with.contains("orderChannelRule"))){
			if(prod.getExtension() != null){
				OrderType orderType = new OrderType();
				BeanUtils.copyProperties(((Map<String, OrderType>)prod.getExtension()).get(searchInput.getOrderType()), orderType);
				if (orderType != null) {
					if (!(with != null && (with.contains("all") || with
							.contains("triggerOrderRule")))) {
						orderType.setEpcTriggerOrderRule(null);
					}
					if (!(with != null && (with.contains("all") || with
							.contains("decomposition")))) {
						orderType.setEpcProductDecomposition(null);
					}else{
						orderType.setEpcProductDecomposition(EPCUtils.deepCopyDecompositions(orderType.getEpcProductDecomposition()));
					}
					if (!(with != null && (with.contains("all") || with
							.contains("orderChannelRule")))) {
						orderType.setEpcOrderChannelRule(null);
					}
					retProd.setOrderType(orderType);
				}
			}
		}
		
		/*if(!(with != null && (with.contains("all") || with.contains("notification")))){
			if(retProd.getEpcProductInitChannel() != null ){
				for(EpcProductInitChannel channel  : retProd.getEpcProductInitChannel()){
					channel.setEpcNotificationTemplate(null);
				}
			}
			if(retProd.getOrderType() != null && retProd.getOrderType().getEpcOrderChannelRule() != null){
				for(EpcOrderChannelRule ocr  : retProd.getOrderType().getEpcOrderChannelRule()){
					ocr.setEpcNotificationTemplate(null);
				}
			}
			if(retProd.getOrderType() != null && retProd.getOrderType().getEpcProductDecomposition() != null){
				for(EpcProductDecomposition decomp  : retProd.getOrderType().getEpcProductDecomposition()){
					decomp.setEpcNotificationTemplate(null);
				}
			}
		}*/
		return retProd;
	}
	
	String staticRespData;
	
	@Transactional
	public String checkEligibilityStatic(
			QueryEligibiltySearchInput searchInput,
			Map<String, List<String>> allRequestParams) throws IOException {

		if (staticRespData != null) {
			return staticRespData;
		} else {
			try (BufferedReader br = new BufferedReader(new InputStreamReader(
					new ClassPathResource(
							"query-eligibility-static-response.xml")
							.getInputStream()))) {
				StringBuilder sb = new StringBuilder();
				String line = br.readLine();
				while (line != null) {
					sb.append(line);
					sb.append(System.lineSeparator());
					line = br.readLine();
				}
				staticRespData = sb.toString();
				br.close();
			} catch (Exception e) {
				logger.error("Error Reading static response file "
						+ e.getMessage());
				staticRespData = "Error in Reading File.. Please contact Admin!";
			}
			return staticRespData;

		}
	}
}
