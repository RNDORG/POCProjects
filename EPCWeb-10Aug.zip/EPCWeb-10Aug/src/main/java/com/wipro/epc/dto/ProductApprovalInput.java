
package com.wipro.epc.dto;


/**
 * @author Developer
 * @version 1.0
 * type ProductApprovalInput
 */
public class ProductApprovalInput {

	/**
	 * Integer ProductApprovalInput.java
	 */
	private Integer productId;
	/**
	 * String ProductApprovalInput.java
	 */
	private String productShortCode;
	/**
	 * String ProductApprovalInput.java
	 */
	private String fromStatus;
	/**
	 * String ProductApprovalInput.java
	 */
	private String toStatus;
	/**
	 * String ProductApprovalInput.java
	 */
	private String user;
	/**
	 * String ProductApprovalInput.java
	 */
	private String suspensionReason;
	/**
	 * String ProductApprovalInput.java
	 */
	private String productClassification;
	/**
	 * Integer ProductApprovalInput.java
	 */
	private Integer copiedFromProductId;
	/**
	 * String ProductApprovalInput.java
	 */
	private String retirePreviousProduct;
	
	/**
	 * @return
	 */
	public Integer getProductId() {
		return productId;
	}
	/**
	 * @param productId
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	/**
	 * @return
	 */
	public String getSuspensionReason() {
		return suspensionReason;
	}
	/**
	 * @param suspensionReason
	 */
	public void setSuspensionReason(String suspensionReason) {
		this.suspensionReason = suspensionReason;
	}
	/**
	 * @return
	 */
	public String getProductShortCode() {
		return productShortCode;
	}
	/**
	 * @param productShortCode
	 */
	public void setProductShortCode(String productShortCode) {
		this.productShortCode = productShortCode;
	}
	/**
	 * @return
	 */
	public String getFromStatus() {
		return fromStatus;
	}
	/**
	 * @param fromStatus
	 */
	public void setFromStatus(String fromStatus) {
		this.fromStatus = fromStatus;
	}
	/**
	 * @return
	 */
	public String getToStatus() {
		return toStatus;
	}
	/**
	 * @param toStatus
	 */
	public void setToStatus(String toStatus) {
		this.toStatus = toStatus;
	}
	/**
	 * @return
	 */
	public String getUser() {
		return user;
	}
	/**
	 * @param user
	 */
	public void setUser(String user) {
		this.user = user;
	}
	/**
	 * @return
	 */
	public String getProductClassification() {
		return productClassification;
	}
	/**
	 * @param classification
	 */
	public void setProductClassification(String classification) {
		this.productClassification = classification;
	}
	/**
	 * @return
	 */
	public Integer getCopiedFromProductId() {
		return copiedFromProductId;
	}
	/**
	 * @param copiedFromProductId
	 */
	public void setCopiedFromProductId(Integer copiedFromProductId) {
		this.copiedFromProductId = copiedFromProductId;
	}
	/**
	 * @return
	 */
	public String getRetirePreviousProduct() {
		return retirePreviousProduct;
	}
	/**
	 * @param retirePreviousProduct
	 */
	public void setRetirePreviousProduct(String retirePreviousProduct) {
		this.retirePreviousProduct = retirePreviousProduct;
	}
	
}
