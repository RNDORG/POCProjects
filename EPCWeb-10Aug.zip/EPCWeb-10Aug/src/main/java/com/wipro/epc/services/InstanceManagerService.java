package com.wipro.epc.services;


import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.wipro.common.config.domain.ServerStatus;
import com.wipro.common.config.service.ServerStatusService;


@Service
public class InstanceManagerService {
	private static Logger logger =LoggerFactory.getLogger(InstanceManagerService.class);
	
	@Autowired
	private ApplicationContext applicationContext;
	
	@Autowired
	ServerStatusService serverStatusService;
	
	public static String url;
	
	
	public static String getUrl() {
		return url;
	}

	public static void setUrl(String url) {
		InstanceManagerService.url = url;
	}
	public String[] getIpPort(String toValue){
		// code to get the values from serverstatus table when the parameter is being passed as 'node' ,'all', 'ui' or 'non-ui'
		List<String> targetIpPortList=new ArrayList<String>();
		
		if(toValue.equalsIgnoreCase("all")){
			List<ServerStatus> serverStatusObjects = serverStatusService.getServerStatus();
			//targetIpPort = new String[serverStatusObjects.size()];
			int m=0;
			for(ServerStatus object: serverStatusObjects) {
			//	targetIpPort[m] = object.getserverName();
				targetIpPortList.add(object.getserverName());
				m = m+1;
			}
		}
		else if(toValue.equalsIgnoreCase("node")) {
			List<ServerStatus> serverStatusObjects = serverStatusService.getServerStatus();
			
			List<String> distinctPorts = new ArrayList<String>();
			//distinctPorts.add(serverStatusObjects.get(0).getserverName());
			for(int i=0; i<serverStatusObjects.size(); i++) {
				String[] array = serverStatusObjects.get(i).getserverName().split(":");
					distinctPorts.add(array[0]);
			}
			Set<String> hs = new HashSet<>();
			hs.addAll(distinctPorts);
			distinctPorts.clear();
			distinctPorts.addAll(hs);
			
			
			//targetIpPort = new String[distinctPorts.size()];
			int f=0;
			for(String ip:distinctPorts){
				for(int i=0; i<serverStatusObjects.size(); i++){
					String[] array = serverStatusObjects.get(i).getserverName().split(":");
					if(array[0].equals(ip)){
					//	targetIpPort[f] = serverStatusObjects.get(i).getserverName();
						targetIpPortList.add(serverStatusObjects.get(i).getserverName());
						f++;
						break;
					}
				}
			}
		}
		
		else if(toValue.equalsIgnoreCase("non-ui")){
			List<ServerStatus> serverStatusObjects = serverStatusService.getServerStatus();
			//targetIpPort = new String[serverStatusObjects.size()];
			int m=0;
			for(ServerStatus object: serverStatusObjects) {
				if(object.getValue().equals(0)) {
				//targetIpPort[m] = object.getserverName();
				targetIpPortList.add(object.getserverName());
				m = m+1;
				}
			}
		}
		else if(toValue.equalsIgnoreCase("ui")){
			List<ServerStatus> serverStatusObjects = serverStatusService.getServerStatus();
			//targetIpPort = new String[serverStatusObjects.size()];
			int m=0;
			for(ServerStatus object: serverStatusObjects) {
				if(object.getValue().equals(1)) {
				//targetIpPort[m] = object.getserverName();
				targetIpPortList.add(object.getserverName());
				m = m+1;
				}
			}
			
		}
		
		// code to get the values from serverstatus table ends here.
		else {
			targetIpPortList=Arrays.asList( toValue.split(",") );
		}
		System.out.println("targetIpPortList: "+targetIpPortList.toString());
		return targetIpPortList.toArray(new String[0]);
	}

	 public Map<String,String> notifyAll(String restApi, String[] targetIpPort) {
		 
		Map<String,String> reply=new HashMap<String, String>();
		String[] urls=constructURL(restApi,targetIpPort);
		
		MyThread[] threads = new MyThread[urls.length];
		for ( int i=0; i<threads.length; i++ ) {
			threads[i] = new MyThread(urls[i]);
			threads[i].setName(urls[i]);
			threads[i].start();
			logger.info("#ThreadStart: [" + i + "] : " + threads[i].getName());
		}
		
		for ( int i=0; i<threads.length; i++ ) {
			try {
				threads[i].join();
				logger.info("#ThreadJoin: [" + i + "] : " + threads[i].getName());
				//String s = t.retVal;
				reply.put(threads[i].url,threads[i].retVal);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}			
		}
		
		return reply;
		
	}
	 

	 String[] constructURL(String api,String[] targetIpPort){
		
		//String[] ips=new String[]{"http://10.207.31.53:8080"};//,"10.208.83.200:8080"//"http://10.201.62.64:8080/EPCWeb",
		String[] urls=new String[targetIpPort.length];
		
		for(int i=0;i<targetIpPort.length;i++){
			urls[i]="http://"+ targetIpPort[i]+applicationContext.getApplicationName()+api;
		}
		return urls;
		
	}

}

class MyThread extends Thread {
	
	String retVal;
	String url;
	public MyThread(String urlName) {
		url=urlName;
	}

	//Mythread
	
	@Override
	public void run() {
		HttpHeaders httpHeader = new HttpHeaders();
		httpHeader=createHeaders();
		
		RestTemplate restTemplate = new RestTemplate();	
		
		//System.setProperty("proxyHost", "proxy1.wipro.com"); 
		//System.setProperty("proxyPort", "8080"); 
		System.out.println("url: "+url);
		//url=InstanceManagerService.getUrl();
		try{
			ResponseEntity<String> entity = restTemplate.exchange(url,HttpMethod.GET,new HttpEntity<Object>(httpHeader),String.class) ;
			retVal=entity.getBody();
			System.out.println("response: "+entity.toString());
		}catch(RestClientException e){
			retVal="#BroadCastError: "+e.getMessage();
			System.out.println("ERROR : "+e.getStackTrace());
		}	
	
	}
	
	 private HttpHeaders createHeaders(){
		    HttpHeaders headers =  new HttpHeaders(){
		          {         
		        	  String auth="admin"+":"+"admin";
		        	  byte[] encodedAuth = Base64.encodeBase64(
		                      auth.getBytes(Charset.forName("US-ASCII")) );
		               String authHeader = "Basic " + new String( encodedAuth );
		             set( "Authorization", authHeader);
		          }
		       };

		       return headers;
		}
	
}

//******************************************************************************************************************************

/*for(int i=0;i<urls.length;i++){
InstanceManagerService.setUrl(urls[i]);
System.out.println("url 1 : "+InstanceManagerService.getUrl());
Thread t=new Thread(new Runnable() {
	
	@Override
	public void run() {
		HttpHeaders httpHeader = new HttpHeaders();
		httpHeader=createHeaders();
		
		RestTemplate restTemplate = new RestTemplate();	
		
		//System.setProperty("proxyHost", "proxy1.wipro.com"); 
		//System.setProperty("proxyPort", "8080"); 
		System.out.println("url: "+InstanceManagerService.getUrl());
		try{
			ResponseEntity<String> entity = restTemplate.exchange(InstanceManagerService.getUrl(),HttpMethod.GET,new HttpEntity<Object>(httpHeader),String.class) ;
			reply.put(InstanceManagerService.getUrl(),entity.getBody());
			System.out.println("response: "+entity.toString());
		}catch(RestClientException e){
			reply.put(InstanceManagerService.getUrl(),"#BroadCastError: "+e.getMessage());
			System.out.println("ERROR : "+e.getStackTrace());
		}
		
		
	}
	
});
t.start();
try {
	t.join();
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}*/
//******************************************************************************************************************************

/*	 private HttpHeaders createHeaders(){
HttpHeaders headers =  new HttpHeaders(){
      {         
    	  String auth="admin"+":"+"admin";
    	  byte[] encodedAuth = Base64.encodeBase64(
                  auth.getBytes(Charset.forName("US-ASCII")) );
           String authHeader = "Basic " + new String( encodedAuth );
         set( "Authorization", authHeader);
      }
   };

   return headers;
}*/

//******************************************************************************************************************************