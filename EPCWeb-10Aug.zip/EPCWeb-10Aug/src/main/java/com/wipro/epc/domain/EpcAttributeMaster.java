package com.wipro.epc.domain;

// Generated Jun 15, 2016 12:46:54 PM by Hibernate Tools 4.3.1


import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the epc_attribute_master database table containing the details about
 * @author VI251443
 * @version 1.0
 */
@Entity
@Table(name = "epc_attribute_master")
public class EpcAttributeMaster  implements Serializable  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "EpcAttributeMaster [attributeId=" + attributeId
				+ ", attributeCtg=" + attributeCtg + ", attributeCtgType="
				+ attributeCtgType + ", attributeName=" + attributeName
				+ ", attributeDescription=" + attributeDescription
				+ ", attributeDataType=" + attributeDataType
				+ ", attributeDataLength=" + attributeDataLength
				+ ", isVisible=" + isVisible + ", isCfs=" + isCfs + ", isRfs="
				+ isRfs + ", status=" + status + ", createdDate=" + createdDate
				+ ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate
				+ ", modifiedBy=" + modifiedBy + ", metaInfo=" + metaInfo + "]";
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "attribute_id", unique = true, nullable = false)
	private Integer attributeId;
	
	@Column(name = "attribute_ctg", nullable = false)
	private String attributeCtg;
	
	@Column(name = "attribute_ctg_type")
	private String attributeCtgType;
	
	@Column(name = "attribute_name", nullable = false, length = 100)
	private String attributeName;
	
	@Column(name = "attribute_description", length = 200)
	private String attributeDescription;
	
	@Column(name = "attribute_data_type", nullable = false)
	private String attributeDataType;
	
	@Column(name = "attribute_data_length", nullable = false)
	private Integer attributeDataLength;
	
	@Column(name = "is_visible", columnDefinition = "bit", length = 1)
	private Byte isVisible;
	
	@Column(name = "is_cfs",columnDefinition = "bit", length = 1)
	private Byte isCfs;
	
	@Column(name = "is_rfs",columnDefinition = "bit", length = 1)
	private Byte isRfs;
	
	@Column(name = "status", nullable = false)
	private String status;
	
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", length = 19)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;
	
	@JsonIgnore
	@Column(name = "created_by", nullable = false, length = 25)
	private String createdBy;
	
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", length = 19)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;
	
	@JsonIgnore
	@Column(name = "modified_by", length = 25)
	private String modifiedBy;
	
	
	@Transient
	private Map<String,String> metaInfo;	
	
	public EpcAttributeMaster() {
	}

	public EpcAttributeMaster(String attributeCtg, String attributeCtgType,
			String attributeName, String attributeDataType,
			Integer attributeDataLength, String status, String createdBy) {
		this.attributeCtg = attributeCtg;
		this.attributeCtgType = attributeCtgType;
		this.attributeName = attributeName;
		this.attributeDataType = attributeDataType;
		this.attributeDataLength = attributeDataLength;
		this.status = status;
		this.createdBy = createdBy;
	}

	public EpcAttributeMaster(String attributeCtg, String attributeCtgType,
			String attributeName, String attributeDescription,
			String attributeDataType, Integer attributeDataLength, Byte isVisible,
			Byte isCfs, Byte isRfs, String status, Date createdDate,
			String createdBy, Date modifiedDate, String modifiedBy) {
		this.attributeCtg = attributeCtg;
		this.attributeCtgType = attributeCtgType;
		this.attributeName = attributeName;
		this.attributeDescription = attributeDescription;
		this.attributeDataType = attributeDataType;
		this.attributeDataLength = attributeDataLength;
		this.isVisible = isVisible;
		this.isCfs = isCfs;
		this.isRfs = isRfs;
		this.status = status;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
	}

	
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}
	
	
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}

	
	public Integer getAttributeId() {
		return this.attributeId;
	}

	public void setAttributeId(Integer attributeId) {
		this.attributeId = attributeId;
	}

	
	public String getAttributeCtg() {
		return this.attributeCtg;
	}

	public void setAttributeCtg(String attributeCtg) {
		this.attributeCtg = attributeCtg;
	}

	
	public String getAttributeCtgType() {
		return this.attributeCtgType;
	}

	public void setAttributeCtgType(String attributeCtgType) {
		this.attributeCtgType = attributeCtgType;
	}

	
	public String getAttributeName() {
		return this.attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	
	public String getAttributeDescription() {
		return this.attributeDescription;
	}

	public void setAttributeDescription(String attributeDescription) {
		this.attributeDescription = attributeDescription;
	}

	
	public String getAttributeDataType() {
		return this.attributeDataType;
	}

	public void setAttributeDataType(String attributeDataType) {
		this.attributeDataType = attributeDataType;
	}

	
	public Integer getAttributeDataLength() {
		return this.attributeDataLength;
	}

	public void setAttributeDataLength(Integer attributeDataLength) {
		this.attributeDataLength = attributeDataLength;
	}

	
	public Byte getIsVisible() {
		return this.isVisible;
	}

	public void setIsVisible(Byte isVisible) {
		this.isVisible = isVisible;
	}

	
	public Byte getIsCfs() {
		return this.isCfs;
	}

	public void setIsCfs(Byte isCfs) {
		this.isCfs = isCfs;
	}

	
	public Byte getIsRfs() {
		return this.isRfs;
	}

	public void setIsRfs(Byte isRfs) {
		this.isRfs = isRfs;
	}

	
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	
	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	public String getAttributeCtgValue() {
		this.attributeCtgValue = attributeCtg;
		return attributeCtgValue;
	}

	public void setAttributeCtgValue(String attributeCtgValue) {
		this.attributeCtgValue = attributeCtgValue;
	}

	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	public String getAttributeCtgTypeValue() {
		this.attributeCtgTypeValue = attributeCtgType;
		return attributeCtgTypeValue;
	}

	public void setAttributeCtgTypeValue(String attributeCtgTypeValue) {
		this.attributeCtgTypeValue = attributeCtgTypeValue;
	}

	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	public String getAttributeDataTypeValue() {
		this.attributeDataTypeValue = attributeDataType;
		return attributeDataTypeValue;
	}

	public void setAttributeDataTypeValue(String attributeDataTypeValue) {
		this.attributeDataTypeValue = attributeDataTypeValue;
	}

	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}
*/
	
}
