package com.wipro.epc.domain;



import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;


/**
 * @author Developer
 * @version 1.0
 * The persistent class for the epc_product_testsuit database table.
 */
@Entity
@Table(name="epc_product_testsuit")
public class EpcProductTestsuit  implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Integer EpcProductTestsuit.java
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="testsuit_id")
	private Integer testsuitId;

	/**
	 * Date EpcProductTestsuit.java
	 */
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;

	/**
	 * String EpcProductTestsuit.java
	 */
	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	/**
	 * String EpcProductTestsuit.java
	 */
	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	/**
	 * Date EpcProductTestsuit.java
	 */
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	private Date modifiedDate;

	/**
	 * Integer EpcProductTestsuit.java
	 */
	@Column(name="product_id")
	private Integer productId;

	/**
	 * String EpcProductTestsuit.java
	 */
	@Column(name="status")
	private String status;

	/**
	 * String EpcProductTestsuit.java
	 */
	@Column(name="testsuit_file_desc")
	private String testsuitFileDesc;

	/**
	 * String EpcProductTestsuit.java
	 */
	@Column(name="testsuit_file_name")
	private String testsuitFileName;

	/**
	 * String EpcProductTestsuit.java
	 */
	@Column(name="testsuit_file_path")
	private String testsuitFilePath;

	/**
	 * 
	 */
	public EpcProductTestsuit() {
	}

	/**
	 * @return
	 */
	public Integer getTestsuitId() {
		return this.testsuitId;
	}

	/**
	 * @param testsuitId
	 */
	public void setTestsuitId(Integer testsuitId) {
		this.testsuitId = testsuitId;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return
	 */
	public Integer getProductId() {
		return this.productId;
	}

	/**
	 * @param productId
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return
	 */
	public String getTestsuitFileDesc() {
		return this.testsuitFileDesc;
	}

	/**
	 * @param testsuitFileDesc
	 */
	public void setTestsuitFileDesc(String testsuitFileDesc) {
		this.testsuitFileDesc = testsuitFileDesc;
	}

	/**
	 * @return
	 */
	public String getTestsuitFileName() {
		return this.testsuitFileName;
	}

	/**
	 * @param testsuitFileName
	 */
	public void setTestsuitFileName(String testsuitFileName) {
		this.testsuitFileName = testsuitFileName;
	}

	/**
	 * @return
	 */
	public String getTestsuitFilePath() {
		return this.testsuitFilePath;
	}

	/**
	 * @param testsuitFilePath
	 */
	public void setTestsuitFilePath(String testsuitFilePath) {
		this.testsuitFilePath = testsuitFilePath;
	}

}