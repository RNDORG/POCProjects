package com.wipro.epc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.dto.GenericQueryAvailabilityResponse;
import com.wipro.epc.dto.GenericQueryAvailabilitySearchInput;
import com.wipro.epc.services.ProductGenericQueryAvailabilityService;



/**
 * @author Developer
 * @version 1.0
 * type ProductGenericQueryAvailabilityController
 */
@RestController
public class ProductGenericQueryAvailabilityController {

	/**
	 * ProductGenericQueryAvailabilityService ProductGenericQueryAvailabilityController.java
	 */
	@Autowired
	ProductGenericQueryAvailabilityService queryEligibiltyService;
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/genericQueryAvailability", method=RequestMethod.POST)
	public GenericQueryAvailabilityResponse queryAvailabilityExt(@RequestBody GenericQueryAvailabilitySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		return queryEligibiltyService.queryEligibility(searchInput,allRequestParams);
	}
	
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/genericQueryAvailability", method=RequestMethod.POST)
	public GenericQueryAvailabilityResponse queryAvailability(@RequestBody GenericQueryAvailabilitySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		return queryEligibiltyService.queryEligibility(searchInput,allRequestParams);
	}
	
}
