package com.wipro.epc.repositories;

import java.util.Date;
import java.util.List;

import com.wipro.epc.util.SimpleDateConvertion;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.wipro.epc.domain.EpcProductAttribute;
	

/**
 * @author Developer
 * @version 1.0
 * type EpcProductAttributeRepositoryImpl
 */
public class EpcProductAttributeRepositoryImpl implements EpcProductAttributeRepositoryCustom {
	
	private static Logger logger =LoggerFactory.getLogger(EpcProductAttributeRepositoryImpl.class);
	
	@Autowired
	SimpleDateConvertion convert; 
	/**
	 * EntityManager EpcProductAttributeRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em; 
	
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductAttributeRepositoryCustom#getEpcProductAttributeList(java.lang.String)
	 */
	@Override
	public List<EpcProductAttribute> getEpcProductAttributeList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductAttribute.class).getResultList();

	}


	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductAttributeRepositoryCustom#modifyProductAttribute(com.wipro.epc.domain.EpcProductAttribute)
	 */
	@Override
	public EpcProductAttribute modifyProductAttribute(EpcProductAttribute productAttribute) {
		StringBuilder queryBuilder=new StringBuilder("update epc_product_attribute set product_attribute_id="+productAttribute.getProductAttributeId());
		
		if(productAttribute.getAttributeId()!=null && productAttribute.getAttributeId()!=0)
			queryBuilder.append(",").append(" attribute_id = '").append(productAttribute.getAttributeId()).append("'");
		if(productAttribute.getAttributeValue1()!=null )
			queryBuilder.append(",").append(" attribute_value1 = '").append(productAttribute.getAttributeValue1()).append("'");
		if(productAttribute.getAttributeValue2()!=null )
			queryBuilder.append(",").append(" attribute_value2 = '").append(productAttribute.getAttributeValue2()).append("'");
		if(productAttribute.getAttributeUom()!=null && !productAttribute.getAttributeUom().isEmpty())
			queryBuilder.append(",").append(" attribute_uom = '").append(productAttribute.getAttributeUom()).append("'");
		if(productAttribute.getDefaultValue1()!=null )
			queryBuilder.append(",").append(" default_value1 = '").append(productAttribute.getDefaultValue1()).append("'");
		if(productAttribute.getDefaultValue2()!=null )
			queryBuilder.append(",").append(" default_value2 = '").append(productAttribute.getDefaultValue2()).append("'");
		if(productAttribute.getIsPriceingAttribute()!=null )
			queryBuilder.append(",").append(" is_priceing_attribute = '").append(productAttribute.getIsPriceingAttribute()).append("'");
		if(productAttribute.getIsOtcAttribute()!=null )
			queryBuilder.append(",").append(" is_otc_attribute = '").append(productAttribute.getIsOtcAttribute()).append("'");
		if(productAttribute.getIsChildProductAttribute()!=null)
			queryBuilder.append(",").append(" is_child_product_attribute = '").append(productAttribute.getIsChildProductAttribute()).append("'");
		if(productAttribute.getIsMandatory()!=null )
			queryBuilder.append(",").append(" is_mandatory = '").append(productAttribute.getIsMandatory()).append("'");
		if(productAttribute.getIsInputReqFromChannel()!=null )
			queryBuilder.append(",").append(" is_input_req_from_channel = '").append(productAttribute.getIsInputReqFromChannel()).append("'");
		if(productAttribute.getStatus()!=null )
			queryBuilder.append(",").append(" status = '").append(productAttribute.getStatus()).append("'");
		if(productAttribute.getModifiedBy()!=null )
			queryBuilder.append(",").append(" modified_by = '").append(productAttribute.getModifiedBy()).append("'");
		if(productAttribute.getModifiedDate()!=null )
			queryBuilder.append(",").append(" modified_date = '").append(convert.getDateInFormat(new Date(),"yyyy-MM-dd kk:mm:ss")).append("'");
		
		
		queryBuilder.append(" where product_attribute_id=").append(productAttribute.getProductAttributeId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		//System.out.println(queryBuilder);
	return productAttribute;
	}


}
