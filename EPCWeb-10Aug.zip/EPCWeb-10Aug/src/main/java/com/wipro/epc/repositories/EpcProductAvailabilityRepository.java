package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductAvailability;


/**
 * @author KE334465
 *
 */
public interface EpcProductAvailabilityRepository extends CrudRepository<EpcProductAvailability, Integer> ,
EpcProductAvailabilityRepositoryCustom{
	
	
	/*@Query(value="select * from epc_product_availability where product_id=:product_id", nativeQuery=true)
	List<EpcProductAvailability> findByProductId(@Param("product_id") Integer productId);*/


	/**
	 * @param productId
	 * @return
	 */
	@Query(value="select * from epc_product_availability where product_id=:productId", nativeQuery = true)
	List<EpcProductAvailability> findAvailabilitiesByProductId(@Param("productId") Integer productId);
	
	/**
	 * @param productId
	 */
	@Modifying
	@Query(value="delete from epc_product_availability where product_id=:productId", nativeQuery=true)
	void deleteProductFromAvailability(@Param("productId") Integer productId);
}
