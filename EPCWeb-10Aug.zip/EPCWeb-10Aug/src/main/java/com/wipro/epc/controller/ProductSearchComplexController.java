package com.wipro.epc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.ComplexSearchInput;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcTariffOverrideRepository;
import com.wipro.epc.services.ComplexSearchInputService;
import com.wipro.epc.services.EpcProductSpecificationService;



/**
 * @author KE334465
 *
 */
@RestController
public class ProductSearchComplexController {

	@Autowired
	private ComplexSearchInputService searchService;
	
	@Autowired
	private EpcProductSpecificationService productService;
	
	private static Logger logger = LoggerFactory.getLogger(ProductSearchComplexController.class);
	
	@Autowired
	private ObjectMapper mapper;
	
	@Autowired
	private EpcTariffOverrideRepository tariffOverrideRepository;
	
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/searchProducts", method=RequestMethod.POST)
	public List<EpcProductSpecification> searchProductsComplexExt(@RequestBody ComplexSearchInput searchInput,
			 @RequestParam MultiValueMap allRequestParams)
	{
		String txnType="searchProducts";
		String request=null;
		List<EpcProductSpecification> response=null;
		try{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, searchInput);
	    response=searchService.searchComplex(searchInput, allRequestParams, true);
		}
		catch (Exception e ) {
			logger.error("#interfaceException: " + e.getMessage());
			throw new EPCException(e.getMessage());
		}
		finally{
		ePCTxnInterceptor.postTxn(txnType, request,response);
		}
		return response;
	}
	
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/searchProducts", method=RequestMethod.POST)
	public List<EpcProductSpecification> searchProductsComplex(@RequestBody ComplexSearchInput searchInput,
			 @RequestParam MultiValueMap allRequestParams)
	{
		////System.out.println("Sent input is : "+searchInput);
		return searchService.searchComplex(searchInput, allRequestParams, false);
	}
	
	
}
