package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductSpecification;


/**
 * @author KE334465
 *
 */
public interface EpcProductSpecificationRepository extends CrudRepository<EpcProductSpecification,Integer>,
EpcProductspecificationRepositoryCustom
{

	//method to get test data/ used only for test cases
	@Query(value="select product_id from epc_product_specification limit 1", nativeQuery=true)
	String findATestProduct();
	
	
	/**
	 * @param productShortCode
	 * @return
	 */
	@Query(value="select * from epc_product_specification where product_short_code=:product_short_code", nativeQuery=true)
	List<EpcProductSpecification> findByProductShortCode(@Param("product_short_code") String productShortCode);
	
	/**
	 * @param productId
	 * @return
	 */
	@Query(value="select * from epc_product_specification where product_id=:product_id", nativeQuery=true)
	List<EpcProductSpecification> findByProductId(@Param("product_id") Integer productId);
	
	/**
	 * @param productShortCode
	 * @param productStatusOld
	 * @param productStatusNew
	 * @param modifiedBy
	 * @return
	 */
	@Modifying(clearAutomatically = true)
	@Query(value ="update epc_product_specification set product_status=:product_status_new, modified_by=:modified_by, modified_date=current_timestamp "
			+ "where product_short_code = :product_short_code and product_status=:product_status_old", nativeQuery=true)
	Integer ApprovalUpdateCount(@Param("product_short_code") String productShortCode,@Param("product_status_old") String productStatusOld,
			@Param("product_status_new") String productStatusNew, @Param("modified_by") String modifiedBy);
	
	/**
	 * @param productId
	 * @param productStatusNew
	 * @param modifiedBy
	 * @return
	 */
	@Modifying(clearAutomatically = true)
	@Query(value ="update epc_product_specification set product_status=:product_status_new, modified_by=:modified_by, modified_date=current_timestamp "
			+ "where product_id = :product_id ", nativeQuery=true)
	Integer ForceUpdateProductStatus(@Param("product_id") Integer productId,@Param("product_status_new") String productStatusNew, @Param("modified_by") String modifiedBy);
	
	
	/**
	 * @param productId
	 * @return
	 */
	@Query(value = "select other_product_id from epc_product_compatibility where product_id = :productId", nativeQuery =true)
	List<Integer> getIds(@Param("productId") Integer productId);
	
	/**
	 * @param productId
	 * @return
	 */
	@Query(value = "select product_short_code from epc_product_specification where product_id = :productId", nativeQuery =true)
	String getProductShortCodeByProductId(@Param("productId") Integer productId);
	
	/**
	 * @param productType
	 * @param prodCategory
	 * @return
	 */
	@Query(value="select product_id from epc_product_specification where product_type=:productType and product_category=:prodCategory "
					+" and product_id not in(select product_id from epc_product_community)", nativeQuery=true)
	List<String> getGlobalCorporateProductId(@Param("productType") String productType,@Param("prodCategory") String prodCategory);

	/**
	 * @param productShortCode
	 * @return
	 */
	@Query(value = "select product_id from epc_product_specification where product_short_code = :productShortCode", nativeQuery=true)
	String findByShortCode(@Param("productShortCode") String productShortCode);
	
	/**
	 * @param list
	 * @return
	 */
	@Query(value="select product_id,upload_id from epc_product_specification s, generic_file g where product_id in :listId "
			+ " and s.product_short_code =  substr(g.upload_id,1,instr(g.upload_id,'_testCase')-1) order by product_id, upload_id", nativeQuery=true)
	List<Object[]> getFileList(@Param("listId") List<Integer> list);


	List<EpcProductSpecification> findByProductShortCodeAndProductType(String productShortCode, String productType);
	
	@Query(value = "select product_id from epc_product_specification ", nativeQuery =true)
	String[] getProductId();
	
//	@Query(value="select distinct new com.wipro.epc.domain.EpcProductSpecification(e.productMarketingName) from EpcProductSpecification e ")
//	List<EpcProductSpecification> getMarketingNames();
	
//	@Query(value="select distinct product_marketing_name  from epc_product_specification e1,epc_product_community e2"
//			+ " where e2.community_name=:community_name and e1.product_id=e2.product_id", nativeQuery=true)
//	List<EpcProductSpecification> getMarketingNames(@Param("community_name") String communityName);
	
	
}
