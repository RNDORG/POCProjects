package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcTriggerOrderRule;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
public class EpcOrderTriggerRuleRepositoryImpl implements EpcOrderTriggerRuleRepositoryCustom{

	private static Logger logger =LoggerFactory.getLogger(EpcOrderTriggerRuleRepositoryImpl.class);
	
	
	@PersistenceContext
	EntityManager em; 
	
	/**
	 * 
	 */
	@Override
	public List<EpcTriggerOrderRule> getList(String query) {
		logger.debug("#Query: "+query);
		////System.out.println((List<EpcOrderTriggerRule>)em.createNativeQuery(query, EpcOrderTriggerRule.class).getResultList());
		return em.createNativeQuery(query, EpcTriggerOrderRule.class).getResultList();
	}

	/**
	 * Modifies the data in DB
	 */
	@Override
	public EpcTriggerOrderRule modifyOrderTriggerRule(EpcTriggerOrderRule OrderTriggerRule)
	{
			StringBuilder queryBuilder = new StringBuilder("update epc_trigger_order_rule set trigger_order_rule_id= "+OrderTriggerRule.getTriggerOrderRuleId());
			
			//Integer fields
			
			if(OrderTriggerRule.getSourceOrderType()!=null) {
				queryBuilder.append(",").append(" source_order_type = '").append(OrderTriggerRule.getSourceOrderType()).append("'"); 
			}
			if(OrderTriggerRule.getSourceProductClassification()!=null) {
				queryBuilder.append(",").append(" source_product_classification = '").append(OrderTriggerRule.getSourceProductClassification()).append("'");
			}
			if(OrderTriggerRule.getSourceProductSubFamily()!=null) {
				queryBuilder.append(",").append(" source_product_sub_family = '").append(OrderTriggerRule.getSourceProductSubFamily()).append("'");
			}
			if(OrderTriggerRule.getTriggeredOrderType()!=null) {
				queryBuilder.append(",").append(" triggered_order_type = '").append(OrderTriggerRule.getTriggeredOrderType()).append("'");
			}
			if(OrderTriggerRule.getTriggeredProductClassification()!=null){
				queryBuilder.append(",").append(" triggered_product_classification = '").append(OrderTriggerRule.getTriggeredProductClassification()).append("'");
			}
			if(OrderTriggerRule.getTriggeredProductSubFamily()!=null){
				queryBuilder.append(",").append(" triggered_product_sub_family = '").append(OrderTriggerRule.getTriggeredProductSubFamily()).append("'");
			}
			if(OrderTriggerRule.getRuleValidationDuration()!=null){
				queryBuilder.append(",").append(" rule_validation_duration = '").append(OrderTriggerRule.getRuleValidationDuration()).append("'");
			}
			if(OrderTriggerRule.getRuleValidationDurationUom()!=null){
				queryBuilder.append(",").append(" rule_validation_duration_uom = '").append(OrderTriggerRule.getRuleValidationDurationUom()).append("'");
			}
			if(OrderTriggerRule.getSubscriptionWithinDuration()!=null){
				queryBuilder.append(",").append(" subscription_within_duration = '").append(OrderTriggerRule.getSubscriptionWithinDuration()).append("'");
			}
			if(OrderTriggerRule.getSubscriptionWithinDurationUom()!=null){
				queryBuilder.append(",").append(" subscription_within_duration_uom = '").append(OrderTriggerRule.getSubscriptionWithinDurationUom()).append("'");
			}
			if(OrderTriggerRule.getStatus()!=null){
				queryBuilder.append(",").append(" status = '").append(OrderTriggerRule.getStatus()).append("'");
			}
			
			//String fields
			if(OrderTriggerRule.getSourceProductShortCode()!=null){
				queryBuilder.append(",").append(" source_product_short_code = '").append(OrderTriggerRule.getSourceProductShortCode()).append("'");
			}
			if(OrderTriggerRule.getTriggeredProductShortCode()!=null){
				queryBuilder.append(",").append(" triggered_product_short_code = '").append(OrderTriggerRule.getTriggeredProductShortCode()).append("'");
			}
			if(OrderTriggerRule.getCreatedBy()!=null){
				queryBuilder.append(",").append(" created_by = '").append(OrderTriggerRule.getCreatedBy()).append("'");
			}
			if(OrderTriggerRule.getModifiedBy()!=null){
				queryBuilder.append(",").append(" modified_by = '").append(OrderTriggerRule.getModifiedBy()).append("'");
			}
			
			//Date fields
			if(OrderTriggerRule.getCreatedDate()!=null){
				queryBuilder.append(",").append(" created_date = '").append(OrderTriggerRule.getCreatedDate()).append("'");
			}
			if(OrderTriggerRule.getModifiedDate()!=null){
				queryBuilder.append(",").append(" modified_date = '").append(OrderTriggerRule.getModifiedDate()).append("'");
			}
			
			
			queryBuilder.append(" where trigger_order_rule_id=").append(OrderTriggerRule.getTriggerOrderRuleId());
			String query = queryBuilder.toString();
			logger.debug("#Query: "+query);
			em.createNativeQuery(query).executeUpdate();
		return OrderTriggerRule;
	}

}
