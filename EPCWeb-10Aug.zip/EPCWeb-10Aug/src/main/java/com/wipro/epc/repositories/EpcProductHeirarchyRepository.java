package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.wipro.epc.domain.EpcProductHeirarchy;



/**
 * @author Developer
 * @version 1.0
 * type EpcProductHeirarchyRepository
 */
public interface EpcProductHeirarchyRepository extends CrudRepository<EpcProductHeirarchy, Integer>,EpcProductHeirarchyRepositoryCustom{
	
	/**
	 * @param ParentId
	 * @return
	 */
	List<EpcProductHeirarchy> findByParentProductId(Integer ParentId);	
	
}
