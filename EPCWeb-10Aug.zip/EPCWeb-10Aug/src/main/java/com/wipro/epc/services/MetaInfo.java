package com.wipro.epc.services;


/*import com.wipro.epc.repositories.AuthorityRepository;
import com.wipro.epc.repositories.FunctionRepository;
import com.wipro.epc.repositories.RoleRepository;
import com.wipro.epc.repositories.UserRoleMapRepository;
import com.wipro.epc.repositories.UsersRepository;

*/

/**
 * @author KE334465
 *
 */
public class MetaInfo {
	
	/**
	 * constant message for status
	 */
	public static final String STATUS = "STATUS";
	/**
	 * constant message for success
	 */
	public static final String SUCCESS = "SUCCESS";
	/**
	 * constant message for error
	 */
	public static final String ERROR = "ERROR";
	/**
	 * constant message for error_message
	 */
	public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
	
}
