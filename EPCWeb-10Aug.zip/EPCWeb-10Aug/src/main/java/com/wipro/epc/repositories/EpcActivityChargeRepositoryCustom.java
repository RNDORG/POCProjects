package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcActivityCharge;

/**
 * @author Developer
 * @version 1.0
 * type EpcActivityChargeRepositoryCustom
 */
public interface EpcActivityChargeRepositoryCustom {

	/**
	 * @param order
	 * @return
	 */
	EpcActivityCharge modifyOrder(EpcActivityCharge order);

	/**
	 * @param query
	 * @return
	 */
	List<EpcActivityCharge> getList(String query);
}
