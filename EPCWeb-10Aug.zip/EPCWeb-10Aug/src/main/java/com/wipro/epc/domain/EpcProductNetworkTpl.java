package com.wipro.epc.domain;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;



/**
 * The persistent class for the epc_product_network_tpl database table.
 * @author VI251443
 * @version 1.0
 * 
 */
@Entity
@Table(name="epc_product_network_tpl")
public class EpcProductNetworkTpl  implements Serializable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="network_template_id")
	private Integer networkTemplateId;

	@Column(name="access_service_id")
	private Integer accessServiceId;

	@Column(name="access_service_description")
	private String accessServiceDescription;
	
	@Column(name="access_service_name")
	private String accessServiceName;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="status")
	private String status;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;*/

/*	@Column(name="template_id")
	private String templateId;*/
	
	@Column(name="template_name")
	private String templateName;

	@Column(name="template_type")
	private String templateType;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusName;
*/
	/**
	 * @param networkTemplateId
	 * @param accessServiceId
	 * @param accessServiceDescription
	 * @param accessServiceName
	 * @param createDate
	 * @param createdBy
	 * @param modifiedBy
	 * @param modifyDate
	 * @param status
	 * @param templateName
	 * @param templateType
	 */
	/**
	 * @param networkTemplateId
	 * @param accessServiceId
	 * @param accessServiceDescription
	 * @param accessServiceName
	 * @param createDate
	 * @param createdBy
	 * @param modifiedBy
	 * @param modifyDate
	 * @param status
	 * @param templateName
	 * @param templateType
	 */
	private EpcProductNetworkTpl(Integer networkTemplateId,
			Integer accessServiceId, String accessServiceDescription,
			String accessServiceName, Date createDate, String createdBy,
			String modifiedBy, Date modifyDate, String status,
			String templateName, String templateType) {
		super();
		this.networkTemplateId = networkTemplateId;
		this.accessServiceId = accessServiceId;
		this.accessServiceDescription = accessServiceDescription;
		this.accessServiceName = accessServiceName;
		this.createdDate = createDate;
		this.createdBy = createdBy;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifyDate;
		this.status = status;
		//this.templateId = templateId;
		this.templateName = templateName;
		this.templateType = templateType;
	}

	
	/**
	 * 
	 */
	public EpcProductNetworkTpl() {
	}


	/**
	 * @param templateName
	 */
	public EpcProductNetworkTpl( String templateName) {
		super();
		//this.templateId = templateId;
		this.templateName = templateName;
	}
	/**
	 * @return
	 */
	public Integer getNetworkTemplateId() {
		return this.networkTemplateId;
	}

	/**
	 * @param networkTemplateId
	 */
	public void setNetworkTemplateId(Integer networkTemplateId) {
		this.networkTemplateId = networkTemplateId;
	}

	/**
	 * @return
	 */
	public Integer getAccessServiceId() {
		return this.accessServiceId;
	}

	/**
	 * @param accessServiceId
	 */
	public void setAccessServiceId(Integer accessServiceId) {
		this.accessServiceId = accessServiceId;
	}

	/**
	 * @return
	 */
	public String getAccessServiceName() {
		return this.accessServiceName;
	}

	/**
	 * @param accessServiceName
	 */
	public void setAccessServiceName(String accessServiceName) {
		this.accessServiceName = accessServiceName;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	public Date getModifyDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifyDate
	 */
	public void setModifyDate(Date modifyDate) {
		this.modifiedDate = modifyDate;
	}

	/**
	 * @return
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

/*	public String getTemplateId() {
		return this.templateId;
	}
*/

/*	public String getStatusName() {
		this.statusName = status;
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
*/
	/**
	 * @return
	 */
	public String getTemplateType() {
		return this.templateType;
	}

	/**
	 * @param templateType
	 */
	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}
	/**
	 * @return
	 */
	public String getAccessServiceDescription() {
		return accessServiceDescription;
	}

	/**
	 * @param accessServiceDescription
	 */
	public void setAccessServiceDescription(String accessServiceDescription) {
		this.accessServiceDescription = accessServiceDescription;
	}

/*	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}
	*/
	

}