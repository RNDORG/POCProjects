package com.wipro.epc.dto;

import java.lang.reflect.Field;


/**
 * @author KE334465
 *
 */
public class ComplexSearchInputForMigration extends  ComplexSearchInput{
	
	 private String targetProductCategory;
	 private String targetProductSubCategory;
	 private String targetCommunityId;
	 
	/**
	 * @return
	 */
	public String getTargetProductCategory() {
		return targetProductCategory;
	}
	/**
	 * @param targetProductCategory
	 */
	public void setTargetProductCategory(String targetProductCategory) {
		this.targetProductCategory = targetProductCategory;
	}
	/**
	 * @return
	 */
	public String getTargetProductSubCategory() {
		return targetProductSubCategory;
	}
	/**
	 * @param targetProductSubCategory
	 */
	public void setTargetProductSubCategory(String targetProductSubCategory) {
		this.targetProductSubCategory = targetProductSubCategory;
	}
	/**
	 * @return
	 */
	public String getTargetCommunityId() {
		return targetCommunityId;
	}
	/**
	 * @param targetCommunityId
	 */
	public void setTargetCommunityId(String targetCommunityId) {
		this.targetCommunityId = targetCommunityId;
	}
	/**
	 * @return
	 * @throws IllegalAccessException
	 * this method has been intentionally overridden to avoid error saying private modifiers from this class can't be accessed from the parent class.
	 */
	@Override
	public boolean checkNull() throws IllegalAccessException {
	    for (Field f : getClass().getDeclaredFields()) {
	        if (f.get(this) != null) {
	            return false;
	        }
	    }
	    return true;            
	}
	 
	
		
	
}
