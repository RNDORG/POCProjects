package com.wipro.epc.domain;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the epc_location database table.
 * @author VI251443 
 * @version 1.0
 */
@Entity
@Table(name="broadcast_logs")
public class BroadcastLogs implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	@GeneratedValue
	private Integer id;
	
	@Column(name="url")
	private String url;

	@Lob
	@Column(name="response")
	private String response;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "broadcast_timestamp", length = 7)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss")
	private Date broadcastTimestamp;

	@Column(name="broadcasted_from")
	private String broadcastedFrom;

	

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Date getBroadcastTimestamp() {
		return broadcastTimestamp;
	}

	public void setBroadcastTimestamp(Date broadcastTimestamp) {
		this.broadcastTimestamp = broadcastTimestamp;
	}

	public String getBroadcastedFrom() {
		return broadcastedFrom;
	}

	public void setBroadcastedFrom(String broadcastedFrom) {
		this.broadcastedFrom = broadcastedFrom;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	

}