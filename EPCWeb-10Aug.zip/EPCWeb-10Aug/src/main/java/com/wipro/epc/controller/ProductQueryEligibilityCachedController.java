package com.wipro.epc.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.dto.QueryEligibilityResponse;
import com.wipro.epc.dto.QueryEligibiltySearchInput;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.ProductQueryEligibiltyCachedService;



/**
 * @author Developer
 * @version 1.0
 * type ProductQueryEligibilityCachedController
 */
@RestController
public class ProductQueryEligibilityCachedController {

	/**
	 * ProductQueryEligibiltyCachedService ProductQueryEligibilityCachedController.java
	 */
	
	private static Logger logger = LoggerFactory.getLogger(ProductQueryEligibilityCachedController.class);
	
	
	@Autowired
	ProductQueryEligibiltyCachedService queryEligibiltyService;
	

	/**
	 * TransactionsService ProductQueryEligibilityCachedController.java
	 */
	@Autowired
	TransactionsService transactionsLogging ;

	/**
	 * ObjectMapper ProductQueryEligibilityCachedController.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * TransactionStore ProductQueryEligibilityCachedController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/queryEligibility", method=RequestMethod.POST)
	public QueryEligibilityResponse checkEligibilityExt(@RequestBody QueryEligibiltySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		Long startTime = System.currentTimeMillis();
		String txnType="queryEligibility";
		String request=null;
		QueryEligibilityResponse response=null;
		try{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, searchInput);
		response=queryEligibiltyService.checkEligibility(searchInput,allRequestParams);
		}
		 catch (Exception e ) {
				logger.error("#interfaceException: " + e.getMessage());
				throw new EPCException(e.getMessage());
			}
		finally{
			Long endTime = System.currentTimeMillis();
			logger.info("#rTime|" + startTime +  "|" + endTime + "|"  + (endTime-startTime) );   
			ePCTxnInterceptor.postTxn(txnType, request,response);
		
		}
		return response;
		
	}
	
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/queryEligibility", method=RequestMethod.POST)
	public QueryEligibilityResponse checkEligibility(@RequestBody QueryEligibiltySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		return queryEligibiltyService.checkEligibility(searchInput,allRequestParams);
	}
	
	@RequestMapping(value="/rest/extapi/v1/queryEligibilityStatic", method=RequestMethod.POST)
	public String checkEligibilityStatic(@RequestBody QueryEligibiltySearchInput searchInput,@RequestParam MultiValueMap allRequestParams) throws IOException
	{
		 return queryEligibiltyService.checkEligibilityStatic(searchInput, allRequestParams);
		 
	}
	
}
