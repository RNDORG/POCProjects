package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.epc.domain.EpcLocation;
import com.wipro.epc.repositories.EpcLocatoionRepository;

/**
 * @author Developer
 * @version 1.0
 * type EpcLocationService
 */
@Service
public class EpcLocationService {
	
	/**
	 * EpcLocatoionRepository EpcLocationService.java
	 */
	@Autowired
	EpcLocatoionRepository epcLocatoionRepository;
	
	/**
	 * List<EpcLocation> EpcLocationService.java
	 */
	List<EpcLocation> epcLocationCache;
	
	/**
	 * 
	 */
	public void loadCache() {
		epcLocationCache = epcLocatoionRepository.getAllLocations();
	}
	
	
	/**
	 * @param value
	 * @return
	 */
	public String getLocationId(String value) {
		if (epcLocationCache == null) {
			loadCache();
		}
		for (EpcLocation epcLocation : epcLocationCache) {
			if (epcLocation != null
					&& epcLocation.getLocationName().equals(value)) {
				return String.valueOf(epcLocation.getLocationId());
			}
		}
		return "9999999999";
	}
	
	/**
	 * @param id
	 * @return
	 */
	public String getLocationName(Integer id) {
		if (epcLocationCache == null) {
			loadCache();
		}
		for (EpcLocation epcLocation : epcLocationCache) {
			if (epcLocation != null
					&& epcLocation.getLocationId().equals(id)) {
				return epcLocation.getLocationName();
			}
		}
		return null;
	}
	
	/**
	 * @return
	 */
	public 	List<EpcLocation> getLocationList(){
		if (epcLocationCache == null) {
			loadCache();
		}
		return epcLocationCache;
	}
	
	/**
	 * @param id
	 * @return
	 */
	public List<EpcLocation> locationsForCorrespdingIds(String id){
		if (epcLocationCache == null) {
			loadCache();
		}
		List<EpcLocation> returnList = new ArrayList<EpcLocation>();
		for(EpcLocation epcLocation : epcLocationCache){
			if(epcLocation.getLocationType().equals(id))
				returnList.add(epcLocation);
		}
		return returnList;
	}
}
