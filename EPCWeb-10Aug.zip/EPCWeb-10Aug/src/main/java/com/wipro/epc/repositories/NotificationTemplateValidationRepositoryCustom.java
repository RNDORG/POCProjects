package com.wipro.epc.repositories;

/**
 * 
 * @author KE334465
 *
 */
public interface NotificationTemplateValidationRepositoryCustom {
	
	/**
	 * given a template name, gives it's count in the table notification template validation
	 * @param templateName
	 * @return
	 */
	int validateTemplateName(String templateName);

}
