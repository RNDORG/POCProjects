package com.wipro.epc.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Developer
 * @version 1.0
 * type DatabaseController
 */
@RestController
public class DatabaseController {
	
	/**
	 * String DatabaseController.java
	 */
	@Value("${spring.profiles.active}")
	private String profile; 
	
	/**
	 * String DatabaseController.java
	 */
	@Value("${spring.datasource.jndi-name:NA}")
	private String jndiName;
	
	/**
	 * String DatabaseController.java
	 */
	@Value("${spring.datasource.url:NA}")
	private String dbUrl;
	
	/**
	 * String DatabaseController.java
	 */
	@Value("${spring.datasource.username:NA}")
	private String dbUser;
	
	//@Value("${is_spring_boot_app:NA}")
	/**
	 * String DatabaseController.java
	 */
	private String dbConsoleUrl;
	
	/**
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/database", method=RequestMethod.GET)
	public Map<String, String> DatabaseController() {
		
		/*boolean dbProfile = false;
		if ("jndi".equalsIgnoreCase(profile)) {
			jndiFlag = true;
		}*/
		if ("nonjndi-h2".equals(profile)) {
			dbConsoleUrl="true";
		} else {
			dbConsoleUrl="false";
		}
		
		Map<String, String> res = new HashMap<String, String>();
		res.put("dbProfile",String.valueOf(profile));
		res.put("jndiName",jndiName);
		res.put("dbUrl",dbUrl);
		res.put("dbUser",dbUser);
		res.put("dbConsoleUrl", dbConsoleUrl); 
		
		return res;
	
	}
	
	
}

