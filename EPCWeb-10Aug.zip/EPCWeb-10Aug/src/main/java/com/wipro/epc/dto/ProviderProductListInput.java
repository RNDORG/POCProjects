package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type ProviderProductListInput
 */
public class ProviderProductListInput {

	/**
	 * String ProviderProductListInput.java
	 */
	private String providerProductId;
	/**
	 * String ProviderProductListInput.java
	 */
	private String providerSystem;
	
	
	/**
	 * @return
	 */
	public String getProviderProductId() {
		return providerProductId;
	}
	/**
	 * @param providerProductId
	 */
	public void setProviderProductId(String providerProductId) {
		this.providerProductId = providerProductId;
	}
	/**
	 * @return
	 */
	public String getProviderSystem() {
		return providerSystem;
	}
	/**
	 * @param providerSystem
	 */
	public void setProviderSystem(String providerSystem) {
		this.providerSystem = providerSystem;
	}
}
