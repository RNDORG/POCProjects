package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductNetworkTplMap;
/**
 * 
 * @author KE334465
 *
 */
public interface EpcProductNetworkTplMapRepositoryCustom {
	/**
	 * Modifies the network template map table with new networkMap
	 * @param networkMap
	 */
	
	void modifyNetworkId(EpcProductNetworkTplMap networkMap);
	
	/**
	 * Given a query it executes and gets the list of networktplmap's
	 * @param query
	 * @return
	 */
	List<EpcProductNetworkTplMap> getNetworkTemplateMapList(String query);

}
