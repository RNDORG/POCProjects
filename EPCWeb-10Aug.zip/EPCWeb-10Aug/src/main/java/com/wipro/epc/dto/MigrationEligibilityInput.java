package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type MigrationEligibilityInput
 */
public class MigrationEligibilityInput {

	/**
	 * String MigrationEligibilityInput.java
	 */
	private String providerProductId;
	/**
	 * String MigrationEligibilityInput.java
	 */
	private String providerSystem;
	/**
	 * String MigrationEligibilityInput.java
	 */
	private String targetPrimaryProduct;
	/**
	 * String MigrationEligibilityInput.java
	 */
	private String initiatingChannel;
	/**
	 * String MigrationEligibilityInput.java
	 */
	private String actionType;
	
	/**
	 * @return
	 */
	public String getProviderProductId() {
		return providerProductId;
	}
	/**
	 * @param providerProductId
	 */
	public void setProviderProductId(String providerProductId) {
		this.providerProductId = providerProductId;
	}
	/**
	 * @return
	 */
	public String getProviderSystem() {
		return providerSystem;
	}
	/**
	 * @param providerSystem
	 */
	public void setProviderSystem(String providerSystem) {
		this.providerSystem = providerSystem;
	}
	/**
	 * @return
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return
	 */
	public String getTargetPrimaryProduct() {
		return targetPrimaryProduct;
	}
	/**
	 * @param targetPrimaryProduct
	 */
	public void setTargetPrimaryProduct(String targetPrimaryProduct) {
		this.targetPrimaryProduct = targetPrimaryProduct;
	}
	/**
	 * @return
	 */
	public String getInitiatingChannel() {
		return initiatingChannel;
	}
	/**
	 * @param initiatingChannel
	 */
	public void setInitiatingChannel(String initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}

}
