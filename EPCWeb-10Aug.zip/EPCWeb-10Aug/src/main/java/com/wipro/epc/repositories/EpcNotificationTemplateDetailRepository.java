/**
 * 
 */
package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcNotificationTemplateDetail;

@Repository
public interface EpcNotificationTemplateDetailRepository extends CrudRepository<EpcNotificationTemplateDetail, Integer>,EpcNotificationTemplateDetailRepositoryCustom {
	
	/**
	 * @param notificationTemplateId
	 */
	@Modifying
	@Query(value="delete from epc_notification_template_detail where notification_template_id=:notificationTemplateId", nativeQuery=true)
	void deleteNetworkTemplateFromDetail(@Param("notificationTemplateId") Integer notificationTemplateId);
	

	 /**
	 * @param notificationTemplateId
	 * @param templateLanguage
	 * @param status
	 * @return
	 */
	List<EpcNotificationTemplateDetail> findByNotificationTemplateIdAndTemplateLanguageAndStatus(Integer notificationTemplateId, String templateLanguage, String status);
	 
	 /**
	 * @param notificationTemplateId
	 * @return
	 */
	@Query(value = "select * from epc_notification_template_detail where notification_template_id = :notificationTemplateId", nativeQuery = true)
	 List<EpcNotificationTemplateDetail> getByNotificationTemplateId(@Param("notificationTemplateId") Integer notificationTemplateId);
	
	 /**
	 * @param notificationTemplateId
	 * @param templateLanguage
	 * @return
	 */
	EpcNotificationTemplateDetail findByNotificationTemplateIdAndTemplateLanguage(Integer notificationTemplateId,String templateLanguage );
	 
	 /**
	 * @param notificationTemplateId
	 * @return
	 */
	List<EpcNotificationTemplateDetail> findByNotificationTemplateId(Integer notificationTemplateId );

}
