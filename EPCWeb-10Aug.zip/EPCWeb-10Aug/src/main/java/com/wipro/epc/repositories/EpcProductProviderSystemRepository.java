package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductProviderSystem;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductProviderSystemRepository
 */
public interface EpcProductProviderSystemRepository extends CrudRepository<EpcProductProviderSystem, Integer>, 
EpcProductProviderSystemRepositoryCustom{


	/**
	 * @param productId
	 * @return
	 */
	@Query(value="select * from epc_product_provider_system where product_id=:productId", nativeQuery = true)
	List<EpcProductProviderSystem> findProvidersByProductId(@Param("productId") Integer productId);
	
	/**
	 * @param productId
	 */
	@Modifying
	@Query(value="delete from epc_product_provider_system where product_id=:productId", nativeQuery=true)
	void deleteProductFromProviders(@Param("productId") Integer productId);
}
