package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductMigration;
import com.wipro.epc.domain.EpcProductProviderSystem;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.MigrationEligibilityInput;
import com.wipro.epc.dto.MigrationEligibilityResponse;
import com.wipro.epc.util.Constants;


/**
 * @author Developer
 * @version 1.0
 * type MigrationEligibilityService
 */
@Service
public class MigrationEligibilityService {
	private static Logger logger = LoggerFactory.getLogger(MigrationEligibilityService.class);
	/**
	 * EpcProductMigrationService MigrationEligibilityService.java
	 */
	@Autowired
	EpcProductMigrationService epcproductMigrationService;

	/**
	 * EpcProductSpecificationService MigrationEligibilityService.java
	 */
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;

	/**
	 * EpcAttributeMasterService MigrationEligibilityService.java
	 */
	@Autowired
	EpcAttributeMasterService epcAttributeMasterService;
	
	/**
	 * EpcProductProviderSystemService MigrationEligibilityService.java
	 */
	@Autowired
	EpcProductProviderSystemService epcProductProviderSystemService;
	
	/**
	 * ComplexSearchInputService MigrationEligibilityService.java
	 */
	@Autowired
	ComplexSearchInputService complexSearchInputService;
	
	@Autowired
	MCachedProductService mCachedProductService;
	/**
	 * @param queryInput
EpcProductSpecification
	 * @return
	 */
	public MigrationEligibilityResponse checkMigrationEligibility(MigrationEligibilityInput queryInput, Map<String, List<String>> allRequestParams) {
		
		MigrationEligibilityResponse response = new MigrationEligibilityResponse();
		
		if(StringUtils.isBlank(queryInput.getInitiatingChannel()) || StringUtils.isBlank(queryInput.getProviderProductId()) || StringUtils.isBlank(queryInput.getProviderSystem())|| StringUtils.isBlank(queryInput.getTargetPrimaryProduct()) || StringUtils.isBlank(queryInput.getActionType())){
			//throw new GenericException("InvalidSearch", "Mandatory Fields are missing. Please provide all mandatory fields (initChannel, providerProductId, providerSystem, targetPrimaryProduct, actionType)", "Mandatory Fields are missing.");
			response.setRemarks("Mandatory Fields are missing. Please provide all mandatory fields (initChannel, providerProductId, providerSystem, targetPrimaryProduct, actionType)");
			response.setStatus("FAILURE");
			return response;
		}
		
		
		List<String> withs = allRequestParams.get("with");
		List<String> supportedWith = Arrays.asList(new String []{"characteristic", "tariff", "provider", "notification"});
		if(withs != null && !withs.isEmpty()){
			for(String str : withs){
				if(!supportedWith.contains(str)){
					if(!(str.contains("ta-") || str.contains("nta-") ) ){
						//throw new GenericException("UnsupportedWith", "Unsupported with parameter ("+ str +") provided.", "Unsupported with parameter ("+ str +") provided.");
						response.setRemarks("Unsupported with parameter ("+ str +") provided.");
						response.setStatus("FAILURE");
						return response;
					}
				}
			}
		}
		String initChannel = queryInput.getInitiatingChannel().equals(Constants.INITCHANNEL_CRM) ? Constants.INITCHANNEL_CRM : Constants.INITCHANNEL_OMNI;
		Integer sourceProdId = fetchPrimaryProductId(queryInput.getProviderProductId(), queryInput.getProviderSystem());
		logger.info("Source Product Id:>>"+sourceProdId);
		if(sourceProdId == null){
			//throw new GenericException("InvalidSearch", "The given providerProductId/providerSystem combination is not a valid one.", "Invalid providerProductId/providerSystem.");
			response.setRemarks("The given providerProductId/providerSystem combination is not a valid one.");
			response.setStatus("FAILURE");
			return response;
		}
		Map<String, List<String>> sourceRatePlanParams = new HashMap<String, List<String>>();
		sourceRatePlanParams.put("productId", Arrays.asList(new  String[]{String.valueOf(sourceProdId)}));
		//EpcProductSpecification srcRatePlan = epcProductSpecificationService.getBasicProductSpecByID(sourceRatePlanParams).get(0);
		
		Map<String, List<String>> basicRequestParams = new HashMap<String, List<String>>();
		basicRequestParams.put("productShortCode", Arrays.asList(new  String[]{queryInput.getTargetPrimaryProduct()}));
		List<EpcProductSpecification> listOfProductsReturned = epcProductSpecificationService.getBasicProductSpecByID(basicRequestParams);
		Integer targetProdId = null;
		if(listOfProductsReturned != null && listOfProductsReturned.size() == 1 && Constants.PRODUCT_STATUS_LAUNCH.equals(listOfProductsReturned.get(0).getProductStatus())){
			targetProdId = listOfProductsReturned.get(0).getProductId();
		}else{
			//throw new GenericException("InvalidSearch", "The given targetPrimaryProduct is not a valid one.", "Invalid targetPrimaryProduct.");
			response.setRemarks("The given targetPrimaryProduct is not a valid one.");
			response.setStatus("FAILURE");
			return response;
		}
		logger.info("Target Product Id:>>"+targetProdId);
		
		if(sourceProdId.equals(targetProdId)) {
			//throw new GenericException("MigrationEligibilityFailed", "The source and target rate-plans can not be same", "Migration Eligibility failed..");
			response.setRemarks("The source and target rate-plans can not be same");
			response.setStatus("FAILURE");
			return response;
		}
		
		EpcProductSpecification srcRatePlan = null;
		EpcProductSpecification targetRatePlan = null;
		String [] ids = {String.valueOf(sourceProdId), String.valueOf(targetProdId)};
		List<EpcProductSpecification> allProds = mCachedProductService.find(ids );
		for(EpcProductSpecification prod : allProds){
			if(sourceProdId.equals(prod.getProductId())){
				srcRatePlan = prod;
			}
			if(targetProdId.equals(prod.getProductId())){
				targetRatePlan = prod;
			}
		}
		
		if(!Constants.PRODUCT_STATUS_LAUNCH.equals(srcRatePlan.getProductStatus())){
			//throw new GenericException("InvalidSearch", "The source product is not in Launch status.", "Invalid source product status.");
			response.setRemarks("The source product is not in Launch status.");
			response.setStatus("FAILURE");
			return response;
		}
		String scValue = null;
		if(srcRatePlan.getEpcProductCharacteristic() != null && srcRatePlan.getEpcProductCharacteristic().size() >0 ){
			for(EpcProductAttribute attr : srcRatePlan.getEpcProductCharacteristic()){
				if(Constants.RECONNECTION_SC.equals(attr.getEpcAttributeMaster().getAttributeName())){
					scValue = attr.getAttributeValue1();
					break;
				}
			}
		}
		if(StringUtils.isNotBlank(scValue)){
			String providerProductId = null;
			if (targetRatePlan.getEpcProductProvider()!=null && targetRatePlan.getEpcProductProvider().size() > 0){
				for(EpcProductProviderSystem providerSystem : targetRatePlan.getEpcProductProvider()){
					if(providerSystem != null && providerSystem.getIsPrimaryProvider() != null &&  providerSystem.getIsPrimaryProvider() == 1) {
						providerProductId = providerSystem.getProviderProductId();
						break;
					}					
				}
			}
			if ( scValue.equals(providerProductId)) {
				response.setRemarks("The source and target rate-plans can not be same");
				response.setStatus("FAILURE");
				return response;
			}
		}
		basicRequestParams = new HashMap<String, List<String>>();
		basicRequestParams.put("sourceProductId", Arrays.asList(new  String[]{String.valueOf(sourceProdId)}));
		basicRequestParams.put("targetProductId", Arrays.asList(new  String[]{String.valueOf(targetProdId)}));
		List<EpcProductMigration> migrations =epcproductMigrationService.searchEpcProductMigration(basicRequestParams);
		boolean isMigrattable = false;
		if(migrations != null && !migrations.isEmpty()){
			for(EpcProductMigration  migration : migrations){
				if(Constants.MIGRATION_INCLUSIVEOREXCLUSIVE_INCLUSION.equals(migration.getInclusiveOrExclusive()) && (migration.getMigrationChannel() != null && initChannel.equalsIgnoreCase(migration.getMigrationChannel()))){
					isMigrattable = true;
					break;
				}
			}
		}
		if(!isMigrattable){
			//throw new GenericException("MigrationEligibilityFailed", "The given providerProductId/providerSystem can not be migrated to the given targetPrimaryProduct.", "Migration Eligibility failed..");
			response.setRemarks("The given providerProductId/providerSystem can not be migrated to the given targetPrimaryProduct.");
			response.setStatus("FAILURE");
			return response;
		}
		
		allRequestParams.put("productShortCode", Arrays.asList(new  String[]{queryInput.getTargetPrimaryProduct()}));
		
		if(withs == null){
			withs = new ArrayList<String>();
		}
		withs.add("initiatingChannel");
		allRequestParams.put("with", withs);
		List<EpcProductSpecification> products = complexSearchInputService.searchProducts(allRequestParams, null, true);
		
		EpcProductSpecification  epcProductSpecification = products.get(0);
		if(epcProductSpecification.getEpcProductInitChannel() != null && epcProductSpecification.getEpcProductInitChannel().size() >0){
			for( Iterator<EpcProductInitChannel> iterator = epcProductSpecification.getEpcProductInitChannel().iterator(); iterator.hasNext();  ){
				EpcProductInitChannel epcProductInitChannel = iterator.next();
				if(queryInput.getInitiatingChannel().equals(epcProductInitChannel.getChannelId()) && queryInput.getActionType().equals(epcProductInitChannel.getActionType())){
					epcProductSpecification.setChannelMarketingName(epcProductInitChannel.getChannelLevelMarketName());
					if(!withs.contains("notification") || (withs.contains("notification") && epcProductInitChannel.getEpcNotificationTemplate() == null)){
						iterator.remove();
					}
				}else{
					iterator.remove();
				}
			}
		}
		response.setProductSpecification(epcProductSpecification);
		return response; 
	}
	
	/**
	 * @param providerProductId
	 * @param providerSystem
	 * @return
	 */
	private Integer fetchPrimaryProductId(
			String providerProductId, String providerSystem) {
		MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
		criteria.add("providerProductId", providerProductId);
		criteria.add("providerSystemCode", providerSystem);
		List<EpcProductProviderSystem> epcProdProviders = epcProductProviderSystemService.searchProvider(criteria);
		Integer prodId = null;
		if (epcProdProviders != null && epcProdProviders.size() == 1 ){
			prodId = epcProdProviders.get(0).getProductId();
		}
		return prodId;
	}
}
