package com.wipro.epc.domain;



//import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


/**
 * The persistent class for the epc_product_init_channel database table.
 * @author VI251443
 * @version 1.0
 * 
 */
@Entity
@Table(name="epc_product_init_channel")
public class EpcProductInitChannel  implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_init_channel_id")
	private Integer productInitChannelId;

	@Column(name="action_type")
	private String actionType;
/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String actionTypeValue;
*/
	@Column(name="alias")
	private String alias;

	@Column(name="channel_id")
	private String channelId;
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String channelIdValue;*/
	 
	@Column(name="channel_level_product_id")
	private String channelLevelProductId;

	@Column(name="channel_level_market_name")
	private String channelLevelMarketName;

	@Column(name="channel_short_code")
	private String channelShortCode;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;

	@Column(name="is_notification_required",columnDefinition = "bit")
	private Byte isNotificationRequired;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;

	@Column(name="notification_template_id")
	private Integer notificationTemplateId;

	@Column(name="product_id")
	private Integer productId;

	@Column(name="service_keyword")
	private String serviceKeyword;

	@Column(name="service_keyword_other")
	private String serviceKeywordOther;
	
	@Column(name="status")
	private String status;
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;
*/
	@Column(name="url_string")
	private String urlString;

	@Transient
	private Map<String,String> metaInfo;	
	
	@Transient
	private EpcNotificationTemplate epcNotificationTemplate;
	
	public EpcProductInitChannel() {
	}
	
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}

	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}
	
	

	public Integer getProductInitChannelId() {
		return this.productInitChannelId;
	}

	public void setProductInitChannelId(Integer productInitChannelId) {
		this.productInitChannelId = productInitChannelId;
	}

	public String getActionType() {
		return this.actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getAlias() {
		return this.alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getChannelId() {
		return this.channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getChannelLevelMarketName() {
		return this.channelLevelMarketName;
	}

	public void setChannelLevelMarketName(String channelLevelMarketName) {
		this.channelLevelMarketName = channelLevelMarketName;
	}

	public String getChannelShortCode() {
		return this.channelShortCode;
	}

	public void setChannelShortCode(String channelShortCode) {
		this.channelShortCode = channelShortCode;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Byte getIsNotificationRequired() {
		return this.isNotificationRequired;
	}

	public void setIsNotificationRequired(Byte isNotificationRequired) {
		this.isNotificationRequired = isNotificationRequired;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getNotificationTemplateId() {
		return this.notificationTemplateId;
	}

	public void setNotificationTemplateId(Integer notificationTemplateId) {
		this.notificationTemplateId = notificationTemplateId;
	}

	public Integer getProductId() {
		return this.productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getServiceKeyword() {
		return this.serviceKeyword;
	}

	public void setServiceKeyword(String serviceKeyword) {
		this.serviceKeyword = serviceKeyword;
	}

	public String getServiceKeywordOther() {
		return this.serviceKeywordOther;
	}

	public void setServiceKeywordOther(String serviceKeywordOther) {
		this.serviceKeywordOther = serviceKeywordOther;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUrlString() {
		return this.urlString;
	}

	public void setUrlString(String urlString) {
		this.urlString = urlString;
	}
	
	public String getChannelLevelProductId() {
		return channelLevelProductId;
	}

	public void setChannelLevelProductId(String channelLevelProductId) {
		this.channelLevelProductId = channelLevelProductId;
	}
	public EpcNotificationTemplate getEpcNotificationTemplate() {
		return epcNotificationTemplate;
	}

	public void setEpcNotificationTemplate(
			EpcNotificationTemplate epcNotificationTemplate) {
		this.epcNotificationTemplate = epcNotificationTemplate;
	}
	

	@Override
	public String toString() {
		return "EpcProductInitChannel [productInitChannelId="
				+ productInitChannelId + ", actionType=" + actionType
				+ ", alias=" + alias
				+ ", channelId=" + channelId + ", channelLevelProductId="
				+ channelLevelProductId + ", channelLevelMarketName="
				+ channelLevelMarketName + ", channelShortCode="
				+ channelShortCode + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", isNotificationRequired="
				+ isNotificationRequired + ", modifiedBy=" + modifiedBy
				+ ", modifiedDate=" + modifiedDate
				+ ", notificationTemplateId=" + notificationTemplateId
				+ ", productId=" + productId + ", serviceKeyword="
				+ serviceKeyword + ", serviceKeywordOther="
				+ serviceKeywordOther + ", status=" + status  
				+  ", urlString=" + urlString + "]";
	}




	/*public String getActionTypeValue() {
		this.actionTypeValue = actionType;
		return actionTypeValue;
	}

	public void setActionTypeValue(String actionTypeValue) {
		this.actionTypeValue = actionTypeValue;
	}

	public String getChannelIdValue() {
		this.channelIdValue = channelId;
		return channelIdValue;
	}

	public void setChannelIdValue(String channelIdValue) {
		this.channelIdValue = channelIdValue;
	}

	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}*/

	
	
	

}