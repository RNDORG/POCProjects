package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.domain.EpcProductProviderSystem;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.CorporatesAssociatedResponse;
import com.wipro.epc.services.EpcProductCommunityService;
import com.wipro.epc.services.EpcProductProviderSystemService;
import com.wipro.epc.services.EpcProductSpecificationService;

/**
 * 
 * @author VI251443
 * @version 1.0
 */

@RestController
public class EpcProductCommunityController {

	@Autowired
	EpcProductCommunityService epcProductCommunityService;
	
	@Autowired
	EpcProductProviderSystemService epcProductProviderService;
	
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	/**
	 * 
	 * @param productCommunityList
	 * @return List<EpcProductCommunity> 
	 */ 
	@RequestMapping(value="rest/extapi/v1/community",method=RequestMethod.POST)
	public List<EpcProductCommunity> updateProductCommunityExt(@RequestBody List<EpcProductCommunity> productCommunityList)
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		return epcProductCommunityService.updateProductCommunity(productCommunityList, user);
	}
	
	/**
	 * 
	 * @param allRequestParams
	 * @return List<EpcProductCommunity>
	 */
	@RequestMapping(value="rest/extapi/v1/community", method=RequestMethod.GET)
	public List<EpcProductCommunity> searchProductCommunityExt(@RequestParam MultiValueMap allRequestParams)
	{
 			return epcProductCommunityService.searchProductCommunity(allRequestParams);
	}
	
	/**
	 *
	 * @param productCommunityList
	 * @return List<EpcProductCommunity> 
	 */
	@RequestMapping(value="rest/api/v1/community",method=RequestMethod.POST)
	public List<EpcProductCommunity> updateProductCommunity(@RequestBody List<EpcProductCommunity> productCommunityList)
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		return epcProductCommunityService.updateProductCommunity(productCommunityList, user);
	}
	
	/**
	 * 
	 * @param communityName
	 * @param marketingName
	 * @param productType
	 * @return List<EpcProductSpecification>
	 */
	@RequestMapping(value="rest/api/v1/communityUI",method=RequestMethod.GET)
	public List<EpcProductSpecification> getResultsForUI(@RequestParam String communityName, @RequestParam(required=false) String marketingName, @RequestParam(required=false) String productType)
	{
		return epcProductCommunityService.getResultsForUI(communityName, marketingName, productType);
	}
	
	/**
	 * 
	 * @param allRequestParams
	 * @return List<EpcProductCommunity>
	 */
	@RequestMapping(value="rest/api/v1/community", method=RequestMethod.GET)
	public List<EpcProductCommunity> searchProductCommunity(@RequestParam MultiValueMap allRequestParams)
	{
 			return epcProductCommunityService.searchProductCommunity(allRequestParams);
	}
	
	/**
	 * 
	 * @return List<EpcProductCommunity>
	 */
	@RequestMapping(value="rest/api/v1/communityNames" , method=RequestMethod.GET)
	public List<EpcProductCommunity> getCommunityNames()
	{
				return epcProductCommunityService.getCommunityNames();
	}
	
	// code for corporate section 
	@RequestMapping(value="rest/api/v1/corporateUI",method=RequestMethod.GET)
	public List<CorporatesAssociatedResponse> getCorporates(@RequestParam String corporateName, @RequestParam(required=false) String corporateId, @RequestParam String corporateShortCode)
	{
		return epcProductCommunityService.getCorporates(corporateName, corporateId, corporateShortCode);
	}
	
	@RequestMapping(value="rest/api/v1/corporateUIVIDProductsFetch",method=RequestMethod.GET)
	public List<CorporatesAssociatedResponse> getGlobalPoolProductsVID(@RequestParam(required=false) String productType, @RequestParam(required=false) String productId,
																@RequestParam(required=false) String productClassification, @RequestParam(required=false, defaultValue="false") Boolean isUsageProducts,
																@RequestParam(required=false) String productSubFamily)
	{
		
		return epcProductCommunityService.getGlobalPoolProducts(productType, productId, productClassification, isUsageProducts, productSubFamily);
	}
	
	
	@RequestMapping(value="rest/api/v1/corporateUIProductsFetch",method=RequestMethod.GET)
	public List<CorporatesAssociatedResponse> getGlobalPoolProducts(@RequestParam(required=false) String productType, @RequestParam(required=false) String productId,
																@RequestParam(required=false) String productClassification, @RequestParam(required=false, defaultValue="false") Boolean isUsageProducts,
																@RequestParam(required=false) String productSubFamily)
	{
		return epcProductCommunityService.getProductsFromQuery(productType, productId, productClassification, productSubFamily);
	}
	@RequestMapping(value="rest/api/v1/corporateUIUpdate",method=RequestMethod.POST)
	public List<EpcProductCommunity> updateCorporate(@RequestBody List<EpcProductCommunity> corporateProduct)
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String user=auth.getName();
		System.out.println("The list that we got from UI is "+corporateProduct);
		return epcProductCommunityService.updateCorporate(corporateProduct, user);
	}
	
	@RequestMapping(value="rest/api/v1/corporateUIUsageProducts",method=RequestMethod.POST)
	public List<String> checkProductsAreIsUsage(@RequestBody List<EpcProductSpecification> products)
	{
		return epcProductCommunityService.checksUsageProducts(products);
	}
	
	@RequestMapping(value="rest/api/v1/getAllEmployeeBands", method=RequestMethod.GET)
	public List<String> getEmployeeApplicableBands() {
		return epcProductCommunityService.getEmployeeBands();
	}
	
	@RequestMapping(value="rest/extapi/v1/corporateUIUsageProducts",method=RequestMethod.POST)
	public List<String> checkProductsAreIsUsageExt(@RequestBody List<EpcProductSpecification> products)
	{
		return epcProductCommunityService.checksUsageProducts(products);
	}
	
	
	@RequestMapping(value="rest/api/v1/corporateUIGetProviderProductId",method=RequestMethod.GET)
	public String getProviderProductId(@RequestParam MultiValueMap allRequestParams)
	{
		List<EpcProductProviderSystem> specList = epcProductProviderService.searchProvider(allRequestParams);
		if(!specList.isEmpty()) {
			return specList.get(0).getProviderProductId();
		}
		return "";
	}
	
	

	
	
}
