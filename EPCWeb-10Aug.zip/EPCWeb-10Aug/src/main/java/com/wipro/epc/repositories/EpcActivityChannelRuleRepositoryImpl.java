package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcActivityChannelRule;


/**
 * @version 1.0
 * @author VI251443
 *
 */
public class EpcActivityChannelRuleRepositoryImpl implements EpcActivityChannelRuleRepositoryCustom {
	
	private static Logger logger =LoggerFactory.getLogger(EpcActivityChannelRuleRepositoryImpl.class);
	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<EpcActivityChannelRule> getSearchResult(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query,EpcActivityChannelRule.class).getResultList();
	}
	
	
	
	@Override
	public EpcActivityChannelRule modifyActivity(EpcActivityChannelRule order) {
	StringBuilder queryBuilder = new StringBuilder("update epc_activity_channel_rule set activity_channel_rule_id="+order.getActivityChannelRuleId());	
	if (order.getCurrency()!=null && !order.getCurrency().isEmpty()){
		queryBuilder.append(",").append("currency ='").append(order.getCurrency()).append("'");
	}
	if (order.getInitiatingChannel()!=null && !order.getInitiatingChannel().isEmpty()){
		queryBuilder.append(",").append("initiating_channel='").append(order.getInitiatingChannel()).append("'");
	}
	if (order.getIsConsentRequired()!=null ){
		queryBuilder.append(",").append("is_consent_required='").append(order.getIsConsentRequired()).append("'");
	}
	//if (order.getIsFutureDate()!=null )
		queryBuilder.append(",").append("is_future_date='").append(order.getIsFutureDate()).append("'");
	//if (order.getNotificationTemplateId()!=null && order.getNotificationTemplateId()!=0)
		queryBuilder.append(",").append("notification_template_id=").append(order.getNotificationTemplateId());
	if (order.getSalesChannel()!=null && !order.getSalesChannel().isEmpty()){
		queryBuilder.append(",").append("sales_channel='").append(order.getSalesChannel()).append("'");
	}
	if (order.getStatus()!=null && !order.getStatus().isEmpty()){
		queryBuilder.append(",").append("status='").append(order.getStatus()).append("'");
	}
	
	queryBuilder.append(" where activity_channel_rule_id =").append(order.getActivityChannelRuleId());
	String query = queryBuilder.toString();
	em.createNativeQuery(query).executeUpdate();
	//System.out.println(query);
	logger.debug("#Query: "+query);
	return order;	
	}

}
