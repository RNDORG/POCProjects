package com.wipro.epc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.services.BroadcastService;
import com.wipro.epc.services.EpcProductProviderSystemService;
import com.wipro.common.gs.exception.GenericException;

@RestController
public class EpcProductProviderController {
	
	@Autowired
	EpcProductProviderSystemService epcProductProviderSystemService;

	@Autowired
	BroadcastService broadcastService;
    
	@RequestMapping(value="rest/extapi/v1/reloadProviderProductCacheLocal", method=RequestMethod.GET)
	public String reloadProviderProductCacheLocal(){
		String msg="";
		try{
		epcProductProviderSystemService.loadProviderCache();
		msg="SUCCESSFULLY RELOADED.";
		}
		catch(GenericException g){
			msg="FAILURE";
		}		
		return msg;
	}
	
	@RequestMapping(value="rest/extapi/v1/reloadProviderProductCache", method=RequestMethod.GET)
	public String reloadProviderProductCache(){
		String msg="";
		try{
			MultiValueMap allRequestParams=new LinkedMultiValueMap<>();
			allRequestParams.add("api", "reloadProviderProductCacheLocal");
			allRequestParams.add("to", "all");
			broadcastService.getReplyService(allRequestParams);
		    msg="SUCCESSFULLY RELOADED.";
		}
		catch(GenericException g){
			msg="FAILURE";
		}		
		return msg;
	}
}
