package com.wipro.epc.dto;

import java.util.List;

/**
 * @author Developer
 * @version 1.0
 * type CBIOResponse
 */
public class CBIOResponse {
	
	/**
	 * String CBIOResponse.java
	 */
	private Integer ratePlanId;
	/**
	 * List<Integer> CBIOResponse.java
	 */
	private List<Integer> subscribedProducts;

	
	/**
	 * @return the ratePlanId
	 */
	public Integer getRatePlanId() {
		return ratePlanId;
	}
	/**
	 * @param ratePlanId the ratePlanId to set
	 */
	public void setRatePlanId(Integer ratePlanId) {
		this.ratePlanId = ratePlanId;
	}
	/**
	 * @return
	 */
	public List<Integer> getSubscribedProducts() {
		return subscribedProducts;
	}
	/**
	 * @param subscribedProducts
	 */
	public void setSubscribedProducts(List<Integer> subscribedProducts) {
		this.subscribedProducts = subscribedProducts;
	}
}
