package com.wipro.epc.uam.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.uam.domain.Authorities;

/**
 * @author Developer
 * @version 1.0
 * type AuthorityRepository
 */
public interface AuthorityRepository extends CrudRepository<Authorities, Long>{
	
	/**
	 * @param username
	 */
	@Modifying
	@Query(value="delete from authorities where username=:username", nativeQuery=true)
	@Transactional
	void deleteFromAuthorities(@Param("username") String username);

	/**
	 * @param username
	 * @return
	 */
	@Query(value="select * from authorities where username=:username", nativeQuery=true)
	List<Authorities> findByUsername(@Param("username") String username);
	
	/**
	 * @param auth
	 * @return
	 */
	@Query(value="select distinct email from users where email is not null and enabled='true' and "
			+ "username in (select distinct username from authorities where authority like :auth%)",nativeQuery=true)
	List<String> getAuthUsersMails(@Param("auth") String auth);
	
	/**
	 * @param username
	 * @return
	 */
	@Query("select a.authority from Authorities a where a.username = :username")
	List<String> getAuthoritiesForUser(@Param("username") String username);
	
	@Query("select distinct email from Users where email is not null and enabled='true' and username in (select distinct userName from UserRoleMap where roleId in "
			+ "(select roleId from Role where name=:role))")
	List<String> getUserMailsForSpecificRole(@Param("role") String roleName);
	
}
