package com.wipro.epc.repositories;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wipro.epc.domain.EpcProductProviderSystem;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductProviderSystemRepositoryImpl
 */
public class EpcProductProviderSystemRepositoryImpl implements EpcProductProviderSystemRepositoryCustom{

	private static Logger logger =LoggerFactory.getLogger(EpcProductProviderSystemRepositoryImpl.class);
	
	/**
	 * EntityManager EpcProductProviderSystemRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em; 
	
	/**
	 * DateFormat EpcProductProviderSystemRepositoryImpl.java
	 */
	private DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
	/**
	 * DateFormat EpcProductProviderSystemRepositoryImpl.java
	 */
	private DateFormat sdfTime = new SimpleDateFormat("kk:mm:ss");
	
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductProviderSystemRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcProductProviderSystem> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductProviderSystem.class).getResultList();
	}

	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductProviderSystemRepositoryCustom#modifyProductProviders(com.wipro.epc.domain.EpcProductProviderSystem)
	 */
	@Override
	public EpcProductProviderSystem modifyProductProviders(EpcProductProviderSystem productProviders)
	{		
			//sdf.setTimeZone(TimeZone.getDefault());
			//sdfTime.setTimeZone(TimeZone.getDefault());
			StringBuilder queryBuilder = new StringBuilder("update epc_product_provider_system set product_provider_system_id="+productProviders.getProductProviderSystemId());
			
			if(productProviders.getIsPrimaryProvider()!=null)
				queryBuilder.append(",").append(" is_primary_provider = '").append(productProviders.getIsPrimaryProvider()).append("'");
			if(productProviders.getProviderProductId()!=null)
				queryBuilder.append(",").append(" provider_product_id = '").append(productProviders.getProviderProductId()).append("'");
			if(productProviders.getProviderSystemCode()!=null)
				queryBuilder.append(",").append(" provider_system_code = '").append(productProviders.getProviderSystemCode()).append("'");
			if(productProviders.getStatus()!=null)
				queryBuilder.append(",").append(" status = '").append(productProviders.getStatus()).append("'");
			if(productProviders.getModifiedBy()!=null)
				queryBuilder.append(",").append(" modified_by = '").append(productProviders.getModifiedBy()).append("'");
			if(productProviders.getModifiedDate()!=null)
				queryBuilder.append(",").append(" modified_date = '").append(new SimpleDateFormat().format(new Date())).append("'");
			if(productProviders.getProviderProductDescription()!=null)
				queryBuilder.append(",").append(" provider_product_description = '").append(productProviders.getProviderProductDescription()).append("'");	
			queryBuilder.append(" where product_provider_system_id=").append(productProviders.getProductProviderSystemId());
			String query = queryBuilder.toString();
			logger.debug("#Query: "+query);
			em.createNativeQuery(query).executeUpdate();
		return productProviders;
	}
	
	/**
	 * @param str
	 * @return
	 */
	private String rectifyHourComponent(String str){
		str = str.replaceFirst(" 24:"," 00:");
		return str;
	}
	
	
	@Override
	public List<Object[]> getAttributeList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query).getResultList();
		
	}


}
