package com.wipro.epc.dto;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.wipro.epc.domain.EpcActivityChannelRule;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ActivitySearchOutputOld {


		
	private Map<String,String> activityDetail;
	private List<EpcActivityChannelRule> epcActivityChannelRule;
	public Map<String, String> getActivityDetail() {
		return activityDetail;
	}
	public void setActivityDetail(Map<String, String> activityDetail) {
		this.activityDetail = activityDetail;
	}
	public List<EpcActivityChannelRule> getEpcActivityChannelRule() {
		return epcActivityChannelRule;
	}
	public void setEpcActivityChannelRule(
			List<EpcActivityChannelRule> epcActivityChannelRule) {
		this.epcActivityChannelRule = epcActivityChannelRule;
	}
		
		
		

	}



