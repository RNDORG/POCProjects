package com.wipro.epc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.DownstreamQueryInput;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.DownstreamQueryService;




/**
 * @author Developer
 * @version 1.0
 * type DownstreamQueryController
 */
@RestController
public class DownstreamQueryController {

	private static Logger logger = LoggerFactory.getLogger(DownstreamQueryController.class);
	
	/**
	 * DownstreamQueryService DownstreamQueryController.java
	 */
	@Autowired
	DownstreamQueryService downstreamQueryService;
	
	/**
	 * TransactionsService DownstreamQueryController.java
	 */
	@Autowired
	TransactionsService transactionsLogging ;

	/**
	 * ObjectMapper DownstreamQueryController.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * TransactionStore DownstreamQueryController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/queryDownstream", method=RequestMethod.POST)
	public EpcProductSpecification queryDownstreamExt(@RequestBody DownstreamQueryInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		String txnType="queryDownstream";
		EpcProductSpecification response=null;
		String request=null;
		try{
			request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, queryInput);
		response=downstreamQueryService.queryDownstream(queryInput,allRequestParams);
		}
		catch (Exception e ) {
			logger.error("#interfaceException: " + e.getMessage());
			throw new EPCException(e.getMessage());
		}
		finally{
		ePCTxnInterceptor.postTxn(txnType, request, response ); 
		}
		return response;
	}
	

	
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/queryDownstream", method=RequestMethod.POST)
	public EpcProductSpecification queryDownstream(@RequestBody DownstreamQueryInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		return downstreamQueryService.queryDownstream(queryInput,allRequestParams);
	}
	
}
