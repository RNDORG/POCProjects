package com.wipro.epc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.dto.MigrationEligibilityInput;
import com.wipro.epc.dto.MigrationEligibilityResponse;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.MigrationEligibilityService;



/**
 * @author Developer
 * @version 1.0
 * type MigrationEligibilityController
 */
@RestController
public class MigrationEligibilityController {

	private static Logger logger = LoggerFactory.getLogger(MigrationEligibilityController.class);
	/**
	 * MigrationEligibilityService MigrationEligibilityController.java
	 */
	@Autowired
	MigrationEligibilityService migrationEligibilityService;
	
	/**
	 * TransactionsService MigrationEligibilityController.java
	 */
	@Autowired
	TransactionsService transactionsLogging ;

	/**
	 * ObjectMapper MigrationEligibilityController.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * TransactionStore MigrationEligibilityController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/migrationEligibility", method=RequestMethod.POST)
	public MigrationEligibilityResponse checkMigrationEligibilityExt(@RequestBody MigrationEligibilityInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		String txnType = "migrationEligibility";
		String request=null;
		MigrationEligibilityResponse response=null;
		try{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, queryInput);
		response=migrationEligibilityService.checkMigrationEligibility(queryInput, allRequestParams);
		}
		catch (Exception e ) {
			logger.error("#interfaceException: " + e.getMessage());
			throw new EPCException(e.getMessage());
		}
		finally{
		ePCTxnInterceptor.postTxn(txnType,request, response);
		}
		return response;
	}
	
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/migrationEligibility", method=RequestMethod.POST)
	public MigrationEligibilityResponse checkMigrationEligibility(@RequestBody MigrationEligibilityInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		return migrationEligibilityService.checkMigrationEligibility(queryInput, allRequestParams);
	}	
}
