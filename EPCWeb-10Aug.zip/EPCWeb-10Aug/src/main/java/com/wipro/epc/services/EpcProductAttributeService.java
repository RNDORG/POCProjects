package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcAttributeMaster;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcAttributeMasterRepository;
import com.wipro.epc.repositories.EpcProductAttributeRepository;
import com.wipro.epc.util.Constants;


/**
 * @author Developer
 * @version 1.0
 * type EpcProductAttributeService
 */
@Service
public class EpcProductAttributeService {
	
	/**
	 * EpcProductAttributeRepository EpcProductAttributeService.java
	 */
	@Autowired
	EpcProductAttributeRepository epcProductAttributeRepository;
	
	/**
	 * EpcAttributeMasterService EpcProductAttributeService.java
	 */
	@Autowired
	EpcAttributeMasterService epcAttributeMasterService;
	
	/**
	 * EpcAttributeMasterRepository EpcProductAttributeService.java
	 */
	@Autowired
	EpcAttributeMasterRepository epcAttributeMasterRepository;

/**
 * @param productAttributeList
 * @param createdBy
 * @return
 */
@Transactional
public List<EpcProductAttribute> manageProductAttribute(List<EpcProductAttribute> productAttributeList,String createdBy){
	
	List<EpcProductAttribute> retProductAttributeList=new ArrayList<EpcProductAttribute>();
	
		for (EpcProductAttribute productAttribute : productAttributeList) {
			productAttribute=manageProductAttribute(productAttribute, createdBy);
			EpcAttributeMaster epcAttributeMaster = epcAttributeMasterRepository.findByAttributeId(productAttribute.getAttributeId());
			if(productAttribute != null && epcAttributeMaster != null){
					productAttribute.setReservedC(epcAttributeMaster.getAttributeCtg());
					productAttribute.setReservedCT(epcAttributeMaster.getAttributeCtgType());
			}
			if (productAttribute.getMetaInfo().get("STATUS") == null) {
				productAttribute.getMetaInfo().put(MetaInfo.STATUS,
						MetaInfo.SUCCESS);
			}
			retProductAttributeList.add(productAttribute);

		}
		return retProductAttributeList;
		
	}
	
	/**
	 * @param productAttribute
	 * @param createdBy
	 * @return
	 */
	public EpcProductAttribute manageProductAttribute(EpcProductAttribute productAttribute,String createdBy){
		
		 EpcProductAttribute retProductAttribute = null;
		 
		switch(productAttribute.getMetaInfo().get("OPERATION")){		
			
				case "CREATE":
					retProductAttribute=createProductAttribute(productAttribute,createdBy);
						break;
				case "UPDATE":
					retProductAttribute=modifyProductAttribute(productAttribute, createdBy);
					break;
				case "DELETE":
					retProductAttribute=deleteProductAttribute(productAttribute);
						break;
				default:
						throw new EPCException("not supported");
		}
		
		return retProductAttribute;
	}
	
	/**
	 * @param productAttribute
	 * @param createdBy
	 * @return
	 */
	public EpcProductAttribute createProductAttribute(EpcProductAttribute  productAttribute, String createdBy){
		
		productAttribute.setCreatedBy(createdBy);
		productAttribute.setCreatedDate(new Date());
		productAttribute.setStatus(Constants.COMMON_STATUS_ACTIVE);
		epcProductAttributeRepository.save(productAttribute);
		
		return productAttribute;
		
	}
	
	/**
	 * @param productAttribute
	 * @param lastUpdatedBy
	 * @return
	 */
	EpcProductAttribute modifyProductAttribute(EpcProductAttribute productAttribute, String lastUpdatedBy) {
		productAttribute.setModifiedBy(lastUpdatedBy);
		productAttribute.setModifiedDate(new Date());
		epcProductAttributeRepository.modifyProductAttribute(productAttribute);
		return productAttribute;
	}
	
	/**
	 * @param productAttribute
	 * @return
	 */
	public EpcProductAttribute deleteProductAttribute(EpcProductAttribute productAttribute){
		
		epcProductAttributeRepository.delete(productAttribute.getProductAttributeId());
		return productAttribute;
	}
	
	//****************************************SEARCH*************************************************************
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductAttribute> searchProductAttribute(Map<String, List<String>> allRequestParams){
		
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,EpcProductAttribute.class.getName(), null);
		
		List<EpcProductAttribute> retProductAttributeList=null;
		//retEpcProductAttributeList=epcProductAttributeRepository.getEpcProductAttributeList(queryBuilder.toString());
		try {
			retProductAttributeList = epcProductAttributeRepository.getEpcProductAttributeList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return retProductAttributeList;
		
	}

}
