package com.wipro.epc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.services.OrderTypeValidationService;

/**
 * @author Developer
 * @version 1.0
 * type OrderTypeValidationController
 */
@RestController
public class OrderTypeValidationController {

	
	/**
	 * OrderTypeValidationService OrderTypeValidationController.java
	 */
	@Autowired
	OrderTypeValidationService service;
	
	/**
	 * @param orderList
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/orderValidation", method=RequestMethod.POST)
	public int manageOrders(@RequestBody EpcOrderChannelRule orderList)
	{
		
		return service.validateOrders(orderList);
	}
	
	
}
