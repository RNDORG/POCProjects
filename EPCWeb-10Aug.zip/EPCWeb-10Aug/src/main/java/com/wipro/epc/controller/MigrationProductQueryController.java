package com.wipro.epc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.ComplexSearchInputForMigration;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.MigrationProductQueryService;

/**
 * @author Developer
 * @version 1.0
 * type MigrationProductQueryController
 */
@RestController
public class MigrationProductQueryController {
	
/*	@Autowired
	TransactionsService transactionsLogging ;*/
	private static Logger logger = LoggerFactory.getLogger(MigrationProductQueryController.class);
	/**
	 * ObjectMapper MigrationProductQueryController.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * TransactionStore MigrationProductQueryController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	/**
	 * MigrationProductQueryService MigrationProductQueryController.java
	 */
	@Autowired
	MigrationProductQueryService migrationService;

	/**
	 * @param searchInputforMigration
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/searchProductsForMigration", method=RequestMethod.POST)
	public List<EpcProductSpecification> searchProductsComplexExt(@RequestBody ComplexSearchInputForMigration searchInputforMigration,
			 @RequestParam MultiValueMap allRequestParams)
	{
		String txnType="searchProductsForMigration";
		String request=null;
		List<EpcProductSpecification> response=null;
		try{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, searchInputforMigration);
		response=migrationService.migrationProductQueryResult(searchInputforMigration, allRequestParams);
		}
		catch (Exception e ) {
			logger.error("#interfaceException: " + e.getMessage());
			throw new EPCException(e.getMessage());
		}
		finally{
		ePCTxnInterceptor.postTxn(txnType, request, response);
		}
		return response;
	}

}
