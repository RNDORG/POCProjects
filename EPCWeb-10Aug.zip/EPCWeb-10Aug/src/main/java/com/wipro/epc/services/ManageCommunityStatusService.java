package com.wipro.epc.services;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.dto.ManageCommunityStatusInput;
import com.wipro.epc.dto.ManageCommunityStatusResponse;
import com.wipro.epc.util.Constants;


/**
 * @author Developer
 * @version 1.0
 * type ProviderProductQueryService
 */
@Service
public class ManageCommunityStatusService {
	
	@Autowired
	EpcProductCommunityService epcProductCommunityService;
	/**
	 * @param input
	 * @param allRequestParams
	 * @return
	 */
	public ManageCommunityStatusResponse manageCommunityStatus(
			ManageCommunityStatusInput input) {
		
		ManageCommunityStatusResponse response = new ManageCommunityStatusResponse();
		if(StringUtils.isBlank(input.getCommunityName()) || StringUtils.isBlank(input.getCommunityShortCode()) || StringUtils.isBlank(input.getAction())){
			response.setStatus(Constants.RESPONSE_FAIL_STATUS);
			response.setRemarks("Mandatory Fields are missing. Please provide all mandatory fields ( communityName, communityShortCode, action)");
			return response;
		}
		List<String> validActions = Arrays.asList(new String []{"Delete", "Enable", "Disable"});
		
		if(!validActions.contains(input.getAction())){
			response.setStatus(Constants.RESPONSE_FAIL_STATUS);
			response.setRemarks("Invalid action provided. Please provide valid action (Delete, Enable, Disable).");
			return response;
		}
		MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
		criteria.add("communityName", input.getCommunityName());
		criteria.add("communityShortCode", input.getCommunityShortCode());
		List<EpcProductCommunity> EpcProductInitChannels = epcProductCommunityService.searchProductCommunity(criteria);
		if(EpcProductInitChannels != null && !EpcProductInitChannels.isEmpty()){
			for( EpcProductCommunity community: EpcProductInitChannels){
				if(community.getCommunityId() != null && input.getCommunityId() != null && !input.getCommunityId().equals(community.getCommunityId())){
					response.setStatus(Constants.RESPONSE_FAIL_STATUS);
					response.setRemarks("Requested community id ["+input.getCommunityId()+"] doesn't match with the community id ["+community.getCommunityId()+"] which is associated with the community name["+community.getCommunityName()+"].");
					return response;
				}
				if("Delete".equals(input.getAction())){
					community.setCommunityStatus(Constants.COMMUNITY_STATUS_DELETED);
				}
				if("Disable".equals(input.getAction())){
					community.setCommunityStatus(Constants.COMMUNITY_STATUS_INACTIVE);
				}
				if("Enable".equals(input.getAction())){
					community.setCommunityStatus(Constants.COMMUNITY_STATUS_ACTIVE);
				}
			}
			response.setStatus(Constants.RESPONSE_SUCCESS_STATUS);
			response.setRemarks("Community status updated successfully.");
			return response;
		}else{
			response.setStatus(Constants.RESPONSE_FAIL_STATUS);
			response.setRemarks("No records found for requested community name and community short code.");
			return response;
		}
	}
}
