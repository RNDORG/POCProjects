package com.wipro.epc.services;

import java.util.Arrays;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.domain.CachedProductDetails;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.repositories.CachedProductDetailsRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.util.BytesUtil;

@Service
public class PCachedProductService {
	
	private static Logger logger =LoggerFactory.getLogger(PCachedProductService.class);
	
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	CachedProductDetailsRepository cachedProductRepository;
	
	@Autowired
	CachedProductDetailsService cachedProdcutService;
	
	@Autowired
	ReloadStatusService reloadStatusService;
	
	@Autowired
	EpcProductSpecificationRepository epcProductSpecificationRepository;
	
	@Transactional
	boolean lock(int id ) {
		logger.info("in lock("+id+")");
		CachedProductDetails cpd=new CachedProductDetails();
		cpd.setId(id);
		cpd.setStatus("Load");
		//StringBuilder queryBuilderInsert = new StringBuilder("Insert into CACHED_PRODUCT_DETAILS (id,status) values( " + id +" , 'Load' )" );
		//String queryInsert = queryBuilderInsert.toString();
	//	if(em.createNativeQuery(queryInsert).executeUpdate()!=0){
		try{
			cachedProductRepository.save(cpd);
			return true;
		}catch(Exception e){ // ToCheck - Since we have deleted ids before calling this method.. this code may never be executed.
			e.printStackTrace();
			StringBuilder queryBuilder = new StringBuilder("update CACHED_PRODUCT_DETAILS  set status= 'Load' where status='Active' and id= "+id);
			String query = queryBuilder.toString();
			if(em.createNativeQuery(query).executeUpdate()!=0){
				return true;
			}else{
				return false;
			}
		}
		
	}
	
	@Transactional
	boolean unLock(int id ) {
		logger.info("in unlock("+id+")");
		StringBuilder queryBuilder = new StringBuilder("update cached_product_details set status= 'Active' where status='Load' and id= "+id+";");
		String query = queryBuilder.toString();
		System.out.println("query : "+query);
		try{
			em.createNativeQuery(query).executeUpdate();
			return true;
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
	
	}
	EpcProductSpecification reloadOne(String id  )  {
		logger.info("reloadOne("+id+") -------------- ");
		EpcProductSpecification spec=null;
		int i=0;
		
		while(true){
			i++;
				if( lock(Integer.parseInt( id ))){
					try{
						spec=calcProductCachedValue(id);
						if(spec==null){
							throw new RuntimeException("calcProductCachedValue(id) returned null.");
						}else{
							saveOrUpdate(spec);// unlock 
							//return spec;
							break;
						}
						
						
					}catch(Exception e){
						logger.error("#Exception in reload("+id+") : "+e.getMessage());
						cachedProductRepository.delete(Integer.parseInt( id ));  
						break;
					}
					/*finally{
						unLock(Integer.parseInt( id ));
					}*/
				}else{
					try {
						if(i>50){
							logger.info("#info in reload(id) :Check.. too much time is taken.");
							break;
						}
						Thread.sleep(1000);
						logger.info("#reload(id) slept for few seconds...");
					} catch (InterruptedException e) {
						logger.error("#Exception in reload() : "+e.getMessage());
					}
				}
			
			
		}
		logger.info("reloadOne("+id+") of PCachedProductService end here--------------");
		return spec;
	}
	void reloadCacheTable( String[] ids,Integer reqId) {
		logger.info("#pcachedProductService.reloadCacheTable("+Arrays.asList(ids).toString()+") starts here-----------------------------------------------------");
		Integer count=0;
		String remark="";
		String errIds = "";
		String ignoredIds = "";
		List<String> idsAll=Arrays.asList( epcProductSpecificationRepository.getProductId() );		
		for(String id:ids){
			count++;
			remark="[ "+count+"/"+ ids.length+" ] ";
				if(idsAll.contains(id)){
					try{					
						EpcProductSpecification spec=reloadOne( id );					
						if(spec== null){
							errIds = errIds + " " + id;						
						}					
					}catch(Exception e){
						logger.error("#Exception in pcachedProductService.reloadCacheTable("+id+") : "+e.getMessage());
					}
				}else {
					ignoredIds = ignoredIds + "(" + id + ")" ;				
					logger.warn("#pcachedProductService.reloadCacheTable("+id+") : This id does not exist in DB, Ignoring this Id ***************************");
				}
				if ( ! errIds.isEmpty() ) { remark = remark + " Error Ids = " + errIds;  }
				if ( ! ignoredIds.isEmpty() ) { remark = remark + " Ignored Ids = " + ignoredIds;  }
				
				if(count<ids.length){
					reloadStatusService.updateReloadStatus(reqId, "LOAD", remark, false);
				}
				else{
					reloadStatusService.updateReloadStatus(reqId, "COMPLETED", remark, false);
				}
		}		
		logger.info("reloadCacheTable Result : " + remark );
		logger.info("#pcachedProductService.reloadCacheTable() ends -----------------------------------------------------------------------------------------------");
		
		
	}
	CachedProductDetails get( String id )  {// check if present in CachedProductDetails Table.
		logger.info("*****in get("+id+") of PcachedProductService*********");
		return cachedProductRepository.getById(Integer.parseInt(id));
	}
	List<CachedProductDetails> get(String[] ids )  {
		logger.info("********in get("+Arrays.asList(ids)+") of PcachedProductService*********");
		//List<String> id= Arrays.asList(ids);
		
		/* String id="";
		  for(int i=0;i<ids.length;i++){
			if(i<ids.length-1)
				id=id+ids[i]+",";
			else
				id=id+ids[i];
		}*/
		  Integer[] intId = new Integer[ids.length];
		    for (int i=0; i < ids.length; i++) {
		    	intId[i] = Integer.parseInt(ids[i]);
		    }
		    List<Integer> listIds=Arrays.asList(intId);
		    
		return cachedProductRepository.findByIds(listIds);
	}
	void clear(String[] ids)   {
		logger.info("PcachedProductService.clear()");
		String id="";
		
		for(int i=0;i<ids.length;i++){
			if(i<ids.length-1)
				id=id+ids[i]+",";
			else
				id=id+ids[i];
		}
		
		    Integer[] intId = new Integer[ids.length];
		    for (int i=0; i < ids.length; i++) {
		    	intId[i] = Integer.parseInt(ids[i]);
		    }
		    List<Integer> listIds=Arrays.asList(intId);
		    
		int i=0;
		while(true){
			i++;
			cachedProductRepository.deleteByIds(id);

			if(cachedProductRepository.findByIdsForStatus(listIds).isEmpty()){
				break;	
			}else{
				try {
					if(i>10){
						logger.error("##PcachedProductService.clear() => Unable to delete all ids in " + i + "attempts. Breaking out.");
						// TODO: Can print the ids which we could not delete.
						break;
						}
					//TimeUnit.SECONDS.sleep(2);//sleep for 2 sec
					logger.warn("#PcachedProductService.clear() => Attempt #" +  i + "Unable to delete all Ids. Sleeping for few seconds...");
					Thread.sleep(1000);
					
				} catch (InterruptedException e) {
					e.printStackTrace();
					logger.error("#Exception in PcachedProductService.clear() : "+e.getMessage());
				}
			}
			
		}
		 
	}
	
	@Transactional
	void saveOrUpdate(EpcProductSpecification productSpec ){
	//	System.out.println(productSpec);
		logger.info("in saveOrUpdate("+productSpec.getProductId()+") of PcachedProductService");
		CachedProductDetails cachedProduct = new CachedProductDetails();
		
		try {
			cachedProductRepository.delete(productSpec.getProductId());
			cachedProduct.setId(productSpec.getProductId());
			cachedProduct.setValue(BytesUtil.toByteArray(productSpec));
			//System.out.println(BytesUtil.toByteArray(productSpec));
			cachedProduct.setStatus("Active");
			cachedProductRepository.save(cachedProduct);
			
		}catch (Exception e) {
			System.out.println("EXCEPTION saveOrUpdate("+productSpec.getProductId()+") : "+e.getMessage());
			logger.error("Error occurred while caching the saveOrUpdate() in PcachedProductService and error is : {}", productSpec.getProductShortCode(), e.getMessage());
		}
	}
	EpcProductSpecification calcProductCachedValue( String id ){
		logger.info("in calProductCachedValue("+id+") of PcachedProductService");
		return cachedProdcutService.cacheProduct(Integer.parseInt(id));
	}
	/*
	 * class PCachedProductService {  // @Service manages Physical table - CachedProductDetails.
*			
*			boolean lock( id ) {
				insert into table status = LOAD.
				if insertion successfull return true.
				
				update table set status = LOAD where status = AVL
				if rowUPdated != 0 return true;
*			}
*
* 			boolean unlock( id ) {
* 				update table set status = AVL where status = LOAD;
* 				if rowCount == 0 then ERRORLOG
* 				return true;
* 			}
*
	* 		EPCProductSpec reload( id  )  {  // If not found..then it will save. If found then it will Update.
	* 			while ( 1 ) {
					if ( lock( id ) ) {  
		* 				ProdSpec ps = calcProductCachedValue (id);
		* 				saveOrUpdate( ps };
		* 				unlock ( id );  // put this in finally.. or after catch.
		* 				break;
		* 			} else sleep 2;
	* 			}
	* 		}
	* 
	* 		List<EPCProductSpec> reload( List<id> ) {} // If not found..then it will save. If found then it will Update. 
	* 		List<EPCProductSpec> get( List<ids> )  {}  // simple getter  
	* 		void clear(String[] ids)   {}              // Deletes rows corresponding to given ids in CachedProductDetails table. | if ALL then truncates table.
	*                                                  // Delete only AVL status.. wait till no records with LOAD status. sleep
	*          while (true ) {  
	*       	delete from table where status=AVL where id in (1,3,4);
	*       	count = select from table wehre status=LOAD and id in (3,4);
	*       	if ( count == 0 ) {  break }
	*           sleep 2
	*           // if looped 50 times, put error log. (if something is taking too long to LOAD). 
	*         }
	*                                                  
	*       }
	*  
	* 		void saveOrUpdate(ProductSpec ){}  //   AVL->LOAD (wait till you get lock) | then do save/update  ten LOAD=>AVL {	 
	*        // AVL | LOAD   ---- ERROR (should never happen)
	*        
	*        1. Lock the table.
	*        
	*        	query = update table set status = LOAD where status = AVL and id = givenId.
	*        	rowsUpdated = executeQuery (query);
	*        	if ( rowsUpdated == 0 )  // Unable to get a lock 
	*        
	*        	}
	*        	 
	*        
	*        
	*   
	*       }		
	* 		ProductSpec calcProductCachedValue( id ){}
* 		}

	 * 
	 * 
	 * */

}
