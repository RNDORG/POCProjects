package com.wipro.epc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.dto.ComplexOrderQueryInput;
import com.wipro.epc.dto.OrderType;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.ComplexOrderQueryService;



/**
 * @author Developer
 * @version 1.0
 * type ComplexOrderQueryController
 */
@RestController
public class ComplexOrderQueryController {

	/**
	 * ComplexOrderQueryService ComplexOrderQueryController.java
	 */
	@Autowired
	ComplexOrderQueryService searchService;
	
	private static Logger logger = LoggerFactory.getLogger(ComplexOrderQueryController.class);
	/**
	 * TransactionsService ComplexOrderQueryController.java
	 */
	@Autowired
	TransactionsService transactionsLogging ;

	/**
	 * ObjectMapper ComplexOrderQueryController.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * TransactionStore ComplexOrderQueryController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/searchOrders", method=RequestMethod.POST)
	public OrderType queryOrderRuleExt(@RequestBody ComplexOrderQueryInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		String txnType="searchOrders";
		String request=null;
		OrderType response=null;
		try
		{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, queryInput);
		response=searchService.queryOrderRule(queryInput,allRequestParams);
		} 
		catch (Exception e ) {
			logger.error("#interfaceException: " + e.getMessage());
			throw new EPCException(e.getMessage());
		}
		finally{
		ePCTxnInterceptor.postTxn(txnType, request,response);
		}
		return response;
		
	}
	
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/searchOrders", method=RequestMethod.POST)
	public OrderType queryOrderRule(@RequestBody ComplexOrderQueryInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		return searchService.queryOrderRule(queryInput,allRequestParams);
	}
	
}
