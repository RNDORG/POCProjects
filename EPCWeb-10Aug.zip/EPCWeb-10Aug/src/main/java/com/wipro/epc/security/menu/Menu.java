package com.wipro.epc.security.menu;

import java.util.List;

/**
 * @author Developer
 * @version 1.0
 * type Menu
 */
public class Menu {

	/**
	 * String Menu.java
	 */
	private String name;
	/**
	 * List<Menu> Menu.java
	 */
	private List<Menu> subMenu;
	/**
	 * String Menu.java
	 */
	private String target;
	/**
	 * String Menu.java
	 */
	private String styleClass;
	/**
	 * boolean Menu.java
	 */
	private boolean isVisible;
	
	/**
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return
	 */
	public List<Menu> getSubMenu() {
		return subMenu;
	}
	/**
	 * @param subMenu
	 */
	public void setSubMenu(List<Menu> subMenu) {
		this.subMenu = subMenu;
	}
	/**
	 * @return
	 */
	public String getTarget() {
		return target;
	}
	/**
	 * @param target
	 */
	public void setTarget(String target) {
		this.target = target;
	}
	/**
	 * @return
	 */
	public boolean isVisible() {
		return isVisible;
	}
	/**
	 * @param isVisible
	 */
	public void setVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}
	/**
	 * @return
	 */
	public String getStyleClass() {
		return styleClass;
	}
	/**
	 * @param styleClass
	 */
	public void setStyleClass(String styleClass) {
		this.styleClass = styleClass;
	}
		
}
