package com.wipro.epc.uam.domain;

// Generated May 27, 2016 1:50:10 PM by Hibernate Tools 4.3.1

import java.util.Date;
import java.util.List;
import java.util.Map;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;




/**
 * @author KE334465
 * @version 1.0
 *
 */
@Entity
@Table(name = "users")
@NamedQuery(name="Users.findAll", query="SELECT u FROM Users u")
public class Users {
	
	
	@Id
	@Column(name = "username", unique = true, nullable = false, length = 25)
	private String username;
	
	@Column(name = "password", length = 30)
	private String password;
	
	@Column(name = "enabled", length = 30)
	private String enabled;
	
	@Column(name = "fname", length = 256, nullable = false)
	private String fname;
	
	@Column(name = "lname", length = 256)
	private String lname;
	
	@Column(name = "mname", length = 256)
	private String mname;
	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "DOB", length = 10)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date dob;
	
	@Column(name = "address", length = 256)
	private String address;
	
	@Column(name = "created_by", length = 25, nullable = false)
	private String createdBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", length = 19)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm a z")
	private Date createdDate;
	
	@Column(name = "modified_by", length = 25)
	private String modifiedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", length = 19)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm a z")
	private Date modifiedDate;
	
	@Column(name = "email", length = 254)
	private String email;
	
	@Column(name = "mobile_number", length = 10)
	private String mobileNumber;
	
	@Column(name = "employee_no", length = 10)
	private String employeeNo;	
	
	@Transient
	private List<Role> roles;
	
	/*@Transient
	private List<Authorities> authorities;*/

	@Transient
	private Map<String,String> metaInfo;	
	
	/**
	 * @return
	 */
	
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}
	

/*	
	*//**
	 * @return
	 *//*
	
	public List<Authorities> getAuthorities() {
		return authorities;
	}*/
		
/*
	*//**
	 * @param authorities
	 *//*
	public void setAuthorities(List<Authorities> authorities) {
		this.authorities = authorities;
	}
	*/

	/**
	 * 
	 */
	public Users() {
	}

	/**
	 * @param username
	 */
	public Users(String username) {
		this.username = username;
	}



	/**
	 * @return
	 */
	
	public String getUsername() {
		return this.username;
	}

	/**
	 * @param username
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return
	 */
	
	public String getPassword() {
		return this.password;
	}

	/**
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return
	 */
	
	public String getEnabled() {
		return this.enabled;
	}

	/**
	 * @param enabled
	 */
	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	/**
	 * @return
	 */
	
	public String getFname() {
		return this.fname;
	}

	/**
	 * @param fname
	 */
	public void setFname(String fname) {
		this.fname = fname;
	}

	/**
	 * @return
	 */
	
	public String getLname() {
		return this.lname;
	}

	/**
	 * @param lname
	 */
	public void setLname(String lname) {
		this.lname = lname;
	}

	/**
	 * @return
	 */
	
	public String getMname() {
		return this.mname;
	}

	/**
	 * @param mname
	 */
	public void setMname(String mname) {
		this.mname = mname;
	}

	/**
	 * @return
	 */
	
	public Date getDob() {
		return this.dob;
	}

	/**
	 * @param dob
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}

	/**
	 * @return
	 */
	
	public String getAddress() {
		return this.address;
	}

	/**
	 * @param address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return
	 */
	
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	/**
	 * @return
	 */
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	/**
	 * @return
	 */
	
	public String getEmployeeNo() {
		return employeeNo;
	}
	/**
	 * @param employeeNo
	 */
	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}

	/**
	 * @return
	 */
	
	public String getEmail() {
		return this.email;
	}

	/**
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return
	 */
	
	public List<Role> getRoles() {
		return this.roles;
	}

	/**
	 * @param roles
	 */
	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	/**
	 * @param users
	 */
	public Users(Users users) {
		this.username = users.getUsername();
		this.password = users.getPassword();
		this.enabled = users.getEnabled();
		this.fname = users.getFname();
		this.lname = users.getLname();
		this.mname = users.getMname();
		this.dob = users.getDob();
		this.address = users.getAddress();
		this.createdBy = users.getCreatedBy();
		this.createdDate = users.getCreatedDate();
		this.modifiedBy = users.getModifiedBy();
		this.modifiedDate = users.getModifiedDate();
		this.email = users.getEmail();
		this.metaInfo=users.getMetaInfo();
		//this.authorities=users.getAuthorities();
		this.employeeNo=users.getEmployeeNo();
		this.mobileNumber=users.getMobileNumber();
		
		this.roles = users.getRoles();
	}
	
	

	

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Users [username=" + username + ", password=" + password
				+ ", enabled=" + enabled + ", fname=" + fname + ", lname="
				+ lname + ", mname=" + mname + ", dob=" + dob + ", address="
				+ address + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", modifiedBy=" + modifiedBy
				+ ", modifiedDate=" + modifiedDate + ", email=" + email
				+ ", mobileNumber=" + mobileNumber + ", employeeNo="
				+ employeeNo + ", roles=" + roles + ", metaInfo=" + metaInfo
				//+ ", authorities=" + authorities 
				+ "]";
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		/*result = prime * result
				+ ((authorities == null) ? 0 : authorities.hashCode());*/
		result = prime * result
				+ ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result
				+ ((employeeNo == null) ? 0 : employeeNo.hashCode());
		result = prime * result + ((enabled == null) ? 0 : enabled.hashCode());
		result = prime * result + ((fname == null) ? 0 : fname.hashCode());
		result = prime * result + ((lname == null) ? 0 : lname.hashCode());
		result = prime * result
				+ ((metaInfo == null) ? 0 : metaInfo.hashCode());
		result = prime * result + ((mname == null) ? 0 : mname.hashCode());
		result = prime * result
				+ ((mobileNumber == null) ? 0 : mobileNumber.hashCode());
		result = prime * result
				+ ((modifiedBy == null) ? 0 : modifiedBy.hashCode());
		result = prime * result
				+ ((modifiedDate == null) ? 0 : modifiedDate.hashCode());
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((roles == null) ? 0 : roles.hashCode());
		result = prime * result
				+ ((username == null) ? 0 : username.hashCode());
		return result;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Users other = (Users) obj;
		if (address == null) {
			if (other.address != null) {
				return false;
			}
		} else if (!address.equals(other.address)) {
			return false;
		}
	/*	if (authorities == null) {
			if (other.authorities != null) {
				return false;
			}
		} else if (!authorities.equals(other.authorities)) {
			return false;
		}*/
		if (createdBy == null) {
			if (other.createdBy != null) {
				return false;
			}
		} else if (!createdBy.equals(other.createdBy)) {
			return false;
		}
		if (createdDate == null) {
			if (other.createdDate != null) {
				return false;
			}
		} else if (!createdDate.equals(other.createdDate)) {
			return false;
		}
		if (dob == null) {
			if (other.dob != null) {
				return false;
			}
		} else if (!dob.equals(other.dob)) {
			return false;
		}
		if (email == null) {
			if (other.email != null) {
				return false;
			}
		} else if (!email.equals(other.email)) {
			return false;
		}
		if (employeeNo == null) {
			if (other.employeeNo != null) {
				return false;
			}
		} else if (!employeeNo.equals(other.employeeNo)) {
			return false;
		}
		if (enabled == null) {
			if (other.enabled != null) {
				return false;
			}
		} else if (!enabled.equals(other.enabled)) {
			return false;
		}
		if (fname == null) {
			if (other.fname != null) {
				return false;
			}
		} else if (!fname.equals(other.fname)) {
			return false;
		}
		if (lname == null) {
			if (other.lname != null) {
				return false;
			}
		} else if (!lname.equals(other.lname)) {
			return false;
		}
		if (metaInfo == null) {
			if (other.metaInfo != null) {
				return false;
			}
		} else if (!metaInfo.equals(other.metaInfo)) {
			return false;
		}
		if (mname == null) {
			if (other.mname != null) {
				return false;
			}
		} else if (!mname.equals(other.mname)) {
			return false;
		}
		if (mobileNumber == null) {
			if (other.mobileNumber != null) {
				return false;
			}
		} else if (!mobileNumber.equals(other.mobileNumber)) {
			return false;
		}
		if (modifiedBy == null) {
			if (other.modifiedBy != null) {
				return false;
			}
		} else if (!modifiedBy.equals(other.modifiedBy)) {
			return false;
		}
		if (modifiedDate == null) {
			if (other.modifiedDate != null) {
				return false;
			}
		} else if (!modifiedDate.equals(other.modifiedDate)) {
			return false;
		}
		if (password == null) {
			if (other.password != null) {
				return false;
			}
		} else if (!password.equals(other.password)) {
			return false;
		}
		if (roles == null) {
			if (other.roles != null) {
				return false;
			}
		} else if (!roles.equals(other.roles)) {
			return false;
		}
		if (username == null) {
			if (other.username != null) {
				return false;
			}
		} else if (!username.equals(other.username)) {
			return false;
		}
		return true;
	}



	/**
	 * @param metaInfo
	 */
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}


	
}
