
package com.wipro.epc.esb.queryvasservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.CustomRefType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.TransactionReferenceType;


/**
 * <p>Java class for QueryVASServiceRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="QueryVASServiceRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}TransactionReference" minOccurs="0"/>
 *         &lt;element name="CircleId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfferType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfferProvider" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Subscriber_No" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OperatorId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrigSourceSystem" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrigTxnRefId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrigTxnRefDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}CustomRef" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryVASServiceRequestType", propOrder = {
    "transactionReference",
    "circleId",
    "offerType",
    "offerProvider",
    "subscriberNo",
    "operatorId",
    "origSourceSystem",
    "origTxnRefId",
    "origTxnRefDate",
    "customRef"
})
public class QueryVASServiceRequestType {

    @XmlElement(name = "TransactionReference", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected TransactionReferenceType transactionReference;
    @XmlElement(name = "CircleId")
    protected String circleId;
    @XmlElement(name = "OfferType")
    protected String offerType;
    @XmlElement(name = "OfferProvider", required = true)
    protected String offerProvider;
    @XmlElement(name = "Subscriber_No", required = true)
    protected String subscriberNo;
    @XmlElement(name = "OperatorId")
    protected String operatorId;
    @XmlElement(name = "OrigSourceSystem")
    protected String origSourceSystem;
    @XmlElement(name = "OrigTxnRefId")
    protected String origTxnRefId;
    @XmlElement(name = "OrigTxnRefDate")
    protected String origTxnRefDate;
    @XmlElement(name = "CustomRef", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected CustomRefType customRef;

    /**
     * Gets the value of the transactionReference property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionReferenceType }
     *     
     */
    public TransactionReferenceType getTransactionReference() {
        return transactionReference;
    }

    /**
     * Sets the value of the transactionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionReferenceType }
     *     
     */
    public void setTransactionReference(TransactionReferenceType value) {
        this.transactionReference = value;
    }

    /**
     * Gets the value of the circleId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCircleId() {
        return circleId;
    }

    /**
     * Sets the value of the circleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCircleId(String value) {
        this.circleId = value;
    }

    /**
     * Gets the value of the offerType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferType() {
        return offerType;
    }

    /**
     * Sets the value of the offerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferType(String value) {
        this.offerType = value;
    }

    /**
     * Gets the value of the offerProvider property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferProvider() {
        return offerProvider;
    }

    /**
     * Sets the value of the offerProvider property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferProvider(String value) {
        this.offerProvider = value;
    }

    /**
     * Gets the value of the subscriberNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberNo() {
        return subscriberNo;
    }

    /**
     * Sets the value of the subscriberNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberNo(String value) {
        this.subscriberNo = value;
    }

    /**
     * Gets the value of the operatorId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatorId() {
        return operatorId;
    }

    /**
     * Sets the value of the operatorId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorId(String value) {
        this.operatorId = value;
    }

    /**
     * Gets the value of the origSourceSystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigSourceSystem() {
        return origSourceSystem;
    }

    /**
     * Sets the value of the origSourceSystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigSourceSystem(String value) {
        this.origSourceSystem = value;
    }

    /**
     * Gets the value of the origTxnRefId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigTxnRefId() {
        return origTxnRefId;
    }

    /**
     * Sets the value of the origTxnRefId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigTxnRefId(String value) {
        this.origTxnRefId = value;
    }

    /**
     * Gets the value of the origTxnRefDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigTxnRefDate() {
        return origTxnRefDate;
    }

    /**
     * Sets the value of the origTxnRefDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigTxnRefDate(String value) {
        this.origTxnRefDate = value;
    }

    /**
     * Gets the value of the customRef property.
     * 
     * @return
     *     possible object is
     *     {@link CustomRefType }
     *     
     */
    public CustomRefType getCustomRef() {
        return customRef;
    }

    /**
     * Sets the value of the customRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomRefType }
     *     
     */
    public void setCustomRef(CustomRefType value) {
        this.customRef = value;
    }

}
