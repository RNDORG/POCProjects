package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.config.service.ConfigService;
import com.wipro.common.fileoperations.service.GenericFileService;
import com.wipro.epc.domain.CachedProductDetails;
import com.wipro.epc.domain.EpcAttributeMaster;
import com.wipro.epc.domain.EpcNotificationTemplate;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcOrderCharge;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductAvailability;
import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.domain.EpcProductCompatibility;
import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductLocation;
import com.wipro.epc.domain.EpcProductMigration;
import com.wipro.epc.domain.EpcProductProviderSystem;
import com.wipro.epc.domain.EpcProductSalesChannel;
import com.wipro.epc.domain.EpcProductSegment;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.domain.EpcTriggerOrderRule;
import com.wipro.epc.dto.OrderType;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.CachedProductDetailsRepository;
import com.wipro.epc.repositories.ComplexSearchInputRepository;
import com.wipro.epc.repositories.EpcAttributeMasterRepository;
import com.wipro.epc.repositories.EpcLookupMasterRepository;
import com.wipro.epc.repositories.EpcProductAttributeRepository;
import com.wipro.epc.repositories.EpcProductAvailabilityRepository;
import com.wipro.epc.repositories.EpcProductCommunityRepository;
import com.wipro.epc.repositories.EpcProductCompatibilityRepository;
import com.wipro.epc.repositories.EpcProductInitChannelRepository;
import com.wipro.epc.repositories.EpcProductLocationRepository;
import com.wipro.epc.repositories.EpcProductMigrationRepository;
import com.wipro.epc.repositories.EpcProductProviderSystemRepository;
import com.wipro.epc.repositories.EpcProductSalesChannelRepository;
import com.wipro.epc.repositories.EpcProductSegmentRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.util.BytesUtil;
import com.wipro.epc.util.Constants;



@Service
public class CachedProductDetailsService {
	
	private static Logger logger = LoggerFactory.getLogger(CachedProductDetailsService.class);
	
	@Autowired
	CachedProductDetailsRepository cachedProductDetailsRepository;  
	
	@Autowired
	EpcProductSpecificationRepository epcProductSpecificationRepository;
	
	@Autowired
	ComplexSearchInputService complexSearchInputService;
	
	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	CachedProductDetailsHelperService cachedProductDetailsHelperService;
	
	/**
	 * EpcProductSpecificationService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	
	/**
	 * EpcLookupMasterService ComplexSearchInputService.java
	 */
	@Autowired
	EpcLookupMasterService epcLookupMasterService;

	/**
	 * ComplexSearchInputRepository ComplexSearchInputService.java
	 */
	@Autowired
	ComplexSearchInputRepository searchRepository;
	
	/**
	 * EpcProductAvailabilityService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductAvailabilityRepository epcProductAvailabilityRepo;
	
	/**
	 * EpcProductSalesChannelService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductSalesChannelRepository epcProductSalesChannelRepo;
	
	/**
	 * EpcProductInitChannelService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductInitChannelRepository epcProductInitChannelRepo;
	
	/**
	 * EpcProductLocationService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductLocationRepository epcProductLocationRepo;
	
	/**
	 * EpcProductSegmentService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductSegmentRepository epcProductSegmentRepo;

	/**
	 * EpcProductCompatibilityService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductCompatibilityRepository epcProductCompatibilityRepo;
	
	/**
	 * EpcProductAttributeService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductAttributeRepository epcProductAttributeRepo;
	
	/**
	 * EpcProductMigrationService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductMigrationRepository epcproductMigrationRepo;
	
	/**
	 * EpcLookupMasterRepository ComplexSearchInputService.java
	 */
	@Autowired
	EpcLookupMasterRepository lookUpRepository;
	
	/**
	 * EpcLocationService ComplexSearchInputService.java
	 */
	@Autowired
	EpcLocationService epcLocationService;
	
	/**
	 * EpcProductHeirarchyService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductHeirarchyService epcProductHeirarchyService;
	
	/**
	 * EpcNotificationTemplateService ComplexSearchInputService.java
	 */
	@Autowired
	EpcNotificationTemplateService epcNotificationTemplateService;
	
	/**
	 * EpcProductCommunityService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductCommunityRepository epcProductCommunityRepo;
	
	/**
	 * EpcOrderChannelRuleService ComplexSearchInputService.java
	 */
	@Autowired
	EpcOrderChannelRuleService epcOrderChannelRuleService;
	
	/**
	 * EpcProductDecompositionService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductDecompositionService epcProductDecompositionService;
	
	/**
	 * EpcOrderTriggerRuleService ComplexSearchInputService.java
	 */
	@Autowired
	EpcOrderTriggerRuleService epcOrderTriggerRuleService;
	
	/**
	 * EpcProductNetworkTplService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductNetworkTplService epcProductNetworkTplService;
	
	/**
	 * EpcAttributeMasterService ComplexSearchInputService.java
	 */
	@Autowired
	EpcAttributeMasterService epcAttributeMasterService;
	
	/**
	 * EpcProductNetworkTplMapService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductNetworkTplMapService epcProductNetworkTplMapService;
	
	/**
	 * GenericFileService ComplexSearchInputService.java
	 */
	@Autowired
	GenericFileService genericFileService;
	
	/**
	 * EpcProductProviderSystemService ComplexSearchInputService.java
	 */
	@Autowired
	EpcProductProviderSystemRepository epcProductProviderSystemRepo;
	
	@Autowired
	EpcAttributeMasterRepository EpcAttributeMasterRepo;
	
	/**
	 * ConfigService ComplexSearchInputService.java
	 */
	@Autowired
	ConfigService configService;
	
	
	public boolean saveCachedProducts(List<CachedProductDetails> prods){
		cachedProductDetailsRepository.save(prods);
		return true;
	}
	
	public List<CachedProductDetails> searchProductCache(String query)
	{
		List<CachedProductDetails> list = new ArrayList<CachedProductDetails>();
		try {
		list = cachedProductDetailsRepository.getList(query);
		} catch (Exception e) {
		throw new EPCException(
				"Error occurred while fetching results from database.\n"
						+ " Query: " + query + "\n"
						+ " Exception: " + e.getMessage(), e);
	}
		return list;
	}
	
	public void notifyProductCache(int id,String entityName){
		
		cacheProduct( cacheProduct( id ) );
		
	}
	
	public void cacheProduct(EpcProductSpecification prodSpec) {     // saveCachedProductToDB() 
		CachedProductDetails cachedProduct = new CachedProductDetails();
			cachedProduct.setId(prodSpec.getProductId());
			try {
				cachedProduct.setValue(BytesUtil.toByteArray(prodSpec));
				cachedProduct.setStatus(Constants.CACHED_PRODUCT_DETAILS_STATUS_ACTIVE);
				cachedProductDetailsHelperService.cacheOneProduct(cachedProduct);
			} catch (Exception e) {
				System.out.println("EXCEPTION cacheproduct() : "+e.getMessage());
				logger.warn("Error occurred while caching the product {} and error is : {}", prodSpec.getProductShortCode(), e.getMessage());
			}
		}
	
	public EpcProductSpecification cacheProduct(Integer productId) {  // createCachedProductInMemory() 
			List<String> ids = new ArrayList<String>();
			EpcProductSpecification prodSpec = epcProductSpecificationRepository.findByProductId(productId).get(0);
			List<EpcProductSegment> segments = epcProductSegmentRepo.findSegmentsByProductId(productId);
			if (segments != null) {
				prodSpec.setEpcProductSegment(segments);
			}
			List<EpcProductProviderSystem> providers = epcProductProviderSystemRepo.findProvidersByProductId(productId);
			if (providers != null) {
				prodSpec.setEpcProductProvider(providers);
			}
			List<EpcProductLocation> locations = epcProductLocationRepo.findLocationsByProductId(productId);
			if (locations != null) {
				prodSpec.setEpcProductLocation(locations);
			}
			List<EpcProductSalesChannel> sales = epcProductSalesChannelRepo.findChannelsByProductId(productId);
			if (sales != null) {
				prodSpec.setEpcProductSalesChannel(sales);
			}
			List<EpcProductAvailability> availabilities =epcProductAvailabilityRepo.findAvailabilitiesByProductId(productId);
			if (availabilities != null) {
				prodSpec.setEpcProductAvailability(availabilities);
			}
			List<EpcProductInitChannel> initChannels = epcProductInitChannelRepo.findInitChannelByProductId(productId);
			if (initChannels != null && !initChannels.isEmpty()) {
				Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
				Set<String> notificationIds = new HashSet<String>();
				List<EpcNotificationTemplate> notificationTemplates = null;
				for (EpcProductInitChannel initChannel : initChannels) {
					if (initChannel
							.getNotificationTemplateId() != null) {
						notificationIds.add(String.valueOf(initChannel
								.getNotificationTemplateId()));
						
					}
				}
				if(!notificationIds.isEmpty()){
					ids.addAll(notificationIds);
					notificationRequestParams.put("notificationTemplateId", ids);
					notificationTemplates = epcNotificationTemplateService.searchEpcNotificationTemplate(notificationRequestParams);
					for (EpcProductInitChannel initChannel : initChannels) {
						for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
							if (notificationtemplate
									.getNotificationTemplateId()
									.equals(initChannel
											.getNotificationTemplateId())) {
								initChannel
										.setEpcNotificationTemplate(notificationtemplate);
							}
						}
					}
				}
				prodSpec.setEpcProductInitChannel(initChannels);
				ids.clear();
			}
			
			List<EpcProductCompatibility> compatibilities =epcProductCompatibilityRepo.findCompatibilityByProductId(productId);
			if (compatibilities != null) {
				Set<String> prodIds = new HashSet<String>();
				for (EpcProductCompatibility compatibility : compatibilities) {
					prodIds.add(String.valueOf(compatibility.getOtherProductId()));
				}
	
				if (!prodIds.isEmpty()) {
					Map<String, List<String>> productIdsRequestParams = new HashMap<String, List<String>>();
					ids.addAll(prodIds);
					productIdsRequestParams.put("productId", ids);
					List<EpcProductSpecification> compatibleProds = epcProductSpecificationService
							.getBasicProductSpecByID(productIdsRequestParams);
					for (EpcProductCompatibility comp : compatibilities) {
	
						if (compatibleProds != null) {
							for (EpcProductSpecification comProdSpec : compatibleProds) {
								if (comp.getOtherProductId().equals(
										comProdSpec.getProductId())) {
									comp.setOtherProductSpecification(comProdSpec);
								}
							}
						}
					}
				}
				ids.clear();
				prodSpec.setEpcProductCompatibility(compatibilities);
			}

			List<EpcProductAttribute> attributes = epcProductAttributeRepo
					.findByProductId(productId);
			if (attributes != null) {
				List<EpcAttributeMaster> epcAttrMasters = EpcAttributeMasterRepo
						.getCharList("select * from epc_attribute_master where attribute_ctg='"
								+ Constants.ATTRIBUTE_CTG_PRODUCTCTG
								+ "' or attribute_ctg='"
								+ Constants.ATTRIBUTE_CTG_TARIFFCTG + "'");
				;
				List<Integer> tariffIds = new ArrayList<Integer>();
				List<Integer> charsIds = new ArrayList<Integer>();
				Map<Integer, EpcAttributeMaster> attrMaster = new HashMap<Integer, EpcAttributeMaster>();
				for (EpcAttributeMaster attrM : epcAttrMasters) {
					if (attrM.getAttributeCtg().equals(
							Constants.ATTRIBUTE_CTG_PRODUCTCTG)) {
						charsIds.add(attrM.getAttributeId());
					} else {
						tariffIds.add(attrM.getAttributeId());
					}
					attrMaster.put(attrM.getAttributeId(), attrM);
				}
				List<EpcProductAttribute> chars = new ArrayList<EpcProductAttribute>();
				List<EpcProductAttribute> tariffs = new ArrayList<EpcProductAttribute>();
				for (EpcProductAttribute attr : attributes) {
					if (tariffIds.contains(attr.getAttributeId())) {
						attr.setEpcAttributeMaster(attrMaster.get(attr
								.getAttributeId()));
						tariffs.add(attr);
					} else if (charsIds.contains(attr.getAttributeId())) {
						attr.setEpcAttributeMaster(attrMaster.get(attr
								.getAttributeId()));
						chars.add(attr);
					}
				}
				if (!tariffs.isEmpty()) {
					prodSpec.setEpcProductTariff(tariffs);
				}
				if (!chars.isEmpty()) {
					prodSpec.setEpcProductCharacteristic(chars);
				}
			}
			
			

			
			List<EpcProductMigration> migrations = epcproductMigrationRepo
					.findMigrationBysourceProductId(productId);
			if (migrations != null) {
				Set<String> prodIds = new HashSet<String>();
				for (EpcProductMigration migration : migrations) {
					prodIds.add(String.valueOf(migration.getTargetProductId()));
				}
	
				// for loading all the products details.
				if (!prodIds.isEmpty()) {
					Map<String, List<String>> productIdsRequestParams = new HashMap<String, List<String>>();
					ids.addAll(prodIds);
					productIdsRequestParams.put("productId", ids);
					List<EpcProductSpecification> migrationProds = epcProductSpecificationService
							.getBasicProductSpecByID(productIdsRequestParams);
					for (EpcProductMigration mig : migrations) {
						for (EpcProductSpecification migProdSpec : migrationProds) {
							if (mig.getTargetProductId().equals(
									migProdSpec.getProductId())) {
								mig.setTargetProductSpec(migProdSpec);
								;
							}
						}
					}
	
				}
				ids.clear();
				prodSpec.setEpcProductMigration(migrations);
			}

			
				
			List<EpcProductCommunity> communities = epcProductCommunityRepo
					.findCommunitiesByProductId(productId);
			if (communities != null) {
				prodSpec.setEpcProductCommunity(communities);
			}
			Map<String, OrderType> orderTypeMap = new HashMap<String, OrderType>();
			orderTypeMap.put(Constants.ORDER_TYPE_OFFER_SUBS, fetchOrderTypeDetails(Constants.ORDER_TYPE_OFFER_SUBS, prodSpec));
			orderTypeMap.put(Constants.ORDER_TYPE_OFFER_UNSU, fetchOrderTypeDetails(Constants.ORDER_TYPE_OFFER_UNSU, prodSpec));
			prodSpec.setExtension(orderTypeMap);
			
		return prodSpec;
	}
	
		private OrderType fetchOrderTypeDetails(String orderType,
				EpcProductSpecification prodSpec) {
	
			OrderType orderTypeTemp = new OrderType();
			orderTypeTemp.setOrderType(orderType);
			MultiValueMap<String, String> searchCriteria = new LinkedMultiValueMap<String, String>();
			searchCriteria.add("orderType", orderType);
			List<EpcOrderChannelRule> epcOrderChannelRules = epcOrderChannelRuleService
					.searchEpcOrderChannelRule(searchCriteria);
	
			MultiValueMap<String, String> searchCriteriaActivityCharge = new LinkedMultiValueMap<String, String>();
			List<String> orderChannelRuleIds = new ArrayList<String>();
			if (epcOrderChannelRules != null && !epcOrderChannelRules.isEmpty()) {
				List<EpcNotificationTemplate> notificationTemplates = null;
				Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
				List<String> notificationIds = new ArrayList<String>();
				for (EpcOrderChannelRule epcOrderChannelRule : epcOrderChannelRules) {
					notificationIds.add(String.valueOf(epcOrderChannelRule
							.getNotificationTemplateId()));
				}
				if (!notificationIds.isEmpty()) {
					notificationRequestParams.put("notificationTemplateId",
							notificationIds);
					notificationTemplates = epcNotificationTemplateService
							.searchEpcNotificationTemplate(notificationRequestParams);
				}
				for (EpcOrderChannelRule epcOrderChannelRule : epcOrderChannelRules) {
					orderChannelRuleIds.add(String.valueOf(epcOrderChannelRule
							.getOrderChannelRuleId()));
				}
				searchCriteriaActivityCharge.put("orderChannelRuleId",
						orderChannelRuleIds);
				List<EpcOrderCharge> EpcOrderCharges = epcOrderChannelRuleService
						.searchEpcActivityChargeByChannelRuleId(searchCriteriaActivityCharge);
				for (EpcOrderChannelRule epcOrderChannelRule : epcOrderChannelRules) {
					if (EpcOrderCharges != null) {
						for (EpcOrderCharge epcOrderCharge : EpcOrderCharges) {
							if (epcOrderCharge.getOrderChannelRuleId().equals(
									epcOrderChannelRule.getOrderChannelRuleId())) {
								epcOrderChannelRule
										.setEpcOrderCharge(epcOrderCharge);
							}
						}
					}
					if (notificationTemplates != null) {
						for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
							if (notificationtemplate.getNotificationTemplateId()
									.equals(epcOrderChannelRule
											.getNotificationTemplateId())) {
								epcOrderChannelRule
										.setEpcNotificationTemplate(notificationtemplate);
							}
						}
					}
	
				}
				orderTypeTemp.setEpcOrderChannelRule(epcOrderChannelRules);
			}
	
			List<EpcProductDecomposition> decompositions = epcProductDecompositionService
					.getDecompositionsByWhereClause("where product_short_code = '"
							+ prodSpec.getProductShortCode()
							+ "' and order_type = '" + orderType + "'");
			if (decompositions == null || decompositions.isEmpty()) {
				decompositions = epcProductDecompositionService
						.getDecompositionsByWhereClause("where product_short_code is null and order_type = '"
								+ orderType
								+ "' and product_classification = '"
								+ prodSpec.getProductClassification()
								+ "' and product_sub_family = '"
								+ prodSpec.getProductSubFamily() + "'");
			}
			if (decompositions == null || decompositions.isEmpty()) {
				decompositions = epcProductDecompositionService
						.getDecompositionsByWhereClause("where product_short_code is null and order_type = '"
								+ orderType
								+ "' and product_classification is null"
								+ " and product_sub_family = '"
								+ prodSpec.getProductSubFamily() + "'");
			}
	
			if (decompositions == null || decompositions.isEmpty()) {
				decompositions = epcProductDecompositionService
						.getDecompositionsByWhereClause("where product_short_code is null and order_type = '"
								+ orderType
								+ "' and product_classification is null "
								+ " and product_sub_family is null ");
			}
	
			if (decompositions != null && !decompositions.isEmpty()) {
				Map<String, List<String>> notificationRequestParams = new HashMap<String, List<String>>();
				List<String> notificationIds = new ArrayList<String>();
				List<EpcNotificationTemplate> notificationTemplates = null;
	
				for (EpcProductDecomposition epcProductDecomposition : decompositions) {
					notificationIds.add(String.valueOf(epcProductDecomposition
							.getNotificationTemplateId()));
				}
				if (!notificationIds.isEmpty()) {
					notificationRequestParams.put("notificationTemplateId",
							notificationIds);
					notificationTemplates = epcNotificationTemplateService
							.searchEpcNotificationTemplate(notificationRequestParams);
				}
				if (decompositions != null) {
					for (EpcProductDecomposition epcProductDecomposition : decompositions) {
						if (notificationTemplates != null) {
							for (EpcNotificationTemplate notificationtemplate : notificationTemplates) {
								if (epcProductDecomposition
										.getNotificationTemplateId() != null
										&& epcProductDecomposition
												.getNotificationTemplateId()
												.equals(notificationtemplate
														.getNotificationTemplateId())) {
									epcProductDecomposition
											.setEpcNotificationTemplate(notificationtemplate);
								}
							}
						}
	
					}
				}
				orderTypeTemp.setEpcProductDecomposition(decompositions);
			}
	
			List<EpcTriggerOrderRule> epcTriggerOrderRules = epcOrderTriggerRuleService
					.getTriggerOrderRulesByWhereClause("where source_product_short_code = '"
							+ prodSpec.getProductShortCode()
							+ "' and source_order_type = '" + orderType + "'");
			if (epcTriggerOrderRules == null || epcTriggerOrderRules.isEmpty()) {
				epcTriggerOrderRules = epcOrderTriggerRuleService
						.getTriggerOrderRulesByWhereClause("where source_product_short_code is null and source_order_type = '"
								+ orderType
								+ "' and source_product_classification = '"
								+ prodSpec.getProductClassification()
								+ "' and source_product_sub_family = '"
								+ prodSpec.getProductSubFamily() + "'");
			}
			if (epcTriggerOrderRules == null || epcTriggerOrderRules.isEmpty()) {
				epcTriggerOrderRules = epcOrderTriggerRuleService
						.getTriggerOrderRulesByWhereClause("where source_product_short_code is null and source_order_type = '"
								+ orderType
								+ "' and source_product_classification is null"
								+ " and source_product_sub_family = '"
								+ prodSpec.getProductSubFamily() + "'");
			}
			if (epcTriggerOrderRules == null || epcTriggerOrderRules.isEmpty()) {
				epcTriggerOrderRules = epcOrderTriggerRuleService
						.getTriggerOrderRulesByWhereClause("where source_product_short_code is null and source_order_type = '"
								+ orderType
								+ "' and source_product_classification is null "
								+ " and source_product_sub_family is null ");
			}
			if (epcTriggerOrderRules != null && !epcTriggerOrderRules.isEmpty()) {
				orderTypeTemp.setEpcTriggerOrderRule(epcTriggerOrderRules);
			}
			
			return orderTypeTemp;
		}
}
