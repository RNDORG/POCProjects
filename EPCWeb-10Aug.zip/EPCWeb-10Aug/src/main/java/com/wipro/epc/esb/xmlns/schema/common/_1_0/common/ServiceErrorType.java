
package com.wipro.epc.esb.xmlns.schema.common._1_0.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ServiceErrorType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceErrorType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}BaseErrorInfoType">
 *       &lt;sequence>
 *         &lt;element name="ErrorCode" type="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}ServiceErrorCodeType"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceErrorType", propOrder = {
    "errorCode"
})
public class ServiceErrorType
    extends BaseErrorInfoType
{

    @XmlElement(name = "ErrorCode", required = true)
    @XmlSchemaType(name = "string")
    protected ServiceErrorCodeType errorCode;

    /**
     * Gets the value of the errorCode property.
     * 
     * @return
     *     possible object is
     *     {@link ServiceErrorCodeType }
     *     
     */
    public ServiceErrorCodeType getErrorCode() {
        return errorCode;
    }

    /**
     * Sets the value of the errorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServiceErrorCodeType }
     *     
     */
    public void setErrorCode(ServiceErrorCodeType value) {
        this.errorCode = value;
    }

}
