package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductNetworkTpl;

/**
 * @author KE334465
 *
 */
public interface EpcProductNetworkTplRepository extends CrudRepository<EpcProductNetworkTpl, Integer>, EpcProductNetworkTplRepositoryCustom {

	
	/*@Query(value="select * from epc_product_network_tpl where template_id=:template_id", nativeQuery=true)
	List<EpcProductNetworkTpl> findByTemplateId(@Param("template_id") String productShortCode);*/
	
	/**
	 * @return
	 */
	@Query(value="select distinct new com.wipro.epc.domain.EpcProductNetworkTpl(e.templateName) from EpcProductNetworkTpl e order by e.templateName")
	List<EpcProductNetworkTpl> getNetworkProfiles();
	
	/**
	 * @param productId
	 * @return
	 */
	@Query(value=  "select * from epc_product_network_tpl where template_name=(select template_name from "
			+ "epc_product_network_tpl_map where product_id = :productId)", nativeQuery =true)
	List<EpcProductNetworkTpl> getNetworkTplByProductId(@Param("productId") Integer productId);



}
