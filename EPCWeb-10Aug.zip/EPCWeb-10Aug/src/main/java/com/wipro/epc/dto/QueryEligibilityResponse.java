package com.wipro.epc.dto;

import com.wipro.epc.domain.EpcProductSpecification;

/**
 * @author Developer
 * @version 1.0
 * type QueryEligibilityResponse
 */
public class QueryEligibilityResponse {
	
	/**
	 * boolean QueryEligibilityResponse.java
	 */
	private boolean isEligible; 
	
	private String subFamily;
	
	/**
	 * String QueryEligibilityResponse.java
	 */
	private String responseCode;
	/**
	 * String QueryEligibilityResponse.java
	 */
	private String remarks;
	/**
	 * EpcProductSpecification QueryEligibilityResponse.java
	 */
	private EpcProductSpecification addonEligibleProduct;
	/**
	 * String QueryEligibilityResponse.java
	 */
	private String downStream;
	
	/**
	 * @return
	 */
	public boolean isEligible() {
		return isEligible;
	}
	/**
	 * @param isEligible
	 */
	public void setEligible(boolean isEligible) {
		this.isEligible = isEligible;
	}
	/**
	 * @return
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	/**
	 * @return
	 */
	public EpcProductSpecification getAddonEligibleProduct() {
		return addonEligibleProduct;
	}
	/**
	 * @param addonEligibleProduct
	 */
	public void setAddonEligibleProduct(EpcProductSpecification addonEligibleProduct) {
		this.addonEligibleProduct = addonEligibleProduct;
	}
	/**
	 * @return the downStream
	 */
	public String getDownStream() {
		return downStream;
	}
	/**
	 * @param downStream the downStream to set
	 */
	public void setDownStream(String downStream) {
		this.downStream = downStream;
	}
	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}
	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	/**
	 * @return the subFamily
	 */
	public String getSubFamily() {
		return subFamily;
	}
	/**
	 * @param subFamily the subFamily to set
	 */
	public void setSubFamily(String subFamily) {
		this.subFamily = subFamily;
	} 
		
}
