package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductNetworkTpl;


/**
 * @author KE334465
 *
 */
public interface EpcProductNetworkTplRepositoryCustom {

	/**
	 * @param query
	 * @return
	 */
	List<EpcProductNetworkTpl> getNetworkProfileList(String query);

}
