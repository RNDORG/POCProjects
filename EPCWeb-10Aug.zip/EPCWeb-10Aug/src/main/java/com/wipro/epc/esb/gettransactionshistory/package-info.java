@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.telenor.com.mm/getTransactionsHistory", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.wipro.epc.esb.gettransactionshistory;
