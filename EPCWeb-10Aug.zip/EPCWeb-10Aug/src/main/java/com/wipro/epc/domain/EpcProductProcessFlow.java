package com.wipro.epc.domain;



import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The persistent class for the epc_product_network_tpl database table.
 * @version 1.0
 * @author VI251443
 *
 */
/**
 * @author Developer
 * @version 1.0
 * type EpcProductProcessFlow
 */
@Entity
@Table(name = "epc_product_process_flow")
public class EpcProductProcessFlow  implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Integer EpcProductProcessFlow.java
	 */
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "product_process_flow_id", unique = true, nullable = false)
	private Integer productProcessFlowId;
	/**
	 * Integer EpcProductProcessFlow.java
	 */
	@Column(name = "function_id", nullable = false)
	private Integer functionId;
	/**
	 * String EpcProductProcessFlow.java
	 */
	@Column(name = "from_status")
	private String fromStatus;
	/**
	 * String EpcProductProcessFlow.java
	 */
	@Column(name = "to_status", nullable = false)
	private String toStatus;
	/**
	 * String EpcProductProcessFlow.java
	 */
	@Column(name = "status", nullable = false)
	private String status;
	/**
	 * String EpcProductProcessFlow.java
	 */
	@Column(name = "state_transition_remarks", nullable = false)
	private String stateTransitionRemarks;
	/**
	 * Date EpcProductProcessFlow.java
	 */
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", length = 19)
	private Date createdDate;
	/**
	 * String EpcProductProcessFlow.java
	 */
	@JsonIgnore
	@Column(name = "created_by", nullable = false, length = 25)
	private String createdBy;
	/**
	 * Date EpcProductProcessFlow.java
	 */
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", length = 19)
	private Date modifiedDate;
	/**
	 * String EpcProductProcessFlow.java
	 */
	@JsonIgnore
	@Column(name = "modified_by", length = 25)
	private String modifiedBy;

	
	/**
	 * 
	 */
	public EpcProductProcessFlow() {
	}

	/**
	 * @param functionId
	 * @param toStatus
	 * @param status
	 * @param stateTransitionRemarks
	 * @param createdBy
	 */
	public EpcProductProcessFlow(Integer functionId, String toStatus, String status,String stateTransitionRemarks,
			String createdBy) {
		this.functionId = functionId;
		this.toStatus = toStatus;
		this.stateTransitionRemarks = stateTransitionRemarks;
		this.status = status;
		this.createdBy = createdBy;
	}

	/**
	 * @param functionId
	 * @param fromStatus
	 * @param stateTransitionRemarks
	 * @param toStatus
	 * @param status
	 * @param createdDate
	 * @param createdBy
	 * @param modifiedDate
	 * @param modifiedBy
	 */
	public EpcProductProcessFlow(Integer functionId, String fromStatus,String stateTransitionRemarks,
			String toStatus, String status, Date createdDate, String createdBy,
			Date modifiedDate, String modifiedBy) {
		this.functionId = functionId;
		this.fromStatus = fromStatus;
		this.toStatus = toStatus;
		this.stateTransitionRemarks = stateTransitionRemarks;
		this.status = status;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	
	public Integer getProductProcessFlowId() {
		return this.productProcessFlowId;
	}

	/**
	 * @param productProcessFlowId
	 */
	public void setProductProcessFlowId(Integer productProcessFlowId) {
		this.productProcessFlowId = productProcessFlowId;
	}

	/**
	 * @return
	 */
	
	public Integer getFunctionId() {
		return this.functionId;
	}

	/**
	 * @param functionId
	 */
	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	/**
	 * @return
	 */
	
	public String getFromStatus() {
		return this.fromStatus;
	}

	/**
	 * @param fromStatus
	 */
	public void setFromStatus(String fromStatus) {
		this.fromStatus = fromStatus;
	}
	
	/**
	 * @return
	 */
	
	public String getStateTransitionRemarks() {
		return stateTransitionRemarks;
	}

	/**
	 * @param stateTransitionRemarks
	 */
	public void setStateTransitionRemarks(String stateTransitionRemarks) {
		this.stateTransitionRemarks = stateTransitionRemarks;
	}

	/**
	 * @return
	 */
	
	public String getToStatus() {
		return this.toStatus;
	}

	/**
	 * @param toStatus
	 */
	public void setToStatus(String toStatus) {
		this.toStatus = toStatus;
	}
	
	/**
	 * @return
	 */
	
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return
	 */
	
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return
	 */
	
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
