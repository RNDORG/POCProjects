/**
 * 
 */
package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcOrderCharge;

 
public interface EpcOrderChargeRepositoryCustom {

	
	EpcOrderCharge modifyOrder(EpcOrderCharge order);

	/**
	 * @param query
	 * @return
	 */
	List<EpcOrderCharge> getList(String query);

}
