package com.wipro.epc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.dto.ProviderProductQueryInput;
import com.wipro.epc.dto.ProviderProductResponse;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.services.ProviderProductQueryService;



/**
 * @author Developer
 * @version 1.0
 * type ProviderProductQueryController
 */
@RestController
public class ProviderProductQueryController {

	private static Logger logger = LoggerFactory.getLogger(ProviderProductQueryController.class);
	/**
	 * ProviderProductQueryService ProviderProductQueryController.java
	 */
	@Autowired
	ProviderProductQueryService providerProductQueryService;
	
	/**
	 * TransactionsService ProviderProductQueryController.java
	 */
	@Autowired
	TransactionsService transactionsLogging ;

	/**
	 * ObjectMapper ProviderProductQueryController.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * TransactionStore ProviderProductQueryController.java
	 */
	@Autowired
	EPCTxnInterceptor ePCTxnInterceptor;
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/extapi/v1/queryProviderProduct", method=RequestMethod.POST)
	public List<ProviderProductResponse> queryProviderProductExt(@RequestBody ProviderProductQueryInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		String txnType="queryProviderProduct";
		String request=null;
		List<ProviderProductResponse> response=null;
		try{
		request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, queryInput);
		response=providerProductQueryService.queryProviderProduct(queryInput, allRequestParams);
		}
		catch (Exception e ) {
			logger.error("#interfaceException: " + e.getMessage());
			throw new EPCException(e.getMessage());
		}
		finally{
		ePCTxnInterceptor.postTxn(txnType,request, response);
		}
		return response;
	}
	
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/queryProviderProduct", method=RequestMethod.POST)
	public List<ProviderProductResponse> queryProviderProduct(@RequestBody ProviderProductQueryInput queryInput,@RequestParam MultiValueMap allRequestParams)
	{
		return providerProductQueryService.queryProviderProduct(queryInput, allRequestParams);
	}	
}
