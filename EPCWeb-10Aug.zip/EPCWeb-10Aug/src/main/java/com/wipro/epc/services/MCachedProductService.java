package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wipro.common.config.service.ConfigService;
import com.wipro.epc.controller.BroadcastController;
import com.wipro.epc.domain.CachedProductDetails;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.util.BytesUtil;

@Service
public class MCachedProductService {
	private static Logger logger =LoggerFactory.getLogger(MCachedProductService.class);
	
	@Autowired
	PCachedProductService pCachedProductService;
	
	@Autowired
	ConfigService configService;
	
	@Autowired
	BroadcastController broacastController;
	
	@Autowired
	BroadcastService broacastService;
	
	@Autowired
	EpcProductSpecificationRepository epcProductSpecificationRepository;
	
	private Map<Integer,EpcProductSpecification> reply=new HashMap<Integer,EpcProductSpecification>();
	
	public Map<Integer, EpcProductSpecification> getReply() {
		return reply;
	}
	public void setReply(Map<Integer, EpcProductSpecification> reply) {
		this.reply = reply;
	}
	public void reload(List<String> idValue,Integer reqId,boolean isBroadcast){ //ids = ALL, 1,2,3 | dynamic=true
		logger.info("McachedProductService.reload("+idValue.toString()+") start ");
		
		String[] ids={};
		if(idValue.get(0).equalsIgnoreCase( "all" ) ){
			ids=epcProductSpecificationRepository.getProductId();
			
		}else{
			ids=idValue.get(0).split(",");
		}
		logger.info("Number of ids : "+ids.length);
		
		pCachedProductService.clear(ids);
		pCachedProductService.reloadCacheTable(ids,reqId);
		
		if(isBroadcast){
			MultiValueMap<String, String > map = new LinkedMultiValueMap<String, String >();
			List<String> api = new ArrayList<String>();
			List<String> ports = new ArrayList<String>();
			
			api.add("cache/product/reloadMemoryLocal");
			ports.add("non-ui");
			
			map.put("to", ports);
			map.put("api", api);
			map.put("id", idValue);
			
			Map<String,String> broadcastResults = broacastService.getReplyService( map);		
			logger.info("McachedProductService.reload("+idValue.toString()+"): broadcastResults = " + broadcastResults.toString() );
		}
		logger.info("McachedProductService.reload("+idValue.toString()+ ") ends ") ;
		
		 
		
	}
	public void reloadMemory(List<String> idList){ //ids = ALL, 1,2,3 
		logger.info("#McachedProductService.reloadMemory() starts -----------------------------------");
		
		String[] ids={};
		List<String> idsAll=Arrays.asList( epcProductSpecificationRepository.getProductId() );
		
		logger.info("Number of Products in memory : " + reply.size() );
		logger.info("Requested Ids for deletion : " + idList.toString() );		
		
		if(idList.get(0).equalsIgnoreCase( "all" ) ){
			ids=epcProductSpecificationRepository.getProductId();
			logger.info( "where all = " + Arrays.asList(ids).toString() );
			deleteMemoryAll();
		}else{
			ids=idList.get(0).split(",");
			for(String id:ids){
				deleteMemoryById(id);
			}
		}
		logger.info( "Requested Memory objects deleted! ");
		logger.info( "Number of Products in Memory : " + reply.size() );
		logger.info( "Product Ids in Memory : " + reply.keySet().toString() );
		
		String ignoredIds = "";
		String idsLoadedInTable = "";
		String errorIds = ""; 
		
		for(String id:ids){  
			if( idsAll.contains(id)){
				try {
					CachedProductDetails cachedProduct = pCachedProductService.get(id);
					EpcProductSpecification prodSpec = null;
					if(cachedProduct==null || cachedProduct.getValue() == null){//pCachedProductService.get(id).getValue()
						prodSpec=pCachedProductService.reloadOne(id);		
						if(prodSpec!=null){	idsLoadedInTable = idsLoadedInTable + " " + id;}
					}else{
						prodSpec = (EpcProductSpecification)BytesUtil.toObject( cachedProduct.getValue() );//pCachedProductService.get(id).getValue()
					}
					if(prodSpec!=null){
						
						saveOrUpdate(id,prodSpec);
					} else {
						errorIds = errorIds + " " + id;
						logger.error("pCachedProductService("+id+") returned null. please check..");
					}
				} catch (Exception e) {// | ClassNotFoundException | IOException
					errorIds = errorIds + " (" + id + ")" ;
					logger.error("#Exception in reloadLocal() : "+ e.getMessage());
				}
				
			} else {
				ignoredIds = ignoredIds + " " + id;
			}
		}
		//System.out.println("In Memory Data: "+reply.toString());
		logger.info("#McachedProductService.reloadMemory() Results : " );
		logger.info("#McachedProductService.reloadMemory() IgnoredIds : " + ignoredIds );
		logger.info("#McachedProductService.reloadMemory() errorIds : " + errorIds );
		logger.info("#McachedProductService.reloadMemory() idsLoadedInTable : " + idsLoadedInTable );
		
		logger.info(" #McachedProductService.reloadMemory() end ------------------------------------- ");
	}
	synchronized void deleteMemoryAll(  ){		
		reply.clear();
	}
	synchronized void deleteMemoryById( String id ){		
		reply.remove(Integer.parseInt(id));
	}
	synchronized void saveOrUpdate( String id,EpcProductSpecification epcSpec ){
		logger.info("in saveOrUpdate("+id+",SpecObj) of McachedProductService");
		reply.put(Integer.parseInt(id), epcSpec);
	}
	EpcProductSpecification find( String id ) {
		logger.info("in find("+id+") of McachedProductService");
		if(reply.get(Integer.parseInt(id))==null){
			String[] ids=new String[]{id};
			reloadMemory(Arrays.asList(ids));
		}
		return reply.get(Integer.parseInt(id));
	}
	List<EpcProductSpecification> find( String[] ids ) {
		logger.info("in find("+Arrays.asList(ids)+") of McachedProductService");
		List<EpcProductSpecification> spec=new ArrayList<EpcProductSpecification>();
		for(String id:ids){
			if(reply.get(Integer.parseInt(id))==null){
				String[] ids1=new String[]{id};
				reloadMemory(Arrays.asList(ids1));
			}
			spec.add( reply.get(Integer.parseInt(id)) );
		}
		/*for(String id:ids){
			spec.add( reply.get(Integer.parseInt(id)) );
		}*/
		
		return spec;
	}
	
	/*private EpcProductSpecification getProductCopy(EpcProductSpecification prod){
		EpcProductSpecification copyProd = new EpcProductSpecification();
		BeanUtils.copyProperties(prod, copyProd);
		return copyProd;
	}*/
/*	
 * class MCachedProductService   {
 * 
 		private Map<id,EPCProductSpec>  mCachedProduct = new Map<,>;  //  ===== getter method  === Thread safe data   
			
			reload( ids) {  // ids = ALL, 1,2,3 
				pCachedProductService.clear( ids ); // deletes corresponding rows from cachedProductDetails table.
				pCachedProductService.reload( ids );
 *  			broadcastService.invoke(api=reloadAllLocal, ids );
			}


            // Reloads memory, does not update DB. However DB insertions may happen if no data was in DB.
 			reloadLocal(String[] ids) {  // ids = ALL, 1,2,4 
 		 *  		for ( ProductId id : all productIds  ) 
 *  				ProdSpec ps = pCachedProductService.get( id )              // check if present in CachedProductDetails Table.
 *  				if( ps == null ) ps = pCachedProductService.reload( id ); // load into cachedProductDetails table if not present.
 *  				mCachedProductService.saveOrUpdate( ps );                 // synchronized method. // always overrides.  
 *    				// try/catch and ERROR LOG for that product which gave error. 
 *  	    }
 		
  			synchronized void saveOrUpdate( EPCProductSpec ); // always overwrites, has nothing to do with Physical table.     
 			
 			EPCProductSpec find( id )     // simple getter  {
 				if id not present in memory then
 				reloadLocal( 2 );
 				return from memory.
 			}
 			
 			List<EPCProductSpec> find ( List<String> ids);  // Beware of outOfMemory error.  // simple getter
 				for ( id in ids ) {
 					find (id);
 				}
 				// return list...
 			 }
 			
 			
 		}
 		
 * 
*/
	
}
