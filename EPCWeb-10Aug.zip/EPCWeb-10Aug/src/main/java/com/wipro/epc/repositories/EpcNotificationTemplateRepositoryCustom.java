package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcNotificationTemplate;

/**
 * @author Developer
 * @version 1.0
 * type EpcNotificationTemplateRepositoryCustom
 */
public interface EpcNotificationTemplateRepositoryCustom {
    /**
     * @param query
     * @return
     */
    List<EpcNotificationTemplate> getList (String query);
 	
    /**
     * @param notification
     * @return
     */
    EpcNotificationTemplate modifyNotifications (EpcNotificationTemplate notification);

}
