package com.wipro.epc.security.menu;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.annotate.JsonMethod;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.uam.domain.Role;
import com.wipro.epc.uam.repositories.RoleRepository;


/**
 * @author Developer
 * @version 1.0
 * type UserDetailsController
 */
@RestController
public class UserDetailsController {
	
	/**
	 * RoleRepository UserDetailsController.java
	 */
	@Autowired
	RoleRepository roleRepo;
	
	/**
	 * Logger UserDetailsController.java
	 */
	private static Logger logger = LoggerFactory.getLogger(UserDetailsController.class);

    /**
     * @return
     */
    @RequestMapping(value="rest/api/v1/userDetailsService",method=RequestMethod.GET)
    @PreAuthorize("isAuthenticated()")//
    public UserDetailsForMenu userDetailsService() {
    	logger.debug( " UserDetailsController() invoked for Menu Json =============================================");
    	
    	UserDetailsForMenu userDetailsforMenu = new UserDetailsForMenu();
    	
    	 //UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    	Object principal  = auth.getPrincipal();
    	
    	
    	logger.debug( "   Authentication Class name = " + auth.getClass().getName() ); 
    	logger.debug( "   Principal Class name = " + principal.getClass().getName() );
    	logger.debug( "   Principal.toString() = " + principal.toString() );
    	logger.debug( "   auth.isAuthenticated()  " + auth.isAuthenticated() );  
    	logger.debug( "   auth.getAuthorities().toString()  " + auth.getAuthorities().toString() + " size = " + auth.getAuthorities().size() );
    	logger.debug( "   auth.toString()" + auth.toString() );
    	logger.debug( "   auth.getDetails()" + auth.getDetails() );
    	logger.debug( "   auth.getName()" + auth.getName() ); 

    	
    	
    	// We need to populate these 2 variables wisely.
    	String currentUser = null;
    	Collection<? extends GrantedAuthority> currentUserAuthorities;
    	
    	if ( principal instanceof UserDetails ) {
    		UserDetails userDetails = (UserDetails) principal; 
        	currentUser = userDetails.getUsername();
    		logger.debug("   Ok. Principal was instance of UserDetails ");
    		logger.debug("   ((UserDetails) Principal).getUsername() : " + userDetails.getUsername());
        	logger.debug("   ((UserDetails) Principal).getAuthorities() : " + userDetails.getAuthorities().toString() );
        	currentUserAuthorities = userDetails.getAuthorities();
    	} else {
    		logger.debug(" Principal was not an instance of UserDetails. Are you using CustomAuthentication ??");
    		// Perhaps we are doing JDBC authentication or custom authentication, we can't do below cast.
    		// UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        	currentUser = auth.getName(); // userDetails.getUsername();
        	currentUserAuthorities = auth.getAuthorities(); // userDetails.getAuthorities();
    	}
    	logger.debug( " UserDetailsController() ends for Menu Json =============================================");
    	
    	// This cast fails hence commented. what we really need (username and roles) is available from auth object itself !  
    	// UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    	
    	 
    	 
         userDetailsforMenu.setUserName( currentUser );
         List<String> functions = new ArrayList<String>();
         for( GrantedAuthority ga : currentUserAuthorities ) {
        	 functions.add( ga.toString() );
         }
         
         userDetailsforMenu.setFunctions(functions);
         
         //setting role
         List<Role> roleDetails= roleRepo.findRolesByUsername(currentUser);
         if(roleDetails!=null && !roleDetails.isEmpty()) {
         userDetailsforMenu.setRole(roleDetails.get(0).getRoleDescription());
         }
         //
         
         
         Menu rootMenu =getMenuAll();
         
         Iterator<Menu> iter1 = rootMenu.getSubMenu().iterator();
			while (iter1.hasNext()) {
				Menu m1 = iter1.next();
				Iterator<Menu> iter2 = m1.getSubMenu().iterator();
				while (iter2.hasNext()) {
					Menu m2 = iter2.next();
					Iterator<Menu> iter3 = m2.getSubMenu().iterator();
					while (iter3.hasNext()) {
						Menu m3 = iter3.next();
						setVisibility(m3, m2, iter3, functions);

					}
					setVisibility(m2, m1, iter2, functions);

				}

				setVisibility(m1, rootMenu, iter1, functions);

			}
         userDetailsforMenu.setMenuDetails(rootMenu);
    	
    	return userDetailsforMenu;
    }
    
    
    /**
     * @param menu
     * @param parentMenu
     * @param iter
     * @param functions
     */
    private void setVisibility(Menu menu, Menu parentMenu, Iterator<Menu> iter,
			List<String> functions) {

		if (menu.isVisible() == true || functions.contains("Page_"+menu.getTarget())) {
			menu.setVisible(true);
			parentMenu.setVisible(true);
		} else {

			iter.remove();
		}

	}
    
    /**
     * @return
     */
    public static Menu getMenuAll() {
		Menu rootMenu = new Menu();
		ObjectMapper mapper = new ObjectMapper().setVisibility(JsonMethod.FIELD, Visibility.ANY);
		mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			ClassPathResource cpr = new ClassPathResource("static/json/menu.json");	
			//ClassPathResource cpr = new ClassPathResource("com/wipro/epc/security/menu/menu.json");
			InputStream is = cpr.getInputStream();
			rootMenu = mapper.readValue(is, Menu.class);
		} catch (JsonGenerationException e) {
			
			logger.error(ExceptionUtils.getStackTrace(e));
			
		} catch (JsonMappingException e) {
			
			logger.error(ExceptionUtils.getStackTrace(e));
			
		} catch (IOException e) {
			
			logger.error(ExceptionUtils.getStackTrace(e));
			
		}

		return rootMenu;

      }
    
    
    
}
