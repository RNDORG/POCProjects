package com.wipro.epc.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.domain.EpcActivityChannelRule;
import com.wipro.epc.repositories.ActivityValidationRepository;


/**
 * @author Developer
 * @version 1.0
 * type ActivityValidationService
 */
@Service
public class ActivityValidationService {

	/**
	 * ActivityValidationRepository ActivityValidationService.java
	 */
	@Autowired
	ActivityValidationRepository repository;
	
	/**
	 * @param orderList
	 * @return
	 */
	@Transactional
	public int validateActivity(EpcActivityChannelRule orderList)
			{
				
				int validType = repository.validateActivity(orderList);
				return validType;
		
			}
}
