package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;


import com.wipro.epc.domain.EpcProductSalesChannel;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductSalesChannelRepository;
import com.wipro.epc.uam.definitions.MetaInfo;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductSalesChannelService
 */
@Service
public class EpcProductSalesChannelService {
	
	/**
	 * EpcProductSalesChannelRepository EpcProductSalesChannelService.java
	 */
	@Autowired
	EpcProductSalesChannelRepository epcProductSalesChannelRepository;
	
	
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductSalesChannel> searchEpcProductSalesChannel(
			Map<String, List<String>> allRequestParams) {
		String with = "";
		
		if (allRequestParams.get("with") != null) {
			with = allRequestParams.get("with").toString();
			with = with.substring(1, 4);
		}

		allRequestParams.remove("with");
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductSalesChannel.class.getName(), null);
		List<EpcProductSalesChannel> listOfEpcProductSalesChannelReturned = null;
		try {
				listOfEpcProductSalesChannelReturned = epcProductSalesChannelRepository.getList(queryBuilder);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return listOfEpcProductSalesChannelReturned;
	}

	
	/**
	 * @param productSalesChannelList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductSalesChannel> manageProductSalesChannels(List<EpcProductSalesChannel> productSalesChannelList, String createdBy )
	{
		List<EpcProductSalesChannel> retListOfEpcProductSalesChannel = new ArrayList<EpcProductSalesChannel>();

		for (EpcProductSalesChannel productSalesChannel : productSalesChannelList) {
			
				productSalesChannel = manageProductSalesChannel(productSalesChannel, createdBy);
				if((productSalesChannel.getMetaInfo().get("STATUS")==null))
				{
					productSalesChannel.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
				}
			
			
			retListOfEpcProductSalesChannel.add(productSalesChannel);
		}
		return retListOfEpcProductSalesChannel;
	}
	
	/**
	 * @param productSalesChannel
	 * @param createdBy
	 * @return
	 */
	EpcProductSalesChannel manageProductSalesChannel(EpcProductSalesChannel productSalesChannel, String createdBy)
	{
		EpcProductSalesChannel retProductSalesChannel = null;
		switch (productSalesChannel.getMetaInfo().get("OPERATION")) {

		case "CREATE":retProductSalesChannel = createProductSalesChannel(productSalesChannel, createdBy);
					  break;
		case "UPDATE":retProductSalesChannel = modifyProductSalesChannel(productSalesChannel, createdBy);
					  break;
		case "DELETE":retProductSalesChannel = deleteProductSalesChannel(productSalesChannel);
					  break;
		default:
			throw new EPCException("not supported");
		}
		return retProductSalesChannel;
		
	}
	/**
	 * @param productSalesChannel
	 * @return
	 */
	EpcProductSalesChannel deleteProductSalesChannel(EpcProductSalesChannel productSalesChannel) {
		
		epcProductSalesChannelRepository.delete(productSalesChannel.getProductSalesChannelId());
		return productSalesChannel;
	}

	/**
	 * @param productSalesChannel
	 * @param lastUpdatedBy
	 * @return
	 */
	EpcProductSalesChannel modifyProductSalesChannel(EpcProductSalesChannel productSalesChannel, String lastUpdatedBy) {
		productSalesChannel.setModifiedBy(lastUpdatedBy);
		return epcProductSalesChannelRepository.modifyProductSalesChannel(productSalesChannel);
	
	}

	/**
	 * @param productSalesChannel
	 * @param createdBy
	 * @return
	 */
	EpcProductSalesChannel createProductSalesChannel(EpcProductSalesChannel productSalesChannel, String createdBy) {
		productSalesChannel.setCreatedBy(createdBy);
		productSalesChannel.setCreatedDate(new Date());
		/*productSalesChannel.setStartDate(new Date());
		productSalesChannel.setEndDate(new Date());*/
		epcProductSalesChannelRepository.save(productSalesChannel);
		return productSalesChannel;
	}

	

}
