package com.wipro.epc.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author Developer
 * @version 1.0
 * type DemoHttpBasicController
 */
@RestController
public class DemoHttpBasicController {
	
	/**
	 * @return
	 */
	@RequestMapping(value="/demo1")
	public String demohttp(){
		return "Hi...HttpBasic Authentication is working now";
		
	}
	
	/**
	 * @return
	 */
	@RequestMapping(value="/hello1")
	public String home1() {
		return "Hello World 1...form login authentication";
	}
	

	/**
	 * @return
	 */
	@RequestMapping(value="/hello2")
	public String home2() {
		return "Hello World 2...form login authentication";
	}

}
