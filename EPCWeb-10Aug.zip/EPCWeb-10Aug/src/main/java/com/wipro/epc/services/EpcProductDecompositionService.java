package com.wipro.epc.services;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.domain.EpcProductDecomposition;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductDecompositionRepository;
import com.wipro.epc.uam.definitions.MetaInfo;

/**
 * This is the service class for EpcProductDecomposition 
 * We can search and modify the data which is there in DB. 
 * @version 1.0
 * @author VI251443
 */
@Service
public class EpcProductDecompositionService {
	
	private static Logger logger = LoggerFactory.getLogger(EpcProductDecompositionService.class);
	
	@Autowired
	EpcProductDecompositionRepository epcProductDecompositionRepository;
	
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	
	@PersistenceContext
	EntityManager em; 

	@Autowired
	EpcNotificationTemplateService epcNotificationTemplateService;
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
  public List<EpcProductDecomposition> searchProductDecomposition(Map<String, List<String>> allRequestParams) {

		
		String query = "select * from epc_product_decomposition where order_type = '"+allRequestParams.get("order_type").get(0)+"'";
		
		if(allRequestParams.get("product_short_code")!=null) {
			if(allRequestParams.get("product_short_code").size()>0) {
				if(!allRequestParams.get("product_short_code").get(0).equals("null") && !allRequestParams.get("product_short_code").get(0).equals("")){
					query = query + " and product_short_code = '"+allRequestParams.get("product_short_code").get(0)+"'";
				}
				else {
					query = query + " and product_short_code IS NULL";
				}
			}
			else {
				query = query + " and product_short_code IS NULL";
			}
		}
		else {
			query = query + " and product_short_code IS NULL";
		}
		
		if(allRequestParams.get("product_sub_family")!=null) {
			if(allRequestParams.get("product_sub_family").size()>0 ) {
				if(!allRequestParams.get("product_sub_family").get(0).equals("null") && !allRequestParams.get("product_sub_family").get(0).equals("")){
					query = query + " and product_sub_family = '"+allRequestParams.get("product_sub_family").get(0)+"'";
				}
				else {
					query = query + " and product_sub_family IS NULL";
				}
			}
			else {
				query = query + " and product_sub_family IS NULL";
			}
		}
		else {
			query = query + " and product_sub_family IS NULL";
		}
		
		if(allRequestParams.get("product_classification")!=null) {
			if(allRequestParams.get("product_classification").size()>0) {
				if(!allRequestParams.get("product_classification").get(0).equals("null") && !allRequestParams.get("product_classification").get(0).equals("")){
					query = query + " and product_classification = '"+allRequestParams.get("product_classification").get(0)+"'";
				}
				else {
					query = query + " and product_classification IS NULL";
				}
			}
			else {
				query = query + " and product_classification IS NULL";
			}
		}
		else {
			query = query + " and product_classification IS NULL";
		}
		
		List<EpcProductDecomposition> listOfDecompositionReturned  = epcProductDecompositionRepository.getList(query);
		//logger.info("Query Generated is "+query);
		
		return listOfDecompositionReturned;
		
	}
  
  public List<EpcProductDecomposition> searchProductDecompositionUI(Map<String, List<String>> allRequestParams) {
		List<EpcProductDecomposition> listOfDecompositionReturned  = searchProductDecomposition(allRequestParams);
		//Code added for Notification template value ------ 
		for(EpcProductDecomposition decomp : listOfDecompositionReturned){
			decomp.setEpcNotificationTemplate(epcNotificationTemplateService.getLookupValue(decomp.getNotificationTemplateId()));
		}
		return listOfDecompositionReturned;
  }
	
    /**
	 * 
	 * @param ProductDecompositionList
	 * @param txn
	 * @param allRequestParams
	 * @param createdBy
	 * @return list of EpcProductDecomposition
	 */
	@Transactional
	public List<EpcProductDecomposition> updateProductDecomposition(List<EpcProductDecomposition> ProductDecompositionList,boolean txn, Map<String, List<String>> allRequestParams, String createdBy )
	{
		String query = "delete from epc_product_decomposition where order_type = '"+allRequestParams.get("order_type").get(0)+"'";
		if(allRequestParams.get("product_short_code")!=null) {
			if(allRequestParams.get("product_short_code").size()>0) {
				if(!allRequestParams.get("product_short_code").get(0).equals("null") && !allRequestParams.get("product_short_code").get(0).equals("")){
					query = query + " and product_short_code = '"+allRequestParams.get("product_short_code").get(0)+"'";
				}
				else {
					query = query + " and product_short_code IS NULL";
				}
			}
			else {
				query = query + " and product_short_code IS NULL";
			}
		}
		else {
			query = query + " and product_short_code IS NULL";
		}
		
		if(allRequestParams.get("product_sub_family")!=null) {
			if(allRequestParams.get("product_sub_family").size()>0 ) {
				if(!allRequestParams.get("product_sub_family").get(0).equals("null") && !allRequestParams.get("product_sub_family").get(0).equals("")){
					query = query + " and product_sub_family = '"+allRequestParams.get("product_sub_family").get(0)+"'";
				}
				else {
					query = query + " and product_sub_family IS NULL";
				}
			}
			else {
				query = query + " and product_sub_family IS NULL";
			}
		}
		else {
			query = query + " and product_sub_family IS NULL";
		}
		
		if(allRequestParams.get("product_classification")!=null) {
			if(allRequestParams.get("product_classification").size()>0) {
				if(!allRequestParams.get("product_classification").get(0).equals("null") && !allRequestParams.get("product_classification").get(0).equals("")){
					query = query + " and product_classification = '"+allRequestParams.get("product_classification").get(0)+"'";
				}
				else {
					query = query + " and product_classification IS NULL";
				}
			}
			else {
				query = query + " and product_classification IS NULL";
			}
		}
		else {
			query = query + " and product_classification IS NULL";
		}
		
		for(EpcProductDecomposition decomposition : ProductDecompositionList)
		{
			decomposition.setCreatedBy(createdBy);
			if (decomposition.getIsNotificationRequired() == 0)
			{
				decomposition.setNotificationTemplateId(null);
			}
		}
			
		//logger.info("Delete query generated is "+query);
			try
			{
				em.createNativeQuery(query).executeUpdate();
				
				if (!ProductDecompositionList.isEmpty()){
					epcProductDecompositionRepository.save(ProductDecompositionList);
					ProductDecompositionList.get(0).getMetaInfo().put(MetaInfo.STATUS,MetaInfo.SUCCESS);
				}
			}catch( Exception e ) {
				if (txn ) {
					throw e;
				} else {
					ProductDecompositionList.get(0).getMetaInfo().put(MetaInfo.STATUS, MetaInfo.ERROR);
					ProductDecompositionList.get(0).getMetaInfo().put(MetaInfo.ERROR_MESSAGE, e.getMessage());
				}				
			}
		return ProductDecompositionList;
	}
	
	
	public List<EpcProductDecomposition> getDecompositionsByWhereClause(String queryBuilder){
		queryBuilder = "select * from epc_product_decomposition "+queryBuilder;
		//logger.info("query is >>>>>"+queryBuilder);
		//logger.debug(queryBuilder);
		List<EpcProductDecomposition> listOfDecompositionReturned = null;
		try {
			listOfDecompositionReturned = epcProductDecompositionRepository.getList(queryBuilder);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		return listOfDecompositionReturned;
	}

	public List<EpcProductDecomposition> getDecompositionByNotificationTemplate(Map<String, List<String>> allRequestParams){
		String query = "select * from epc_product_decomposition where notification_template_id = "+allRequestParams.get("notification_template_id").get(0);
		return epcProductDecompositionRepository.getList(query);
	}	
	
	//To get the decomposition rules for the orderType = OFFER_UNSU and OFFER_SUBS, in Product_View.
	public List<EpcProductDecomposition> searchProductDecompositionForSubscription (Map<String, List<String>> allRequestParams, boolean isOfferSubs) {
		
		List<EpcProductSpecification> listOfProductsReturned = epcProductSpecificationService.getBasicProductSpecByID(allRequestParams);
		
		EpcProductSpecification prodSpec =  listOfProductsReturned.get(0);
		
		String orderType = "";
		if(isOfferSubs){
			orderType = "OFFER_SUBS";
		} else {
			orderType = "OFFER_UNSU";
		}
		List<EpcProductDecomposition>  decompositions = getDecompositionsByWhereClause(
				"where product_short_code = '"+prodSpec.getProductShortCode()
				+"' and order_type = 'OFFER_SUBS'");
		if(decompositions == null || decompositions.isEmpty() ){
			decompositions = getDecompositionsByWhereClause(
					"where product_short_code is null and order_type = '"+orderType+"'"
					+" and product_classification = '"+prodSpec.getProductClassification()
					+"' and product_sub_family = '"+prodSpec.getProductSubFamily()+"'");
		}
		if(decompositions == null || decompositions.isEmpty() ){
			decompositions = getDecompositionsByWhereClause(
					"where product_short_code is null and order_type = '"+orderType+"'"
					+" and product_classification is null"
					+" and product_sub_family = '"+prodSpec.getProductSubFamily()+"'");
		}

		if(decompositions == null || decompositions.isEmpty() ){
			decompositions = getDecompositionsByWhereClause(
					"where product_short_code is null and order_type = '"+orderType+"'"
					+" and product_classification is null "
					+" and product_sub_family is null ");
		}
		
		return decompositions;
	}
}
