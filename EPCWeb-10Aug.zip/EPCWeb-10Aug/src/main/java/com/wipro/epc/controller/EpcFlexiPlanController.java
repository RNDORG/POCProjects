/**
 * EPC Application - EpcFlexiPlanController.java
 */
package com.wipro.epc.controller;

import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.dto.FlexiPlanInput;
import com.wipro.epc.dto.FlexiPlanResponse;
import com.wipro.epc.services.BroadcastService;
import com.wipro.epc.services.EpcFlexiPlanService;
import com.wipro.epc.util.Constants;

/**
 * @author Developer
 * @version 1.0
 * type EpcFlexiPlanController
 */
@RestController
public class EpcFlexiPlanController {
	
	/**
	 * EpcFlexiPlanService EpcFlexiPlanController.java
	 */
	@Autowired
	EpcFlexiPlanService flexiService;

	
	@Autowired
	BroadcastService broadcastService;
    
	/**
	 * @param input
	 * @return FlexiPlanResponse
	 */
	@RequestMapping(value="rest/extapi/v1/flexiPlanPriceDepricated", method=RequestMethod.POST)
	public FlexiPlanResponse flexiPlanPrice(@RequestBody @Valid FlexiPlanInput input){
		FlexiPlanResponse resp = new FlexiPlanResponse();		
		try{
		BigDecimal price =flexiService.flexiPlanPrice(input);
		//resp.setFlexiPrice(price.stripTrailingZeros());
		resp.setFlexiPrice(price.setScale(6, RoundingMode.HALF_UP));
		resp.setStatus(Constants.RESPONSE_SUCCESS_STATUS);
		
		}
		
		catch(GenericException g){
			resp.setRemarks(g.getErrorMessage());
		}		
		
		return resp;
	}
	
	@RequestMapping(value="rest/extapi/v1/flexiPlanPrice", method=RequestMethod.POST)
	public FlexiPlanResponse flexiPlanPriceCached(@RequestBody @Valid FlexiPlanInput input){
		FlexiPlanResponse resp = new FlexiPlanResponse();		
		try{
		 resp =flexiService.flexiPlanPriceCached(input);			
		
		}
		catch(GenericException g){
			resp.setRemarks(g.getErrorMessage());
		}		
		
		return resp;
	}
	
	@RequestMapping(value="rest/extapi/v1/reloadFlexiPlanPriceCacheLocal", method=RequestMethod.GET)
	public String reloadFlexiPlanListLocal(){
		String msg="";
		try{
		flexiService.loadFlexiPlanList();
		msg="SUCCESSFULLY RELOADED.";
		}
		catch(GenericException g){
			msg="FAILURE";
		}		
		return msg;
	}
	
	@RequestMapping(value="rest/extapi/v1/reloadFlexiPlanPriceCache", method=RequestMethod.GET)
	public String reloadFlexiPlanList(){
		String msg="";
		try{
			MultiValueMap allRequestParams=new LinkedMultiValueMap<>();
			allRequestParams.add("api", "reloadFlexiPlanPriceCacheLocal");
			allRequestParams.add("to", "all");
			broadcastService.getReplyService(allRequestParams);
		msg="SUCCESSFULLY RELOADED.";
		}
		catch(GenericException g){
			msg="FAILURE";
		}		
		return msg;
	}
}
