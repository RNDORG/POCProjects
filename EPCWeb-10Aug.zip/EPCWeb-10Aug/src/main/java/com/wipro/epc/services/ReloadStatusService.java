package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wipro.epc.domain.ReloadStatus;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.ReloadStatusRepository;

@Service
public class ReloadStatusService {
	
	private static Logger logger =LoggerFactory.getLogger(ReloadStatusService.class);
	
	@Autowired
	ReloadStatusRepository reloadStatusRepository;
	
	public Integer createReloadStatus(List<String> idPassed, boolean toDelay){
		int idRet=0;
		
		if(toDelay && idPassed.get(0).equalsIgnoreCase("all") && reloadStatusRepository.countReloadEntryOfRequestBeforeMinutes("all", 15)>0) {
			
			logger.debug("Inside Delay mode");
			throw new EPCException("Exception! An entry with request='ALL' is delayed for 15 minutes");
		}
		
		ReloadStatus reloadStatus=new ReloadStatus();
		if(idPassed.get(0).equalsIgnoreCase("all")){
			
		    String query="select * from reload_status where status='LOAD' and request='ALL'";
		    int count=reloadStatusRepository.getCount(query);
		    if (count!=0)
		    {
		    	throw new EPCException("Exception! An entry with status='LOAD' and request='ALL' already exists in "
		    			+ "reload_status table.");
		    }else
		    {
			reloadStatus.setRequest("ALL");
			
		    }
		}else{
			reloadStatus.setRequest(idPassed.toString());
		}
		reloadStatus.setStatus("LOAD");
		reloadStatus.setCreatedDate(new Date());
		reloadStatusRepository.save(reloadStatus);
		idRet=reloadStatus.getId();
	    return idRet;
	}
	

	@Transactional
	public Integer updateReloadStatus(Integer primKeyId, String status,String remarks,boolean appendRemarks)
	{
		if(appendRemarks)
		{ 
			//String remark=reloadStatusRepository.getRemarksToAppend(primKeyId);
			String remark=reloadStatusRepository.getReloadStatusById(primKeyId).getRemarks();
			remarks=remark+" "+remarks;
		}
		int rowsAffected=reloadStatusRepository.updateReloadStatus(primKeyId, status, remarks);
		return rowsAffected;
	}
	
	
	public List<ReloadStatus>  getStatus(Integer request)
	{
		List<ReloadStatus> result=new ArrayList<ReloadStatus>();
		try{
		if(request==null)
		{
			request=reloadStatusRepository.getMaxId();
		}
		
			String query="select * from reload_status where id = "+request;
			result=reloadStatusRepository.getStatus(query);
		}catch(Exception e)
		{
			logger.info("Exception!!!!!!! "+e.getMessage());
		}
		return result;
	}

	public List<ReloadStatus> getStatusWithLimit(Integer limit)
	{
		List<ReloadStatus> result=new ArrayList<ReloadStatus>();
		if(limit==null)
		{
	      limit=10;
	    }
		try{
		String query=" SELECT * FROM reload_status ORDER BY id DESC LIMIT "+limit;
		result=reloadStatusRepository.getStatus(query);
		}catch(Exception e)
		{
			logger.info("Exception!!!! "+e.getMessage());
		}
		return result;
	}
}
