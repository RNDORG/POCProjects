package com.wipro.epc.repositories;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcLookupMaster;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
@Repository
public interface EpcLookupMasterRepository extends CrudRepository<EpcLookupMaster, Integer>, EpcLookupMasterRepositoryCustom {
	
	/*@Query(value = "select lookup_id from epc_lookup_master where lookup_value = :value", nativeQuery=true)
	String idToValue(@Param("value") String value);*/
	
	/**
	 * This query gets the from EpcLookupMaster
	 * @return List<EpcLookupMaster>
	 */
	@Query(value = "select * from epc_lookup_master", nativeQuery=true)
	List<EpcLookupMaster> getAllListofValues();
}
