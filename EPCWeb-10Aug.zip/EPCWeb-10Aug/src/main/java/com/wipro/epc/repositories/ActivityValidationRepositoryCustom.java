package com.wipro.epc.repositories;

import com.wipro.epc.domain.EpcActivityChannelRule;


/**
 * @author Developer
 * @version 1.0
 * type ActivityValidationRepositoryCustom
 */
public interface ActivityValidationRepositoryCustom {
	
	/**
	 * @param orderList
	 * @return
	 */
	int validateActivity(EpcActivityChannelRule orderList);

}
