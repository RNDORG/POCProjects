package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type DownstreamQueryInput
 */
public class DownstreamQueryInput {


	/**
	 * String DownstreamQueryInput.java
	 */
	private String productShortCode;
	/**
	 * String DownstreamQueryInput.java
	 */
	private String initiatingChannel;
	/**
	 * String DownstreamQueryInput.java
	 */
	private String salesChannel;
	/**
	 * String DownstreamQueryInput.java
	 */
	private String orderType;
	/**
	 * @return
	 */
	public String getProductShortCode() {
		return productShortCode;
	}
	/**
	 * @param productShortCode
	 */
	public void setProductShortCode(String productShortCode) {
		this.productShortCode = productShortCode;
	}
	/**
	 * @return
	 */
	public String getInitiatingChannel() {
		return initiatingChannel;
	}
	/**
	 * @param initiatingChannel
	 */
	public void setInitiatingChannel(String initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}
	/**
	 * @return
	 */
	public String getSalesChannel() {
		return salesChannel;
	}
	/**
	 * @param salesChannel
	 */
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	/**
	 * @return
	 */
	public String getOrderType() {
		return orderType;
	}
	/**
	 * @param orderType
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
}
