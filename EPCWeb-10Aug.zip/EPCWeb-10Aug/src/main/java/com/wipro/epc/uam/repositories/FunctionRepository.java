package com.wipro.epc.uam.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.uam.domain.Function;


/**
 * @author KE334465
 *
 */
public interface FunctionRepository extends CrudRepository<Function, Integer>{

	//get's function names corresponding to a role
	/**
	 * @param role_id
	 * @return
	 */
	@Query(value = "select name from function where function_id in (select function_id from role_function_map where role_id=:role_id)", nativeQuery=true)
	String[] getFunctionNames(@Param("role_id") Integer role_id);
	
	/**
	 * @param name
	 * @return
	 */
	@Query(value = "select function_id from function where name = :name", nativeQuery=true)
	Integer getFunctionId(@Param("name") String name);
	
}
