package com.wipro.epc.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Developer
 * @version 1.0
 * type QueryEligibiltySearchInput
 */
public class QueryEligibiltySearchInput {
	
	@Override
	public String toString() {
		return "QueryEligibiltySearchInput [optionalProductId="
				+ optionalProductId + ", orderType=" + orderType
				+ ", initiatingChannel=" + initiatingChannel
				+ ", salesChannel=" + salesChannel + ", segment=" + segment
				+ ", area=" + area + ", region=" + region + ", territory="
				+ territory + ", communityId=" + communityId
				+ ", otherProductId1=" + otherProductId1 + ", otherProductId2="
				+ otherProductId2 + ", otherProductId3=" + otherProductId3
				+ ", otherProductId4=" + otherProductId4 + ", startDate="
				+ startDate + ", actionType=" + actionType
				+ ", bypassEligibilityCheck=" + bypassEligibilityCheck
				+ ", slabId=" + slabId + ", clientRequestId=" + clientRequestId
				+ ", customerRatePlanId=" + customerRatePlanId
				+ ", subscribedAddOnIds=" + subscribedAddOnIds
				+ ", sourceSystem=" + sourceSystem + ", data=" + data
				+ ", dataUnit=" + dataUnit + ", voice=" + voice
				+ ", voiceUnit=" + voiceUnit + ", voiceType=" + voiceType
				+ ", sms=" + sms + ", validity=" + validity + ", flexiPrice="
				+ flexiPrice + "]";
	}
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String optionalProductId;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String orderType;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String initiatingChannel;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String salesChannel;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String segment;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String area;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String region;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String territory;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String communityId;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String otherProductId1;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String otherProductId2;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String otherProductId3;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String otherProductId4;
	
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	private String startDate;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String actionType;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String bypassEligibilityCheck; 
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String slabId;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	public String clientRequestId;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String customerRatePlanId;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String subscribedAddOnIds;
	/**
	 * String QueryEligibiltySearchInput.java
	 */
	private String sourceSystem;
	
	private Integer data;
	private String dataUnit;
	private Integer voice;
	private String voiceUnit;
	private String voiceType;
	private Integer sms;
	private Integer validity;
	private BigDecimal flexiPrice;
	private BigDecimal flexiPriceWithTax;
	private String priceSuppressionFlag;
	private String receiverRatePlanId;
	
	/**
	 * @return
	 */
	public String getCommunityId() {
		return communityId;
	}
	/**
	 * @param communityId
	 */
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
	
	/**
	 * @return
	 */
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd kk:mm:ss", timezone="Asia/Kolkata")
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return
	 */
	public String getOptionalProductId() {
		return optionalProductId;
	}
	/**
	 * @param optionalProductId
	 */
	public void setOptionalProductId(String optionalProductId) {
		this.optionalProductId = optionalProductId;
	}
	/**
	 * @return
	 */
	public String getOrderType() {
		return orderType;
	}
	/**
	 * @param orderType
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	/**
	 * @return
	 */
	public String getInitiatingChannel() {
		return initiatingChannel;
	}
	/**
	 * @param initiatingChannel
	 */
	public void setInitiatingChannel(String initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}
	/**
	 * @return
	 */
	public String getSalesChannel() {
		return salesChannel;
	}
	/**
	 * @param salesChannel
	 */
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	/**
	 * @return
	 */
	public String getSegment() {
		return segment;
	}
	/**
	 * @param segment
	 */
	public void setSegment(String segment) {
		this.segment = segment;
	}
	/**
	 * @return
	 */
	public String getArea() {
		return area;
	}
	/**
	 * @param area
	 */
	public void setArea(String area) {
		this.area = area;
	}
	/**
	 * @return
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return
	 */
	public String getTerritory() {
		return territory;
	}
	/**
	 * @param territory
	 */
	public void setTerritory(String territory) {
		this.territory = territory;
	}
	/**
	 * @return
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	/**
	 * @return
	 */
	public String getOtherProductId1() {
		return otherProductId1;
	}
	/**
	 * @param otherProductId1
	 */
	public void setOtherProductId1(String otherProductId1) {
		this.otherProductId1 = otherProductId1;
	}
	/**
	 * @return
	 */
	public String getOtherProductId2() {
		return otherProductId2;
	}
	/**
	 * @param otherProductId2
	 */
	public void setOtherProductId2(String otherProductId2) {
		this.otherProductId2 = otherProductId2;
	}
	/**
	 * @return
	 */
	public String getOtherProductId3() {
		return otherProductId3;
	}
	/**
	 * @param otherProductId3
	 */
	public void setOtherProductId3(String otherProductId3) {
		this.otherProductId3 = otherProductId3;
	}
	/**
	 * @return
	 */
	public String getOtherProductId4() {
		return otherProductId4;
	}
	/**
	 * @param otherProductId4
	 */
	public void setOtherProductId4(String otherProductId4) {
		this.otherProductId4 = otherProductId4;
	}	
	/**
	 * @return
	 */
	public String getBypassEligibilityCheck() {
		return bypassEligibilityCheck;
	}
	/**
	 * @param bypassEligibilityCheck
	 */
	public void setBypassEligibilityCheck(String bypassEligibilityCheck) {
		this.bypassEligibilityCheck = bypassEligibilityCheck;
	}
	/**
	 * @return
	 */
	public String getSlabId() {
		return slabId;
	}
	/**
	 * @param slabId
	 */
	public void setSlabId(String slabId) {
		this.slabId = slabId;
	}
	/**
	 * 
	 * @return
	 */
	public String getClientRequestId() {
		return clientRequestId;
	}
	/**
	 * 
	 * @param clientRequestId
	 */
	public void setClientRequestId(String clientRequestId) {
		this.clientRequestId = clientRequestId;
	}
	/**
	 * @return the customerRatePlanId
	 */
	public String getCustomerRatePlanId() {
		return customerRatePlanId;
	}
	/**
	 * @param customerRatePlanId the customerRatePlanId to set
	 */
	public void setCustomerRatePlanId(String customerRatePlanId) {
		this.customerRatePlanId = customerRatePlanId;
	}
	/**
	 * @return the subscribedAddOnIds
	 */
	public String getSubscribedAddOnIds() {
		return subscribedAddOnIds;
	}
	/**
	 * @param subscribedAddOnIds the subscribedAddOnIds to set
	 */
	public void setSubscribedAddOnIds(String subscribedAddOnIds) {
		this.subscribedAddOnIds = subscribedAddOnIds;
	}
	/**
	 * @return the sourceSystem
	 */
	public String getSourceSystem() {
		return sourceSystem;
	}
	/**
	 * @param sourceSystem the sourceSystem to set
	 */
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	/**
	 * @return the data
	 */
	public Integer getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(Integer data) {
		this.data = data;
	}
	/**
	 * @return the dataUnit
	 */
	public String getDataUnit() {
		return dataUnit;
	}
	/**
	 * @param dataUnit the dataUnit to set
	 */
	public void setDataUnit(String dataUnit) {
		this.dataUnit = dataUnit;
	}
	/**
	 * @return the voice
	 */
	public Integer getVoice() {
		return voice;
	}
	/**
	 * @param voice the voice to set
	 */
	public void setVoice(Integer voice) {
		this.voice = voice;
	}
	/**
	 * @return the voiceUnit
	 */
	public String getVoiceUnit() {
		return voiceUnit;
	}
	/**
	 * @param voiceUnit the voiceUnit to set
	 */
	public void setVoiceUnit(String voiceUnit) {
		this.voiceUnit = voiceUnit;
	}
	/**
	 * @return the voiceType
	 */
	public String getVoiceType() {
		return voiceType;
	}
	/**
	 * @param voiceType the voiceType to set
	 */
	public void setVoiceType(String voiceType) {
		this.voiceType = voiceType;
	}
	/**
	 * @return the sms
	 */
	public Integer getSms() {
		return sms;
	}
	/**
	 * @param sms the sms to set
	 */
	public void setSms(Integer sms) {
		this.sms = sms;
	}
	/**
	 * @return the validity
	 */
	public Integer getValidity() {
		return validity;
	}
	/**
	 * @param validity the validity to set
	 */
	public void setValidity(Integer validity) {
		this.validity = validity;
	}
	/**
	 * @return the flexiPrice
	 */
	public BigDecimal getFlexiPrice() {
		return flexiPrice;
	}
	/**
	 * @param flexiPrice the flexiPrice to set
	 */
	public void setFlexiPrice(BigDecimal flexiPrice) {
		this.flexiPrice = flexiPrice;
	}
	/**
	 * @return the flexiPriceWithTax
	 */
	public BigDecimal getFlexiPriceWithTax() {
		return flexiPriceWithTax;
	}
	/**
	 * @param flexiPriceWithTax the flexiPriceWithTax to set
	 */
	public void setFlexiPriceWithTax(BigDecimal flexiPriceWithTax) {
		this.flexiPriceWithTax = flexiPriceWithTax;
	}
	/**
	 * @return the priceSuppressionFlag
	 */
	public String getPriceSuppressionFlag() {
		return priceSuppressionFlag;
	}
	/**
	 * @param priceSuppressionFlag the priceSuppressionFlag to set
	 */
	public void setPriceSuppressionFlag(String priceSuppressionFlag) {
		this.priceSuppressionFlag = priceSuppressionFlag;
	}
	/**
	 * @return the receiverRatePlanId
	 */
	public String getReceiverRatePlanId() {
		return receiverRatePlanId;
	}
	/**
	 * @param receiverRatePlanId the receiverRatePlanId to set
	 */
	public void setReceiverRatePlanId(String receiverRatePlanId) {
		this.receiverRatePlanId = receiverRatePlanId;
	}
	
}
