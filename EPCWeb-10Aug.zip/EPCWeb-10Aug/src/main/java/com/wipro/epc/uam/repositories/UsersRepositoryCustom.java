package com.wipro.epc.uam.repositories;


import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.uam.domain.Users;

/**
 * 
 * @author KE334465
 *
 */
public interface UsersRepositoryCustom {
	
	/**
	 * sets the roles of an user
	 * @param user
	 */
	 void addRolesAssociatedWithAnUser(Users user);
	 
	 /**
	  * modifies the user with new user object
	  * @param user
	  * @return
	  */
	 @Transactional
	 Users modifyUser(Users user);
	 
	 /**
	  * Gets the list of users by executing the query, a list of users will be returned
	  * @param query
	  * @return
	  */
	 List<Users> getList(String query);
}
