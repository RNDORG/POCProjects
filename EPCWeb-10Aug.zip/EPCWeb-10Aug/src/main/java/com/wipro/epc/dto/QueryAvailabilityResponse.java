package com.wipro.epc.dto;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author Developer
 * @version 1.0
 * type QueryAvailabilityResponse
 */
public class QueryAvailabilityResponse {
	
	/**
	 * Map<String,List<QueryAvailabilityProductSpec>> QueryAvailabilityResponse.java
	 */
	private Map<String, List<QueryAvailabilityProductSpec>> availableProduct; 
	/**
	 * Set<String> QueryAvailabilityResponse.java
	 */
	private Set<String> otherClassification;
	/**
	 * String QueryAvailabilityResponse.java
	 */
	private String remarks;
	/**
	 * String QueryAvailabilityResponse.java
	 */
	private String responseCode;
	
	/**
	 * @return
	 */
	public Set<String> getOtherClassification() {
		return otherClassification;
	}
	/**
	 * @param otherClassification
	 */
	public void setOtherClassification(Set<String> otherClassification) {
		this.otherClassification = otherClassification;
	}
	/**
	 * @return
	 */
	public Map<String, List<QueryAvailabilityProductSpec>> getAvailableProduct() {
		return availableProduct;
	}
	/**
	 * @param availableProduct
	 */
	public void setAvailableProduct(
			Map<String, List<QueryAvailabilityProductSpec>> availableProduct) {
		this.availableProduct = availableProduct;
	}
	/**
	 * @return
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}
	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
}
