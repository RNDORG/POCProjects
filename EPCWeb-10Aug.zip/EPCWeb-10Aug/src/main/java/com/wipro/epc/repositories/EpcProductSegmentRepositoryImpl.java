package com.wipro.epc.repositories;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcProductSegment;


/**
 * @author Developer
 * @version 1.0
 * type EpcProductSegmentRepositoryImpl
 */
public class EpcProductSegmentRepositoryImpl implements EpcProductSegmentRepositoryCustom{

	private static Logger logger =LoggerFactory.getLogger(EpcProductSegmentRepositoryImpl.class);
	
	/**
	 * EntityManager EpcProductSegmentRepositoryImpl.java
	 */
	@PersistenceContext
	private EntityManager em;
	
	/**
	 * @return
	 */
	public EntityManager getEm() {
		return em;
	}

	/**
	 * @param em
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductSegmentRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcProductSegment> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductSegment.class).getResultList();
		
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductSegmentRepositoryCustom#modifyProductSegment(com.wipro.epc.domain.EpcProductSegment)
	 */
	@Override
	public EpcProductSegment modifyProductSegment(EpcProductSegment segment) {
		StringBuilder queryBuilder = new StringBuilder("update epc_product_segment set product_segment_id='"+segment.getProductSegmentId()+"'");
		
		if(segment.getProductId()!=0 && segment.getProductId()!=null) {
			queryBuilder.append(",").append(" product_id = '").append(segment.getProductId()).append("'");
		}
		if(segment.getSegmentType()!=null && !segment.getSegmentType().isEmpty()) {
			queryBuilder.append(",").append(" segment_type = '").append(segment.getSegmentType()).append("'");
		}
		if(segment.getSegment()!=null && !segment.getSegment().isEmpty()) {
			queryBuilder.append(",").append(" segment_value = '").append(segment.getSegment()).append("'");
		}
		if(segment.getStatus()!=null) {
			queryBuilder.append(",").append(" status = '").append(segment.getStatus()).append("'");
		}
		
		if(segment.getModifiedBy()!=null) {
			queryBuilder.append(",").append(" modified_by = '").append(segment.getModifiedBy()).append("'");
		}
		if(segment.getModifiedDate()!=null) {
			queryBuilder.append(",").append(" modified_date = '").append(new SimpleDateFormat().format(new Date())).append("'");
		}
		
		queryBuilder.append(" where product_segment_id =").append(segment.getProductSegmentId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		
		return segment;
	}


}
