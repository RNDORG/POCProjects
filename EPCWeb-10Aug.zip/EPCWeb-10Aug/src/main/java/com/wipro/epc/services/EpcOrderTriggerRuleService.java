package com.wipro.epc.services;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.domain.EpcTriggerOrderRule;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcOrderTriggerRuleRepository;
import com.wipro.epc.uam.definitions.MetaInfo;

/**
 * This is the service class for EpcOrderTriggerRule 
 * We can search and modify the data which is there in DB.
 * @author VI251443
 * @version 1.0
 */
@Service
public class EpcOrderTriggerRuleService {

	private static Logger logger = LoggerFactory.getLogger(EpcOrderTriggerRuleService.class);

	@Autowired
	EpcOrderTriggerRuleRepository epcOrderTriggerRuleRepository;
	
	@PersistenceContext
	EntityManager em; 
	
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcTriggerOrderRule> searchTriggerOrderRule(Map<String, List<String>> allRequestParams) {

		
		String query = "select * from epc_trigger_order_rule where source_order_type = '"+allRequestParams.get("source_order_type").get(0)+"'";
		if(allRequestParams.get("source_product_short_code")!=null) {
			if(allRequestParams.get("source_product_short_code").size()>0) {
				if(!allRequestParams.get("source_product_short_code").get(0).equals("null") && !allRequestParams.get("source_product_short_code").get(0).equals("")) {
					query = query + " and source_product_short_code = '"+allRequestParams.get("source_product_short_code").get(0)+"'";
				}
				else {
					query = query + " and source_product_short_code IS NULL";
				}
			}
			else {
				query = query + " and source_product_short_code IS NULL";
			}
		}
		else {
			query = query + " and source_product_short_code IS NULL";
		}
		
		if(allRequestParams.get("source_product_sub_family")!=null) {
			if(allRequestParams.get("source_product_sub_family").size()>0 ) {
				if(!allRequestParams.get("source_product_sub_family").get(0).equals("null") && !allRequestParams.get("source_product_sub_family").get(0).equals("")) {
					query = query + " and source_product_sub_family = '"+allRequestParams.get("source_product_sub_family").get(0)+"'";
				}
				else {
					query = query + " and source_product_sub_family IS NULL";
				}
			}
			else {
				query = query + " and source_product_sub_family IS NULL";
			}
		}
		else {
			query = query + " and source_product_sub_family IS NULL";
		}
		
		if(allRequestParams.get("source_product_classification")!=null) {
			if(allRequestParams.get("source_product_classification").size()>0) {
				if(!allRequestParams.get("source_product_classification").get(0).equals("null") && !allRequestParams.get("source_product_classification").get(0).equals("")){
					query = query + " and source_product_classification = '"+allRequestParams.get("source_product_classification").get(0)+"'";
				}
				else {
					query = query + " and source_product_classification IS NULL";
				}
			}
			else {
				query = query + " and source_product_classification IS NULL";
			}
		}
		else {
			query = query + " and source_product_classification IS NULL";
		}
		
		List<EpcTriggerOrderRule> listOfDecompositionReturned  = epcOrderTriggerRuleRepository.getList(query);
	//	logger.info("Query Generated is "+query);
		
		return listOfDecompositionReturned;
		
	}

    /**
     * 
     * @param OrderTriggerRuleList
     * @param txn
     * @param allRequestParams
     * @param createdBy
     * @return
     */

	
	@Transactional
	public List<EpcTriggerOrderRule> manageTriggers(List<EpcTriggerOrderRule> OrderTriggerRuleList, boolean txn, Map<String, List<String>> allRequestParams, String createdBy )
	{
		String query = "delete from epc_trigger_order_rule where source_order_type = '"+allRequestParams.get("source_order_type").get(0)+"'";
		if(allRequestParams.get("source_product_short_code")!=null) {
			if(allRequestParams.get("source_product_short_code").size()>0) {
				if(!allRequestParams.get("source_product_short_code").get(0).equals("null") && !allRequestParams.get("source_product_short_code").get(0).equals("")){
					query = query + " and source_product_short_code = '"+allRequestParams.get("source_product_short_code").get(0)+"'";
				}
				else {
					query = query + " and source_product_short_code IS NULL";
				}
			}
			else {
				query = query + " and source_product_short_code IS NULL";
			}
		}
		else {
			query = query + " and source_product_short_code IS NULL";
		}
		
		if(allRequestParams.get("source_product_sub_family")!=null) {
			if(allRequestParams.get("source_product_sub_family").size()>0 ) {
				if(!allRequestParams.get("source_product_sub_family").get(0).equals("null") && !allRequestParams.get("source_product_sub_family").get(0).equals("")){
					query = query + " and source_product_sub_family = '"+allRequestParams.get("source_product_sub_family").get(0)+"'";
				}
				else {
					query = query + " and source_product_sub_family IS NULL";
				}
			}
			else {
				query = query + " and source_product_sub_family IS NULL";
			}
		}
		else {
			query = query + " and source_product_sub_family IS NULL";
		}
		
		if(allRequestParams.get("source_product_classification")!=null) {
			if(allRequestParams.get("source_product_classification").size()>0) {
				if(!allRequestParams.get("source_product_classification").get(0).equals("null") && !allRequestParams.get("source_product_classification").get(0).equals("")) {
					query = query + " and source_product_classification = '"+allRequestParams.get("source_product_classification").get(0)+"'";
				}
				else {
					query = query + " and source_product_classification IS NULL";
				}
			} 
			else {
				query = query + " and source_product_classification IS NULL";
			}
		}
		else {
			query = query + " and source_product_classification IS NULL";
		}
		
		for(EpcTriggerOrderRule decomposition : OrderTriggerRuleList)
		{
			decomposition.setCreatedBy(createdBy);
		}
			//logger.info("Delete query generated is "+query);
		
			try
			{
				em.createNativeQuery(query).executeUpdate();
				
				epcOrderTriggerRuleRepository.save(OrderTriggerRuleList);
				OrderTriggerRuleList.get(0).getMetaInfo().put(MetaInfo.STATUS,MetaInfo.SUCCESS);
			}catch( Exception e ) {
				if (txn ) {
					throw e;
				} else {
					OrderTriggerRuleList.get(0).getMetaInfo().put(MetaInfo.STATUS, MetaInfo.ERROR);
					OrderTriggerRuleList.get(0).getMetaInfo().put(MetaInfo.ERROR_MESSAGE, e.getMessage());
				}				
			}
		return OrderTriggerRuleList;
	}
	

	
  /**
   * 
   * @param queryBuilder
   * @return
   */
	public List<EpcTriggerOrderRule> getTriggerOrderRulesByWhereClause(String queryBuilder){
		queryBuilder = "select * from epc_trigger_order_rule "+queryBuilder;
		//logger.info("query is >>>>>"+queryBuilder);
		List<EpcTriggerOrderRule> listOfAvailabilitiesReturned = null;
		try {
			listOfAvailabilitiesReturned = epcOrderTriggerRuleRepository.getList(queryBuilder);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return listOfAvailabilitiesReturned;
	}
	
	
}
