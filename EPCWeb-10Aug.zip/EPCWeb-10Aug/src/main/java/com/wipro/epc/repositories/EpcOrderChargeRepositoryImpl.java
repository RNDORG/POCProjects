/**
 * 
 */
package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcOrderCharge;


/**
 * @author Developer
 * @version 1.0
 * type EpcOrderChargeRepositoryImpl
 */
public class EpcOrderChargeRepositoryImpl implements EpcOrderChargeRepositoryCustom{
	
	
	private static Logger logger =LoggerFactory.getLogger(EpcOrderChargeRepositoryImpl.class);
	
	
	/**
	 * EntityManager EpcOrderChargeRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcOrderChargeRepositoryCustom#modifyOrder(com.wipro.epc.domain.EpcOrderCharge)
	 */
	@Override
	public EpcOrderCharge modifyOrder(EpcOrderCharge order) {
		
		StringBuilder queryBuilder = new StringBuilder("update epc_order_charge set order_channel_rule_id="+order.getOrderChannelRuleId());	
		if (order.getOccCode()!=null && !order.getOccCode().isEmpty())
			queryBuilder.append(",").append("occ_code='").append(order.getOccCode()).append("' ");
		if (order.getOrderChargeFee()!=null)
			queryBuilder.append(",").append("order_charge_fee=").append(order.getOrderChargeFee());
		
		queryBuilder.append(" where order_channel_rule_id =").append(order.getOrderChannelRuleId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		//System.out.println(query);
		return order;	
		
	}

	@Override
	public List<EpcOrderCharge> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query,EpcOrderCharge.class).getResultList();
	}
}
