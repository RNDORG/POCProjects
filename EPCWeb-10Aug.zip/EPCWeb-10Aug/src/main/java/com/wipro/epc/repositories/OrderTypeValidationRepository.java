package com.wipro.epc.repositories;

import org.springframework.data.repository.CrudRepository;

import com.wipro.epc.domain.EpcOrderChannelRule;

/**
 * @author Developer
 * @version 1.0
 * type OrderTypeValidationRepository
 */
public interface OrderTypeValidationRepository extends CrudRepository<EpcOrderChannelRule, Integer>,OrderTypeValidationRepositoryCustom{

}
