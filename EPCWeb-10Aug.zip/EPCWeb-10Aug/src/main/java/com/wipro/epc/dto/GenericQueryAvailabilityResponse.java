package com.wipro.epc.dto;

import java.util.List;
import java.util.Map;

import com.wipro.epc.domain.EpcProductSpecification;

/**
 * @author Developer
 * @version 1.0
 * type GenericQueryAvailabilityResponse
 */
public class GenericQueryAvailabilityResponse {
	
	/**
	 * Map<String,List<EpcProductSpecification>> GenericQueryAvailabilityResponse.java
	 */
	private Map<String, List<EpcProductSpecification>> eligibleProduct; 
	/**
	 * List<String> GenericQueryAvailabilityResponse.java
	 */
	private List<String> otherClassification;
	/**
	 * String GenericQueryAvailabilityResponse.java
	 */
	private String remarks;
	
	/**
	 * @return
	 */
	public Map<String, List<EpcProductSpecification>> getEligibleProduct() {
		return eligibleProduct;
	}
	/**
	 * @param eligibleProduct
	 */
	public void setEligibleProduct(
			Map<String, List<EpcProductSpecification>> eligibleProduct) {
		this.eligibleProduct = eligibleProduct;
	}
	/**
	 * @return
	 */
	public List<String> getOtherClassification() {
		return otherClassification;
	}
	/**
	 * @param otherClassification
	 */
	public void setOtherClassification(List<String> otherClassification) {
		this.otherClassification = otherClassification;
	}
	/**
	 * @return
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
