package com.wipro.epc.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import com.wipro.epc.dto.ComplexSearchInput;

@Repository
public class ComplexSearchInputRepository {
	
	private static Logger logger =LoggerFactory.getLogger(ComplexSearchInputRepository.class);

	@PersistenceContext
	private EntityManager em;
	
	/**
	 * @param searchInput
	 * @return
	 */
	public List<String> findSearchResults(ComplexSearchInput searchInput) {
		String query = "";
			query = getQuery(searchInput);
			//System.out.println("---------------------------------------------------------------------");
			logger.debug("#Query: "+query);
			List<Integer> returnList =  em.createNativeQuery(query).getResultList();
			List<String> pordIds = new ArrayList<String>();
			for (Integer id: returnList){
				pordIds.add(id.toString());
			}
		return pordIds;
	}

	/**
	 * @param searchInput
	 * @return
	 */
	private String getQuery(ComplexSearchInput searchInput) {
		StringBuilder query = new StringBuilder(" select distinct epc_product_specification.product_id from " 
			+" epc_product_specification left join epc_product_availability on epc_product_specification.product_id = epc_product_availability.product_id " 
			+" left join epc_product_location on epc_product_specification.product_id = epc_product_location.product_id "
			+" left join epc_product_segment on epc_product_specification.product_id = epc_product_segment.product_id "
			+" left join epc_product_init_channel on epc_product_specification.product_id = epc_product_init_channel.product_id "
			+" left join epc_product_sales_channel on epc_product_specification.product_id = epc_product_sales_channel.product_id "
			+" left join epc_product_network_tpl_map on epc_product_specification.product_id = epc_product_network_tpl_map.product_id "
			+" left join epc_product_attribute on epc_product_specification.product_id = epc_product_attribute.product_id "
			+" left join epc_product_community on epc_product_specification.product_id = epc_product_community.product_id "
			+" left join epc_product_provider_system  on epc_product_specification.product_id = epc_product_provider_system.product_id where 1=1 ");
		if(searchInput.getProductId()  != null ){
			query.append(" AND ").append("epc_product_specification.product_id = ").append(searchInput.getProductId());
		}
		if(searchInput.getProductShortCode()!=null) {
			query.append(" AND ").append("lower(product_short_code) like  lower('").append(searchInput.getProductShortCode()).append("')");
		}
		if(searchInput.getProductMarketingName()!=null) {
			query.append(" AND ").append("lower(product_marketing_name) like  lower('").append(searchInput.getProductMarketingName()).append("')");
		}
		if(searchInput.getProductStatus()!=null) {
			query.append(" AND ").append("product_status = '").append(searchInput.getProductStatus()).append("'");
		}
		if(searchInput.getProductFamily()!=null) {
			query.append(" AND ").append("product_family = '").append(searchInput.getProductFamily()).append("'");
		}
		if(searchInput.getProductSubfamily()!=null) {
			query.append(" AND ").append("product_sub_family = '").append(searchInput.getProductSubfamily()).append("'");
		}
		if(searchInput.getProductCategory()!=null) {
			if(!("BOTH".equalsIgnoreCase(searchInput.getProductCategory()))) {
				query.append(" AND (").append("product_category = '").append(searchInput.getProductCategory()).append("'");
				query.append(" OR ").append("product_category = 'BOTH')");
			}
			else if("BOTH".equalsIgnoreCase(searchInput.getProductCategory())){
				query.append(" AND ").append("product_category = 'BOTH'");
			}
		}
			
		if(searchInput.getProductSubCategory()!=null ) {
			if(!("ALL".equalsIgnoreCase(searchInput.getProductSubCategory()))) {
				query.append(" AND (").append("product_sub_category = '").append(searchInput.getProductSubCategory()).append("'");
				query.append(" OR ").append("product_sub_category = 'ALL')");
			}
			else if(("ALL".equalsIgnoreCase(searchInput.getProductSubCategory()))){
				query.append(" AND ").append("product_sub_category = 'ALL'");
			}
		}
		if(searchInput.getProductType()!=null) {
			query.append(" AND ").append("product_type = '").append(searchInput.getProductType()).append("'");
		}
		if(searchInput.getIsTemplateProduct()!=null) {
			query.append(" AND ").append("is_template_product = '").append(searchInput.getIsTemplateProduct()).append("'");
		}
		if(searchInput.getLifeValidityStartDate()!=null) {
			query.append(" AND ").append("life_validity_start_date  >= '").append(searchInput.getLifeValidityStartDate()).append("'");
		}
		if(searchInput.getLifeValidityEndDate()!=null) {
			query.append(" AND ").append("life_validity_end_date <= '").append(searchInput.getLifeValidityEndDate()).append("'");
		}
		if(searchInput.getSellingStartDate()!=null) {
			query.append(" AND ").append("selling_start_date >= '").append(searchInput.getSellingStartDate()).append("'");
		}
		if(searchInput.getSellingEndDate()!=null) {
			query.append(" AND ").append("selling_end_date <= '").append(searchInput.getSellingEndDate()).append("'");
			if(searchInput.getSubscriptionStartDate()!=null) {
				query.append(" AND ").append("subscription_start_date >= '").append(searchInput.getSubscriptionStartDate()).append("'");
			}
			if(searchInput.getSubscriptionEndDate()!=null) {
				query.append(" AND ").append("subscription_end_date <= '").append(searchInput.getSubscriptionEndDate()).append("'");
			}
		}
		//TODO - Launch date >= to be fixed.
		if(searchInput.getLaunchDate()!=null) {
			query.append(" AND ").append("launch_date >= '").append(searchInput.getLaunchDate()).append("'");
		}
		if(searchInput.getRegion()!=null) {
			query.append(" AND ").append("location_code_2 = '").append(searchInput.getRegion()).append("'");
		}
		if(searchInput.getArea()!=null) {
			query.append(" AND ").append("location_code_3 = '").append(searchInput.getArea()).append("'");
		}
		if(searchInput.getTerritory()!=null) {
			query.append(" AND ").append("location_code_4 = '").append(searchInput.getTerritory()).append("'");
		}
		if(searchInput.getInitiatingChannel()!=null) {
			query.append(" AND ").append("channel_id = '").append(searchInput.getInitiatingChannel()).append("'");
		}
		if(searchInput.getInitiatingChannelLevelMarketingName()!=null) {
			query.append(" AND ").append("lower(channel_level_market_name) like lower('").append(searchInput.getInitiatingChannelLevelMarketingName()).append("')");
		}
		if(searchInput.getInitiatingChannelProductId()!=null) {
			query.append(" AND ").append("lower(channel_level_product_id) like lower('").append(searchInput.getInitiatingChannelProductId()).append("')");
		}
		if(searchInput.getSalesChannel()!=null) {
			query.append(" AND ").append("partner_type = '").append(searchInput.getSalesChannel()).append("'");
		}
		if(searchInput.getSegment()!=null) {
			query.append(" AND ").append("segment_value = '").append(searchInput.getSegment()).append("'");
		}
		if(searchInput.getSegmentType()!=null) {
			query.append(" AND ").append("segment_type = '").append(searchInput.getSegmentType()).append("'");
		}
		
		if(searchInput.getProductClassification()!=null) {
			query.append(" AND ").append("product_classification = '").append(searchInput.getProductClassification()).append("'");
		}
		
		if(searchInput.getProviderSystemCode()!=null) {
			query.append(" AND ").append("provider_system_code = '").append(searchInput.getProviderSystemCode()).append("'");
		}
		
		if(searchInput.getProviderProductId()!=null) {
			query.append(" AND ").append("provider_product_id = '").append(searchInput.getProviderProductId()).append("'");
		}
		
		if(searchInput.getProviderProductDescription()!=null) {
			query.append(" AND ").append("lower(provider_product_description) like lower('").append(searchInput.getProviderProductDescription()).append("')");
		}
		
		if(searchInput.getDownstreamSystem()!=null) {
			query.append(" AND ").append("downstream_system = '").append(searchInput.getDownstreamSystem()).append("'");
		}
		
		if(searchInput.getIsAutoRenewalAllowed()!=null) {
			query.append(" AND ").append("is_auto_renewal_allowed = '").append(searchInput.getIsAutoRenewalAllowed()).append("'");
		}
		
		if(searchInput.getIsBundle()!=null) {
			query.append(" AND ").append("is_bundle = '").append(searchInput.getIsBundle()).append("'");
		}
		
		if(searchInput.getIsHybrid()!=null) {
			query.append(" AND ").append("is_hybrid = '").append(searchInput.getIsHybrid()).append("'");
		}
		
		if(searchInput.getIsOmOrchestrationRequired()!=null) {
			query.append(" AND ").append("api_indicator = '").append(searchInput.getIsOmOrchestrationRequired()).append("'");
		}
		
		if(searchInput.getIsRoamingProduct()!=null) {
			query.append(" AND ").append("is_roaming_product = '").append(searchInput.getIsRoamingProduct()).append("'");
		}
		
		if(searchInput.getIsProductPaused()!=null) {
			query.append(" AND ").append("is_product_paused = '").append(searchInput.getIsProductPaused()).append("'");
		}
		
		if(searchInput.getCommunityName()!=null) {
			query.append(" AND ").append("lower(community_name) like lower('").append(searchInput.getCommunityName()).append("')");
		}
		if(searchInput.getCommunityId()!=null) {
			query.append(" AND ").append("lower(community_id) = lower('").append(searchInput.getCommunityId()).append("')");
		}
		
		if(searchInput.getNetworkTemplateName()!=null) {
			query.append(" AND ").append("lower(template_name) like lower('").append(searchInput.getNetworkTemplateName()).append("')");
		}
		
		if(searchInput.getSpecCreatedDateFrom()!=null) {
			query.append(" AND ").append("epc_product_specification.created_date  >= '").append(searchInput.getSpecCreatedDateFrom()).append("'");
		}
		if(searchInput.getSpecCreatedDateTo()!=null) {
			query.append(" AND ").append("epc_product_specification.created_date  <= '").append(searchInput.getSpecCreatedDateTo()).append("'");
		}
		if(searchInput.getAttributeName()!=null) {
			query.append(" AND ").append("attribute_id = (select attribute_id from epc_attribute_master where lower(attribute_name) like lower('").append(searchInput.getAttributeName()).append("'))");
		}
		if(searchInput.getAttributeValue()!=null) {
			query.append(" AND ").append("lower(attribute_value1) like lower('").append(searchInput.getAttributeValue()).append("')");
		}
		
			//logger.info("#Query: "+query.toString());
		return query.toString();
	}

	/**
	 * @param classification
	 * @return
	 */
	public List<Integer> getProductidsByclassification(String classification) {
		String query = "";
			query = "select product_id from epc_product_specification where product_classification='"+classification+"'";
			//System.out.println("---------------------------------------------------------------------");
			//System.out.println("Query generated is : "+query);
			logger.debug("#Query: "+query);
			List<Integer> returnList =  em.createNativeQuery(query).getResultList();
			List<Integer> pordIds = new ArrayList<Integer>();
			if (returnList != null && !returnList.isEmpty() ) {
				for (Integer id : returnList) {
					pordIds.add(id);
				}
			}
		return pordIds;
	}

	/**
	 * @return
	 */
	public EntityManager getEm() {
		return em;
	}

	/**
	 * @param em
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}
	
}
