package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductInitChannel;

/**
 * EpcProductInitChannelRepository
 *
 */
public interface EpcProductInitChannelRepository extends CrudRepository<EpcProductInitChannel, Integer>,
EpcProductInitChannelRepositoryCustom{

	/**
	 * @param productId
	 */
	@Modifying
	@Query(value="delete from epc_product_init_channel where product_id =:product_id", nativeQuery = true)
	void deleteProductFromInit(@Param("product_id") Integer productId);

	/**
	 * @param productId
	 * @return
	 */
	@Query(value="select * from epc_product_init_channel where product_id=:productId", nativeQuery=true)
	List<EpcProductInitChannel> findInitChannelByProductId(@Param("productId") Integer productId);

	/**
	 * @param notification_template_id
	 * @return
	 */
	@Query(value="select * from epc_product_init_channel where notification_template_id = :notification_template_id", nativeQuery=true)
	List<EpcProductInitChannel> searchEpcProductInitChannel(@Param("notification_template_id")Integer notification_template_id);

	/**
	 * @param productId
	 * @param channelProductId
	 * @return
	 */
	@Query(value="select * from epc_product_init_channel where product_id!=:productId and channel_level_product_id=:channelProductId", nativeQuery=true)
	List<EpcProductInitChannel> productIdExist(@Param("productId") String productId, @Param("channelProductId") String channelProductId);
	
	/**
	 * @param productId
	 * @param channelLevelMarketName
	 * @return
	 */
	@Query(value="select * from epc_product_init_channel where product_id!=:productId and channel_level_market_name=:channelLevelMarketName", nativeQuery=true)
	List<EpcProductInitChannel> marketNameExist(@Param("productId") String productId, @Param("channelLevelMarketName") String channelLevelMarketName);
}
