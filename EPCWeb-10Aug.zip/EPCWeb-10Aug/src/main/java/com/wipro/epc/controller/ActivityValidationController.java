package com.wipro.epc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcActivityChannelRule;
import com.wipro.epc.services.ActivityValidationService;


/**
 * @author Developer
 * @version 1.0
 * type ActivityValidationController
 */
@RestController
public class ActivityValidationController {

	/**
	 * ActivityValidationService ActivityValidationController.java
	 */
	@Autowired
	ActivityValidationService service;
	
	/**
	 * @param orderList
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/activityValidation", method=RequestMethod.POST)
	public int manageOrders(@RequestBody EpcActivityChannelRule orderList)
	{
		
		return service.validateActivity(orderList);
	}
}
