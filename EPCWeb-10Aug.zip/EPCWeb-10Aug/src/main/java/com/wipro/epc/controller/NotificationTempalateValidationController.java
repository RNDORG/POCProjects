package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;





import com.wipro.epc.services.NotificationTemplateValidationService;


/**
 * @author KE334465
 *
 */
@RestController
public class NotificationTempalateValidationController {
	
	@Autowired
	private NotificationTemplateValidationService service;
	
	/**
	 * 
	 * @param templateName
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/notificationTemplateValidation", method=RequestMethod.POST)
	public int manageTemplateName(@RequestBody String templateName)
	{
		return service.validateTemplateName(templateName);
	}
	
	/**
	 * 
	 * @param validationArray
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/templateValidation", method=RequestMethod.POST)
	public String[] checkUniqueCombination(@RequestBody List<String[]> validationArray)
	{
		////System.out.println("Validation array is "+validationArray.get(0).);
		return service.validateTemplateCombination(validationArray);
	}
	

}
