package com.wipro.epc.domain;



import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;


/**
 * The persistent class for the epc_notification_template database table.
 * @author VI251443
 * @version 1.0
 */
@Entity
@Table(name="epc_notification_template")
public class EpcNotificationTemplate  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="notification_template_id")
	private Integer notificationTemplateId;

	@Column(name="template_type")
	private String templateType;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String templateTypeValue;*/
	
	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="created_date")
	private Date createdDate;

	@Column(name="mode_of_delivery")
	private String modeOfDelivery;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String modeOfDeliveryValue;*/

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="status")
	private String status;

	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;
	*/
	@Column(name="template_name")
	private String templateName;
	
	@Column(name="source_system")
	private String sourceSystem;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String sourceSystemValue;*/
	
	@Transient
	private Map<String,String> metaInfo;	

	@Transient
	private List<EpcNotificationTemplateDetail> epcNotificationTemplateDetail;
	
	
	public List<EpcNotificationTemplateDetail> getEpcNotificationTemplateDetail() {
		return epcNotificationTemplateDetail;
	}

	public void setEpcNotificationTemplateDetail(
			List<EpcNotificationTemplateDetail> epcNotificationTemplateDetail) {
		this.epcNotificationTemplateDetail = epcNotificationTemplateDetail;
	}

	public EpcNotificationTemplate() {
	}

	
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}

	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}
	
	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public Integer getNotificationTemplateId() {
		return this.notificationTemplateId;
	}

	public void setNotificationTemplateId(Integer notificationTemplateId) {
		this.notificationTemplateId = notificationTemplateId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	
	public Date getCreatedDate() {
		return this.createdDate;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModeOfDelivery() {
		return this.modeOfDelivery;
	}

	public void setModeOfDelivery(String modeOfDelivery) {
		this.modeOfDelivery = modeOfDelivery;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
    
	
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	@Override
	public String toString() {
		return "EpcNotificationTemplate [notificationTemplateId="
				+ notificationTemplateId + ", templateType=" + templateType
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", modeOfDelivery=" + modeOfDelivery + ", modifiedBy="
				+ modifiedBy + ", modifiedDate=" + modifiedDate + ", status="
				+ status 
				+ ", templateBengali="+ ", templateEnglish="
				+  ", templateOther=" 
				+ ", templateName=" + templateName + ", subjectEnglish="
				+ ", subjectBengali=" 
				+ ", subjectOther=" + ", sourceSystem="
				+ sourceSystem + "]";
	}

	/*public String getTemplateTypeValue() {
		this.templateTypeValue = templateType;
		return templateTypeValue;
	}

	public void setTemplateTypeValue(String templateTypeValue) {
		this.templateTypeValue = templateTypeValue;
	}

	public String getModeOfDeliveryValue() {
		this.modeOfDeliveryValue = modeOfDelivery;
		return modeOfDeliveryValue;
	}

	public void setModeOfDeliveryValue(String modeOfDeliveryValue) {
		this.modeOfDeliveryValue = modeOfDeliveryValue;
	}

	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

	public String getSourceSystemValue() {
		this.sourceSystemValue = sourceSystem;
		return sourceSystemValue;
	}

	public void setSourceSystemValue(String sourceSystemValue) {
		this.sourceSystemValue = sourceSystemValue;
	}*/
	
	

}