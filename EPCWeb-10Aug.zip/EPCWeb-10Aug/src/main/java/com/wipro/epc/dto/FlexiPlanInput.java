/**
 * EPC Application - FlexiPlanInput.java
 */
package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type FlexiPlanInput
 */
public class FlexiPlanInput {
	private Integer data;
	private String dataUnit;
	private Integer voice;
	private String voiceUnit;
	private String voiceType;
	private Integer sms;
	private Integer validity;
	public Integer getData() {
		return data;
	}
	public void setData(Integer data) {
		this.data = data;
	}
	public String getDataUnit() {
		return dataUnit;
	}
	public void setDataUnit(String dataUnit) {
		this.dataUnit = dataUnit;
	}
	public Integer getVoice() {
		return voice;
	}
	public void setVoice(Integer voice) {
		this.voice = voice;
	}
	public String getVoiceType() {
		return voiceType;
	}
	public void setVoiceType(String voiceType) {
		this.voiceType = voiceType;
	}
	public Integer getSms() {
		return sms;
	}
	public void setSms(Integer sms) {
		this.sms = sms;
	}
	public Integer getValidity() {
		return validity;
	}
	public void setValidity(Integer validity) {
		this.validity = validity;
	}
	public String getVoiceUnit() {
		return voiceUnit;
	}
	public void setVoiceUnit(String voiceUnit) {
		this.voiceUnit = voiceUnit;
	}
	
}
