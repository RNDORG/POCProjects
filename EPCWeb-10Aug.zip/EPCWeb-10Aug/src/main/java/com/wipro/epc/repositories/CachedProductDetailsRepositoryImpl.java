package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.CachedProductDetails;

public class CachedProductDetailsRepositoryImpl implements CachedProductDetailsRepositoryCustom {
	
	private static Logger logger =LoggerFactory.getLogger(CachedProductDetailsRepositoryImpl.class);

	@PersistenceContext
	EntityManager em;
	
	
	
	@Override
	public CachedProductDetails updateCachedProductDetails(
			CachedProductDetails cpd) {

		/*StringBuilder queryBuilder = new StringBuilder(
				"update cached_product_details set value="+cpd.getValue()
				+", id="+cpd.getId()
				+", status= 'Active' "
				);
		
		queryBuilder.append(" where id=").append(cpd.getId());
		
		String query = queryBuilder.toString();
		logger.info("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		*/		
		em.merge(cpd);
		
		return cpd;
	}
	
	@Override
	public List<CachedProductDetails> getList(String query) {
		logger.debug("#Query :"+query);
		return em.createNativeQuery(query,CachedProductDetails.class).getResultList();
	}

	@Override
	public void deleteByIds(String ids) {
		
			//@Query( value=" delete from cached_product_details where id IN :ids  ",nativeQuery=true)
			StringBuilder queryBuilder = new StringBuilder(
					"delete from cached_product_details where status='Active' and id IN ("+ids +")"
					);
			
			String query = queryBuilder.toString();
			logger.info("#Query: "+query);
			em.createNativeQuery(query).executeUpdate();
			
		}
		
	
	


}
