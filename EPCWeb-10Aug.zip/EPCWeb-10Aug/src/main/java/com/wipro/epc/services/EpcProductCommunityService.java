package com.wipro.epc.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.ComplexSearchInput;
import com.wipro.epc.dto.CorporatesAssociatedResponse;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductCommunityRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.util.Constants;
/**
 * 
 * @author VI251443
 * @version 1.0
 */
@Service
public class EpcProductCommunityService {

	
	private static Logger logger = LoggerFactory.getLogger(EpcProductCommunity.class);
	@Autowired
	EpcProductCommunityRepository epcProductCommunityRepository;
	
	@PersistenceContext
	EntityManager em; 
	
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	
	@Autowired
	EpcProductSpecificationRepository epcProductSpecificationRepository;
	
	@Autowired
	EpcLookupMasterService epcLookupMasterService;

	@Autowired
	ComplexSearchInputService complexSearchInputService;
	/**
	 * 
	 * @param productCommunityList
	 * @param username
	 * @return
	 */
	@Transactional
	public List<EpcProductCommunity> updateProductCommunity(
			List<EpcProductCommunity> productCommunityList, String username) {
		//validations 
		
		// *1 To check if product exists in product specification table, ie product_id exists in prod_spec table
		// *2 To check if product_id exists in product community table
			for(EpcProductCommunity community : productCommunityList)
			{
				if(community.getProductId() == null || community.getCommunityId() == null){
					throw new EPCException("Associate Community", "product id and community id are mandatory.", "product id and community id are mandatory.");
				}
			}
			for(EpcProductCommunity community : productCommunityList)
			{
				if(epcProductSpecificationRepository.findByProductId(community.getProductId()).isEmpty()){
					throw new EPCException(
							"Error occurred the product doesn't exist.\n"
									+ " Id passed: "+ community.getProductId());
				}
				else {
					Map<String, List<String>> allRequestParams = new HashMap<String, List<String>>();
					allRequestParams.put("productId", Arrays.asList(new String[]{String.valueOf(community.getProductId())}));
					allRequestParams.put("communityId", Arrays.asList(new String[]{String.valueOf(community.getCommunityId())}));
					
					if(community.getStatus() == null){
						community.setStatus(Constants.COMMON_STATUS_ACTIVE);
					}
					if(StringUtils.isBlank(community.getApplicableEmpBand())){
						community.setApplicableEmpBand("ALL");
					}
					allRequestParams.put("applicableEmpBand", Arrays.asList(new String[]{community.getApplicableEmpBand()}));
					List<EpcProductCommunity> listReturned = searchProductCommunity(allRequestParams);
					if(listReturned.isEmpty())
					{  
						community.setCreatedBy(username);
						community.setCreatedDate(new Date());
						epcProductCommunityRepository.save(community);
					}
					else
					{
						community.setModifiedBy(username);
						community.setModifiedDate(new Date());
					   epcProductCommunityRepository.modify(community);
					}
				}
			}
	
		return productCommunityList;
	}
	
    /**
     * 
     * @param allRequestParams
     * @return
     */
	public List<EpcProductCommunity> searchProductCommunity(
			Map<String, List<String>> allRequestParams) {
		if (allRequestParams.get("with") != null) {
			allRequestParams.remove("with");
		}
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductCommunity.class.getName(), null);
		List<EpcProductCommunity> listOfCommunitiesReturned = null;
		try {
			listOfCommunitiesReturned = epcProductCommunityRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return listOfCommunitiesReturned;
	}
	
    /**
     * 
     * @return
     */
	public List<EpcProductCommunity> getCommunityNames() {
		String query = "select distinct community_name from epc_product_community order by community_name";
		List<EpcProductCommunity> returnedChar = null;
		try {
			returnedChar = epcProductCommunityRepository.getCommunityNames();
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + query + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		 
		
		//System.out.println(returnedChar);		
		
		
			return returnedChar;
	}
	
	/**
	 * 
	 * @param communityName
	 * @param marketingName
	 * @param productType
	 * @return
	 */
	public List<EpcProductSpecification> getResultsForUI(String communityName, String marketingName, String productType) {
		String productId = "";
		int i = 0;
		List<EpcProductCommunity> listOfCommunitiesReturned = epcProductCommunityRepository.getList("select * from epc_product_community where community_name = '" + communityName + "' ");
		logger.info("COmmunity List is "+listOfCommunitiesReturned);
		for(EpcProductCommunity community : listOfCommunitiesReturned) {
			if(i==0) {
				productId = productId + " where (" ;
			}
			if(!productId.contains(community.getProductId().toString())) {
				productId = productId + " product_id = "+ community.getProductId() ;
				if(i<listOfCommunitiesReturned.size()){
					productId = productId+ " OR " ;
				}
			}
			i++;
			
		}
		if(productId.endsWith(" OR ")){
			productId = productId.substring(0, productId.length()-3);
		productId = productId + " )";
		}
		if(!listOfCommunitiesReturned.isEmpty())
		{	
			String queryForProducts = "select * from epc_product_specification "+productId;
			
			if(marketingName!=null){
				queryForProducts = queryForProducts + "and product_marketing_name = '"+marketingName+ "'";
			}
			
			if(productType!=null){
				queryForProducts = queryForProducts + " and product_type = '"+productType+"'";
			}
			
		//	logger.info("Query for products table is "+queryForProducts);
			List<EpcProductSpecification> listOfEpcSpecification =  epcProductSpecificationRepository.getList(queryForProducts);
			
			for(EpcProductSpecification product : listOfEpcSpecification)
			{
				List<EpcProductCommunity> communityList = new ArrayList<EpcProductCommunity>();
				for(EpcProductCommunity community : listOfCommunitiesReturned){
					if(community.getProductId().equals(product.getProductId())) {
						communityList.add(community);
					}
				}
				product.setEpcProductCommunity(communityList);
				
			}
			
			return listOfEpcSpecification;
		}
		else {
			return null;
		}
	}
	
	public List<Integer> getAllNonGlobalCorpPoolProductIds() {
		return epcProductCommunityRepository.getAllNonGlobalCorpPoolProductIds();
	}
	
	// code for corporate 
	public List<CorporatesAssociatedResponse> getCorporates(String corporateName,
			String corporateId, String corporateShortCode) {
		
		String testQuery = "select * from epc_product_community where community_name='"+corporateName+"' "
				+ "and community_short_code = '"+corporateShortCode+"'";
		
		if(corporateId!=null) {
			testQuery = testQuery  + " and community_id = "+corporateId;
		}
		
		List<EpcProductCommunity> communityList = epcProductCommunityRepository.getList(testQuery);
		logger.info("#communityList: "+communityList);
		if(!communityList.isEmpty()){
			if(communityList.get(0).getProductId()==null) {
				CorporatesAssociatedResponse singleElement = new CorporatesAssociatedResponse();
				singleElement.setCommunity(communityList.get(0));
				List<CorporatesAssociatedResponse> returnListSimple  = new ArrayList<CorporatesAssociatedResponse>();
				returnListSimple.add(singleElement);
				return returnListSimple;
			}
		}
		
		String query = "select distinct spec.product_id, spec.product_short_code,spec.product_marketing_name,"+ 
						" spec.product_description,spec.product_sub_family,spec.product_type, prodattr.attribute_value1, comm.community_id, "+
						" comm.community_name, comm.community_short_code, comm.cug_id, comm.slab_id, comm.is_vat_exempted, "+
						" comm.is_employee_allowed_to_purchase, comm.discounted_price, comm.status, comm.remarks, comm.community_status, spec.product_classification "+
						" from epc_product_attribute prodattr, epc_attribute_master attrmas, epc_product_specification spec"+ 
						", epc_product_community comm "+
						" where spec.product_id=prodattr.product_id and prodattr.attribute_id=attrmas.attribute_id and"+
						" attrmas.attribute_ctg='tariffCtg' and attribute_ctg_type ='OneTime' and attribute_name"+
						" in ('CONNECTION_FEE','SUBSCRIPTION_FEE') and spec.product_id =comm.product_id ";
		if(corporateName!=null){
			query = query + " and community_name = '"+corporateName+"'";
		}
		if(corporateId!=null) {
			query = query + " and community_id = '"+corporateId+"'";
		}
		if(corporateShortCode!=null) {
			query = query + " and community_short_code = '"+corporateShortCode+"'";
		}
		
		return getProductsFromQueryFirst(query);
	}

	
	
	public List<CorporatesAssociatedResponse> getGlobalPoolProducts(
			String productType, String productId, String productClassification, Boolean isUsageProducts, String productSubFamily) {
		
		String query = "select distinct spec.product_id, spec.product_short_code, spec.product_description,prodattr.attribute_value1"
				+" from epc_product_attribute prodattr, epc_attribute_master attrmas, epc_product_specification spec "
				+" , epc_product_community comm"
				+" where spec.product_id=prodattr.product_id and prodattr.attribute_id=attrmas.attribute_id and"
				+" attribute_name ='IS_USAGE_VID' and spec.product_classification='VID' and spec.product_id "
				+" NOT IN( select product_id from epc_product_community where product_id is not null)";
		
		return getProductsFromQuerySecond(query);
		
	}

	private List<CorporatesAssociatedResponse> getProductsFromQuerySecond(String query) {
		List<Object[]> productsDtoReturned = epcProductSpecificationRepository.getListOfObjects(query);
		List<CorporatesAssociatedResponse> returnList = new ArrayList<CorporatesAssociatedResponse>();
		for(Object[] object: productsDtoReturned){
			CorporatesAssociatedResponse singleElement = new CorporatesAssociatedResponse();
			singleElement.setProductId(object[0].toString());
			singleElement.setProductShortCode(object[1].toString());
			singleElement.setProductDescription(object[2].toString());
			
			if(object[3]!=null) {
				singleElement.setFee(object[3].toString());
			}
			returnList.add(singleElement);
		}
		return returnList;
	}
	public List<CorporatesAssociatedResponse> getProductsFromQuery(String productType, String productId, String productClassification, String productSubFamily){
		//call a function that doesn't gets results from complex query instead execute a sql query as Vidhu suggested.
		String query = "";
		if(productType!=null){
			
			query = query + " and spec.product_type = '"+productType+"' ";
			if(productId!=null){
				productId = productId.replace("*", "%");
				query  = query + " and spec.product_short_code like '"+productId+"' ";
			}
			if(productClassification!=null){
				query = query + " and spec.product_classification ='"+productClassification+"'";
			}
			if(productSubFamily!=null) {
				query = query + " and spec.product_sub_family = '"+productSubFamily+"'";
			}
		}
		String queryToBeExecuted = "select distinct spec.product_id, spec.product_short_code,spec.product_marketing_name, spec.product_description,"
									+"spec.product_sub_family,spec.product_type, prodattr.attribute_value1 "
									+"from epc_product_attribute prodattr, epc_attribute_master attrmas, epc_product_specification spec "
									+", epc_product_community comm "
									+"where spec.product_id=prodattr.product_id and prodattr.attribute_id=attrmas.attribute_id and "
									+"attrmas.attribute_ctg='tariffCtg' and attribute_ctg_type ='OneTime' and "
									+"attribute_name in ('CONNECTION_FEE','SUBSCRIPTION_FEE') and product_status='Launch' and "
									
									// get the products that have the sub_category='Both' or 'Corporate'
									+" (product_sub_category='ALL' or product_sub_category='Corporate') and "
									
									+" ((is_corporate_specific is null or is_corporate_specific =0) or "
									// get the products that can be associated any times.
									
									+ " (is_corporate_specific =1 and spec.product_id NOT IN( select product_id from epc_product_community where product_id is not null)))"
									// get the products that can be associated only once(ie products that are not already associated)
									+query;
		return getProductsFromQuery(queryToBeExecuted);
	}
	private List<CorporatesAssociatedResponse> getProductsFromQuery(String query) {
		List<Object[]> productsDtoReturned = epcProductSpecificationRepository.getListOfObjects(query);
		List<CorporatesAssociatedResponse> returnList = new ArrayList<CorporatesAssociatedResponse>();
		for(Object[] object: productsDtoReturned){
			CorporatesAssociatedResponse singleElement = new CorporatesAssociatedResponse();
			singleElement.setProductId(object[0].toString());
			singleElement.setProductShortCode(object[1].toString());
			singleElement.setProductMarketingName(object[2].toString());
			singleElement.setProductDescription(object[3].toString());
			singleElement.setProductSubFamily(object[4].toString());
			singleElement.setProductType(object[5].toString());
			if(object[6]!=null) {
				singleElement.setFee(object[6].toString());
			}
			returnList.add(singleElement);
		}
		return returnList;
	}
	
	private List<CorporatesAssociatedResponse> getProductsFromQueryFirst(String query) {
		List<Object[]> productsDtoReturned = epcProductSpecificationRepository.getListOfObjects(query);
		List<CorporatesAssociatedResponse> returnList = new ArrayList<CorporatesAssociatedResponse>();
		for(Object[] object: productsDtoReturned){
			CorporatesAssociatedResponse singleElement = new CorporatesAssociatedResponse();
			singleElement.setProductId(object[0].toString());
			singleElement.setProductShortCode(object[1].toString());
			singleElement.setProductMarketingName(object[2].toString());
			singleElement.setProductDescription(object[3].toString());
			singleElement.setProductSubFamily(object[4].toString());
			singleElement.setProductType(object[5].toString());
			if(object[6]!=null) {
				singleElement.setFee(object[6].toString());
			}
			
			EpcProductCommunity community = new EpcProductCommunity();
			if(object[7]!=null) {
				community.setCommunityId(object[7].toString());
			}
			if(object[8]!=null) {
				community.setCommunityName(object[8].toString());
			}
			if(object[9]!=null) {
				community.setCommunityShortCode(object[9].toString());
			}
			if(object[10]!=null) {
				community.setCugId(object[10].toString());
			}
			if(object[11]!=null) {
				community.setSlabId(object[11].toString());
			}
			if(object[12]!=null) {
				if(object[12].toString().equals("false")) {
					object[12] = '0';
				} else {
					object[12] = '1';
				}
				community.setIsVatExempted((byte)Integer.parseInt(object[12].toString()));
			}
			if(object[13]!=null) {
				if(object[13].toString().equals("false")) {
					object[13] = '0';
				} else {
					object[13] = '1';
				}
				community.setIsEmployeeAllowedToPurchase((byte)Integer.parseInt(object[13].toString()));
			}
			if(object[14]!=null) {
				community.setDiscountedPrice(new BigDecimal(object[14].toString()));
			}
			if(object[15]!=null) {
				community.setStatus(object[15].toString());
			}
			if(object[16]!=null) {
				community.setRemarks(object[16].toString());
			}
			if(object[17]!=null) {
				community.setCommunityStatus(object[17].toString());
			}
			if(object[18]!=null) {
				singleElement.setProductClassification(object[18].toString());
			}
			singleElement.setCommunity(community);
			
			returnList.add(singleElement);
		}
		return returnList;
	}
	
	public List<String> checksUsageProducts(List<EpcProductSpecification> products) {
		System.out.println("Products obtained are "+products);
		List<String> returnList = new ArrayList<String>();
		for(EpcProductSpecification product : products) {
			ComplexSearchInput searchInput = new ComplexSearchInput();
			searchInput.setProductClassification("VID");
			searchInput.setProductShortCode(product.getProductShortCode());
			Map<String, List<String>> allRequestParams = new HashMap<String, List<String>>();
			List<String> withList = new ArrayList<String>();
			withList.add("characteristic");
			allRequestParams.put("with", withList);
			List<EpcProductAttribute> attributeList = new ArrayList<EpcProductAttribute>();
			List<EpcProductSpecification> productList = complexSearchInputService.searchComplex(searchInput, allRequestParams, true);
			if(productList!=null && !productList.isEmpty()) {
				EpcProductSpecification productFirst = productList.get(0);
				System.out.println("Results from complex search is "+productFirst);
				
				attributeList = productFirst.getEpcProductCharacteristic();
				
				System.out.println("Attribute list is "+attributeList);
				if(attributeList!=null && !attributeList.isEmpty()) {
					for(EpcProductAttribute attribute: attributeList) {
						if("IS_USAGE_VID".equals(attribute.getEpcAttributeMaster().getAttributeName())){
							System.out.println("Inside Usage VID, product id is "+product.getProductId());
							if("true".equals(attribute.getAttributeValue1())){
								returnList.add("YES");
								break;
							}
							else if("false".equals(attribute.getAttributeValue1())){
								returnList.add("NO");
								break;
							}
						}
						
					}
				}
				else {
					returnList.add("NO");
				}
				
				
			}
		}
		return returnList;
	}
	
	@Transactional
	public List<EpcProductCommunity> updateCorporate(
			List<EpcProductCommunity> corporateProducts, String username) {
		
//		for(EpcProductCommunity community : corporateProducts) {
//			Map<String, List<String>> allRequestParams = new HashMap<String, List<String>>();
//			allRequestParams.put("productId", Arrays.asList(new String[]{String.valueOf(community.getProductId())}));
//			allRequestParams.put("communityId", Arrays.asList(new String[]{String.valueOf(community.getCommunityId())}));
//
//			List<EpcProductCommunity> listReturned = searchProductCommunity(allRequestParams);
//			if(listReturned.isEmpty())
//			{  
//				community.setProductCommunityId(null);
//				community.setCreatedBy(username);
//				community.setCreatedDate(new Date());
//				if(community.getStatus()==null) {
//					community.setStatus("Active");
//				}
//				System.out.println("Trying to save product "+community.getProductId());
//				epcProductCommunityRepository.save(community);
//				System.out.println("Saving product with community id "+ community.getCommunityId()+" "+community.getProductId()+" successfull");
//				
//			}
//			else
//			{
//				community.setModifiedBy(username);
//				community.setModifiedDate(new Date());
//				System.out.println("Update Number "+community.getProductId());
//				epcProductCommunityRepository.update(community);
//				System.out.println("Update Successfull for product with community id "+ community.getCommunityId()+" "+community.getProductId());
//			}
//		}
//		return corporateProducts;
			System.out.println("COmmunity id is "+corporateProducts.get(0));
			String communityId = corporateProducts.get(0).getCommunityId();
			String query = "delete from epc_product_community where"
					+ " community_name = '"+corporateProducts.get(0).getCommunityName()+"' and"
					+ " community_short_code = '"+corporateProducts.get(0).getCommunityShortCode()+"'";
//			if(communityId!=null && !communityId.equals("")){
//				query = query + " and community_id = "+corporateProducts.get(0).getCommunityId();
//			}
			em.createNativeQuery(query).executeUpdate();
			
			for(EpcProductCommunity community : corporateProducts) {
				community.setProductCommunityId(null);
				community.setCreatedBy(username);
				community.setCreatedDate(new Date());
				if(community.getStatus()==null) {
					community.setStatus("Active");
				}
				System.out.println("Trying to save product "+community.getProductId());
				epcProductCommunityRepository.save(community);
				System.out.println("Saved successfully");
			}
			return corporateProducts;
	}

	public List<String> getEmployeeBands() {
		return epcProductCommunityRepository.getEmployeeBands();
	}
	
	
}
