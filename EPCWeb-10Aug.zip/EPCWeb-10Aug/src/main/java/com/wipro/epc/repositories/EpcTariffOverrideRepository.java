package com.wipro.epc.repositories;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;



import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.EpcTariffOverride;
/**
 * @author Developer
 * @version 1.0
 * type EpcTariffOverrideRepository
 */
@Repository
public interface EpcTariffOverrideRepository extends CrudRepository<EpcTariffOverride,Integer>,
EpcTariffOverrideRepositoryCustom{
	
	/**
	 * @param otherProdId1
	 * @param otherProdId2
	 * @param otherProdId3
	 * @param otherProdId4
	 * @param ratePlanId
	 * @param addonProdId
	 * @return
	 */
	@Query(value="select override_tariff_amount from epc_tariff_override where rateplan_product_id=:ratePlanId and addon_product_id=:addonProdId"
			+ " and other_product_id_1=:otherProdId1 and other_product_id_2=:otherProdId2 and other_product_id_3=:otherProdId3 "
			+ "and other_product_id_4=:otherProdId4 order by priority", nativeQuery = true)
	List<BigDecimal> getOverrideTariffAmount(@Param("otherProdId1") String otherProdId1,@Param("otherProdId2") String otherProdId2,@Param("otherProdId3") String otherProdId3,
			@Param("otherProdId4") String otherProdId4,@Param("ratePlanId") String ratePlanId,@Param("addonProdId") String addonProdId);

	@Query(value="select * from epc_tariff_override where rateplan_product_id  = :ratePlanId", nativeQuery=true)
	List<EpcTariffOverride> getTariffOverridePrimary(@Param("ratePlanId") String ratePlanId);
	
	@Query(value="select * from epc_tariff_override where addon_product_id  = :addOnId", nativeQuery=true)
	List<EpcTariffOverride> getTariffOverrideOptional(@Param("addOnId") String addOnId);
	
	@Query(value="select * from epc_tariff_override where attribute_name='SUBSCRIPTION_FEE' order by priority ",nativeQuery=true)
	List<EpcTariffOverride> getEpcTariffOverrideForCaching();
}
