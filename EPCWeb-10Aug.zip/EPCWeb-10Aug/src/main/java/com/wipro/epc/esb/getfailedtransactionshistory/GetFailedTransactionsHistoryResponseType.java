
package com.wipro.epc.esb.getfailedtransactionshistory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.CustomRefType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.FaultType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.TransactionReferenceType;


/**
 * <p>Java class for getFailedTransactionsHistoryResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getFailedTransactionsHistoryResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}TransactionReference" minOccurs="0"/>
 *         &lt;element name="returnCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recordSum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="logInfos" type="{http://www.telenor.com.mm/getFailedTransactionsHistory}LogInfo" minOccurs="0"/>
 *         &lt;element name="transactionID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}CustomRef" minOccurs="0"/>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}Fault" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getFailedTransactionsHistoryResponseType", propOrder = {
    "transactionReference",
    "returnCode",
    "recordSum",
    "logInfos",
    "transactionID",
    "customRef",
    "fault"
})
public class GetFailedTransactionsHistoryResponseType {

    @XmlElement(name = "TransactionReference", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected TransactionReferenceType transactionReference;
    protected String returnCode;
    protected String recordSum;
    protected LogInfo logInfos;
    protected String transactionID;
    @XmlElement(name = "CustomRef", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected CustomRefType customRef;
    @XmlElement(name = "Fault", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected FaultType fault;

    /**
     * Gets the value of the transactionReference property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionReferenceType }
     *     
     */
    public TransactionReferenceType getTransactionReference() {
        return transactionReference;
    }

    /**
     * Sets the value of the transactionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionReferenceType }
     *     
     */
    public void setTransactionReference(TransactionReferenceType value) {
        this.transactionReference = value;
    }

    /**
     * Gets the value of the returnCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnCode() {
        return returnCode;
    }

    /**
     * Sets the value of the returnCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnCode(String value) {
        this.returnCode = value;
    }

    /**
     * Gets the value of the recordSum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordSum() {
        return recordSum;
    }

    /**
     * Sets the value of the recordSum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordSum(String value) {
        this.recordSum = value;
    }

    /**
     * Gets the value of the logInfos property.
     * 
     * @return
     *     possible object is
     *     {@link LogInfo }
     *     
     */
    public LogInfo getLogInfos() {
        return logInfos;
    }

    /**
     * Sets the value of the logInfos property.
     * 
     * @param value
     *     allowed object is
     *     {@link LogInfo }
     *     
     */
    public void setLogInfos(LogInfo value) {
        this.logInfos = value;
    }

    /**
     * Gets the value of the transactionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * Sets the value of the transactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionID(String value) {
        this.transactionID = value;
    }

    /**
     * Gets the value of the customRef property.
     * 
     * @return
     *     possible object is
     *     {@link CustomRefType }
     *     
     */
    public CustomRefType getCustomRef() {
        return customRef;
    }

    /**
     * Sets the value of the customRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomRefType }
     *     
     */
    public void setCustomRef(CustomRefType value) {
        this.customRef = value;
    }

    /**
     * Gets the value of the fault property.
     * 
     * @return
     *     possible object is
     *     {@link FaultType }
     *     
     */
    public FaultType getFault() {
        return fault;
    }

    /**
     * Sets the value of the fault property.
     * 
     * @param value
     *     allowed object is
     *     {@link FaultType }
     *     
     */
    public void setFault(FaultType value) {
        this.fault = value;
    }

}
