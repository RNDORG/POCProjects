package com.wipro.epc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.services.TransactionsService;
import com.wipro.common.gs.util.EPCTxnInterceptor;
import com.wipro.epc.domain.EpcActivityMaster;
import com.wipro.epc.dto.ActivitySearchInput;
import com.wipro.epc.dto.ActivitySearchOutput;
import com.wipro.epc.services.EpcActivityMasterService;
/**
 * 
 * @author VI251443
 * @version 1.0
 */
@RestController
public class EpcActivityMasterController {

private static Logger logger = LoggerFactory.getLogger(EpcActivityMasterController.class);
	
@Autowired
EpcActivityMasterService epcActivityDetatilService;

@Autowired
EPCTxnInterceptor ePCTxnInterceptor;

@Autowired
ObjectMapper mapper;

@Autowired
TransactionsService transactionsLogging ;
	    /**
	     * 
	     * @param productCommunityList
	     * @return
	     */
		@RequestMapping(value="/rest/api/v1/activityConfigs",method=RequestMethod.POST)
		public List<EpcActivityMaster> manageActivities(@RequestBody List<EpcActivityMaster> productCommunityList)
		{
			String user=SecurityContextHolder.getContext().getAuthentication().getName();
			//System.out.println("Sent list is "+productCommunityList);
			return epcActivityDetatilService.manageActivities(productCommunityList, user);
		}
		
		/**
		 * 
		 * @param productCommunityList
		 * @param activityId
		 * @return
		 */
		@RequestMapping(value="/rest/api/v1/activityConfig",method=RequestMethod.POST)
		public List<EpcActivityMaster> updateActivities(@RequestBody List<EpcActivityMaster> productCommunityList, 
				 @RequestParam(value="activityId", required = false)  String activityId)
		{
			String user=SecurityContextHolder.getContext().getAuthentication().getName();
			//System.out.println("Product community list is "+productCommunityList);
			//System.out.println("Parameters are name, id"+activityId);
			return epcActivityDetatilService.updateActivities(productCommunityList, user, activityId);
		}
		
		/**
		 * 
		 * @param activityName
		 * @param key
		 * @return
		 */
		@RequestMapping(value="/rest/api/v1/activityConfigs", method=RequestMethod.GET)
		public List<EpcActivityMaster> searchActivities(@RequestParam(value="name", required = false) String activityName, @RequestParam(value="key", required = false)  String key)
		{
			//System.out.println("name is "+activityName+" Key is "+key);
					return epcActivityDetatilService.searchActivities(activityName, key);
		}
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
	@RequestMapping(value="/rest/api/v1/activityMasters", method=RequestMethod.GET)
	public List<EpcActivityMaster> searchActivityMaster(@RequestParam MultiValueMap allRequestParams)
	{
 			return epcActivityDetatilService.searchActivityMaster(allRequestParams);
	}
	
/**
 * 
 * @param searchInput
 * @param allRequestParams
 * @return
 */
	@RequestMapping(value="/rest/extapi/v1/activityNew",method=RequestMethod.POST)
	public ActivitySearchOutput updateActivitiesExt(@RequestBody ActivitySearchInput searchInput,@RequestParam MultiValueMap allRequestParams)
	{
		String txnType="activity";
		String request=ePCTxnInterceptor.preTxn(txnType, allRequestParams, searchInput);
		ActivitySearchOutput response=epcActivityDetatilService.updateActivityExt(searchInput,allRequestParams);
		ePCTxnInterceptor.postTxn(txnType, request, response ); 
		return response;
		
	}
}
