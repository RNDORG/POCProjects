/**
 * 
 *//*
package com.wipro.epc.esb;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.wipro.epc.esb.queryvasservice.QueryVASServiceRequestType;


public class Test {

	*//**
	 * @param args
	 *//*
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(QueryVASServiceConfig.class);
		EsbRequestService test = context.getBean(EsbRequestService.class);
		//VASSubscriptiondetails b = (VASSubscriptiondetails) context.getBean("vasClient");
		
		//QueryVASServiceRequestType vasServiceRequest = new QueryVASServiceRequestType();
		 //vasServiceRequest.setSubscriberNo(msisdn);
		 //vasServiceRequest.setSubscriberNo("8801711083817");
		// vasServiceRequest.setOrigSourceSystem("CCC");
		// vasServiceRequest.setOrigTxnRefId("89765");
		// vasServiceRequest.setOfferProvider("");
		 //QueryVASServicesResponseMsg  resp = b.queryVASSService(vasServiceRequest);		 
		// //System.out.println(resp.getQueryVASServiceResponse().getCurrentSubscriptions().get(0).getOfferId());
		
		test.getVASAddons("8801711083817","http://10.10.23.191:7001/VASSubscriptiondetails/PS/VASSubscriptiondetailsPS?wsdl");
		
	}

}
*/