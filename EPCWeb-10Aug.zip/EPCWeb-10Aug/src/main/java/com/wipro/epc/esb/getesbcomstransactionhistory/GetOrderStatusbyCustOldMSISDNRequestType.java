
package com.wipro.epc.esb.getesbcomstransactionhistory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.CustomRefType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.TransactionReferenceType;


/**
 * <p>Java class for GetOrderStatusbyCustOldMSISDNRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetOrderStatusbyCustOldMSISDNRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}TransactionReference" minOccurs="0"/>
 *         &lt;element name="Circle" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerMSISDN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustomerNewMSISDN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartnerMSISDN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustomerNewIMSI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustomerIMSI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrderID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FromDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ToDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}CustomRef" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetOrderStatusbyCustOldMSISDNRequestType", propOrder = {
    "transactionReference",
    "circle",
    "customerMSISDN",
    "customerNewMSISDN",
    "partnerMSISDN",
    "customerNewIMSI",
    "customerIMSI",
    "orderID",
    "fromDate",
    "toDate",
    "customRef"
})
public class GetOrderStatusbyCustOldMSISDNRequestType {

    @XmlElement(name = "TransactionReference", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected TransactionReferenceType transactionReference;
    @XmlElement(name = "Circle", required = true)
    protected String circle;
    @XmlElement(name = "CustomerMSISDN")
    protected String customerMSISDN;
    @XmlElement(name = "CustomerNewMSISDN")
    protected String customerNewMSISDN;
    @XmlElement(name = "PartnerMSISDN")
    protected String partnerMSISDN;
    @XmlElement(name = "CustomerNewIMSI")
    protected String customerNewIMSI;
    @XmlElement(name = "CustomerIMSI")
    protected String customerIMSI;
    @XmlElement(name = "OrderID")
    protected String orderID;
    @XmlElement(name = "FromDate")
    protected String fromDate;
    @XmlElement(name = "ToDate")
    protected String toDate;
    @XmlElement(name = "CustomRef", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected CustomRefType customRef;

    /**
     * Gets the value of the transactionReference property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionReferenceType }
     *     
     */
    public TransactionReferenceType getTransactionReference() {
        return transactionReference;
    }

    /**
     * Sets the value of the transactionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionReferenceType }
     *     
     */
    public void setTransactionReference(TransactionReferenceType value) {
        this.transactionReference = value;
    }

    /**
     * Gets the value of the circle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCircle() {
        return circle;
    }

    /**
     * Sets the value of the circle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCircle(String value) {
        this.circle = value;
    }

    /**
     * Gets the value of the customerMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerMSISDN() {
        return customerMSISDN;
    }

    /**
     * Sets the value of the customerMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerMSISDN(String value) {
        this.customerMSISDN = value;
    }

    /**
     * Gets the value of the customerNewMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerNewMSISDN() {
        return customerNewMSISDN;
    }

    /**
     * Sets the value of the customerNewMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerNewMSISDN(String value) {
        this.customerNewMSISDN = value;
    }

    /**
     * Gets the value of the partnerMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartnerMSISDN() {
        return partnerMSISDN;
    }

    /**
     * Sets the value of the partnerMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartnerMSISDN(String value) {
        this.partnerMSISDN = value;
    }

    /**
     * Gets the value of the customerNewIMSI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerNewIMSI() {
        return customerNewIMSI;
    }

    /**
     * Sets the value of the customerNewIMSI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerNewIMSI(String value) {
        this.customerNewIMSI = value;
    }

    /**
     * Gets the value of the customerIMSI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerIMSI() {
        return customerIMSI;
    }

    /**
     * Sets the value of the customerIMSI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerIMSI(String value) {
        this.customerIMSI = value;
    }

    /**
     * Gets the value of the orderID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderID() {
        return orderID;
    }

    /**
     * Sets the value of the orderID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderID(String value) {
        this.orderID = value;
    }

    /**
     * Gets the value of the fromDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromDate() {
        return fromDate;
    }

    /**
     * Sets the value of the fromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromDate(String value) {
        this.fromDate = value;
    }

    /**
     * Gets the value of the toDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToDate() {
        return toDate;
    }

    /**
     * Sets the value of the toDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToDate(String value) {
        this.toDate = value;
    }

    /**
     * Gets the value of the customRef property.
     * 
     * @return
     *     possible object is
     *     {@link CustomRefType }
     *     
     */
    public CustomRefType getCustomRef() {
        return customRef;
    }

    /**
     * Sets the value of the customRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomRefType }
     *     
     */
    public void setCustomRef(CustomRefType value) {
        this.customRef = value;
    }

}
