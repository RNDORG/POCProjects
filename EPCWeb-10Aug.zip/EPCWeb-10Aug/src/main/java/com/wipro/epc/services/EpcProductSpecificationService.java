package com.wipro.epc.services;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.controller.CachedProductController;
import com.wipro.epc.controller.EpcProductProviderController;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductAvailability;
import com.wipro.epc.domain.EpcProductCompatibility;
import com.wipro.epc.domain.EpcProductHeirarchy;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductLocation;
import com.wipro.epc.domain.EpcProductNetworkTplMap;
import com.wipro.epc.domain.EpcProductMigration;
import com.wipro.epc.domain.EpcProductProviderSystem;
import com.wipro.epc.domain.EpcProductSalesChannel;
import com.wipro.epc.domain.EpcProductSegment;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.domain.EpcProductStatusHistory;
import com.wipro.epc.domain.EpcTariffOverride;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductAttributeRepository;
import com.wipro.epc.repositories.EpcProductAvailabilityRepository;
import com.wipro.epc.repositories.EpcProductCompatibilityRepository;
import com.wipro.epc.repositories.EpcProductInitChannelRepository;
import com.wipro.epc.repositories.EpcProductLocationRepository;
import com.wipro.epc.repositories.EpcProductNetworkTplMapRepository;
import com.wipro.epc.repositories.EpcProductMigrationRepository;
import com.wipro.epc.repositories.EpcProductNetworkTplRepository;
import com.wipro.epc.repositories.EpcProductProviderSystemRepository;
import com.wipro.epc.repositories.EpcProductSalesChannelRepository;
import com.wipro.epc.repositories.EpcProductSegmentRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.repositories.EpcProductStatusHistoryRepository;
import com.wipro.epc.util.Constants;


/**
 * @author KE334465
 *
 */
@Service
public class EpcProductSpecificationService {
	
	@Autowired
	private EpcTariffOverrideService epcTariffOverrideService;
	
	@Autowired
	private EpcProductSpecificationRepository epcProductSpecificationRepository;
	
	@Autowired
	private EpcProductNetworkTplMapRepository epcProductNetworkTplMapRepository;
	
	@Autowired
	private EpcProductAvailabilityService epcProductAvailabilityService;
	
	@Autowired
	private EpcProductSalesChannelService epcProductSalesChannelService;
	
	@Autowired
	private EpcProductInitChannelService epcProductInitChannelService;
	
	@Autowired
	private EpcProductLocationService epcProductLocationService;
	
	@Autowired
	private EpcProductSegmentRepository epcProductSegmentRepository;
	
	@Autowired
	private EpcProductSalesChannelRepository epcProductSalesChannelRepository;
	
	@Autowired
	private EpcProductInitChannelRepository epcProductInitChannelRepository;
	
	@Autowired
	private EpcProductAvailabilityRepository epcProductAvailabilityRepository;
	
	@Autowired
	private EpcProductLocationRepository epcProductLocationRepository;
	
	@Autowired
	private EpcProductCompatibilityRepository epcProductCompatibilityRepository;
	
	@Autowired
	private EpcProductAttributeRepository epcProductAttributeRepository;
	
	@Autowired
	private EpcProductSegmentService epcProductSegmentService;

	@Autowired
	private EpcProductCompatibilityService epcProductCompatibilityService;
	
	
	@Autowired
	private EpcProductAttributeService epcProductAttributeService;
	

	@Autowired
	private EpcProductMigrationRepository epcProductMigrationRepository;
	
	@Autowired
	private EpcProductMigrationService epcproductMigrationService;
	
	@Autowired
	private EpcProductHeirarchyService epcProductHeirarchyService;
	
	@Autowired
	private EpcProductNetworkTplRepository epcProductNetworkTplRepository;
	
	@Autowired
	private EpcProductProviderSystemService epcProductProviderSystemService;
	
	@Autowired
	private EpcProductProviderSystemRepository epcProductProviderSystemRepository;
	
	@Autowired
	private ProductApprovalService approvalService;
	
	@Autowired
	private EpcProductStatusHistoryRepository productStatusHistoryRepo;
	
	@Autowired
	private MCachedProductService mProductCacheService;
	
	@Autowired
	CachedProductService cachedProductService;
	
	@Autowired
	EpcProductProviderController providerController;

	/**
	 * @param productsList
	 * @param txn
	 * @param mix_op
	 * @param createdBy
	 * @param values
	 * @return
	 */
	@Transactional
	public List<EpcProductSpecification> updateProduct(List<EpcProductSpecification> productsList,
			boolean txn,boolean mix_op,String createdBy, MultiValueMap values)	{
		
			List<String> withValues = (List<String>) values.get("with");
			System.out.println("values frm Service "+values);
			List<EpcProductSpecification> newProductList=new ArrayList<EpcProductSpecification>();
			
			for(EpcProductSpecification product:productsList)
			{
				try
				{	String compatibilityOtherIds = "";
					List<String> ids = new ArrayList<String>();
					ids.add( compatibilityOtherIds );
					EpcProductSpecification productSpec = updateProduct(product,createdBy, withValues, ids);
					if(productSpec!=null)
					{
						product= productSpec;
					}
					//***************cacheProduct******************************
					final int cachedProductId=product.getProductId();
					
					MultiValueMap<String, String > reqMap = new LinkedMultiValueMap<String, String >();
					compatibilityOtherIds = ids.get(0);
					if(StringUtils.isNotBlank(compatibilityOtherIds)){
						compatibilityOtherIds= compatibilityOtherIds+",";
					}
					compatibilityOtherIds= compatibilityOtherIds+Integer.toString(cachedProductId);
					ids.clear();
					ids.add( compatibilityOtherIds );					
					reqMap.put("id", ids);
					reqMap.put("broadcast",Arrays.asList("true"));
					
					Thread t=new Thread(new Runnable() {
						@Override
						public void run() {
							cachedProductService.reloadService(reqMap);//notifyProductCache(  cachedProductId , "productSpec" ) ;
							
						}
					});
					t.start();
					//*****************cacheProduct****************************
					//*****************provider cache****************************
					if( withValues != null && (withValues.contains("all") || withValues.contains("provider")) ){
						Thread tProvider=new Thread(new Runnable() {
							
							@Override
							public void run() {
								providerController.reloadProviderProductCache();
								
							}
						});
						tProvider.start();
					}
					//****************provider cache*****************************
					product.getMetaInfo().put(MetaInfo.STATUS,MetaInfo.SUCCESS);
				}catch( Exception e ) {
					if (txn ) {
						throw e;
					} else {
						product.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.ERROR);
						product.getMetaInfo().put(MetaInfo.ERROR_MESSAGE, e.getMessage());
					}				
				}
				newProductList.add(product);
			}
			
				return newProductList;
			}
	
	/**
	 * @param product
	 * @param createdBy
	 * @param withValues
	 * @param ids 
	 * @return
	 */
	public EpcProductSpecification updateProduct(EpcProductSpecification product,String createdBy, List<String> withValues, List<String> ids) 
		{
		switch(product.getMetaInfo().get("OPERATION"))
		{
			case "CREATE" : createProduct(product,createdBy, withValues);
							manageChidlren(product,createdBy, withValues, ids);
							break;
							
			case "UPDATE" : modifyProduct(product,createdBy);
							manageChidlren(product,createdBy, withValues, ids);
							break;
							
			case "UPDATE_CHILD" : manageChidlren(product,createdBy, withValues, ids);
							break;
			
			case "UPDATE_PARENT" : modifyProduct(product,createdBy);
							break;
			
			case "DELETE" : //All the children should be deleted before deleting the product
							epcProductAvailabilityRepository.deleteProductFromAvailability(product.getProductId());
							epcProductSegmentRepository.deleteProductFromSegment(product.getProductId());
							epcProductSalesChannelRepository.deleteProductFromChannel(product.getProductId());
							epcProductLocationRepository.deleteProductFromLocation(product.getProductId());
							epcProductInitChannelRepository.deleteProductFromInit(product.getProductId());
							epcProductCompatibilityRepository.deleteProductFromCompatibility(product.getProductId());
							epcProductAttributeRepository.deleteProductFromAttribute(product.getProductId());
							//manageChidlren(product,createdBy, withValues);
							epcProductMigrationRepository.deleteProductFromMigration(product.getProductId());
							epcProductProviderSystemRepository.deleteProductFromProviders(product.getProductId());
							deleteProduct(product);
							
							break;
			default : throw new EPCException("not supported");		
		}
			//manageChidlren(product,createdBy, withValues);
			return product;
		}
	
	/**
	 * @param product
	 * @param createdBy
	 * @param withValues
	 * @param ids.get(0) 
	 */
	private void manageChidlren(EpcProductSpecification product,
			String createdBy, List<String> withValues, List<String> ids) {
		if(withValues!=null && !withValues.isEmpty()) {
			if ( (withValues.contains("segment") || withValues.contains("all"))) {
				List<EpcProductSegment> segments = product.getEpcProductSegment();
				for(EpcProductSegment segment : segments) {
					segment.setProductId(product.getProductId());
				}
				epcProductSegmentService.manageProductSegments(segments, createdBy);
			}
			if ( withValues.contains("all") || withValues.contains("availability")) {
				List<EpcProductAvailability> availabilities = product.getEpcProductAvailability();
				for(EpcProductAvailability availability : availabilities)
				{
					availability.setProductId(product.getProductId());
					availability.setStatus(Constants.COMMON_STATUS_ACTIVE);
				}
				epcProductAvailabilityService.manageProductAvailabilities(availabilities, createdBy);
			}
			if ( withValues.contains("all") || withValues.contains("salesChannel")) {
				List<EpcProductSalesChannel> channels = product.getEpcProductSalesChannel();

				for(EpcProductSalesChannel channel : channels) {
					channel.setProductId(product.getProductId());
				}

				epcProductSalesChannelService.manageProductSalesChannels(channels, createdBy);
			}
			if ( withValues.contains("all") || withValues.contains("location")) {
				List<EpcProductLocation> locations = product.getEpcProductLocation();
				for(EpcProductLocation location : locations) {
					location.setProductId(product.getProductId());
				}

				epcProductLocationService.manageProductLocations(locations, createdBy);
			}
			if ( withValues.contains("all") || withValues.contains("initiatingChannel")) {
				List<EpcProductInitChannel> inits = product.getEpcProductInitChannel();
				for(EpcProductInitChannel init : inits) {
					init.setProductId(product.getProductId());
				}

				epcProductInitChannelService.manageProductInitChannels(inits, createdBy);
			}

			if ( withValues.contains("all") || withValues.contains("compatibility")) {
				List<EpcProductCompatibility> comapatibility = product.getEpcProductCompatibility();
				if(comapatibility != null){
					String compOtherIds = ids.get(0);
					for(EpcProductCompatibility comp : comapatibility)
					{
						comp.setProductId(product.getProductId());
						if(StringUtils.isNotBlank(compOtherIds)){
							compOtherIds= compOtherIds+",";
						}
						compOtherIds= compOtherIds+String.valueOf(comp.getOtherProductId());
					}
					ids.clear();
					ids.add(compOtherIds);
					epcProductCompatibilityService.manageProductCompatibilities(comapatibility, createdBy);
				}
			}

			if ( (withValues.contains("characteristic") || withValues.contains("all"))) {
				List<EpcProductAttribute> attributes = product.getEpcProductAttribute();
				for(EpcProductAttribute attribute : attributes) {
					attribute.setProductId(product.getProductId());
				}
				//System.out.println("");
				epcProductAttributeService.manageProductAttribute(attributes, createdBy);
		
			}
			
			// code for tariff override 
			if ( (withValues.contains("tariffOverride") || withValues.contains("all"))) {
				List<EpcTariffOverride> tariffOverride = product.getEpcProductTariffOverride();
				
				epcTariffOverrideService.manageTariffOverride(tariffOverride, createdBy);
		
			}
			
			
			// code for tariff override ends here
			


			if ( withValues.contains("all") || withValues.contains("migration")) {
				List<EpcProductMigration> migrations = product.getEpcProductMigration();
				if(migrations != null){
				for(EpcProductMigration migration : migrations) {
					migration.setSourceProductId(product.getProductId());
				}

				epcproductMigrationService.manageProductMigrations(migrations, createdBy);
				}
			}

			if ( withValues.contains("all") || withValues.contains("bundle")) {
				List<EpcProductHeirarchy> heirarchies = product.getEpcProductHeirarchy();
				for(EpcProductHeirarchy heirarchy : heirarchies) {
					heirarchy.setParentProductId(product.getProductId());
				}

				epcProductHeirarchyService.manageProductHeirarchies(heirarchies, createdBy);
			}
			/*if (withValues.contains("all") || withValues.contains("networkTemplate")) {
				EpcProductNetworkTplMap networkTplMap = product.getEpcProductNetworkTplMap();
				
					networkTplMap.setProductId(product.getProductId());
			}*/
			if ( withValues.contains("all") || withValues.contains("provider")) {
				List<EpcProductProviderSystem> providers = product.getEpcProductProvider();

				for(EpcProductProviderSystem provider : providers) {
					provider.setProductId(product.getProductId());
				}

				epcProductProviderSystemService.manageProductProviders(providers, createdBy);
			}
				
		
	}
	}

	/**
	 * @param product
	 * @param createdBy
	 * @param withValues
	 * @return
	 */
	EpcProductSpecification createProduct(EpcProductSpecification product,String createdBy, List<String> withValues) // String with 
	{
		product.setCreatedBy(createdBy);
		product.setCreatedDate(new Date());
		epcProductSpecificationRepository.save(product);
	/*	Commented to remove networkProfile tag
	 * if(product.getNetworkProfileId()!=null && product.getNetworkProfileId().length()>0)
		{
			//logger.info("product.getNetworkProfileId()"+product.getNetworkProfileId());
		EpcProductNetworkTplMap epcProductNetworkTplMap = new EpcProductNetworkTplMap();
		epcProductNetworkTplMap.setProductId(product.getProductId());
		epcProductNetworkTplMap.setTemplateName(product.getNetworkProfileId());
		epcProductNetworkTplMap.setCreatedBy(createdBy);
		epcProductNetworkTplMap.setStatus(Constants.COMMON_STATUS_ACTIVE);
		//epcProductNetworkTplMap.setProductTemplateMapId(1);
		epcProductNetworkTplMap.setCreatedDate(new Date());
		epcProductNetworkTplMapRepository.save(epcProductNetworkTplMap);
		}*/
		return product;
	}
	/**
	 * @param product
	 * @param modifiedBy
	 * @return
	 */
	EpcProductSpecification modifyProduct(EpcProductSpecification product,String modifiedBy)
	{
		EpcProductSpecification productAvail=new EpcProductSpecification();
		product.setModifiedBy(modifiedBy);
		
		//logger.info("in service"+product.getNetworkProfileId());
		
		EpcProductNetworkTplMap epcProductNetworkTplMap = new EpcProductNetworkTplMap();
		epcProductNetworkTplMap.setProductId(product.getProductId());
		/*Commented to remove networkProfile tag
		 * epcProductNetworkTplMap.setTemplateName(product.getNetworkProfileId());
		if(product.getNetworkProfileId()==null){
			epcProductNetworkTplMapRepository.deleteProductFromNetworkTpl(product.getProductId());
		}else{
			epcProductNetworkTplMapRepository.modifyNetworkId(epcProductNetworkTplMap);
		}*/
		
		EpcProductSpecification specUpdated = epcProductSpecificationRepository.modifyProductSpec(product);
		if(specUpdated.getProductStatus().equalsIgnoreCase(Constants.PRODUCT_STATUS_SUBMITTED)){
			List<EpcProductSpecification> resultData = epcProductSpecificationRepository.findByProductId(product.getProductId());
			List<HashMap<String,String>> productDetails =  new ArrayList<HashMap<String,String>>();
			EpcProductStatusHistory epcProductStatusHistory = new EpcProductStatusHistory();
			epcProductStatusHistory.setCreatedBy(modifiedBy);
			epcProductStatusHistory.setProductId(product.getProductId());
			epcProductStatusHistory.setProductStatus(Constants.PRODUCT_STATUS_SUBMITTED);
			epcProductStatusHistory.setReason("Normal State Transition Flow");
			epcProductStatusHistory.setCreatedDate(new Date());
			productStatusHistoryRepo.save(epcProductStatusHistory);
			HashMap<String,String> successProduct = new HashMap<String,String>();
			successProduct.put("stateTransition", Constants.PRODUCT_STATUS_SUBMITTED);
			successProduct.put("productShortCode",resultData.get(0).getProductShortCode());	
			successProduct.put("productClassification",resultData.get(0).getProductClassification() != null ? resultData.get(0).getProductClassification() : "");
			productDetails.add(successProduct);
			Thread backgroudCall = new Thread(new Runnable(){
				@Override
				public void run() {
					approvalService.formTemplateNotification(Constants.PRODUCT_STATUS_DRAFT,Constants.PRODUCT_STATUS_SUBMITTED,productDetails,modifiedBy);
				}
				
			});	
			backgroudCall.start();
		}
		
		return specUpdated;
	}
	/**
	 * @param product
	 * @return
	 */
	EpcProductSpecification deleteProduct(EpcProductSpecification product)
	{
		epcProductSpecificationRepository.delete(product.getProductId());
		return product;
	}
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductSpecification> searchProducts(
			Map<String, List<String>> allRequestParams) {

		List<String> with = allRequestParams.get("with");
		
		allRequestParams.remove("with");
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductSpecification.class.getName(), null);
		List<EpcProductSpecification> listOfProductsReturned = null;
		try {
			listOfProductsReturned = epcProductSpecificationRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		allRequestParams = new HashMap<String, List<String>>();
		if (with != null && !with.isEmpty()) {
			if (with.contains("all")|| with.contains("segment"))
			{
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("productId", prodId);
					product.setEpcProductSegment(epcProductSegmentService.searchEpcProductSegment(allRequestParams));
					allRequestParams.remove("productId");
				}
			}
			if (with.contains("all")|| with.contains("location")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("productId", prodId);
					product.setEpcProductLocation(epcProductLocationService.searchEpcProductLocation(allRequestParams));
					allRequestParams.remove("productId");
				}
			}
			if (with.contains("all")|| with.contains("salesChannel")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("productId", prodId);
					product.setEpcProductSalesChannel(epcProductSalesChannelService.searchEpcProductSalesChannel(allRequestParams));
					allRequestParams.remove("productId");
				}
			}
			if (with.contains("all")|| with.contains("availability")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("productId", prodId);
					product.setEpcProductAvailability(epcProductAvailabilityService.searchAvailabilities(allRequestParams));
					allRequestParams.remove("productId");
				}
			}
			if (with.contains("all")|| with.contains("initiatingChannel")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("productId", prodId);
					product.setEpcProductInitChannel(epcProductInitChannelService.searchEpcProductInitChannel(allRequestParams));
					allRequestParams.remove("productId");
				}
			}

			if (with.contains("all")|| with.contains("compatibility")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("productId", prodId);
					product.setEpcProductInitChannel(epcProductInitChannelService.searchEpcProductInitChannel(allRequestParams));
					product.setEpcProductCompatibility(epcProductCompatibilityService.searchEpcProductCompatibility(allRequestParams));
					allRequestParams.remove("productId");
				}
			}

			if (with.contains("all")|| with.contains("characteristic")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("productId", prodId);
					product.setEpcProductAttribute(epcProductAttributeService.searchProductAttribute(allRequestParams));
					allRequestParams.remove("productId");
				}
			}
			


			
			if (with.contains("all")|| with.contains("migration")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("sourceProductId", prodId);
					product.setEpcProductMigration(epcproductMigrationService.searchEpcProductMigration(allRequestParams));
					allRequestParams.remove("sourceProductId");
				}
			}
			if (with.contains("all")|| with.contains("bundle")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("parentProductId", prodId);
					product.setEpcProductHeirarchy(epcProductHeirarchyService.searchEpcProductHeirarchy(allRequestParams));
					allRequestParams.remove("parentProductId");
				}
			}
			
			if (with.contains("all")|| with.contains("networkTemplate")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<EpcProductNetworkTplMap> maps = (epcProductNetworkTplMapRepository).getNetworkTplMap(product.getProductId());
					if (maps != null && maps.size() ==  1) {
						EpcProductNetworkTplMap map = maps.get(0);
						map.setEpcProductNetworkTpl(epcProductNetworkTplRepository
								.getNetworkTplByProductId(product
										.getProductId()));
						product.setEpcProductNetworkTplMap(map);
					}
				}
			}
			if (with.contains("all")|| with.contains("provider")) {
				for(EpcProductSpecification product: listOfProductsReturned)
				{
					List<String> prodId = new ArrayList<String>();
					prodId.add(product.getProductId().toString());
					allRequestParams.put("productId", prodId);
					product.setEpcProductProvider(epcProductProviderSystemService.searchProvider(allRequestParams));
					allRequestParams.remove("productId");
				}
			}

		}
		return listOfProductsReturned;
	}
	/**
	 * @param communityName
	 * @return
	 */
	public List<String> getMarketingNames(String communityName) {
		List<String> returnedChar = null;
		try {
			returnedChar = epcProductSpecificationRepository.getMarketingNamesForCommunityNames(communityName);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: "
							+ " Exception: " + e.getMessage(), e );
		}
		
		
			return returnedChar;
	}
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductSpecification> getBasicProductSpecByID( Map<String, List<String>> allRequestParams ){
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductSpecification.class.getName(), null);
		List<EpcProductSpecification> listOfProductsReturned = null;
		try {
			listOfProductsReturned = epcProductSpecificationRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		return listOfProductsReturned;
	}

	/**
	 * @param productArray
	 * @param productOne
	 * @return
	 */
	public List<String> compatibilityCheck(	List<Integer> productArray,	Integer productOne) {
		// TODO Auto-generated method stub
		List<String> compatibleShortCodes = new ArrayList<String>();
		for(Integer product: productArray) {
			if(!isCompatible(productOne, product)){
				compatibleShortCodes.add(epcProductSpecificationRepository.getProductShortCodeByProductId(product));
			}
		}
		return compatibleShortCodes;
	}
	
	/**
	 * @param productOne
	 * @param productTwo
	 * @return
	 */
	public boolean isCompatible(Integer productOne, Integer productTwo) {
		
	
		List<Integer> otherProductIdsOne = epcProductSpecificationRepository.getIds( productOne);
		for(Integer prodId:otherProductIdsOne){
			if(prodId.equals(productTwo)) {
				return true;
			}
		}
		
		List<Integer> otherProductIdsTwo = epcProductSpecificationRepository.getIds( productTwo);
		for(Integer prodId:otherProductIdsTwo){
			if(prodId.equals(productOne)) {
				return true;
			}
		}
		
		return false;
		
	}
	
	/**
	 * @param ids
	 * @return
	 */
	public List<Object[]> getFileList(List<Integer> ids) {
		//List<GenericFile> genfileList = new ArrayList<GenericFile>();
		//Integer [] list = {5,4};
		//List<String> lists= [""];
		
		 List<Object[]> obj =epcProductSpecificationRepository.getFileList(ids);
		/* if(obj.size()>0){
		  for(Object[] fileList : obj ){
			 /// GenericFile genFile = new GenericFile();
			  if(fileList[0]!=null)
			  //System.out.println(String.valueOf(fileList[0])+"dsgsgsgsdgsdgdsgh");
			  if(fileList[1]!=null)
				  //System.out.println(String.valueOf(fileList[1])+"=========================");
		  }
		 }*/
		 return obj;
	}

	/**
	 * @return
	 */
	public EpcProductSpecificationRepository getEpcProductSpecificationRepository() {
		return epcProductSpecificationRepository;
	}

	/**
	 * @param epcProductSpecificationRepository
	 */
	public void setEpcProductSpecificationRepository(
			EpcProductSpecificationRepository epcProductSpecificationRepository) {
		this.epcProductSpecificationRepository = epcProductSpecificationRepository;
	}

	/**
	 * @return
	 */
	public EpcProductNetworkTplMapRepository getEpcProductNetworkTplMapRepository() {
		return epcProductNetworkTplMapRepository;
	}

	/**
	 * @param epcProductNetworkTplMapRepository
	 */
	public void setEpcProductNetworkTplMapRepository(
			EpcProductNetworkTplMapRepository epcProductNetworkTplMapRepository) {
		this.epcProductNetworkTplMapRepository = epcProductNetworkTplMapRepository;
	}

	/**
	 * @return
	 */
	public EpcProductAvailabilityService getEpcProductAvailabilityService() {
		return epcProductAvailabilityService;
	}

	/**
	 * @param epcProductAvailabilityService
	 */
	public void setEpcProductAvailabilityService(
			EpcProductAvailabilityService epcProductAvailabilityService) {
		this.epcProductAvailabilityService = epcProductAvailabilityService;
	}

	/**
	 * @return
	 */
	public EpcProductSalesChannelService getEpcProductSalesChannelService() {
		return epcProductSalesChannelService;
	}

	/**
	 * @param epcProductSalesChannelService
	 */
	public void setEpcProductSalesChannelService(
			EpcProductSalesChannelService epcProductSalesChannelService) {
		this.epcProductSalesChannelService = epcProductSalesChannelService;
	}

	/**
	 * @return
	 */
	public EpcProductInitChannelService getEpcProductInitChannelService() {
		return epcProductInitChannelService;
	}

	/**
	 * @param epcProductInitChannelService
	 */
	public void setEpcProductInitChannelService(
			EpcProductInitChannelService epcProductInitChannelService) {
		this.epcProductInitChannelService = epcProductInitChannelService;
	}

	/**
	 * @return
	 */
	public EpcProductLocationService getEpcProductLocationService() {
		return epcProductLocationService;
	}

	/**
	 * @param epcProductLocationService
	 */
	public void setEpcProductLocationService(
			EpcProductLocationService epcProductLocationService) {
		this.epcProductLocationService = epcProductLocationService;
	}

	/**
	 * @return
	 */
	public EpcProductSegmentRepository getEpcProductSegmentRepository() {
		return epcProductSegmentRepository;
	}

	/**
	 * @param epcProductSegmentRepository
	 */
	public void setEpcProductSegmentRepository(
			EpcProductSegmentRepository epcProductSegmentRepository) {
		this.epcProductSegmentRepository = epcProductSegmentRepository;
	}

	/**
	 * @return
	 */
	public EpcProductSalesChannelRepository getEpcProductSalesChannelRepository() {
		return epcProductSalesChannelRepository;
	}

	/**
	 * @param epcProductSalesChannelRepository
	 */
	public void setEpcProductSalesChannelRepository(
			EpcProductSalesChannelRepository epcProductSalesChannelRepository) {
		this.epcProductSalesChannelRepository = epcProductSalesChannelRepository;
	}

	/**
	 * @return
	 */
	public EpcProductInitChannelRepository getEpcProductInitChannelRepository() {
		return epcProductInitChannelRepository;
	}

	/**
	 * @param epcProductInitChannelRepository
	 */
	public void setEpcProductInitChannelRepository(
			EpcProductInitChannelRepository epcProductInitChannelRepository) {
		this.epcProductInitChannelRepository = epcProductInitChannelRepository;
	}

	/**
	 * @return
	 */
	public EpcProductAvailabilityRepository getEpcProductAvailabilityRepository() {
		return epcProductAvailabilityRepository;
	}

	/**
	 * @param epcProductAvailabilityRepository
	 */
	public void setEpcProductAvailabilityRepository(
			EpcProductAvailabilityRepository epcProductAvailabilityRepository) {
		this.epcProductAvailabilityRepository = epcProductAvailabilityRepository;
	}

	/**
	 * @return
	 */
	public EpcProductLocationRepository getEpcProductLocationRepository() {
		return epcProductLocationRepository;
	}

	/**
	 * @param epcProductLocationRepository
	 */
	public void setEpcProductLocationRepository(
			EpcProductLocationRepository epcProductLocationRepository) {
		this.epcProductLocationRepository = epcProductLocationRepository;
	}

	/**
	 * @return
	 */
	public EpcProductCompatibilityRepository getEpcProductCompatibilityRepository() {
		return epcProductCompatibilityRepository;
	}

	/**
	 * @param epcProductCompatibilityRepository
	 */
	public void setEpcProductCompatibilityRepository(
			EpcProductCompatibilityRepository epcProductCompatibilityRepository) {
		this.epcProductCompatibilityRepository = epcProductCompatibilityRepository;
	}

	/**
	 * @return
	 */
	public EpcProductAttributeRepository getEpcProductAttributeRepository() {
		return epcProductAttributeRepository;
	}

	/**
	 * @param epcProductAttributeRepository
	 */
	public void setEpcProductAttributeRepository(
			EpcProductAttributeRepository epcProductAttributeRepository) {
		this.epcProductAttributeRepository = epcProductAttributeRepository;
	}

	/**
	 * @return
	 */
	public EpcProductSegmentService getEpcProductSegmentService() {
		return epcProductSegmentService;
	}

	/**
	 * @param epcProductSegmentService
	 */
	public void setEpcProductSegmentService(
			EpcProductSegmentService epcProductSegmentService) {
		this.epcProductSegmentService = epcProductSegmentService;
	}

	/**
	 * @return
	 */
	public EpcProductCompatibilityService getEpcProductCompatibilityService() {
		return epcProductCompatibilityService;
	}

	/**
	 * @param epcProductCompatibilityService
	 */
	public void setEpcProductCompatibilityService(
			EpcProductCompatibilityService epcProductCompatibilityService) {
		this.epcProductCompatibilityService = epcProductCompatibilityService;
	}

	/**
	 * @return
	 */
	public EpcProductAttributeService getEpcProductAttributeService() {
		return epcProductAttributeService;
	}

	/**
	 * @param epcProductAttributeService
	 */
	public void setEpcProductAttributeService(
			EpcProductAttributeService epcProductAttributeService) {
		this.epcProductAttributeService = epcProductAttributeService;
	}

	/**
	 * @return
	 */
	public EpcProductMigrationRepository getEpcProductMigrationRepository() {
		return epcProductMigrationRepository;
	}

	/**
	 * @param epcProductMigrationRepository
	 */
	public void setEpcProductMigrationRepository(
			EpcProductMigrationRepository epcProductMigrationRepository) {
		this.epcProductMigrationRepository = epcProductMigrationRepository;
	}

	/**
	 * @return
	 */
	public EpcProductMigrationService getEpcproductMigrationService() {
		return epcproductMigrationService;
	}

	/**
	 * @param epcproductMigrationService
	 */
	public void setEpcproductMigrationService(
			EpcProductMigrationService epcproductMigrationService) {
		this.epcproductMigrationService = epcproductMigrationService;
	}

	/**
	 * @return
	 */
	public EpcProductHeirarchyService getEpcProductHeirarchyService() {
		return epcProductHeirarchyService;
	}

	/**
	 * @param epcProductHeirarchyService
	 */
	public void setEpcProductHeirarchyService(
			EpcProductHeirarchyService epcProductHeirarchyService) {
		this.epcProductHeirarchyService = epcProductHeirarchyService;
	}

	/**
	 * @return
	 */
	public EpcProductNetworkTplRepository getEpcProductNetworkTplRepository() {
		return epcProductNetworkTplRepository;
	}

	/**
	 * @param epcProductNetworkTplRepository
	 */
	public void setEpcProductNetworkTplRepository(
			EpcProductNetworkTplRepository epcProductNetworkTplRepository) {
		this.epcProductNetworkTplRepository = epcProductNetworkTplRepository;
	}

	/**
	 * @return
	 */
	public EpcProductProviderSystemService getEpcProductProviderSystemService() {
		return epcProductProviderSystemService;
	}

	/**
	 * @param epcProductProviderSystemService
	 */
	public void setEpcProductProviderSystemService(
			EpcProductProviderSystemService epcProductProviderSystemService) {
		this.epcProductProviderSystemService = epcProductProviderSystemService;
	}

	/**
	 * @return
	 */
	public EpcProductProviderSystemRepository getEpcProductProviderSystemRepository() {
		return epcProductProviderSystemRepository;
	}

	/**
	 * @param epcProductProviderSystemRepository
	 */
	public void setEpcProductProviderSystemRepository(
			EpcProductProviderSystemRepository epcProductProviderSystemRepository) {
		this.epcProductProviderSystemRepository = epcProductProviderSystemRepository;
	}

	/**
	 * @return
	 */
	public ProductApprovalService getApprovalService() {
		return approvalService;
	}

	/**
	 * @param approvalService
	 */
	public void setApprovalService(ProductApprovalService approvalService) {
		this.approvalService = approvalService;
	}

	/**
	 * @return
	 */
	public EpcProductStatusHistoryRepository getProductStatusHistoryRepo() {
		return productStatusHistoryRepo;
	}

	/**
	 * @param productStatusHistoryRepo
	 */
	public void setProductStatusHistoryRepo(
			EpcProductStatusHistoryRepository productStatusHistoryRepo) {
		this.productStatusHistoryRepo = productStatusHistoryRepo;
	}

}


