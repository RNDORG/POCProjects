package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.wipro.epc.domain.EpcActivityMaster;
/**
 * @version 1.0
 * @author VI251443
 *
 */
public interface EpcActivityMasterRepository extends CrudRepository<EpcActivityMaster, Integer>,
EpcActivityMasterRepositoryCustom{

    /**
     * 
     * @return
     */
	@Query(value = "select * from epc_activity_master ", nativeQuery=true)
	List<EpcActivityMaster> getAllListofValues();
	/**
	 * 
	 * @param name
	 */
	@Modifying
	@Query(value="delete from epc_activity_master where activity_name = :name", nativeQuery=true)
	void deleteFromMaster(@Param(value="name") String name);
    /**
     * 
     * @param name
     * @return
     */
	@Query(value="select activity_id from epc_activity_master where activity_name = :name", nativeQuery = true)
	Integer findByName(@Param(value="name") String name);
	/**
	 * 
	 * @param name
	 * @param id
	 */
	@Modifying
	@Query(value="update epc_activity_master set activity_name = :name where activity_id = :id", nativeQuery=true)
	void modifyActivity(@Param(value="name") String name, @Param(value="id") Integer id);

}
