package com.wipro.epc.endpoints;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.endpoint.Endpoint;
import org.springframework.stereotype.Component;

import com.wipro.common.version.ReadFileInMap;

/**
 * @author Developer
 * @version 1.0
 * type BuildInfo
 */
@Component
public class BuildInfo implements Endpoint<List<String>> {
	
	/**
	 * String BuildInfo.java
	 */
	@Value("${buildTimestamp}")
	String buildTimestamp;
     
    /* (non-Javadoc)
     * @see org.springframework.boot.actuate.endpoint.Endpoint#getId()
     */
    @Override
	public String getId() {
        return "buildinfo";
    }
 
    /* (non-Javadoc)
     * @see org.springframework.boot.actuate.endpoint.Endpoint#isEnabled()
     */
    @Override
	public boolean isEnabled() {
        return true;
    }
 
    /* (non-Javadoc)
     * @see org.springframework.boot.actuate.endpoint.Endpoint#isSensitive()
     */
    @Override
	public boolean isSensitive() {
        return true;
    }
 
    /* (non-Javadoc)
     * @see org.springframework.boot.actuate.endpoint.Endpoint#invoke()
     */
    @Override
	public List<String> invoke() {
        // Custom logic to build the output
        List<String> messages = new ArrayList<String>();
        ReadFileInMap readFile = new ReadFileInMap();
        messages.add("Version:"+ readFile.fileRead().get("Version"));
        messages.add("Build Timestamp: " + readFile.fileRead().get("Build_TimeStamp") );        
        return messages;
    }
    
    
    
}