package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcActivityCharge;

/**
 * @author Developer
 * @version 1.0
 * type EpcActivityChargeRepositoryImpl
 */
public class EpcActivityChargeRepositoryImpl implements EpcActivityChargeRepositoryCustom  {
	
	private static Logger logger =LoggerFactory.getLogger(EpcActivityChargeRepositoryImpl.class);
	
	/**
	 * EntityManager EpcActivityChargeRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcActivityChargeRepositoryCustom#modifyOrder(com.wipro.epc.domain.EpcActivityCharge)
	 */
	@Override
	public EpcActivityCharge modifyOrder(EpcActivityCharge order) {
	StringBuilder queryBuilder = new StringBuilder("update epc_activity_charge set activity_channel_rule_id="+order.getActivityChannelRuleId());	
	if (order.getOccCode()!=null && !order.getOccCode().isEmpty())
		queryBuilder.append(",").append("occ_code='").append(order.getOccCode()).append("'");
	
		queryBuilder.append(",").append("activity_charge_fee=").append(order.getActivityChargeFee());
	
	queryBuilder.append(" where activity_channel_rule_id =").append(order.getActivityChannelRuleId());
	String query = queryBuilder.toString();
	em.createNativeQuery(query).executeUpdate();
	logger.debug("#Query: "+query);
	//System.out.println(query);
	return order;	
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcActivityChargeRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcActivityCharge> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query,EpcActivityCharge.class).getResultList();
	}
}
