/*package com.wipro.epc.util;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.wipro.epc.services.EpcLookupMasterService;

public class LookupValueSerializer extends ToStringSerializer {
	@Autowired
	EpcLookupMasterService epcLookupMasterService;
	
    @Override
    public void serialize(Object value, JsonGenerator jgen, SerializerProvider provider)
        throws IOException, JsonGenerationException
    {
        jgen.writeString(epcLookupMasterService.getLookupValue((Integer)value));
    }
}*/