package com.wipro.epc.repositories;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcActivityCharge;

/**
 * @author Developer
 * @version 1.0
 * type EpcActivityChargeRepository
 */
public interface EpcActivityChargeRepository extends CrudRepository<EpcActivityCharge,Integer>, EpcActivityChargeRepositoryCustom{

    /**
     * @param activityChannelRuleId
     */
    @Modifying
	@Query(value="delete from epc_activity_charge where activity_channel_rule_id=:activityChannelRuleId", nativeQuery=true)
	void deleteActivityFromChannel(@Param("activityChannelRuleId") Integer activityChannelRuleId);
    
    /**
     * @param activityChannelRuleId
     * @return
     */
    @Query(value="select * from epc_activity_charge where activity_channel_rule_id =:activityChannelRuleId", nativeQuery=true)
	EpcActivityCharge findActivityChargeByactivityChannelRuleId(@Param("activityChannelRuleId") Integer activityChannelRuleId);
}
