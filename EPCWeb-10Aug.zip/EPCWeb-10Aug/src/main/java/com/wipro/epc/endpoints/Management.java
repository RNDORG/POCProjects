
package com.wipro.epc.endpoints;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.AbstractEndpoint;
import org.springframework.boot.actuate.endpoint.Endpoint;
import org.springframework.stereotype.Component;

/**
 * @author Developer
 * @version 1.0
 * type Management
 */
@Component
public class Management extends AbstractEndpoint<List<Endpoint>> {
    /**
     * List<Endpoint> Management.java
     */
    private List<Endpoint> endpoints;
 
    /**
     * @param endpoints
     */
    @Autowired
    public Management(List<Endpoint> endpoints) {
        super("");
        this.endpoints = endpoints;
    }
 
    /* (non-Javadoc)
     * @see org.springframework.boot.actuate.endpoint.Endpoint#invoke()
     */
    @Override
	public List<Endpoint> invoke() {
        return this.endpoints;
    }
}