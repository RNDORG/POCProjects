package com.wipro.epc.domain;


import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;



/**
 * The persistent class for the epc_product_migration database table.
 * @author KE334465
 * @version 1.0
 */
@Entity
@Table(name="epc_product_migration")
public class EpcProductMigration  implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_migration_id")
	private Integer productMigrationId;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;

	@Column(name="inclusive_or_exclusive")
	private String inclusiveOrExclusive;

	@Column(name="migration_remark")
	private String migrationRemark;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;

	@Column(name="source_category")
	private String sourceCategory;

	@Column(name="source_product_id")
	private Integer sourceProductId;

	@Column(name="status")
	private String status;

	@Column(name="target_category")
	private String targetCategory;

	@Column(name="target_product_id")
	private Integer targetProductId;

	@Column(name="migration_channel")
	private String migrationChannel;
	
	@Transient
	private String reservedMN;
	@Transient
	private String reservedSC;
	@Transient
	private String reservedAL;
	@Transient
	private String reservedPPS;


	
	@Transient
	private EpcProductSpecification targetProductSpec;
	
	
	@Transient
	private Map<String,String> metaInfo;	
	
	/**
	 * 
	 */
	public EpcProductMigration() {
	} 
	
	
	
	/**
	 * @return
	 */
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}
	

	/**
	 * @param metaInfo
	 */
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}



	/**
	 * @return
	 */
	public Integer getProductMigrationId() {
		return this.productMigrationId;
	}

	/**
	 * @param productMigrationId
	 */
	public void setProductMigrationId(Integer productMigrationId) {
		this.productMigrationId = productMigrationId;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getIsExcludedFromMigration() {
		return this.inclusiveOrExclusive;
	}


	/**
	 * @return
	 */
	public String getInclusiveOrExclusive() {
		return inclusiveOrExclusive;
	}

	/**
	 * @param inclusiveOrExclusive
	 */
	public void setInclusiveOrExclusive(String inclusiveOrExclusive) {
		this.inclusiveOrExclusive = inclusiveOrExclusive;
	}

	/**
	 * @return
	 */
	public String getMigrationRemark() {
		return this.migrationRemark;
	}

	/**
	 * @param migrationRemark
	 */
	public void setMigrationRemark(String migrationRemark) {
		this.migrationRemark = migrationRemark;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return
	 */
	public String getSourceCategory() {
		return this.sourceCategory;
	}

	/**
	 * @param sourceCategory
	 */
	public void setSourceCategory(String sourceCategory) {
		this.sourceCategory = sourceCategory;
	}

	/**
	 * @return
	 */
	public Integer getSourceProductId() {
		return this.sourceProductId;
	}

	/**
	 * @param sourceProductId
	 */
	public void setSourceProductId(Integer sourceProductId) {
		this.sourceProductId = sourceProductId;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return
	 */
	public String getTargetCategory() {
		return this.targetCategory;
	}

	/**
	 * @param targetCategory
	 */
	public void setTargetCategory(String targetCategory) {
		this.targetCategory = targetCategory;
	}

	/**
	 * @return
	 */
	public Integer getTargetProductId() {
		return this.targetProductId;
	}

	/**
	 * @param targetProductId
	 */
	public void setTargetProductId(Integer targetProductId) {
		this.targetProductId = targetProductId;
	}

	
	
	
	/**
	 * @return
	 */
	public EpcProductSpecification getTargetProductSpec() {
		return targetProductSpec;
	}

	/**
	 * @param targetProductSpec
	 */
	public void setTargetProductSpec(EpcProductSpecification targetProductSpec) {
		this.targetProductSpec = targetProductSpec;
	}


	
	/**
	 * @return
	 */
	public String getMigrationChannel() {
		return migrationChannel;
	}

	/**
	 * @param migrationChannel
	 */
	public void setMigrationChannel(String migrationChannel) {
		this.migrationChannel = migrationChannel;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EpcProductMigration [productMigrationId=" + productMigrationId
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", inclusiveOrExclusive=" + inclusiveOrExclusive
				+ ", migrationRemark=" + migrationRemark + ", modifiedBy="
				+ modifiedBy + ", modifiedDate=" + modifiedDate
				+ ", sourceCategory=" + sourceCategory + ", sourceProductId="
				+ sourceProductId + ", status=" + status + ", targetCategory="
				+ targetCategory + ", targetProductId=" + targetProductId
				+ ", migrationChannel=" + migrationChannel + ", metaInfo="
				+ metaInfo + ", targetProductSpec=" + targetProductSpec
				+ ", reservedMN=" + reservedMN + ", reservedSC=" + reservedSC
				+ ", reservedAL=" + reservedAL + "]";
	}

	
	/**
	 * @return
	 */
	public String getReservedMN() {
		return reservedMN;
	}
	/**
	 * @param reservedMN
	 */
	public void setReservedMN(String reservedMN) {
		this.reservedMN = reservedMN;
	}
	/**
	 * @return
	 */
	public String getReservedSC() {
		return reservedSC;
	}
	/**
	 * @param reservedSC
	 */
	public void setReservedSC(String reservedSC) {
		this.reservedSC = reservedSC;
	}
	/**
	 * @return
	 */
	public String getReservedAL() {
		return reservedAL;
	}
	/**
	 * @param reservedAL
	 */
	public void setReservedAL(String reservedAL) {
		this.reservedAL = reservedAL;
	}
	/**
	 *  @return
	 */
	public String getReservedPPS() {
		return reservedPPS;
	}
	/**
	 * @param reservedPPS
	 */
	public void setReservedPPS(String reservedPPS) {
		this.reservedPPS = reservedPPS;
	}
}