package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type ProviderProductQueryInput
 */
public class ManageCommunityStatusInput {

	private String communityId;
	
	private String communityShortCode;
	
	private String communityName;
	
	private String action;

	/**
	 * @return the communityId
	 */
	public String getCommunityId() {
		return communityId;
	}

	/**
	 * @param communityId the communityId to set
	 */
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	/**
	 * @return the communityShortCode
	 */
	public String getCommunityShortCode() {
		return communityShortCode;
	}

	/**
	 * @param communityShortCode the communityShortCode to set
	 */
	public void setCommunityShortCode(String communityShortCode) {
		this.communityShortCode = communityShortCode;
	}

	/**
	 * @return the communityName
	 */
	public String getCommunityName() {
		return communityName;
	}

	/**
	 * @param communityName the communityName to set
	 */
	public void setCommunityName(String communityName) {
		this.communityName = communityName;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	
	
	

}
