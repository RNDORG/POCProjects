package com.wipro.epc.domain;


import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the epc_order_channel_rule database table. 
 * @author VI251443
 * @version 1.0
 */
@Entity
@Table(name="epc_order_channel_rule")
public class EpcOrderChannelRule  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="order_channel_rule_id")
	private Integer orderChannelRuleId;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm a z")
	@Column(name="created_date")
	private Date createdDate;

	@Column(name="currency")
	private String currency;
	
/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String currencyValue;*/

	@Column(name="initiating_channel")
	private String initiatingChannel;

/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String initiatingChannelValue;*/
		
	@Column(name="is_consent_required",columnDefinition = "bit")
	private Byte isConsentRequired;

	@Column(name="is_future_date",columnDefinition = "bit")
	private Byte isFutureDate;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm a z")
	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="notification_template_id")
	private Integer notificationTemplateId;
	

	@Column(name="order_type")
	private String orderType;
	
/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String orderTypeValue;*/
	
	
	@Column(name="sales_channel")
	private String salesChannel;
	
/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String salesChannelValue;*/
	
	@Column(name="product_sub_family")
	private String productSubFamily;
	
/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String productSubFamilyValue;*/
	
	@Column(name="product_classification")
	private String productClassification;
	
/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String productClassificationValue;*/
	
	@Column(name="status")
	private String status;
	
/*	@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;*/
	
	@Transient
	private EpcOrderCharge epcOrderCharge;
	
	@Transient
	private EpcNotificationTemplate epcNotificationTemplate;
	
	@Transient
	private Map<String,String> metaInfo;	
	
	
	/**
	 * @return
	 */
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}

	/**
	 * @param metaInfo
	 */
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}

	/**
	 * @return
	 */
	public EpcOrderCharge getEpcOrderCharge() {
		return epcOrderCharge;
	}

	/**
	 * @param epcOrderCharge
	 */
	public void setEpcOrderCharge(EpcOrderCharge epcOrderCharge) {
		this.epcOrderCharge = epcOrderCharge;
	}
	
	/**
	 * 
	 */
	public EpcOrderChannelRule() 
	{
	}

	/**
	 * @return
	 */
	public Integer getOrderChannelRuleId() {
		return this.orderChannelRuleId;
	}

	/**
	 * @param orderChannelRuleId
	 */
	public void setOrderChannelRuleId(Integer orderChannelRuleId) {
		this.orderChannelRuleId = orderChannelRuleId;
	}
	
	
	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getCurrency() {
		return this.currency;
	}

	/**
	 * @param currency
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return
	 */
	public String getInitiatingChannel() {
		return this.initiatingChannel;
	}

	/**
	 * @param initiatingChannel
	 */
	public void setInitiatingChannel(String initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}

	/**
	 * @return
	 */
	public Byte getIsConsentRequired() {
		return this.isConsentRequired;
	}

	/**
	 * @param isConsentRequired
	 */
	public void setIsConsentRequired(Byte isConsentRequired) {
		this.isConsentRequired = isConsentRequired;
	}

	/**
	 * @return
	 */
	public Byte getIsFutureDate() {
		return this.isFutureDate;
	}

	/**
	 * @param isFutureDate
	 */
	public void setIsFutureDate(Byte isFutureDate) {
		this.isFutureDate = isFutureDate;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	/**
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	/**
	 * @return
	 */
	public Integer getNotificationTemplateId() {
		return this.notificationTemplateId;
	}

	/**
	 * @param notificationTemplateId
	 */
	public void setNotificationTemplateId(Integer notificationTemplateId) {
		this.notificationTemplateId = notificationTemplateId;
	}

	/**
	 * @return
	 */
	public String getOrderType() {
		return this.orderType;
	}

	/**
	 * @param orderType
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	/**
	 * @return
	 */
	public String getSalesChannel() {
		return this.salesChannel;
	}

	/**
	 * @param salesChannel
	 */
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * 
	 */
	@Override
	public String toString() {
		return "EpcOrderChannelRule [orderChannelRuleId=" + orderChannelRuleId
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", currency=" + currency 
				+ ", initiatingChannel=" + initiatingChannel
				+ ", isConsentRequired=" + isConsentRequired
				+ ", isFutureDate=" + isFutureDate + ", modifiedBy="
				+ modifiedBy + ", modifiedDate=" + modifiedDate
				+ ", notificationTemplateId=" + notificationTemplateId
				+ ", orderType=" + orderType + ", salesChannel=" + salesChannel
				+ ", productSubFamily=" + productSubFamily
				+ ", productClassification=" + productClassification
				+ ", status=" + status  + "]";
	}

	/*public String getCurrencyValue() {
		this.currencyValue = currency;
		return currencyValue;
	}

	public void setCurrencyValue(String currencyValue) {
		this.currencyValue = currencyValue;
	}

	public String getInitiatingChannelValue() {
		this.initiatingChannelValue = initiatingChannel;
		return initiatingChannelValue;
	}

	public void setInitiatingChannelValue(String initiatingChannelValue) {
		this.initiatingChannelValue = initiatingChannelValue;
	}

	public String getSalesChannelValue() {
		this.salesChannelValue = salesChannel;
		return salesChannelValue;
	}

	public void setSalesChannelValue(String salesChannelValue) {
		this.salesChannelValue = salesChannelValue;
	}
	*/
	/**
	 * @return
	 */
	public String getProductSubFamily() {
		return productSubFamily;
	}

	/**
	 * @param productSubFamily
	 */
	public void setProductSubFamily(String productSubFamily) {
		this.productSubFamily = productSubFamily;
	}

	/*public String getProductSubFamilyValue() {
		this.productSubFamilyValue = productSubFamily;
		return productSubFamilyValue;
	}

	public void setProductSubFamilyValue(String productSubFamilyValue) {
		this.productSubFamilyValue = productSubFamilyValue;
	}
	*/
	/**
	 * @return
	 */
	public String getProductClassification() {
		return productClassification;
	}

	/**
	 * @param productClassification
	 */
	public void setProductClassification(String productClassification) {
		this.productClassification = productClassification;
	}

	/*public String getProductClassificationValue() {
		this.productClassificationValue = productClassification;
		return productClassificationValue;
	}

	public void setProductClassificationValue(String productClassificationValue) {
		this.productClassificationValue = productClassificationValue;
	}
	public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}*/

	/**
	 * @return
	 */
	public EpcNotificationTemplate getEpcNotificationTemplate() {
		return epcNotificationTemplate;
	}

	/**
	 * @param epcNotificationTemplate
	 */
	public void setEpcNotificationTemplate(EpcNotificationTemplate epcNotificationTemplate) {
		this.epcNotificationTemplate = epcNotificationTemplate;
	}

	
}