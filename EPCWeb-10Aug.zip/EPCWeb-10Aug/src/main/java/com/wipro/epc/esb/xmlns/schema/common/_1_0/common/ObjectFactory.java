
package com.wipro.epc.esb.xmlns.schema.common._1_0.common;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.wipro.epc.esb.xmlns.schema.common._1_0.common package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DateReference_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "DateReference");
    private final static QName _ApplicationError_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "ApplicationError");
    private final static QName _ServiceError_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "ServiceError");
    private final static QName _TransactionReference_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "TransactionReference");
    private final static QName _SystemError_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "SystemError");
    private final static QName _CustomRef_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "CustomRef");
    private final static QName _ErrorInfo_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "ErrorInfo");
    private final static QName _GPSTransactionReference_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "GPSTransactionReference");
    private final static QName _BalanceRec_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "balanceRec");
    private final static QName _Fault_QNAME = new QName("http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", "Fault");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.wipro.epc.esb.xmlns.schema.common._1_0.common
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FaultType }
     * 
     */
    public FaultType createFaultType() {
        return new FaultType();
    }

    /**
     * Create an instance of {@link FaultType.Detail }
     * 
     */
    public FaultType.Detail createFaultTypeDetail() {
        return new FaultType.Detail();
    }

    /**
     * Create an instance of {@link FaultType.Detail.Error }
     * 
     */
    public FaultType.Detail.Error createFaultTypeDetailError() {
        return new FaultType.Detail.Error();
    }

    /**
     * Create an instance of {@link ServiceErrorType }
     * 
     */
    public ServiceErrorType createServiceErrorType() {
        return new ServiceErrorType();
    }

    /**
     * Create an instance of {@link CustomRefType }
     * 
     */
    public CustomRefType createCustomRefType() {
        return new CustomRefType();
    }

    /**
     * Create an instance of {@link TransactionReferenceType }
     * 
     */
    public TransactionReferenceType createTransactionReferenceType() {
        return new TransactionReferenceType();
    }

    /**
     * Create an instance of {@link SystemErrorType }
     * 
     */
    public SystemErrorType createSystemErrorType() {
        return new SystemErrorType();
    }

    /**
     * Create an instance of {@link GPSTransactionReferenceType }
     * 
     */
    public GPSTransactionReferenceType createGPSTransactionReferenceType() {
        return new GPSTransactionReferenceType();
    }

    /**
     * Create an instance of {@link BaseErrorInfoType }
     * 
     */
    public BaseErrorInfoType createBaseErrorInfoType() {
        return new BaseErrorInfoType();
    }

    /**
     * Create an instance of {@link DateReferenceType }
     * 
     */
    public DateReferenceType createDateReferenceType() {
        return new DateReferenceType();
    }

    /**
     * Create an instance of {@link ApplicationErrorType }
     * 
     */
    public ApplicationErrorType createApplicationErrorType() {
        return new ApplicationErrorType();
    }

    /**
     * Create an instance of {@link BalanceType }
     * 
     */
    public BalanceType createBalanceType() {
        return new BalanceType();
    }

    /**
     * Create an instance of {@link RequestHeaderType }
     * 
     */
    public RequestHeaderType createRequestHeaderType() {
        return new RequestHeaderType();
    }

    /**
     * Create an instance of {@link SessionEntityType }
     * 
     */
    public SessionEntityType createSessionEntityType() {
        return new SessionEntityType();
    }

    /**
     * Create an instance of {@link ParamType }
     * 
     */
    public ParamType createParamType() {
        return new ParamType();
    }

    /**
     * Create an instance of {@link RechargeRequestHeaderType }
     * 
     */
    public RechargeRequestHeaderType createRechargeRequestHeaderType() {
        return new RechargeRequestHeaderType();
    }

    /**
     * Create an instance of {@link FaultType.Detail.Error.ErrorDetails }
     * 
     */
    public FaultType.Detail.Error.ErrorDetails createFaultTypeDetailErrorErrorDetails() {
        return new FaultType.Detail.Error.ErrorDetails();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateReferenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "DateReference")
    public JAXBElement<DateReferenceType> createDateReference(DateReferenceType value) {
        return new JAXBElement<DateReferenceType>(_DateReference_QNAME, DateReferenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationErrorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "ApplicationError")
    public JAXBElement<ApplicationErrorType> createApplicationError(ApplicationErrorType value) {
        return new JAXBElement<ApplicationErrorType>(_ApplicationError_QNAME, ApplicationErrorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServiceErrorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "ServiceError")
    public JAXBElement<ServiceErrorType> createServiceError(ServiceErrorType value) {
        return new JAXBElement<ServiceErrorType>(_ServiceError_QNAME, ServiceErrorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransactionReferenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "TransactionReference")
    public JAXBElement<TransactionReferenceType> createTransactionReference(TransactionReferenceType value) {
        return new JAXBElement<TransactionReferenceType>(_TransactionReference_QNAME, TransactionReferenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SystemErrorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "SystemError")
    public JAXBElement<SystemErrorType> createSystemError(SystemErrorType value) {
        return new JAXBElement<SystemErrorType>(_SystemError_QNAME, SystemErrorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CustomRefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "CustomRef")
    public JAXBElement<CustomRefType> createCustomRef(CustomRefType value) {
        return new JAXBElement<CustomRefType>(_CustomRef_QNAME, CustomRefType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BaseErrorInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "ErrorInfo")
    public JAXBElement<BaseErrorInfoType> createErrorInfo(BaseErrorInfoType value) {
        return new JAXBElement<BaseErrorInfoType>(_ErrorInfo_QNAME, BaseErrorInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GPSTransactionReferenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "GPSTransactionReference")
    public JAXBElement<GPSTransactionReferenceType> createGPSTransactionReference(GPSTransactionReferenceType value) {
        return new JAXBElement<GPSTransactionReferenceType>(_GPSTransactionReference_QNAME, GPSTransactionReferenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BalanceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "balanceRec")
    public JAXBElement<BalanceType> createBalanceRec(BalanceType value) {
        return new JAXBElement<BalanceType>(_BalanceRec_QNAME, BalanceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaultType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd", name = "Fault")
    public JAXBElement<FaultType> createFault(FaultType value) {
        return new JAXBElement<FaultType>(_Fault_QNAME, FaultType.class, null, value);
    }

}
