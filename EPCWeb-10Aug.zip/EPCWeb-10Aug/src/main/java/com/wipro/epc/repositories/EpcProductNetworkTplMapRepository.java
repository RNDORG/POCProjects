package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductNetworkTplMap;


/**
 * @author Developer
 * @version 1.0
 * type EpcProductNetworkTplMapRepository
 */
public interface EpcProductNetworkTplMapRepository extends CrudRepository<EpcProductNetworkTplMap,Integer>,
EpcProductNetworkTplMapRepositoryCustom{

	/**
	 * @param productId
	 */
	@Modifying
	@Query(value = "delete from epc_product_network_tpl_map where product_id= :productId", nativeQuery=true)
	void deleteProductFromNetworkTpl(@Param("productId")Integer productId);

	
	/**
	 * @param productId
	 * @return
	 */
	@Query(value= "select * from epc_product_network_tpl_map where product_id= :productId", nativeQuery=true)
	List<EpcProductNetworkTplMap> getNetworkTplMap(@Param("productId") Integer productId);
	
	

}
