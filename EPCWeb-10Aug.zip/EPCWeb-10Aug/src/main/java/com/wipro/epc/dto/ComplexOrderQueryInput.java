package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type ComplexOrderQueryInput
 */
public class ComplexOrderQueryInput {


	/**
	 * String ComplexOrderQueryInput.java
	 */
	private String productSubfamily;
	/**
	 * String ComplexOrderQueryInput.java
	 */
	private String productClassification;
	/**
	 * String ComplexOrderQueryInput.java
	 */
	private String initiatingChannel;
	/**
	 * String ComplexOrderQueryInput.java
	 */
	private String salesChannel;
	/**
	 * String ComplexOrderQueryInput.java
	 */
	private String orderType;
	/**
	 * @return
	 */
	public String getProductSubfamily() {
		return productSubfamily;
	}
	/**
	 * @param productSubfamily
	 */
	public void setProductSubfamily(String productSubfamily) {
		this.productSubfamily = productSubfamily;
	}
	/**
	 * @return
	 */
	public String getProductClassification() {
		return productClassification;
	}
	/**
	 * @param productClassification
	 */
	public void setProductClassification(String productClassification) {
		this.productClassification = productClassification;
	}
	/**
	 * @return
	 */
	public String getInitiatingChannel() {
		return initiatingChannel;
	}
	/**
	 * @param initChannel
	 */
	public void setInitiatingChannel(String initChannel) {
		this.initiatingChannel = initChannel;
	}
	/**
	 * @return
	 */
	public String getSalesChannel() {
		return salesChannel;
	}
	/**
	 * @param salesChannel
	 */
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	/**
	 * @return
	 */
	public String getOrderType() {
		return orderType;
	}
	/**
	 * @param orderType
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
}
