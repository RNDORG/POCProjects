package com.wipro.epc.exception;

import com.wipro.common.gs.exception.GenericException;


/**
 * @author Developer
 * @version 1.0
 * type EPCException
 */
public class EPCException extends GenericException {

	/**
	 * long EPCException.java
	 */
	private static final long serialVersionUID = -1108763472436930096L;

	/**
	 * @param errorCode
	 * @param errorMessage
	 * @param lowLevelError
	 * @param exception
	 */
	public EPCException(String errorCode, String errorMessage,
			String lowLevelError, Throwable exception) {
		super(errorCode, errorMessage, lowLevelError, exception);
	}

	/**
	 * @param errorCode
	 * @param errorMessage
	 * @param lowLevelError
	 */
	public EPCException(String errorCode, String errorMessage, String lowLevelError) {
		super(errorCode, errorMessage, lowLevelError);
	}
	
	public EPCException(String errorMessage) {		
		super( "" , errorMessage, "" );
	}

	public EPCException(String errorMessage, Throwable exception) {		
		super( "" , errorMessage, "" , exception);
	}


}
