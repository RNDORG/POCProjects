package com.wipro.epc.repositories;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcOrderChannelRule;



/**
 * @author Developer
 * @version 1.0
 * type OrderTypeValidationRepositoryImpl
 */
public class OrderTypeValidationRepositoryImpl implements OrderTypeValidationRepositoryCustom{
	
	private static Logger logger =LoggerFactory.getLogger(OrderTypeValidationRepositoryImpl.class);
	
	/**
	 * EntityManager OrderTypeValidationRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.OrderTypeValidationRepositoryCustom#validateOrders(com.wipro.epc.domain.EpcOrderChannelRule)
	 */
	@Override
	public int validateOrders(EpcOrderChannelRule orderList){
		
		StringBuilder queryBuilder = new StringBuilder("select count(1) from epc_order_channel_rule where order_type = '"+ orderList.getOrderType()+"' and  sales_channel ='"+orderList.getSalesChannel()+"' and initiating_channel ='"+orderList.getInitiatingChannel()+"' and product_sub_family ='"+orderList.getProductSubFamily()+"' and product_classification ='"+orderList.getProductClassification()+"'");	
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		int maxValue = ((Number) em.createNativeQuery(query).getSingleResult()).intValue();
		
		//System.out.println(maxValue+"-----------");
		
		
			
			return maxValue;
		
		
		
		}

	

}
