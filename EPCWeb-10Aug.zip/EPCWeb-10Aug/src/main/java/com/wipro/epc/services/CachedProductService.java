package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wipro.common.config.service.ServerStatusService;
import com.wipro.epc.controller.BroadcastController;


@Service
public class CachedProductService {
	private static Logger logger =LoggerFactory.getLogger( CachedProductService.class);
	
	@Autowired
	ReloadStatusService reloadStatusService;
	
	@Autowired
	MCachedProductService mCachedProductService;
	
	@Autowired
	BroadcastController broacastController;
	
	@Autowired
	BroadcastService broacastService;
	
	@Autowired
	ServerStatusService serverService;
	
	public String reloadMemoryService(MultiValueMap<String,String> allRequestParams){
		if(serverService.isCurrentlyUiServer()) {
			if(allRequestParams.get("id")==null || ((List<String>)allRequestParams.get("id")).get(0).isEmpty() ){
				logger.info("reloadMemoryService():"+"#ERROR: Missing Mandatory field to Id. Mandatory fields [ id ] " );
				throw new RuntimeException("#ERROR: Missing Mandatory field to Id. Mandatory fields [ id ] ");
			}
			
			List<String> idValue=(List<String>)allRequestParams.get("id");
			
			
				MultiValueMap<String, String > map = new LinkedMultiValueMap<String, String >();
				List<String> api = new ArrayList<String>();
				List<String> ports = new ArrayList<String>();
				
				api.add("cache/product/reloadMemoryLocal");
				ports.add("non-ui");
				
				map.put("to", ports);
				map.put("api", api);
				map.put("id", idValue);
				
				Map<String,String> broadcastResults = broacastService.getReplyService( map);	//Map<String,String> broadcastResults =
				logger.info("CachedProductController.reloadMemory("+idValue.toString()+"): broadcastResults = " + broadcastResults.toString() );
			
			
			return null;
			}else{
				logger.warn("Not Allowed Server to do Reload Memory ");
				return "Not Allowed to do Reload Memory. Please check with Admin";
			}
	
	}
	
	public String reloadService(MultiValueMap<String,String> allRequestParams){
		if(serverService.isCurrentlyUiServer()) {
				if(allRequestParams.get("id")==null || ((List<String>)allRequestParams.get("id")).get(0).isEmpty() ){
					logger.info("#reloadService():" + "#ERROR: Missing Mandatory field to Id. Mandatory fields [ id ] " );
					throw new RuntimeException("#ERROR: Missing Mandatory field to Id. Mandatory fields [ id ] ");
				}
				
				boolean isBroadcast=true;
				if(allRequestParams.get("broadcast")==null || ((List<String>)allRequestParams.get("broadcast")).get(0).isEmpty() || ((List<String>)allRequestParams.get("broadcast")).get(0).equalsIgnoreCase("true")  ){
					isBroadcast=true;
				}else{
					isBroadcast=false;
				}
				
				boolean delay=false;
				if(((List<String>)allRequestParams.get("delay"))!= null && ((List<String>)allRequestParams.get("delay")).get(0).equalsIgnoreCase("true")) {
					delay = true;
				}
				
				try{
										
					Integer reqId=reloadStatusService.createReloadStatus((List<String>)allRequestParams.get("id"),delay);
					
					final boolean isBroadCastFinal=isBroadcast;
					final List<String> idFinal=(List<String>)allRequestParams.get("id");
					Thread t=new Thread(new Runnable() {
						
						@Override
						public void run() {
							mCachedProductService.reload(idFinal,reqId,isBroadCastFinal);
							
						}
					});
					t.start();
					logger.info("#cache/product/reload?id="+ allRequestParams.get("id").toString() + " => " + reqId.toString() );
					
					return reqId.toString();
					
				}catch(Exception e ){
					logger.info("#cache/product/reload?id="+" Error: Reload Request Failed : "+e.getMessage() );
					return "Error: Reload Request Failed : "+e.getMessage();
				}
		}else{
			logger.warn("Not Allowed Server to do Reload Cache Table");
			return "Not Allowed to do Reload Cache Table. Please check with Admin";
		}
	}

	public String reloadMemoryLocalService(MultiValueMap<String,String> allRequestParams) {
		if(allRequestParams.get("id")==null || ((List<String>)allRequestParams.get("id")).get(0).isEmpty() ){
			logger.info("reloadMemoryLocalService():"+"#ERROR: Missing Mandatory field to Id. Mandatory fields [ id ] " );
			return "#ERROR: Missing Mandatory field to Id. Mandatory fields [ id ] ";
		}else{
			mCachedProductService.reloadMemory((List<String>)allRequestParams.get("id"));
		}
		
		return null;
	}

}
