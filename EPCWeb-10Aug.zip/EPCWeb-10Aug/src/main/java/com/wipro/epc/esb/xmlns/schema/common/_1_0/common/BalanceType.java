
package com.wipro.epc.esb.xmlns.schema.common._1_0.common;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for balanceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="balanceType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UOM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CurrentBalance" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="StartDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="AccountPlan" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ExpirationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BalanceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountTypeDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountCredit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelatedType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelatedObjectID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InitialAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReserveAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}CustomRef" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "balanceType", propOrder = {
    "type",
    "uom",
    "currentBalance",
    "startDate",
    "accountPlan",
    "expirationDate",
    "balanceId",
    "accountTypeDescription",
    "accountCredit",
    "relatedType",
    "relatedObjectID",
    "initialAmount",
    "reserveAmount",
    "customRef"
})
public class BalanceType {

    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "UOM", required = true)
    protected String uom;
    @XmlElement(name = "CurrentBalance", required = true)
    protected String currentBalance;
    @XmlElement(name = "StartDate", required = true)
    protected String startDate;
    @XmlElement(name = "AccountPlan", required = true)
    protected String accountPlan;
    @XmlElement(name = "ExpirationDate", required = true)
    protected String expirationDate;
    @XmlElement(name = "BalanceId")
    protected String balanceId;
    @XmlElement(name = "AccountTypeDescription")
    protected String accountTypeDescription;
    @XmlElement(name = "AccountCredit")
    protected String accountCredit;
    @XmlElement(name = "RelatedType")
    protected String relatedType;
    @XmlElement(name = "RelatedObjectID")
    protected String relatedObjectID;
    @XmlElement(name = "InitialAmount")
    protected String initialAmount;
    @XmlElement(name = "ReserveAmount")
    protected String reserveAmount;
    @XmlElement(name = "CustomRef")
    protected List<CustomRefType> customRef;

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the uom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUOM() {
        return uom;
    }

    /**
     * Sets the value of the uom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUOM(String value) {
        this.uom = value;
    }

    /**
     * Gets the value of the currentBalance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentBalance() {
        return currentBalance;
    }

    /**
     * Sets the value of the currentBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentBalance(String value) {
        this.currentBalance = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDate(String value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the accountPlan property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountPlan() {
        return accountPlan;
    }

    /**
     * Sets the value of the accountPlan property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountPlan(String value) {
        this.accountPlan = value;
    }

    /**
     * Gets the value of the expirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the value of the expirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpirationDate(String value) {
        this.expirationDate = value;
    }

    /**
     * Gets the value of the balanceId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBalanceId() {
        return balanceId;
    }

    /**
     * Sets the value of the balanceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBalanceId(String value) {
        this.balanceId = value;
    }

    /**
     * Gets the value of the accountTypeDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTypeDescription() {
        return accountTypeDescription;
    }

    /**
     * Sets the value of the accountTypeDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTypeDescription(String value) {
        this.accountTypeDescription = value;
    }

    /**
     * Gets the value of the accountCredit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountCredit() {
        return accountCredit;
    }

    /**
     * Sets the value of the accountCredit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountCredit(String value) {
        this.accountCredit = value;
    }

    /**
     * Gets the value of the relatedType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelatedType() {
        return relatedType;
    }

    /**
     * Sets the value of the relatedType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelatedType(String value) {
        this.relatedType = value;
    }

    /**
     * Gets the value of the relatedObjectID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelatedObjectID() {
        return relatedObjectID;
    }

    /**
     * Sets the value of the relatedObjectID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelatedObjectID(String value) {
        this.relatedObjectID = value;
    }

    /**
     * Gets the value of the initialAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitialAmount() {
        return initialAmount;
    }

    /**
     * Sets the value of the initialAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitialAmount(String value) {
        this.initialAmount = value;
    }

    /**
     * Gets the value of the reserveAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReserveAmount() {
        return reserveAmount;
    }

    /**
     * Sets the value of the reserveAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReserveAmount(String value) {
        this.reserveAmount = value;
    }

    /**
     * Gets the value of the customRef property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customRef property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomRef().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CustomRefType }
     * 
     * 
     */
    public List<CustomRefType> getCustomRef() {
        if (customRef == null) {
            customRef = new ArrayList<CustomRefType>();
        }
        return this.customRef;
    }

}
