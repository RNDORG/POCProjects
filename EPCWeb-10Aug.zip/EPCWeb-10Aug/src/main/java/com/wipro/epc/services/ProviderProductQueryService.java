package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductProviderSystem;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.ProviderProductListInput;
import com.wipro.epc.dto.ProviderProductQueryInput;
import com.wipro.epc.dto.ProviderProductResponse;
import com.wipro.epc.util.EPCUtils;


/**
 * @author Developer
 * @version 1.0
 * type ProviderProductQueryService
 */
@Service
public class ProviderProductQueryService {
	
	/**
	 * EpcProductMigrationService ProviderProductQueryService.java
	 */
	@Autowired
	EpcProductMigrationService epcproductMigrationService;

	/**
	 * EpcProductSpecificationService ProviderProductQueryService.java
	 */
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;

	/**
	 * EpcAttributeMasterService ProviderProductQueryService.java
	 */
	@Autowired
	EpcAttributeMasterService epcAttributeMasterService;
	
	/**
	 * EpcProductProviderSystemService ProviderProductQueryService.java
	 */
	@Autowired
	EpcProductProviderSystemService epcProductProviderSystemService;
	
	/**
	 * ComplexSearchInputService ProviderProductQueryService.java
	 */
	@Autowired
	ComplexSearchInputService complexSearchInputService;
	
	/**
	 * EpcLookupMasterService ProviderProductQueryService.java
	 */
	@Autowired
	EpcLookupMasterService epcLookupMasterService;
	
	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	public List<ProviderProductResponse> queryProviderProduct(
			ProviderProductQueryInput queryInput, MultiValueMap allRequestParams) {
		
		if(StringUtils.isBlank(queryInput.getCategory()) || StringUtils.isBlank(queryInput.getInitiatingChannel()) || StringUtils.isBlank(queryInput.getActionType()) || queryInput.getProviderList() == null || (queryInput.getProviderList() != null && queryInput.getProviderList().isEmpty())){
			throw new GenericException("InvalidSearch", "Mandatory Fields are missing. Please provide all mandatory fields ( providerList<providerProductId, providerSystem>, initChannel, actionType, category)", "Mandatory Fields are missing.");
		}
		
		List<EpcProductProviderSystem> providers = fetchProductProviders(queryInput.getProviderList());
		if(providers == null || (providers != null && providers.isEmpty())){
			throw new GenericException("InvalidSearch", "The given providerList<providerProductId, providerSystem> doesn't return any product.", "Invalid providerList<providerProductId, providerSystem> given.");
		}
		
		List<String> initChannelLookups = epcLookupMasterService.getLookUpValuesByGroupAndName("epc_product_init_channel", "channel_id");
		if(!initChannelLookups.contains(queryInput.getInitiatingChannel())){
			throw new GenericException("InvalidSearch", "Invalid Initiating Channel provided.", "Invalid Initiating Channel provided.");
		}
		List<String> lookups = epcLookupMasterService.getLookUpValuesByGroupAndName("epc_product_init_channel", "action_type");
		if(!lookups.contains(queryInput.getActionType())){
			throw new GenericException("InvalidSearch", "Invalid Action Type provided.", "Invalid Action Type provided.");
		}
		
		List<String> productIds = new ArrayList<String>();
		for(EpcProductProviderSystem provider : providers){
			productIds.add(String.valueOf(provider.getProductId()));
		}

		List<String> withClauses = new ArrayList<String>();
		withClauses.add("initiatingChannel");
		
		List<String> requestParamWith = (List<String>) allRequestParams.get("with");
		List<String> supportedWith = Arrays.asList(new String []{"characteristic", "tariff", "availability"});
		if(requestParamWith != null && !requestParamWith.isEmpty()){
			for(String str : requestParamWith){
				if(!supportedWith.contains(str)){
					if(!(str.contains("ta-") || str.contains("nta-") ) ){
						throw new GenericException("UnsupportedWith", "Unsupported with parameter ("+ str +") provided.", "Unsupported with parameter ("+ str +") provided.");
					}
				}
			}
		}
		
		if(requestParamWith!=null && requestParamWith.contains("tariff"))
			withClauses.add("tariff");
		if(requestParamWith!=null && requestParamWith.contains("characteristic"))
			withClauses.add("characteristic");
		if(requestParamWith!=null && requestParamWith.contains("availability"))
			withClauses.add("availability");;
		Map<String, List<String>> basicRequestParams = new HashMap<String, List<String>>();
		basicRequestParams.put("productId", productIds);
		//basicRequestParams.put("with", Arrays.asList(new  String[]{"initiatingChannel","characteristic","tariff"})); 
		basicRequestParams.put("with", withClauses); 
		List<EpcProductSpecification> products = complexSearchInputService.searchProducts(basicRequestParams, null, true);
		
		for( Iterator<EpcProductSpecification> iterator = products.iterator(); iterator.hasNext();  ){
			EpcProductSpecification epcProductSpecification = iterator.next();
			boolean initChannelCheck = false;
			List<EpcProductInitChannel> initChannels = epcProductSpecification.getEpcProductInitChannel();
			if (initChannels != null) {
				for (EpcProductInitChannel initChannel : initChannels) {
					if (queryInput.getInitiatingChannel().equals(String.valueOf(initChannel.getChannelId())) && queryInput.getActionType().equals(String.valueOf(initChannel.getActionType()))) {
						initChannelCheck = true;
						epcProductSpecification.setChannelMarketingName(initChannel.getChannelLevelMarketName());
						epcProductSpecification.setChannelLevelProductId(initChannel.getChannelLevelProductId());
						epcProductSpecification.setMetaInfo(new HashMap<String, String>());
						epcProductSpecification.getMetaInfo().put("isUnsubsAllowedFromCRM", "true");
						break;
					}
				}
			}
			if(initChannels != null && !initChannelCheck){
						epcProductSpecification.setChannelMarketingName(initChannels.get(0).getChannelLevelMarketName());
						epcProductSpecification.setChannelLevelProductId(initChannels.get(0).getChannelLevelProductId());
						epcProductSpecification.setMetaInfo(new HashMap<String, String>());
						epcProductSpecification.getMetaInfo().put("isUnsubsAllowedFromCRM", "false");
			}
			if (initChannels == null){
				epcProductSpecification.setMetaInfo(new HashMap<String, String>());
				epcProductSpecification.getMetaInfo().put("isUnsubsAllowedFromCRM", "false");
			}
			
			//else{
				epcProductSpecification.setEpcProductInitChannel(null);
			//}
		}
		List<ProviderProductResponse> response = new ArrayList<ProviderProductResponse>();
		Map<String, EpcProductSpecification> prodShortCodes = null;
		for(ProviderProductListInput input : queryInput.getProviderList()){
			List<Integer> pids = new ArrayList<Integer>();
			prodShortCodes = new TreeMap<String, EpcProductSpecification>();
			ProviderProductResponse providerProductResponse = new ProviderProductResponse();
			providerProductResponse.setProviderProductId(input.getProviderProductId());
			providerProductResponse.setProviderSystem(input.getProviderSystem());				
			for(EpcProductProviderSystem provider : providers){
				if(input.getProviderProductId().equals(provider.getProviderProductId()) && provider.getProviderSystemCode().equals(input.getProviderSystem())){
					pids.add( provider.getProductId());
				}
			}
			if( pids.isEmpty()){
				providerProductResponse.setRemarks("Product not found for given providerProductId, providerSystem.");
				providerProductResponse.setIsUnsubsAllowedFromCRM(false);
			}else{
				for(EpcProductSpecification product : products){
					for(Integer pid : pids){
						if(product.getProductId().equals(pid) && EPCUtils.validateCategory(product.getProductCategory(), queryInput.getCategory())){
							prodShortCodes.put(product.getProductShortCode(), product);
						}
					}
				}
				if(!prodShortCodes.isEmpty()){
					EpcProductSpecification prod = prodShortCodes.get(prodShortCodes.keySet().toArray()[0]);
					providerProductResponse.setIsUnsubsAllowedFromCRM(Boolean.valueOf(prod.getMetaInfo().get("isUnsubsAllowedFromCRM")));
					providerProductResponse.setEpcProductSpecification(prod);
				}
			}
			response.add(providerProductResponse);
		}
		for(EpcProductSpecification product : products){
			product.setMetaInfo(null);
		}
		return response;
	}
	
	/**
	 * @param providersList
	 * @return
	 */
	private List<EpcProductProviderSystem> fetchProductProviders(List<ProviderProductListInput> providersList) {
		List<EpcProductProviderSystem> epcProdProviders = epcProductProviderSystemService.getList(providersList);
		return epcProdProviders;
	}

}
