package com.wipro.epc.dto;

import com.wipro.epc.domain.EpcProductSpecification;

public class MigrationEligibilityResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	private String status = "SUCCESS";
	
	private String remarks = "NA";
	
	private EpcProductSpecification productSpecification;
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public EpcProductSpecification getProductSpecification() {
		return productSpecification;
	}
	public void setProductSpecification(EpcProductSpecification productSpecification) {
		this.productSpecification = productSpecification;
	}

	
	

}
