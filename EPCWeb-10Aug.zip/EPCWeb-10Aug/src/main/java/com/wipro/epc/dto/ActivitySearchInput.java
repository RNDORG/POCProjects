package com.wipro.epc.dto;

import java.util.List;

/**
 * @author Developer
 * @version 1.0
 * type ActivitySearchInput
 */
public class ActivitySearchInput {
	/**
	 * String ActivitySearchInput.java
	 */
	private String activityName;
	/**
	 * List<String> ActivitySearchInput.java
	 */
	private List<String> activityKey;
	/**
	 * String ActivitySearchInput.java
	 */
	private String activityValue;
	/**
	 * String ActivitySearchInput.java
	 */
	private String initiatingChannel;
	/**
	 * String ActivitySearchInput.java
	 */
	private String salesChannel;
	/**
	 * @return
	 */
	public String getActivityName() {
		return activityName;
	}
	/**
	 * @param activityName
	 */
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	/**
	 * @return
	 */
	public List<String> getActivityKey() {
		return activityKey;
	}
	/**
	 * @param activityKey
	 */
	public void setActivityKey(List<String> activityKey) {
		this.activityKey = activityKey;
	}
	/**
	 * @return
	 */
	public String getActivityValue() {
		return activityValue;
	}
	/**
	 * @param activityValue
	 */
	public void setActivityValue(String activityValue) {
		this.activityValue = activityValue;
	}
	/**
	 * @return
	 */
	public String getInitiatingChannel() {
		return initiatingChannel;
	}
	/**
	 * @param initiatingChannel
	 */
	public void setInitiatingChannel(String initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}
	/**
	 * @return
	 */
	public String getSalesChannel() {
		return salesChannel;
	}
	/**
	 * @param salesChannel
	 */
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ActivitySearchInput [activityName=" + activityName
				+ ", activityKey=" + activityKey + ", activityValue="
				+ activityValue + ", initiatingChannel=" + initiatingChannel
				+ ", salesChannel=" + salesChannel + "]";
	}
	

}
