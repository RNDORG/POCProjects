package com.wipro.epc.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.epc.repositories.EpcNotificationTemplateRepository;
import com.wipro.epc.repositories.NotificationTemplateValidationRepository;


/**
 * @author KE334465
 *
 */
@Service
public class NotificationTemplateValidationService {
	private static Logger logger = LoggerFactory.getLogger(NotificationTemplateValidationService.class);

	@Autowired
	private NotificationTemplateValidationRepository repository;
	
	@Autowired
	private EpcNotificationTemplateRepository notificationTemplateRepository;
	
	
	
	/**
	 * @return
	 */
	public NotificationTemplateValidationRepository getRepository() {
		return repository;
	}


	/**
	 * @param repository
	 */
	public void setRepository(NotificationTemplateValidationRepository repository) {
		this.repository = repository;
	}


	/**
	 * @return
	 */
	public EpcNotificationTemplateRepository getNotificationTemplateRepository() {
		return notificationTemplateRepository;
	}


	/**
	 * @param notificationTemplateRepository
	 */
	public void setNotificationTemplateRepository(
			EpcNotificationTemplateRepository notificationTemplateRepository) {
		this.notificationTemplateRepository = notificationTemplateRepository;
	}


	/**
	 * @param templateName
	 * @return
	 */
	@Transactional
	public int validateTemplateName(String templateName)
			{
				
				int validType = repository.validateTemplateName(templateName);
				return validType;
		
			}

	
	/**
	 * @param validationArray, checks for validation and gives success/failure in a new array
	 * @return
	 */
	public String[] validateTemplateCombination(
			List<String[]> validationArray) {
		String[]  returnArray = new String[validationArray.size()];
		int i=0;
		for(String[] array: validationArray) {
			logger.info("Hi, the values passed are "+ array[0] +" "+ array[1]+" "+ array[2]+" " +array[3]);
			if(notificationTemplateRepository.getListOfValidation(array[0], array[1], array[2], array[3]).size()>1) {
				returnArray[i] = "SUCCESS";
			} else {
				returnArray[i] = "FAILURE";
			}
			i++;
				
		}
		
		return returnArray;
	}

}
