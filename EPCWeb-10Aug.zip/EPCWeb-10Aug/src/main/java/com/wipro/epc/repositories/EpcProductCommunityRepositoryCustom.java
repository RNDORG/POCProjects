package com.wipro.epc.repositories;
import com.wipro.epc.domain.EpcProductCommunity;

import java.util.List;

/**
 * 
 * @author VI251443
 * @version 1.0
 */

public interface EpcProductCommunityRepositoryCustom {
    /**
     * 
     * @param string
     * @return
     */
	List<EpcProductCommunity> getList(String string);
	
	/**
	 * 
	 * @param community
	 */
	void modify(EpcProductCommunity community);
	
	void update(EpcProductCommunity community);
	/**
	 * 
	 * @return
	 */
	public List<Integer> getAllNonGlobalCorpPoolProductIds();
}
