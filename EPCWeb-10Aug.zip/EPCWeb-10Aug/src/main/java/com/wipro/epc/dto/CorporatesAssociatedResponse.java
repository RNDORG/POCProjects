package com.wipro.epc.dto;

import com.wipro.epc.domain.EpcProductCommunity;

public class CorporatesAssociatedResponse {
	
	 private String productMarketingName;
	 private String productShortCode;
	 private String productId;
	 private String productDescription;
	 private String productSubFamily;
	 private String productType;
	 private String fee;
	 private String productProviderId;
	 private String productClassification;
	 private String productCategory;
	 private String productSubCategory;
	 private String status;
	 
	
	 private EpcProductCommunity community; 
	 
	 
	public void setProductMarketingName(String productmarketingName) {
		this.productMarketingName = productmarketingName;
	}
	public String getProductShortCode() {
		return productShortCode;
	}
	public void setProductShortCode(String productShortCode) {
		this.productShortCode = productShortCode;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getProductSubFamily() {
		return productSubFamily;
	}
	public void setProductSubFamily(String productSubFamily) {
		this.productSubFamily = productSubFamily;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String getProductProviderId() {
		return productProviderId;
	}
	public void setProductProviderId(String productProviderId) {
		this.productProviderId = productProviderId;
	}
	@Override
	public String toString() {
		return "CorporatesAssociatedResponse [productmarketingName="
				+ productMarketingName + ", productShortCode="
				+ productShortCode + ", productId=" + productId
				+ ", productDescription=" + productDescription
				+ ", productSubFamily=" + productSubFamily + ", productType="
				+ productType + ", fee=" + fee + ", productProviderId="
				+ productProviderId + "]";
	}
	public EpcProductCommunity getCommunity() {
		return community;
	}
	public void setCommunity(EpcProductCommunity community) {
		this.community = community;
	}
	public String getProductMarketingName() {
		return productMarketingName;
	}
	public String getProductClassification() {
		return productClassification;
	}
	public void setProductClassification(String productClassification) {
		this.productClassification = productClassification;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductSubCategory() {
		return productSubCategory;
	}
	public void setProductSubCategory(String productSubCategory) {
		this.productSubCategory = productSubCategory;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	 
	 
	 
}
