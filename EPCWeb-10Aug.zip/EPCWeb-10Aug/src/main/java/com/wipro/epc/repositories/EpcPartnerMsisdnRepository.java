package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcPartnerMsisdn;

/**
 * @author Developer
 * @version 1.0
 * type EpcPartnerMsisdnRepository
 */
public interface EpcPartnerMsisdnRepository extends CrudRepository<EpcPartnerMsisdn, Integer>{

	/**
	 * @param partnerMsisdn
	 * @return
	 */
	@Query(value="select * from epc_partner_msisdn where partner_msisdn = :partnerMsisdn", nativeQuery=true)
	List<EpcPartnerMsisdn> getListOfPartnerMsisdn(@Param("partnerMsisdn") String partnerMsisdn);
}
