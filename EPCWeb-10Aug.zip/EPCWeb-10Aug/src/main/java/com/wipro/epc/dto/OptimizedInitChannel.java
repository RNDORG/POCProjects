package com.wipro.epc.dto;

import java.io.Serializable;


public class OptimizedInitChannel  implements Serializable {

	private String channelLevelProductId;

	private String channelLevelMarketName;

	private String status;
	
	private String urlString;

	/**
	 * @return the channelLevelProductId
	 */
	public String getChannelLevelProductId() {
		return channelLevelProductId;
	}

	/**
	 * @param channelLevelProductId the channelLevelProductId to set
	 */
	public void setChannelLevelProductId(String channelLevelProductId) {
		this.channelLevelProductId = channelLevelProductId;
	}

	/**
	 * @return the channelLevelMarketName
	 */
	public String getChannelLevelMarketName() {
		return channelLevelMarketName;
	}

	/**
	 * @param channelLevelMarketName the channelLevelMarketName to set
	 */
	public void setChannelLevelMarketName(String channelLevelMarketName) {
		this.channelLevelMarketName = channelLevelMarketName;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the urlString
	 */
	public String getUrlString() {
		return urlString;
	}

	/**
	 * @param urlString the urlString to set
	 */
	public void setUrlString(String urlString) {
		this.urlString = urlString;
	}

}