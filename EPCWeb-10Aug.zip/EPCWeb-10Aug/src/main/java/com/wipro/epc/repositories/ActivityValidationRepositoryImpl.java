package com.wipro.epc.repositories;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.wipro.epc.domain.EpcActivityChannelRule;


/**
 * @version 1.0
 * @author VI251443
 *
 */
public class ActivityValidationRepositoryImpl implements ActivityValidationRepositoryCustom{
	
	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public int validateActivity(EpcActivityChannelRule orderList){
		
		StringBuilder queryBuilder = new StringBuilder("select count(1) from epc_activity_channel_rule where activity_id = "+ orderList.getActivityId()+" and  sales_channel ='"+orderList.getSalesChannel()+"' and initiating_channel ='"+orderList.getInitiatingChannel()+"'");	
		String query = queryBuilder.toString();
		int maxValue = ((Number) em.createNativeQuery(query).getSingleResult()).intValue();
		
		//System.out.println(maxValue+"-----------");
		
		
			
			return maxValue;
		
		
		
		}


}
