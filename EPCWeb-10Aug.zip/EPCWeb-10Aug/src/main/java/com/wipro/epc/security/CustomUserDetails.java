package com.wipro.epc.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import com.wipro.epc.uam.domain.Users;



public class CustomUserDetails extends Users implements UserDetails {
	
	List<String> authorities;

	public CustomUserDetails(Users users, List<String> authorities ) {
		super(users);
		this.authorities = (authorities != null ) ? authorities : new ArrayList<String>() ;
		
		System.out.println("CustomUserDetails(" + users.toString() + "," + authorities.toString() + ") Constructed."  );
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
    	
		List<GrantedAuthority> retVal = new ArrayList<GrantedAuthority>();
		
		for( String s : authorities ) {
			retVal.add( new SimpleGrantedAuthority(s) );
		}	
   	
		return retVal;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		String enabled = getEnabled();
		return ( enabled != null && enabled.equalsIgnoreCase("true")) ? true : false;
	}
	
}