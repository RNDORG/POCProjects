package com.wipro.epc.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.wipro.epc.domain.CacheEligibility;

@Repository
public interface CacheEligibilityRepository extends CrudRepository<CacheEligibility, Integer>,
CacheEligibilityRepositoryCustom{

}
