package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wipro.epc.domain.ReloadStatus;

public class ReloadStatusRepositoryImpl implements ReloadStatusRepositoryCustom {
	
	private static Logger logger =LoggerFactory.getLogger(ReloadStatusRepositoryImpl.class);
	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<ReloadStatus> getStatus(String query){
		logger.debug("#Query: "+query);
			return em.createNativeQuery(query, ReloadStatus.class).getResultList();
	}

	@Override
	public Integer getCount(String query){
		logger.debug("#Query: "+query);
			return em.createNativeQuery(query, ReloadStatus.class).getResultList().size();
	}

}
