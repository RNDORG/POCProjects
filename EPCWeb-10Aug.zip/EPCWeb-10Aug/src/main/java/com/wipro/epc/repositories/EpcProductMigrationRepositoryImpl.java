package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.epc.domain.EpcProductMigration;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductMigrationRepositoryImpl
 */
public class EpcProductMigrationRepositoryImpl implements EpcProductMigrationRepositorycCustom{

	private static Logger logger =LoggerFactory.getLogger(EpcProductMigrationRepositoryImpl.class);
	
	/**
	 * EntityManager EpcProductMigrationRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductMigrationRepositorycCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcProductMigration> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query,EpcProductMigration.class).getResultList();
	}
	
    /* (non-Javadoc)
     * @see com.wipro.epc.repositories.EpcProductMigrationRepositorycCustom#modifyProductMigration(com.wipro.epc.domain.EpcProductMigration)
     */
    @Override
	public EpcProductMigration modifyProductMigration(EpcProductMigration migration) {
StringBuilder queryBuilder = new StringBuilder("update epc_product_migration set product_migration_id="+migration.getProductMigrationId());
		
		if(migration.getStatus()!=null && !migration.getStatus().isEmpty())
			queryBuilder.append(",").append(" status = '").append(migration.getStatus()).append("'");
		if(migration.getSourceCategory()!=null && !migration.getSourceCategory().isEmpty())
			queryBuilder.append(",").append("source_category = '").append(migration.getSourceCategory()).append("'");
		if(migration.getSourceProductId()!=null && migration.getSourceProductId()!=0)
			queryBuilder.append(",").append("source_product_id = '").append(migration.getSourceProductId()).append("'");;
		if(migration.getTargetCategory()!=null && !migration.getTargetCategory().isEmpty())
			queryBuilder.append(",").append("target_category = '").append(migration.getTargetCategory()).append("'");
		if(migration.getTargetProductId()!=null && migration.getTargetProductId()!=0)
			queryBuilder.append(",").append("target_product_id = '").append(migration.getTargetProductId()).append("'");
		if(migration.getMigrationChannel()!=null && !migration.getMigrationChannel().isEmpty() )
			queryBuilder.append(",").append("migration_channel  = '").append(migration.getMigrationChannel()).append("'");
				
		queryBuilder.append(" where product_migration_id =").append(migration.getProductMigrationId());
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		//System.out.println(query);
		return migration;
	}
}
