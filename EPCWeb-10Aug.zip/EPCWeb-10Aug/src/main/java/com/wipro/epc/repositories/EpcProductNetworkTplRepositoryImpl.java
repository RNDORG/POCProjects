package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wipro.epc.domain.EpcProductNetworkTpl;


/**
 * @author KE334465
 *
 */
public class EpcProductNetworkTplRepositoryImpl implements EpcProductNetworkTplRepositoryCustom{
	
	private static Logger logger =LoggerFactory.getLogger(EpcProductNetworkTplRepositoryImpl.class);
	
	@PersistenceContext
	private EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcProductNetworkTplRepositoryCustom#getNetworkProfileList(java.lang.String)
	 */
	@Override
	public List<EpcProductNetworkTpl> getNetworkProfileList(String query){
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query, EpcProductNetworkTpl.class).getResultList();
	
	}

	/**
	 * @return
	 */
	public EntityManager getEm() {
		return em;
	}

	/**
	 * @param em
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}
}
