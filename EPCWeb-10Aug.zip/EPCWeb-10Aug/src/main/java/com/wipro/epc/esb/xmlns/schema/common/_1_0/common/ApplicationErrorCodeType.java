
package com.wipro.epc.esb.xmlns.schema.common._1_0.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ApplicationErrorCodeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ApplicationErrorCodeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="TNM-BIZERR-APP001"/>
 *     &lt;enumeration value="TNM-BIZERR-APP002"/>
 *     &lt;enumeration value="TNM-BIZERR-APP003"/>
 *     &lt;enumeration value="TNM-BIZERR-APP004"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ApplicationErrorCodeType")
@XmlEnum
public enum ApplicationErrorCodeType {

    @XmlEnumValue("TNM-BIZERR-APP001")
    TNM_BIZERR_APP_001("TNM-BIZERR-APP001"),
    @XmlEnumValue("TNM-BIZERR-APP002")
    TNM_BIZERR_APP_002("TNM-BIZERR-APP002"),
    @XmlEnumValue("TNM-BIZERR-APP003")
    TNM_BIZERR_APP_003("TNM-BIZERR-APP003"),
    @XmlEnumValue("TNM-BIZERR-APP004")
    TNM_BIZERR_APP_004("TNM-BIZERR-APP004");
    private final String value;

    ApplicationErrorCodeType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ApplicationErrorCodeType fromValue(String v) {
        for (ApplicationErrorCodeType c: ApplicationErrorCodeType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
