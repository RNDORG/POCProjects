package com.wipro.epc.services;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.DownstreamQueryInput;
import com.wipro.epc.util.Constants;


/**
 * @author Developer
 * @version 1.0
 * type DownstreamQueryService
 */
@Service
public class DownstreamQueryService {
	
	
	/**
	 * ComplexSearchInputService DownstreamQueryService.java
	 */
	@Autowired
	ComplexSearchInputService complexSearchInputService;
	
	/**
	 * EpcOrderChannelRuleService DownstreamQueryService.java
	 */
	@Autowired
	EpcOrderChannelRuleService epcOrderChannelRuleService;
	

	/**
	 * @param queryInput
	 * @param allRequestParams
	 * @return
	 */
	@Transactional
	public EpcProductSpecification queryDownstream(DownstreamQueryInput queryInput, Map<String, List<String>> allRequestParams){
		
		if(StringUtils.isBlank(queryInput.getInitiatingChannel()) || StringUtils.isBlank(queryInput.getOrderType()) || StringUtils.isBlank(queryInput.getProductShortCode())){
				throw new GenericException("InvalidSearch", "Mandatory Fields are missing. Please provide all mandatory fields (orderType, initChannel, productShortCode)", "Mandatory Fields are missing.");
			}

		List<String> with = allRequestParams.get("with");
		List<String> supportedWith = Arrays.asList(new String []{"provider"});
		if(with != null && !with.isEmpty()){
			for(String str : with){
				if(!supportedWith.contains(str)){
						throw new GenericException("UnsupportedWith", "Unsupported with parameter ("+ str +") provided.", "Unsupported with parameter ("+ str +") provided.");
				}
			}
		}
		
		//logic for OCR check
		EpcOrderChannelRule orderChannelRule = fetchOrderChannelRule(queryInput);
		if(orderChannelRule != null && orderChannelRule.getStatus().equals(Constants.COMMON_STATUS_ACTIVE)){
			//OCR checked 
		}else{
			throw new GenericException("SearchFailed", "Failed for Order Channel Rule check.", "Failed for Order Channel Rule check.");
		}
		allRequestParams.put("productShortCode", Arrays.asList(new  String[]{queryInput.getProductShortCode()}));
		List<EpcProductSpecification> products = complexSearchInputService.searchProducts(allRequestParams, null, false);
		if(products != null && products.size()==1){
			return products.get(0);
		}else{
			throw new GenericException("InvalidSearch", "No product found for the given product short code.", "No product found for the given product short code.");
		}
	}
	
	/**
	 * @param queryInput
	 * @return
	 */
	private EpcOrderChannelRule fetchOrderChannelRule(DownstreamQueryInput queryInput) {
		StringBuilder query = new StringBuilder().append(" where order_type = '").append(queryInput.getOrderType()).append("' and initiating_channel = '")
				.append(queryInput.getInitiatingChannel()).append("'");
		if(queryInput.getSalesChannel() != null){
			query.append(" and sales_channel = '").append(queryInput.getSalesChannel()).append("'");
		}else{
			query.append(" and sales_channel is null ");
		}
		
		List<EpcOrderChannelRule> epcOrderChannelRules = epcOrderChannelRuleService.getOrderChannelRulesByWhereClause(query.toString() );
		EpcOrderChannelRule epcOrderChannelRule = null;
		if(epcOrderChannelRules != null && !epcOrderChannelRules.isEmpty() ){
			epcOrderChannelRule = epcOrderChannelRules.get(0);
		}
		return epcOrderChannelRule;
	}
}
