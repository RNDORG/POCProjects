package com.wipro.epc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.services.EpcOrderChannelRuleService;

/**
 * 
 * @author VI251443
 * @version 1.0
 */
@RestController
public class EpcOrderChannelRuleController {
	
	@Autowired
	EpcOrderChannelRuleService service;
	
	/**
	 * 
	 * @param orderList
	 * @param txn
	 * @param mix_op
	 * @return
	 */
	@RequestMapping(value="rest/extapi/v1/orders", method=RequestMethod.POST)
	public List<EpcOrderChannelRule> manageOrdersExt(@RequestBody List<EpcOrderChannelRule> orderList,
			@RequestParam(value="txn",defaultValue="true")boolean txn,
			@RequestParam(value="mix_op",defaultValue="true")boolean mix_op)
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		return service.manageOrders(orderList, txn, mix_op,user);
	}
	/**
	 * This API gets the data from DB
	 * @param allRequestParams
	 * @return List<EpcOrderChannelRule>
	 */
	@RequestMapping(value="rest/extapi/v1/orders", method=RequestMethod.GET)
	public List<EpcOrderChannelRule> searchOrdersExt(@RequestParam MultiValueMap allRequestParams)
	{
 			return service.searchEpcOrderChannelRule(allRequestParams);
	}
	
	/**
	 * using this API user can modify the data in DB 
	 * @param orderList
	 * @param txn
	 * @param mix_op
	 * @return List<EpcOrderChannelRule>
	 */
	@RequestMapping(value="rest/api/v1/orders", method=RequestMethod.POST)
	public List<EpcOrderChannelRule> manageOrders(@RequestBody List<EpcOrderChannelRule> orderList,
			@RequestParam(value="txn",defaultValue="true")boolean txn,
			@RequestParam(value="mix_op",defaultValue="true")boolean mix_op)
	{
		String user=SecurityContextHolder.getContext().getAuthentication().getName();
		return service.manageOrders(orderList, txn, mix_op,user);
	}
	
	/**
	 * This API gets the data from DB
	 * @param allRequestParams
	 * @return List<EpcOrderChannelRule>
	 */
	@RequestMapping(value="rest/api/v1/orders", method=RequestMethod.GET)
	public List<EpcOrderChannelRule> searchOrders(@RequestParam MultiValueMap allRequestParams)
	{
		//System.out.println("All request params is "+allRequestParams);
 			return service.searchEpcOrderChannelRuleInt(allRequestParams);
	}
	
	/**
	 * This API gets the data from DB
	 * @param allRequestParams
	 * @return List<EpcOrderChannelRule> 
	 */
	@RequestMapping(value="rest/api/v1/ordersValidation", method=RequestMethod.GET)
	public List<EpcOrderChannelRule> searchOrdersValidation(@RequestParam MultiValueMap allRequestParams)
	{
		//System.out.println("All request params is "+allRequestParams);
 			return service.searchEpcOrderChannelRuleValidation(allRequestParams);
	}
}
