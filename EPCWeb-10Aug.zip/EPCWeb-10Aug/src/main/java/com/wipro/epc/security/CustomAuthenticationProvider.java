package com.wipro.epc.security;

import java.io.Serializable;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.AuthenticationNotSupportedException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.wipro.common.config.service.ConfigService;
import com.wipro.epc.uam.domain.Users;


@Component(value = "authenticationProvider")
public class CustomAuthenticationProvider implements AuthenticationProvider, Serializable {

	public static Logger logger = LoggerFactory.getLogger(CustomAuthenticationProvider.class);
	
    @Autowired
    public CustomUserDetailsService userService;
    @Autowired
    ConfigService config;
    public CustomAuthenticationProvider() {}

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
    	System.out.println("authenticate(Authentication authentication) Invoked  =========================================");
        System.out.println("authentication.toString() : " + authentication.toString() );
        System.out.println("authentication.getDetails(): " + authentication.getDetails() );
        System.out.println("authentication.getName() : " + authentication.getName() );
       // System.out.println("authentication.getCredentials() " + authentication.getCredentials());
        
        System.out.println("Now looking up and getting UserDetails from userService  =========================================");
        
        UserDetails userDetails = userService.loadUserByUsername(authentication.getName() );
        Users user = (Users) userDetails;
        System.out.println(" Looked up and GOT: " + "userDetails.isEnabled() = " + userDetails.isEnabled() + " | user.getEnabled = " + user.getEnabled() + " | user = " + user.toString() );
           
        System.out.println(" userDetails.getUsername() :  " + userDetails.getUsername() );
        System.out.println(" userDetails.getPassword() :  " + userDetails.getPassword().length() );
        System.out.println(" userDetails.getAuthorities() :  " + userDetails.getAuthorities() );
        System.out.println(" userDetails.isEnabled() :  " + userDetails.isEnabled() );
        
        
        System.out.println("authenticate() : Now checking Credentials ==================================================================================================");
        
        String domain = "@"+config.searchConfigKey("CustomConfig","CustomLDAP_Domain").getConfigValue();
        String username = authentication.getName();
        String password = (String) authentication.getCredentials();   
        String timeoutInMiliSec = config.searchConfigKey("CustomConfig","CustomLDAP_Timeout").getConfigValue();;
       // String url = config.searchConfigKey("LDAPConfig","contextSource").getConfigValue();
        String url = config.searchConfigKey("CustomConfig","CustomLDAP_URL").getConfigValue();
        ////-------------Required above one? -------------------------
        
        boolean authenticated=false;
        String customType=config.searchConfigKey("CustomConfig","CustomType").getConfigValue();
        
         // look up for key customType if value is customLdap if value is custom jdbc
        if ( customType.equals("CUSTOM_JDBC") )   {       
        	authenticated = password.equals(user.getPassword());
        }
		else {
			if (!customType.equals("CUSTOM_LDAP") ) {
				logger.error("Incorrect Configuration please chceck Custom Type");
				
			}
			
			String securityAuth=config.searchConfigKey("CustomConfig","CustomLDAP_SecurityAuthentication").getConfigValue();
			authenticated = ldapAuthentication(username,password,url,securityAuth,domain,timeoutInMiliSec);
		}
       
        
        if (!authenticated ) {
        	System.out.println("About to throw BadCredentials Exception: ");
        	//System.out.println("From Login Screen we got ==> " + "[username=" + username + ", password="+ password + "]" );
        	System.out.println("From Database we got     ==> " + user.toString()  );
        	System.out.println("authenticate() : Ends Unsuccessfully ==================================================================================================");
            throw new BadCredentialsException("Invalid credentials");       
        }
        System.out.println("authenticate() : Now checking if user enabled ==================================================================================================");

        if ( !userDetails.isEnabled() ) {
        	System.out.println("User " + userDetails.getUsername() + " is disabled." );
        	System.out.println( "userDetails.toString() : " + userDetails.toString()  );
        	System.out.println( "users.toString() : " + user.toString()  );
        	System.out.println("authenticate() : Ends Unsuccessfully ==================================================================================================");
        	throw new BadCredentialsException("User Disabled.");
        }     

        Authentication retAuth = new UsernamePasswordAuthenticationToken(userDetails, password, userDetails.getAuthorities() );
        System.out.println("authenticate() : Ends successfully ==================================================================================================");
        return retAuth;
    }

    @Override
    public boolean supports(Class<? extends Object> authentication) {
    	return (UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication));
    }
    
    public static boolean ldapAuthentication(String ldapUsername,String ldapPassword,String ldapAdServer,String securityAuth,String domain, String timeout) 
    {System.out.println("ldapAuthentication(" + ldapUsername + "," + ldapPassword + "," + ldapAdServer + ") start --------------- ");
	System.out.println("Username:"+ldapUsername);
	System.out.println("Server:"+ldapAdServer);
	//System.out.println("Password:"+ldapPassword);
	System.out.println("domain:"+domain);
	System.out.println("securityAuth:"+securityAuth);
	System.out.println("per server connectionTimeout in ms:"+timeout);
      boolean result=false;
     
Hashtable<String, Object> env = new Hashtable<String, Object>();
        
        env.put(Context.SECURITY_AUTHENTICATION, securityAuth);
        if(ldapUsername != null) {
            env.put(Context.SECURITY_PRINCIPAL, ldapUsername+domain);
        }
        if(ldapPassword != null) {
            env.put(Context.SECURITY_CREDENTIALS, ldapPassword);
        }
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, ldapAdServer);
              
        if(timeout!=null) {
        env.put("com.sun.jndi.ldap.connect.timeout",timeout);
        }

        //ensures that objectSID attribute values
        //will be returned as a byte[] instead of a String
        env.put("java.naming.ldap.attributes.binary", "objectSID");
        
        // the following is helpful in debugging errors
        //env.put("com.sun.jndi.ldap.trace.ber", System.err);
        
try {

            DirContext ctx = new InitialDirContext(env);
           

            System.out.println("DirContext created: " + ctx.getEnvironment());

            //SearchResult srLdapUser = ldap.findAccountByAccountName(ctx, ldapSearchBase, "ngoyal");



            // do something useful with the context...

        

            ctx.close();
	    System.out.println("DirContext closed");
	    result = true;

}

         catch (AuthenticationNotSupportedException ex) {result=false;

		ex.printStackTrace();
            System.out.println("The authentication is not supported by the server");

        } catch (AuthenticationException ex) {result=false;
ex.printStackTrace();

            System.out.println("incorrect password or username");

        } catch (javax.naming.NamingException ex) {result=false;
ex.printStackTrace();
System.out.println(ex.getMessage());
	   
            System.out.println("error when trying to create the context");

        }
	System.out.println("ldapAuthentication() ends. Returned => " + result + " --------------- ");
	return result;
	
    }
}