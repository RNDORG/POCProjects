package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type ProviderProductResponse
 */
public class ManageCommunityStatusResponse {
	private String status;
	private String remarks;
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
