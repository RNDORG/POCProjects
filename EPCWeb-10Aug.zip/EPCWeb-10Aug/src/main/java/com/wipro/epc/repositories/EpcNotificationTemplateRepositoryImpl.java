package com.wipro.epc.repositories;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.wipro.epc.domain.EpcNotificationTemplate;
import com.wipro.epc.util.SimpleDateConvertion;
/**
 * 
 * @author VI251443
 * @version 0.1
 */
public class EpcNotificationTemplateRepositoryImpl implements EpcNotificationTemplateRepositoryCustom{
	
	private static Logger logger =LoggerFactory.getLogger(EpcNotificationTemplateRepositoryImpl.class);

	/**
	 * 
	 */
	@PersistenceContext
	private EntityManager em;
	

	/**
	 * 
	 */
	@Autowired
	private SimpleDateConvertion convert;
	
	
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcNotificationTemplateRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcNotificationTemplate> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query,EpcNotificationTemplate.class).getResultList();
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcNotificationTemplateRepositoryCustom#modifyNotifications(com.wipro.epc.domain.EpcNotificationTemplate)
	 */
	@Override
	public EpcNotificationTemplate modifyNotifications (EpcNotificationTemplate notification) {
		StringBuilder queryBuilder = new StringBuilder("update epc_notification_template set notification_template_id="+notification.getNotificationTemplateId());
		if (notification.getTemplateType()!=null && !notification.getTemplateType().isEmpty()){
			queryBuilder.append(",").append("template_type = '").append(notification.getTemplateType()).append("'");
		}
		if (notification.getSourceSystem()!=null && !notification.getSourceSystem().isEmpty()) {
			queryBuilder.append(",").append("source_system ='").append(notification.getSourceSystem()).append("'");
		}
		if (notification.getModeOfDelivery()!=null && !notification.getSourceSystem().isEmpty()) {
			queryBuilder.append(",").append("mode_of_delivery ='").append(notification.getModeOfDelivery()).append("'");
		}
		if (notification.getTemplateName()!=null ){
			queryBuilder.append(",").append("template_name ='").append(notification.getTemplateName()).append("'");
		}
		if (notification.getStatus()!=null && !notification.getStatus().isEmpty()){
			queryBuilder.append(",").append("status ='").append(notification.getStatus()).append("'");
		}
		if (notification.getModifiedBy()!=null  ){
			queryBuilder.append(",").append("modified_by='").append(notification.getModifiedBy()).append("'");
		}
		if (notification.getModifiedDate()!=null  ) {
			queryBuilder.append(",").append("modified_date='").append(convert.getDateInFormat(new Date(),"yyyy-MM-dd kk:mm:ss")).append("'");
		}
		
		queryBuilder.append(" where notification_template_id =").append(notification.getNotificationTemplateId());
		String query = queryBuilder.toString();
		em.createNativeQuery(query).executeUpdate();
		logger.debug("#Query: "+query);
		//System.out.println(query);
		return notification;
	}

	/**
	 * @return
	 */
	public EntityManager getEm() {
		return em;
	}

	/**
	 * @param em
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}

	/**
	 * @return
	 */
	public SimpleDateConvertion getConvert() {
		return convert;
	}

	/**
	 * @param convert
	 */
	public void setConvert(SimpleDateConvertion convert) {
		this.convert = convert;
	}
}
