package com.wipro.epc.repositories;

import java.util.List;


import com.wipro.epc.domain.EpcProductHeirarchy;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductHeirarchyRepositoryCustom
 */
public interface EpcProductHeirarchyRepositoryCustom {
	
	/**
	 * @param query
	 * @return
	 */
	List<EpcProductHeirarchy> getEpcProductHeirarchyList(String query);
	
	/**
	 * @param heirarchy
	 * @return
	 */
	EpcProductHeirarchy modifyProductHeirarchy(EpcProductHeirarchy heirarchy);

}
