package com.wipro.epc.repositories;


import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.wipro.epc.domain.EpcNotificationTemplateDetail;
import com.wipro.epc.util.EscapeSpecialCharacters;
import com.wipro.epc.util.SimpleDateConvertion;


/**
 * @author KE334465
 *
 */
public class EpcNotificationTemplateDetailRepositoryImpl implements EpcNotificationTemplateDetailRepositoryCustom {
	
	private static Logger logger =LoggerFactory.getLogger(EpcNotificationTemplateDetailRepositoryImpl.class);
	
	/**
	 * EntityManager EpcNotificationTemplateDetailRepositoryImpl.java
	 */
	@PersistenceContext
	private EntityManager em;
	
	/**
	 * SimpleDateConvertion EpcNotificationTemplateDetailRepositoryImpl.java
	 */
	@Autowired
	private SimpleDateConvertion convert;
	
	/**
	 * EscapeSpecialCharacters EpcNotificationTemplateDetailRepositoryImpl.java
	 */
	@Autowired
	private EscapeSpecialCharacters escapeSpecialChar;
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcNotificationTemplateDetailRepositoryCustom#modifyNotificationTemplateDetail(com.wipro.epc.domain.EpcNotificationTemplateDetail)
	 */
	@Override
	public EpcNotificationTemplateDetail modifyNotificationTemplateDetail(
			EpcNotificationTemplateDetail detail) {
		
		StringBuilder queryBuilder = new StringBuilder("update epc_notification_template_detail set notification_template_detail_id="+detail.getNotificationTemplateDetailId());	
		if (detail.getTemplateLanguage()!=null ) {
			queryBuilder.append(",").append("template_language='").append(detail.getTemplateLanguage()).append("'");
		}
		if (detail.getTemplateSubject()!=null  ) {
			queryBuilder.append(",").append("template_subject='").append(detail.getTemplateSubject()).append("'");
		}
		if (detail.getTemplateBody()!=null  ) {
			queryBuilder.append(",").append("template_body='").append(escapeSpecialChar.escapeMetaCharacters(detail.getTemplateBody())).append("'");
		}
		if (detail.getModifiedBy()!=null  ) {
			queryBuilder.append(",").append("modified_by='").append(detail.getModifiedBy()).append("'");
		}
		if (detail.getModifiedDate()!=null  ) {
			queryBuilder.append(",").append("modified_date='").append(convert.getDateInFormat(new Date(),"yyyy-MM-dd kk:mm:ss")).append("'");
		}
		
		queryBuilder.append(" where notification_template_detail_id =").append(detail.getNotificationTemplateDetailId());
		String query = queryBuilder.toString();
		//System.out.println(query);
		logger.debug("#Query: "+query);
		em.createNativeQuery(query).executeUpdate();
		return detail;	
		}

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcNotificationTemplateDetailRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<EpcNotificationTemplateDetail> getList(String query) {
		// TODO Auto-generated method stub
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query,EpcNotificationTemplateDetail.class).getResultList();
	}

	/**
	 * @return
	 */
	public EntityManager getEm() {
		return em;
	}

	/**
	 * @param em
	 */
	public void setEm(EntityManager em) {
		this.em = em;
	}

	/**
	 * @return
	 */
	public SimpleDateConvertion getConvert() {
		return convert;
	}

	/**
	 * @param convert
	 */
	public void setConvert(SimpleDateConvertion convert) {
		this.convert = convert;
	}

	/**
	 * @return
	 */
	public EscapeSpecialCharacters getEscapeSpecialChar() {
		return escapeSpecialChar;
	}

	/**
	 * @param escapeSpecialChar
	 */
	public void setEscapeSpecialChar(EscapeSpecialCharacters escapeSpecialChar) {
		this.escapeSpecialChar = escapeSpecialChar;
	}
	}

