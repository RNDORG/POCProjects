package com.wipro.epc.domain;



import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonFormat;



import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the epc_activity_charge database table containing the details about 
 * activity charges as per order type (New, Change, Terminate), 
 * order sub type (Change IMSI, Migration, Change Bill Cycle etc.). 
 * @author VI251443
 * @version 1.0
 * 
 */
@Entity
@Table(name="epc_activity_charge")
public class EpcActivityCharge   implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3251068917226372493L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="activity_charge_id")
	private Integer activityChargeId;

	@Column(name="activity_channel_rule_id")
	private Integer activityChannelRuleId;
	
	@Column(name="activity_charge_fee")
	private BigDecimal activityChargeFee;

    @JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date createdDate;

    @JsonIgnore
	@Column(name="created_by")
	private String createdBy;

    @JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date modifiedDate;

	@Column(name="occ_code")
	private String occCode;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String occCodeValue;*/

	@Column(name="status")
	private String status;
	
	/*@Transient
	@JsonSerialize(using = LookupValueSerializer.class)
	private String statusValue;*/
	

	public EpcActivityCharge() {
	}

	public Integer getActivityChargeId() {
		return this.activityChargeId;
	}

	public void setActivityChargeId(Integer activityChargeId) {
		this.activityChargeId = activityChargeId;
	}

	public BigDecimal getActivityChargeFee() {
		return this.activityChargeFee;
	}

	public void setActivityChargeFee(BigDecimal activityChargeFee) {
		this.activityChargeFee = activityChargeFee;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getOccCode() {
		return this.occCode;
	}

	public void setOccCode(String occCode) {
		this.occCode = occCode;
	}

	/*@Transient
	public String getOccCodeValue() {
		this.occCodeValue = occCode;
		return occCodeValue;
	}

	public void setOccCodeValue(String occCodeValue) {
		this.occCodeValue = occCodeValue;
	}*/
	
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public Integer getActivityChannelRuleId() {
		return activityChannelRuleId;
	}

	public void setActivityChannelRuleId(Integer activityChannelRuleId) {
		this.activityChannelRuleId = activityChannelRuleId;
	}

	/*public String getStatusValue() {
		this.statusValue = status;
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}*/
	
	
}