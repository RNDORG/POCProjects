package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductMigration;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.ComplexSearchInputForMigration;
import com.wipro.epc.dto.OptimizedInitChannel;
import com.wipro.epc.dto.OptimizedProductAttribute;
import com.wipro.epc.repositories.EpcProductCommunityRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.util.Constants;
import com.wipro.epc.util.EPCUtils;



/**
 * @author Developer
 * @version 1.0
 * type MigrationProductQueryService
 */
@Service
public class MigrationProductQueryService {
	
	/**
	 * ComplexSearchInputService MigrationProductQueryService.java
	 */
	@Autowired
	ComplexSearchInputService complexQuery;
	/**
	 * EpcProductSpecificationRepository MigrationProductQueryService.java
	 */
	@Autowired
	EpcProductSpecificationRepository specRepo;
	
	@Autowired
	EpcProductCommunityRepository epcProductCommunityRepository;
	
	/**
	 * Logger MigrationProductQueryService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(MigrationProductQueryService.class);
	
	/**
	 * @param searchInputforMigration
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductSpecification> migrationProductQueryResult(ComplexSearchInputForMigration searchInputforMigration,Map<String, List<String>> allRequestParams){
		
		if(StringUtils.isBlank(searchInputforMigration.getProductType()) || StringUtils.isBlank(searchInputforMigration.getProductCategory()) || StringUtils.isBlank(searchInputforMigration.getProductSubCategory()) 
				|| StringUtils.isBlank(searchInputforMigration.getInitiatingChannel()) || StringUtils.isBlank(searchInputforMigration.getProviderProductId()) || StringUtils.isBlank(searchInputforMigration.getProviderSystemCode())
				|| StringUtils.isBlank(searchInputforMigration.getTargetProductCategory()) || StringUtils.isBlank(searchInputforMigration.getTargetProductSubCategory())){
			throw new GenericException("InvalidSearch", "Mandatory Fields are missing. Please provide all mandatory fields (productType, productSubcategory,productSubCategory,"
					+ " initiatingChannel, providerProductId, providerSystemCode, targetProductCategory, targetProductSubCategory)", "Mandatory Fields are missing.");
		}
		
		List<String> with = allRequestParams.get("with");
		
		List<String> supportedWith = Arrays.asList(new String []{"initiatingChannel"});
		if(with != null && !with.isEmpty()){
			for(String str : with){
				if(!supportedWith.contains(str)){
					if(!(str.contains("ta-") || str.contains("nta-") ) ){
						throw new GenericException("UnsupportedWith", "Unsupported with parameter ("+ str +") provided.", "Unsupported with parameter ("+ str +") provided.");
					}
				}
			}
		}
		Map<String, List<String>> requestParams = new HashMap<String, List<String>>();
		requestParams.put("with", Arrays.asList("migration"));
		List<EpcProductSpecification> responseProducts = complexQuery.searchComplex(searchInputforMigration, requestParams, true, true);
		
		if(responseProducts==null || responseProducts.isEmpty())// || !Constants.PRODUCT_STATUS_LAUNCH.equals(responseProducts.get(0).getProductStatus())
			throw new GenericException("NoResultFound","No Product Found","Please refine Criteria");
		
		if(responseProducts.size()!=1)
			throw new GenericException("DuplicateProduct","For same providerProductId and providerSystemCode mulitple Products found.","Please contact Admin");
		
		String initChannel = searchInputforMigration.getInitiatingChannel().equals(Constants.INITCHANNEL_CRM) ? Constants.INITCHANNEL_CRM : Constants.INITCHANNEL_OMNI;
		logger.info( "will be checked with CRM or OMNI? "+initChannel );
		//for(EpcProductSpecification specBean : responseProducts){
		
		EpcProductSpecification specBean = responseProducts.get(0);
		
		if(specBean.getEpcProductMigration()!=null && !specBean.getEpcProductMigration().isEmpty()){
			
		/*	List<String> targetProductids = new ArrayList<String>();
			List<String> filteredTargetProductids = new ArrayList<String>();
			for(EpcProductMigration migr : specBean.getEpcProductMigration()){
				if(Constants.PRODUCT_STATUS_LAUNCH.equalsIgnoreCase(migr.getTargetProductSpec().getProductStatus()) && EPCUtils.validateCategory(migr.getTargetCategory(),searchInputforMigration.getTargetProductCategory())){
					targetProductids.add(""+migr.getTargetProductId());
				}
				
			}
			logger.info("Migration target product ids are "+String.join(", ", targetProductids));
			
			if(targetProductids!=null && !targetProductids.isEmpty())
				filteredTargetProductids = specRepo.needsToBeFilteredForMigration(targetProductids, searchInputforMigration.getTargetProductSubCategory(), searchInputforMigration.getTargetCommunityId());
			
			//if(targetProductids!=null && (targetProductids.size()!=filteredTargetProductids.size())){
				logger.debug("Target products are "+ targetProductids+"\n Filtered products are "+ filteredTargetProductids);*/
			Iterator<EpcProductMigration> iter = specBean.getEpcProductMigration().iterator();
			List<EpcProductCommunity> communities = null;
			Byte isEmpAllowedToPurchase = null;
			if(StringUtils.isNotBlank(searchInputforMigration.getTargetCommunityId())) {
				communities = epcProductCommunityRepository.findEpcProductCommunityByCommunityId(searchInputforMigration.getTargetCommunityId());
				if(communities != null && !communities.isEmpty()) {
					isEmpAllowedToPurchase = communities.get(0).getIsEmployeeAllowedToPurchase();
				}
			}
			while(iter.hasNext()) {
				EpcProductMigration migrationBean = iter.next();
				
				//checking  target product category & status
				if(!(EPCUtils.validateCategory(migrationBean.getTargetCategory(),searchInputforMigration.getTargetProductCategory())) 
						|| !Constants.PRODUCT_STATUS_LAUNCH.equalsIgnoreCase(migrationBean.getTargetProductSpec().getProductStatus())) {
					logger.debug("Removing migration data as "+migrationBean.getTargetCategory()+" with target product status "+migrationBean.getTargetProductSpec().getProductStatus()
							+" not required for target category "+searchInputforMigration.getTargetProductCategory());
					iter.remove();
				}
				
				
				else if (/*!filteredTargetProductids.contains(migrationBean.getTargetProductId()) || */
						(migrationBean.getMigrationChannel()!=null && !migrationBean.getMigrationChannel().equalsIgnoreCase(initChannel)) 
						|| migrationBean.getMigrationChannel()==null) {
					logger.debug("Filtering migration channel "+migrationBean.getMigrationChannel()+ "  with "+initChannel);
					iter.remove();
				}
				
				else if(StringUtils.isNotBlank(searchInputforMigration.getTargetCommunityId())) {
					if(Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(searchInputforMigration.getTargetProductSubCategory())
							|| Constants.PRODUCT_SUB_CATEGORY_ALL.equals(searchInputforMigration.getTargetProductSubCategory()))	{
						if (EPCUtils.validateSubCategory(migrationBean.getTargetProductSpec().getProductSubCategory(),searchInputforMigration.getTargetProductSubCategory())) {
							if (isEmpAllowedToPurchase != null
									&& isEmpAllowedToPurchase == 1) {
								if (!(migrationBean.getTargetProductSpec()
										.getIsCorporateSpecific() != null && migrationBean
										.getTargetProductSpec()
										.getIsCorporateSpecific() == 1)) {
									//do nothing
									continue;
								}
							}
							if (communities != null && !communities.isEmpty()) {
								for (EpcProductCommunity community : communities) {
									if (migrationBean.getTargetProductSpec()
											.getProductId()
											.equals(community.getProductId())) {
										//do nothing
										continue;
									}
								}
							}
							iter.remove();
						}else {
							iter.remove();
						}
					}else {
						throw new GenericException("WrongInputCombination","Target product sub-category and communityId contradictory.","Please correct Inputs");
					}
					
					
				}else {
					if(!EPCUtils.validateSubCategory(migrationBean.getTargetProductSpec().getProductSubCategory(),searchInputforMigration.getTargetProductSubCategory())) {
						iter.remove();
					}
				}
				
				
				
				
/*				
				//target sub-category &  target community id
				else if(StringUtils.isNotBlank(searchInputforMigration.getTargetCommunityId()) && !()) {
					logger.debug("Removing migration data as targetCommunitId is not null but, subCategory not Corporate or All");
					iter.remove();
					}
				else if(StringUtils.isNotBlank(searchInputforMigration.getTargetCommunityId()) && (Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equalsIgnoreCase(searchInputforMigration.getTargetProductSubCategory())
						|| Constants.PRODUCT_SUB_CATEGORY_ALL.equalsIgnoreCase(searchInputforMigration.getTargetProductSubCategory())) && ) {
					
				}
			*/
				
			
							
			}
			}
			
		//}
		List<String> targetProds = new ArrayList<String>();
		for(EpcProductMigration migrationBean : specBean.getEpcProductMigration()){
			targetProds.add(String.valueOf(migrationBean.getTargetProductId()));
		}
		
		if (!targetProds.isEmpty()) {
			allRequestParams.put("productId", targetProds);
			List<EpcProductSpecification> tgtPrds = complexQuery
					.searchProducts(allRequestParams, null, true);
			Map<String, Object> objs = null;
			List<OptimizedInitChannel> initChannels = null;
			List<OptimizedProductAttribute> characteristics = null;
			List<OptimizedProductAttribute> tariffs = null;
			for (EpcProductSpecification prod : tgtPrds) {
				objs = new HashMap<String, Object>();
				initChannels = new ArrayList<OptimizedInitChannel>();
				characteristics = new ArrayList<OptimizedProductAttribute>();
				tariffs = new ArrayList<OptimizedProductAttribute>();
				if (prod.getEpcProductInitChannel() != null
						&& !prod.getEpcProductInitChannel().isEmpty()) {
					OptimizedInitChannel chnl = null;
					for (EpcProductInitChannel channel : prod
							.getEpcProductInitChannel()) {
						if (channel.getChannelId().equals(
								searchInputforMigration.getInitiatingChannel())
								&& channel
										.getActionType()
										.equalsIgnoreCase(
												Constants.ACTION_TYPE_MIGRATION_OR_MODIFICATION)) {
							chnl = new OptimizedInitChannel();
							BeanUtils.copyProperties(channel, chnl);
							initChannels.add(chnl);
						}
					}
					if (!initChannels.isEmpty()) {
						objs.put("productInitChannels", initChannels);
					}
					prod.setEpcProductInitChannel(null);
				}
				if (prod.getEpcProductCharacteristic() != null
						&& !prod.getEpcProductCharacteristic().isEmpty()) {
					OptimizedProductAttribute character = null;
					for (EpcProductAttribute chr : prod
							.getEpcProductCharacteristic()) {
						character = new OptimizedProductAttribute();
						BeanUtils.copyProperties(chr, character);
						character.setAttributeName(chr.getEpcAttributeMaster()
								.getAttributeName());
						characteristics.add(character);
					}
					if (!characteristics.isEmpty()) {
						objs.put("productCharacteristics", characteristics);
					}
					prod.setEpcProductCharacteristic(null);
				}
				if (prod.getEpcProductTariff() != null
						&& !prod.getEpcProductTariff().isEmpty()) {
					OptimizedProductAttribute character = null;
					for (EpcProductAttribute chr : prod.getEpcProductTariff()) {
						character = new OptimizedProductAttribute();
						BeanUtils.copyProperties(chr, character);
						character.setAttributeName(chr.getEpcAttributeMaster()
								.getAttributeName());
						tariffs.add(character);
					}
					if (!tariffs.isEmpty()) {
						objs.put("productTariffs", tariffs);
					}
					prod.setEpcProductTariff(null);
				}
				if (!objs.isEmpty()) {
					prod.setExtension(objs);
				}

				for (EpcProductMigration migrationBean : specBean
						.getEpcProductMigration()) {
					if (migrationBean.getTargetProductId().equals(
							prod.getProductId())) {
						migrationBean.setTargetProductSpec(prod);
					}
				}
			}
		}
		return responseProducts;
		
	}
	
}
