package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.repositories.CachedProductDetailsRepository;
import com.wipro.epc.util.BytesUtil;

@Service
public class CachedProductDisplayService {

	private static Logger logger =LoggerFactory.getLogger(CachedProductDisplayService.class);

	@Autowired
	PCachedProductService pCachedProductService;
	
	@Autowired
	CachedProductDetailsRepository cachedProductRepository;
	
	
	public List<EpcProductSpecification> DisplayList(String[] ids){
		List<EpcProductSpecification> prods = new ArrayList<EpcProductSpecification>();
	
		for(String id:ids){
			
			try {
				
				if(pCachedProductService.get(id) != null){
					EpcProductSpecification prodSpec = (EpcProductSpecification)BytesUtil.toObject( pCachedProductService.get(id).getValue() );
					prods.add(prodSpec);
				}
				
			} catch (Exception e) {// | ClassNotFoundException | IOException
				logger.error("#Exception in reloadLocal() : "+ e.getMessage());
			}
			
		}
		return prods;
	}
	
	public String cachedProductInfo(){
		
		List<Integer> ids=cachedProductRepository.getIds();
		int count=ids.size();
		
		return "Count= "+count+" \n Ids =  "+ids.toString();
	
		
	}
	
}