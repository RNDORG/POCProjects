package com.wipro.epc.repositories;

import java.util.List;

import com.wipro.epc.domain.EpcProductInitChannel;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductInitChannelRepositoryCustom
 */
public interface EpcProductInitChannelRepositoryCustom {
	
	/**
	 * @param query
	 * @return
	 */
	List<EpcProductInitChannel> getList(String query);
	/**
	 * @param channel
	 * @return
	 */
	EpcProductInitChannel modifyProductInitChannel(EpcProductInitChannel channel);

}
