package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.wipro.epc.domain.EpcProductSalesChannel;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductSalesChannelRepository
 */
public interface EpcProductSalesChannelRepository extends CrudRepository<EpcProductSalesChannel, Integer>, 
 EpcProductSalesChannelRepositoryCustom{

	/**
	 * @param productId
	 * @return
	 */
	@Query(value="select * from epc_product_sales_channel where product_id=:productId", nativeQuery = true)
	List<EpcProductSalesChannel> findChannelsByProductId(@Param("productId") Integer productId);
	
	/**
	 * @param productId
	 */
	@Modifying
	@Query(value="delete from epc_product_sales_channel where product_id=:productId", nativeQuery=true)
	void deleteProductFromChannel(@Param("productId") Integer productId);
}
