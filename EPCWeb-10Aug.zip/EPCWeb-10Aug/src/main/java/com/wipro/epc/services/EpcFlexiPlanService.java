/**
 * EPC Application - EpcFlexiPlanService.java
 */
package com.wipro.epc.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.wipro.common.config.service.ConfigService;
import com.wipro.common.gs.exception.GenericException;
import com.wipro.epc.domain.EpcFlexiPlan;
import com.wipro.epc.dto.FlexiPlanInput;
import com.wipro.epc.dto.FlexiPlanResponse;
import com.wipro.epc.repositories.EpcFlexiPlanRepository;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.util.Constants;

/**
 * @author Developer
 * @version 1.0
 * type EpcFlexiPlanService
 */
@Service
public class EpcFlexiPlanService {
	
	/**
	 * Logger EpcFlexiPlanService.java
	 */
	private static Logger logger= LoggerFactory.getLogger(EpcFlexiPlanService.class);

	/**
	 * EpcFlexiPlanRepository EpcFlexiPlanService.java
	 */
	@Autowired
	EpcFlexiPlanRepository flexRepo;
	
	/**
	 * ConfigService EpcFlexiPlanService.java
	 */
	@Autowired
	ConfigService config;
	
	@Autowired
	EpcProductProviderSystemService providerSysService;
	
	@Autowired
	EpcProductSpecificationRepository specRepo;
	
	private List<EpcFlexiPlan> epcFlexiPlanList=null;
	
	/**
	 * @param FlexiPlanInput input
	 * @return flexiPrice
	 */
	public BigDecimal flexiPlanPrice(FlexiPlanInput input) {
		
		if(StringUtils.isBlank(input.getDataUnit()) || input.getData()==null || StringUtils.isBlank(input.getVoiceType()) || input.getVoice()==null
				|| StringUtils.isBlank(input.getVoiceUnit()) || input.getSms() == null || input.getValidity()==null ){
			throw new GenericException("Mandatory Fields are missing", "Please validate all fields value.", "Mandatory Fields are missing.");
		}
		
		BigDecimal onnetMinutePriceRate=new BigDecimal(0);
		BigDecimal anynetMinutePriceRate=new BigDecimal(0);
		BigDecimal dataPriceRate=new BigDecimal(0);
		BigDecimal smsPriceRate=new BigDecimal(0);
		BigDecimal totalPrice=new BigDecimal(0);
		
		logger.debug("Checking input data unit");
		if(input.getDataUnit().equals(Constants.DATA_UNIT_MB)){
			input.setData(input.getData()*1);
			logger.debug("Data is getting converted after multiplying with 1 as: "+input.getData());
		}
		else if(input.getDataUnit().equals(Constants.DATA_UNIT_GB)){
			input.setData(input.getData()*1024);
			logger.debug("Data is getting converted after multiplying with 1024 as: "+input.getData());
		}
		else{
			throw new GenericException("Wrong Data Unit","Only Allowed Data Units are "+Constants.DATA_UNIT_MB+" and "+Constants.DATA_UNIT_GB,"Please provide correct data Unit");
		}
		
		logger.debug("Checking input voice unit");
		if(input.getVoiceUnit().equals(Constants.VOICE_UNIT_MINUTES)){
			input.setVoice(input.getVoice()*1);
			logger.debug("Voice is getting converted after multiplying with 1 as: "+input.getVoice());
		}
		else if(input.getVoiceUnit().equals(Constants.VOICE_UNIT_HOURS)){
			input.setVoice(input.getVoice()*60);
			logger.debug("Voice is getting converted after multiplying with 60 as: "+input.getVoice());
		}
		else{
			throw new GenericException("Wrong Voice Unit","Only Allowed Voice Units are "+Constants.VOICE_UNIT_MINUTES+" and "+Constants.VOICE_UNIT_HOURS,"Please provide correct Voice Unit");
		}
		
		logger.debug("Voice type check");
		if(input.getVoiceType().equalsIgnoreCase(Constants.VOICE_TYPE_ANYNET)){
			anynetMinutePriceRate= flexRepo.getFlexiPlanPriceRate(Constants.PLAN_ANYNETVOICE, input.getValidity(), input.getData(), input.getVoice(), 0, Constants.COMMON_STATUS_ACTIVE);
			if (anynetMinutePriceRate==null){
				throw new GenericException("No Valid Flexi Plan Found","No Valid Flexi Plan '"+Constants.PLAN_ANYNETVOICE+"' found for given input combination","Please provide valid data");
			}
			logger.info("Any Minute Voice price "+anynetMinutePriceRate.toString());
		}
		else if(input.getVoiceType().equalsIgnoreCase(Constants.VOICE_TYPE_ONNET)){
			onnetMinutePriceRate= flexRepo.getFlexiPlanPriceRate(Constants.PLAN_ONNETVOICE, input.getValidity(), input.getData(), input.getVoice(), 0, Constants.COMMON_STATUS_ACTIVE);
			if (onnetMinutePriceRate==null){
				throw new GenericException("No Valid Flexi Plan Found","No Valid Flexi Plan '"+Constants.PLAN_ONNETVOICE+"' found for given input combination","Please provide valid data");
			}
			logger.info("OnNet Minute Voice price "+onnetMinutePriceRate.toString());
		}
		else{
			throw new GenericException("Wrong Voice Type","Only Allowed Voice Type selections are "+Constants.VOICE_TYPE_ANYNET+" and "+Constants.VOICE_TYPE_ONNET,"Please provide correct voice type");
		}
		
		dataPriceRate = flexRepo.getFlexiPlanPriceRate(Constants.PLAN_ONNETDATA, input.getValidity(), input.getData(), input.getVoice(), 0, Constants.COMMON_STATUS_ACTIVE);
		if (dataPriceRate==null){
			throw new GenericException("No Valid Flexi Plan Found","No Valid Flexi Plan '"+Constants.PLAN_ONNETDATA+"' found for given input combination","Please provide valid data");
		}
		logger.info("Data Price is "+dataPriceRate.toString());
		
		smsPriceRate = flexRepo.getFlexiPlanPriceRate(Constants.PLAN_SMS, input.getValidity(), 0, 0, input.getSms(), Constants.COMMON_STATUS_ACTIVE);
		if (smsPriceRate==null){
			throw new GenericException("No Valid Flexi Plan Found","No Valid Flexi Plan '"+Constants.PLAN_SMS+"' found for given input combination","Please provide valid data");
		}
		logger.info("SMS Price is "+smsPriceRate.toString());
		
		/*String onNetPriceRate = config.searchConfigKey("Price Rate", "OnNet").getConfigValue();
		if (onNetPriceRate==null){
			throw new GenericException("No Valid Price Rate Found","Not Retrieved 'OnNet' Price Rate","Please configure valid price rate");
		}
		
		String anyNetPriceRate = config.searchConfigKey("Price Rate", "AnyNet").getConfigValue();
		if (anyNetPriceRate==null){
			throw new GenericException("No Valid Price Rate Found","Not Retrieved 'AnyNet' Price Rate","Please configure valid price rate");
		}
		
		String dataPriceRate = config.searchConfigKey("Price Rate", "Data").getConfigValue();
		if (dataPriceRate==null){
			throw new GenericException("No Valid Price Rate Found","Not Retrieved 'Data' Price Rate","Please configure valid price rate");
		}
		
		String smsPriceRate = config.searchConfigKey("Price Rate", "SMS").getConfigValue();
		if (smsPriceRate==null){
			throw new GenericException("No Valid Price Rate Found","Not Retrieved 'SMS' Price Rate","Please configure valid price rate");
		}*/
		
		totalPrice = (onnetMinutePriceRate.multiply(new BigDecimal(input.getVoice()))).add(anynetMinutePriceRate.multiply(new BigDecimal(input.getVoice())))
				.add(dataPriceRate.multiply(new BigDecimal(input.getData()))).add(smsPriceRate.multiply(new BigDecimal(input.getSms())));
		logger.info("Total Price is "+ totalPrice.toString());
		
		String taxRate = config.searchConfigKey("Price Rate", "Tax").getConfigValue();
		if (taxRate==null){
			throw new GenericException("No Valid Price Rate Found","Not Retrieved 'Tax' Price Rate","Please configure valid price rate");
		}
		
		return totalPrice.multiply(new BigDecimal(taxRate));
	}
	
	public FlexiPlanResponse flexiPlanPriceCached(FlexiPlanInput input) {
		if(StringUtils.isBlank(input.getDataUnit()) || input.getData()==null || StringUtils.isBlank(input.getVoiceType()) || input.getVoice()==null
				|| StringUtils.isBlank(input.getVoiceUnit()) || input.getSms() == null || input.getValidity()==null){
			throw new GenericException("Mandatory Fields are missing", "Please validate all fields value.", "Mandatory Fields are missing.");
		}
		BigDecimal onnetMinutePriceRate=new BigDecimal(0);
		BigDecimal anynetMinutePriceRate=new BigDecimal(0);
		BigDecimal onnetDataPriceRate=new BigDecimal(0);
		BigDecimal anynetDataPriceRate=new BigDecimal(0);
		BigDecimal smsPriceRate=new BigDecimal(0);
		BigDecimal totalPrice=new BigDecimal(0);
		
		BigDecimal marketOnnetMinutePrice=new BigDecimal(0);
		BigDecimal marketAnynetMinutePrice=new BigDecimal(0);
		BigDecimal onnetMarketDataPrice=new BigDecimal(0);
		BigDecimal anynetMarketDataPrice=new BigDecimal(0);
		BigDecimal marketSmsPrice=new BigDecimal(0);
		BigDecimal totalMarketPrice=new BigDecimal(0);
		
		
		logger.debug("Checking validity input");
		String validityOptions= config.searchConfigKey("ext_api", "flexi_validity").getConfigValue();
		String validity = validityOptions == null? Constants.VALIDITY_OPTIONS : validityOptions.replaceAll(",", "|");
		if(!input.getValidity().toString().matches(validity) ) {
			throw new GenericException("Wrong Validity Input","Only one of "+validityOptions+" validity days are Allowed.","Please provide correct validity");		
		}
		
		logger.debug("Checking input data unit");
		if(input.getDataUnit().equals(Constants.DATA_UNIT_MB)){
			input.setData(input.getData()*1);
			logger.debug("Data is getting converted after multiplying with 1 as: "+input.getData());
		}
		else if(input.getDataUnit().equals(Constants.DATA_UNIT_GB)){
			input.setData(input.getData()*1024);
			logger.debug("Data is getting converted after multiplying with 1024 as: "+input.getData());
		}
		else{
			throw new GenericException("Wrong Data Unit","Only Allowed Data Units are "+Constants.DATA_UNIT_MB+" and "+Constants.DATA_UNIT_GB,"Please provide correct data Unit");
		}
		
		logger.debug("Checking input voice unit");
		if(input.getVoiceUnit().equals(Constants.VOICE_UNIT_MINUTES)){
			input.setVoice(input.getVoice()*1);
			logger.debug("Voice is getting converted after multiplying with 1 as: "+input.getVoice());
		}
		else if(input.getVoiceUnit().equals(Constants.VOICE_UNIT_HOURS)){
			input.setVoice(input.getVoice()*60);
			logger.debug("Voice is getting converted after multiplying with 60 as: "+input.getVoice());
		}
		else{
			throw new GenericException("Wrong Voice Unit","Only Allowed Voice Units are "+Constants.VOICE_UNIT_MINUTES+" and "+Constants.VOICE_UNIT_HOURS,"Please provide correct Voice Unit");
		}
		if (epcFlexiPlanList==null)
		{
			loadFlexiPlanList();
		}
		/*
		Integer productId= null;
		String[] ids = input.getCustomerRatePlanId().split(":");
		if(ids.length==2) {			
			productId = providerSysService.getAddOnIdCached(ids[1], ids[0]);
			logger.info("For channeRatePlanId found product id "+productId);
		}
		else {
			throw new GenericException("Wrong CustomerRatePlanId","Provided CustomerRatePlanId "+input.getCustomerRatePlanId()+" is not in valid format","Please provide correct CustomerRatePlanId");
		}
		if(productId==null) {
			throw new GenericException("No Valid CustomerRatePlanId","No mapping found for provided CustomerRatePlanId","Please provide valid CustomerRatePlanId");
		}
		*/
		
		for (int i = 0; i < epcFlexiPlanList.size(); i++) 
		{
				EpcFlexiPlan plan= epcFlexiPlanList.get(i);
				if(input.getVoiceType().equalsIgnoreCase(Constants.VOICE_TYPE_ANYNET))
				{
						if(respectivePlanDataFound(plan,Constants.PLAN_ANYNETVOICE,input.getValidity(),input.getData(),input.getVoice(), 0) )
						{
							if (anynetMinutePriceRate.compareTo(BigDecimal.ZERO) == 0){
							anynetMinutePriceRate=plan.getPrice();	
							marketAnynetMinutePrice=plan.getMarketPrice()==null ? BigDecimal.ZERO :  plan.getMarketPrice().multiply(new BigDecimal(input.getVoice()));
							logger.info("anynetMinutePriceRate-------"+anynetMinutePriceRate + " Market anynetMinutePrice -------"+marketAnynetMinutePrice);}
						}
						
						/*//Market AnnNet Voice Price
						if(respectivePlanDataFound(plan,Constants.MARKET_PLAN_ANYNETVOICE,input.getValidity(),input.getData(),input.getVoice(), 0) )
						{
							if (marketAnynetMinutePrice.compareTo(BigDecimal.ZERO) == 0){
								marketAnynetMinutePrice=plan.getPrice().multiply(new BigDecimal(input.getVoice()));
							
							logger.info("Market anynetMinutePrice -------"+marketAnynetMinutePrice);}
						}
						*/
						//Data anyNet
						if(respectivePlanDataFound(plan,Constants.PLAN_ANYNETDATA,input.getValidity(),input.getData(),input.getVoice(), 0))
					    {
							if (anynetDataPriceRate.compareTo(BigDecimal.ZERO) == 0){
					    	anynetDataPriceRate=plan.getPrice();
					    	anynetMarketDataPrice=plan.getMarketPrice()==null ? BigDecimal.ZERO :  plan.getMarketPrice().multiply(new BigDecimal(input.getData()));
					    	
					    	logger.info("Anynet dataPriceRate---------------"+anynetDataPriceRate+" Market Anynet dataPrice -------"+anynetMarketDataPrice);}
					    }
						
						 //Market Data Price
					/*	if(respectivePlanDataFound(plan,Constants.MARKET_PLAN_ANYNETDATA,input.getValidity(),input.getData(),input.getVoice(), 0) )
						{
							if (anynetMarketDataPrice.compareTo(BigDecimal.ZERO) == 0){
								anynetMarketDataPrice=plan.getPrice().multiply(new BigDecimal(input.getData()));
							
							logger.info("Market Anynet dataPrice -------"+anynetMarketDataPrice);}
						}
						*/
						
			    }
				else if(input.getVoiceType().equalsIgnoreCase(Constants.VOICE_TYPE_ONNET))
				{
					    if(respectivePlanDataFound(plan,Constants.PLAN_ONNETVOICE,input.getValidity(),input.getData(),input.getVoice(), 0))
					    {
					    	if (onnetMinutePriceRate.compareTo(BigDecimal.ZERO) == 0){
					    	onnetMinutePriceRate=plan.getPrice();	
					    	marketOnnetMinutePrice=plan.getMarketPrice()==null ? BigDecimal.ZERO :  plan.getMarketPrice().multiply(new BigDecimal(input.getVoice()));
					    	logger.info("onnetMinutePriceRate--------"+onnetMinutePriceRate + " Market onnetMinutePrice -------"+marketOnnetMinutePrice);}
					    }
					    
					  /*//Market Onnet Voice Price
						if(respectivePlanDataFound(plan,Constants.MARKET_PLAN_ONNETVOICE,input.getValidity(),input.getData(),input.getVoice(), 0) )
						{
							if (marketOnnetMinutePrice.compareTo(BigDecimal.ZERO) == 0){
								marketOnnetMinutePrice=plan.getPrice().multiply(new BigDecimal(input.getVoice()));
							
							logger.info("Market onnetMinutePrice -------"+marketOnnetMinutePrice);}
						}
						*/
						//Data on net
						if(respectivePlanDataFound(plan,Constants.PLAN_ONNETDATA,input.getValidity(),input.getData(),input.getVoice(), 0))
					    {
							if (onnetDataPriceRate.compareTo(BigDecimal.ZERO) == 0){
					    	onnetDataPriceRate=plan.getPrice();
					    	onnetMarketDataPrice=plan.getMarketPrice()==null ? BigDecimal.ZERO :  plan.getMarketPrice().multiply(new BigDecimal(input.getData()));
					    	
					    	logger.info(" onNet dataPriceRate---------------"+onnetDataPriceRate+" Market onNet dataPrice -------"+onnetMarketDataPrice);}
					    }
						
					/*	 //Market Data Price
						if(respectivePlanDataFound(plan,Constants.MARKET_PLAN_ONNETDATA,input.getValidity(),input.getData(),input.getVoice(), 0) )
						{
							if (onnetMarketDataPrice.compareTo(BigDecimal.ZERO) == 0){
								onnetMarketDataPrice=plan.getPrice().multiply(new BigDecimal(input.getData()));
							
							logger.info("Market onNet dataPrice -------"+onnetMarketDataPrice);}
						}*/
						
						
				}
				else
				{
					throw new GenericException("Wrong Voice Type","Only Allowed Voice Type selections are "+Constants.VOICE_TYPE_ANYNET+" and "+Constants.VOICE_TYPE_ONNET,"Please provide correct voice type");
				}
				
				
				

				if(respectivePlanDataFound(plan,Constants.PLAN_SMS,0,0,0,input.getSms()))
			    {
					if (smsPriceRate.compareTo(BigDecimal.ZERO) == 0){
					smsPriceRate=plan.getPrice();
					marketSmsPrice=plan.getMarketPrice()==null ? BigDecimal.ZERO :  plan.getMarketPrice().multiply(new BigDecimal(input.getSms()));
					
					logger.info(" smsPriceRate---------------"+smsPriceRate+" Market smsPrice -------"+marketSmsPrice);}
			    }
				
				/* //Market SMS Price
				if(respectivePlanDataFound(plan,Constants.MARKET_PLAN_SMS,0,0,0,input.getSms()) )
				{
					if (marketSmsPrice.compareTo(BigDecimal.ZERO) == 0){
						marketSmsPrice=plan.getPrice().multiply(new BigDecimal(input.getSms()));
					
					logger.info("Market smsPrice -------"+marketSmsPrice);}
				}*/
		}

		//
		
		if (input.getVoiceType().equalsIgnoreCase(Constants.VOICE_TYPE_ANYNET)){
			//invalid anynetMinutePriceRate check
			if(input.getVoice()!=0 && (anynetMinutePriceRate.compareTo(BigDecimal.ZERO)==0 || marketAnynetMinutePrice.compareTo(BigDecimal.ZERO)==0)){
				throw new GenericException("No Valid Flexi Plan Found","No Valid Flexi Plan / Market Plan '"+Constants.PLAN_ANYNETVOICE+"' found for given input combination","Please provide valid data");
			}
		/*	//invalid marketAnynetMinutePrice check
			if(marketAnynetMinutePrice.compareTo(BigDecimal.ZERO)==0){
				throw new GenericException("No Valid Market Plan Found","No Valid Market Plan '"+Constants.PLAN_ANYNETVOICE+"' found for given input combination","Please provide valid data");
			}*/
			//invalid anynetDataPriceRate check
			if (input.getData()!=0 && (anynetDataPriceRate.compareTo(BigDecimal.ZERO)==0 || anynetMarketDataPrice.compareTo(BigDecimal.ZERO)==0)){
				throw new GenericException("No Valid Flexi Plan Found","No Valid Flexi Plan / Market Plan '"+Constants.PLAN_ANYNETDATA+"' found for given input combination","Please provide valid data");
			}
			/*//invalid anynetMarketDataPrice check
			if (anynetMarketDataPrice.compareTo(BigDecimal.ZERO)==0){
				throw new GenericException("No Valid Market Plan Found","No Valid Market Plan '"+Constants.PLAN_ANYNETDATA+"' found for given input combination","Please provide valid data");
			}
				*/
	}
		
		
		if (input.getVoiceType().equalsIgnoreCase(Constants.VOICE_TYPE_ONNET) ) {
			//invalid onnetMinutePriceRate check
			if(input.getVoice()!=0 && (onnetMinutePriceRate.compareTo(BigDecimal.ZERO)==0 || marketOnnetMinutePrice.compareTo(BigDecimal.ZERO)==0)){		
				throw new GenericException("No Valid Flexi Plan Found","No Valid Flexi Plan / Market Plan '"+Constants.PLAN_ONNETVOICE+"' found for given input combination","Please provide valid data");
			}
		/*	//invalid marketOnnetMinutePrice check
			if (marketOnnetMinutePrice.compareTo(BigDecimal.ZERO)==0){
				throw new GenericException("No Valid Market Plan Found","No Valid Flexi Plan / Market Plan '"+Constants.PLAN_ONNETVOICE+"' found for given input combination","Please provide valid data");
			}*/
			//invalid onnetMinutePriceRate check
			if (input.getData()!=0 && (onnetDataPriceRate.compareTo(BigDecimal.ZERO)==0 || onnetMarketDataPrice.compareTo(BigDecimal.ZERO)==0)){
				throw new GenericException("No Valid Flexi Plan Found","No Valid Flexi Plan / Market Plan '"+Constants.PLAN_ONNETDATA+"' found for given input combination","Please provide valid data");
			}
		/*	//invalid onnetMarketDataPrice check
			if (onnetMarketDataPrice.compareTo(BigDecimal.ZERO)==0){
				throw new GenericException("No Valid Market Plan Found","No Valid Market Plan '"+Constants.PLAN_ONNETDATA+"' found for given input combination","Please provide valid data");
			}*/
				
		}
			
		
		
		if (input.getSms()!=0 && (smsPriceRate.compareTo(BigDecimal.ZERO)==0 ||  marketSmsPrice.compareTo(BigDecimal.ZERO)==0)){
			throw new GenericException("No Valid Flexi Plan Found","No Valid Flexi Plan / Market Plan '"+Constants.PLAN_SMS+"' found for given input combination","Please provide valid data");
		}
		/*if (input.getSms()!=0 && marketSmsPrice.compareTo(BigDecimal.ZERO)==0){
			throw new GenericException("No Valid Market Plan Found","No Valid Market Plan '"+Constants.PLAN_SMS+"' found for given input combination","Please provide valid data");
		}*/
		
		//
		totalPrice = (onnetMinutePriceRate.multiply(new BigDecimal(input.getVoice()))).add(anynetMinutePriceRate.multiply(new BigDecimal(input.getVoice())))
				.add(onnetDataPriceRate.multiply(new BigDecimal(input.getData()))).add(anynetDataPriceRate.multiply(new BigDecimal(input.getData()))).add(smsPriceRate.multiply(new BigDecimal(input.getSms())));
		logger.info("Total Price is "+ totalPrice.toString());
		
		totalMarketPrice = marketAnynetMinutePrice.add(marketOnnetMinutePrice).add(onnetMarketDataPrice).add(anynetMarketDataPrice).add(marketSmsPrice);
		logger.info("Total Market Price is "+ totalMarketPrice.toString());
		
		
		BigDecimal savingPercentage = new BigDecimal(0);
		savingPercentage=((totalMarketPrice.subtract(totalPrice)).divide(totalMarketPrice,RoundingMode.HALF_UP)).multiply(new BigDecimal(100));
		logger.info("Saving is "+ savingPercentage.toString()+"%");
		
		/*String productCategory = null;
		productCategory= specRepo.findByProductId(productId).get(0).getProductCategory();
		logger.info("Product category found "+ productCategory);
		*/
		
		
		
		//if(Constants.PRODUCT_CATEGORY_POSTPAID.equals(productCategory)) {
			
			
		//}
		//else {
			String taxRate = config.searchConfigKey("Price Rate", "Tax").getConfigValue();
				if (taxRate==null){
					throw new GenericException("No Valid Price Rate Found","Not Retrieved 'Tax' Price Rate","Please configure valid price rate");
				}
		
		FlexiPlanResponse resp = new FlexiPlanResponse();
		resp.setFlexiPrice((totalPrice).setScale(2, RoundingMode.HALF_UP));
		resp.setFlexiPriceWithTax((totalPrice.multiply(new BigDecimal(taxRate))).setScale(2, RoundingMode.HALF_UP));
		
		//}
		
		resp.setSavingPercentage(savingPercentage.setScale(2, RoundingMode.HALF_UP));
		resp.setStatus(Constants.RESPONSE_SUCCESS_STATUS);
		
		
		return resp;
	}
	
	public synchronized void loadFlexiPlanList()
	{
		epcFlexiPlanList=new ArrayList<EpcFlexiPlan>();
		epcFlexiPlanList=flexRepo.getFlexiPlanDetail();
		logger.info("length of the list is---"+epcFlexiPlanList.size());
		epcFlexiPlanList = epcFlexiPlanList;
	}

	public List<EpcFlexiPlan> getEpcFlexiPlanList() {
		return epcFlexiPlanList;
	}
	
	private boolean respectivePlanDataFound(EpcFlexiPlan planRow, String planType,Integer validity, Integer dataPack,
			Integer voicePack, Integer smsPack) {
		if(planRow.getFlexiPlanType().equals(planType)
	    		&& (validity.equals(planRow.getValidityInDays()))
	    		&&(dataPack.compareTo(planRow.getDataRangeStart())>=0)
	    		&&(dataPack.compareTo(planRow.getDataRangeEnd())<=0)
	    		&&(voicePack.compareTo(planRow.getVoiceRangeStart())>=0)
	    		&&(voicePack.compareTo(planRow.getVoiceRangeEnd())<=0)
	    		&&(smsPack.compareTo(planRow.getSmsRangeStart())>=0)
	    		&&(smsPack.compareTo(planRow.getSmsRangeEnd())<=0)
	    		&&(planRow.getStatus().equals(Constants.COMMON_STATUS_ACTIVE))) {
			return true;
		}
		else{return false;}
	}
	
	
}
