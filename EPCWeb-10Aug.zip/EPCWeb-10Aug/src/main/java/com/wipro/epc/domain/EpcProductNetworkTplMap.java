package com.wipro.epc.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the epc_product_network_tpl_map database table.
 * @author KE334465
 * @version 1.0
 */
@Entity
@Table(name="epc_product_network_tpl_map")
public class EpcProductNetworkTplMap  implements Serializable  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	@Transient
	private Map<String,String> metaInfo;	
	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="product_template_map_id")
	private Integer productTemplateMapId;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="product_id")
	private Integer productId;

	@Column(name="status")
	private String status;

/*	@Column(name="template_id")
	private String templateId;*/
	@Column(name="template_name")
	private String templateName;
	
	@Transient
	private List<EpcProductNetworkTpl> epcProductNetworkTpl; 
	
	/**
	 * 
	 */
	public EpcProductNetworkTplMap() {
	}

	
	
	/**
	 * @return
	 */
	public List<EpcProductNetworkTpl> getEpcProductNetworkTpl() {
		return epcProductNetworkTpl;
	}

	/**
	 * @param epcProductNetworkTpl
	 */
	public void setEpcProductNetworkTpl(
			List<EpcProductNetworkTpl> epcProductNetworkTpl) {
		this.epcProductNetworkTpl = epcProductNetworkTpl;
	}

	
	/**
	 * @return
	 */
	public Integer getProductTemplateMapId() {
		return this.productTemplateMapId;
	}

	/**
	 * @param productTemplateMapId
	 */
	public void setProductTemplateMapId(Integer productTemplateMapId) {
		this.productTemplateMapId = productTemplateMapId;
	}

	/**
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return
	 */
	public Integer getProductId() {
		return this.productId;
	}

	public Map<String, String> getMetaInfo() {
		
		if ( metaInfo == null ) {
			metaInfo = new HashMap<String,String>();
		}
		return metaInfo;
		
	}



	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}



	/**
	 * @param productId
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}



/*	public String getTemplateId() {
		return this.templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}*/

}