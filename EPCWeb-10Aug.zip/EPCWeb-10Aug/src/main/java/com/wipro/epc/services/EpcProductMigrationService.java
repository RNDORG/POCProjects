package com.wipro.epc.services;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductMigration;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductMigrationRepository;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductMigrationService
 */
@Service
public class EpcProductMigrationService {

	/**
	 * EpcProductMigrationRepository EpcProductMigrationService.java
	 */
	@Autowired
	EpcProductMigrationRepository epcProductMigrationRepository;
	
	/**
	 * EpcProductSpecificationService EpcProductMigrationService.java
	 */
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	
	@Autowired
	ComplexSearchInputService complexSearchInputService;
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductMigration> searchEpcProductMigration(
			Map<String, List<String>> allRequestParams) {
		
		if (allRequestParams.get("with") != null) {
			allRequestParams.remove("with");
		}

		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductMigration.class.getName(), null);
		List<EpcProductMigration> listOfEpcProductMigrationReturned = null;
		try {
			listOfEpcProductMigrationReturned = epcProductMigrationRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return listOfEpcProductMigrationReturned;
	}
	
	/**
	 * @param productMigrationList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductMigration> manageProductMigrations(List<EpcProductMigration> productMigrationList,
			String createdBy)
			{
				List<EpcProductMigration> retListOfEpcProductMigration=new ArrayList<EpcProductMigration>();
				
				for(EpcProductMigration productMigration:productMigrationList)
				{
					productMigration=manageproductMigration(productMigration,createdBy);
					if((productMigration.getMetaInfo().get("STATUS")==null))
					{
						productMigration.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
					}
				retListOfEpcProductMigration.add(productMigration);
			}
				if(retListOfEpcProductMigration != null){
					List<String> productIds = new ArrayList<String>();
					for (EpcProductMigration  epcProductMigration :retListOfEpcProductMigration){
						productIds.add(String.valueOf(epcProductMigration.getTargetProductId()));
					}
					Map<String, List<String>> allRequestParams = new HashMap<String, List<String>>();
					allRequestParams.put("productId", productIds);
					allRequestParams.put("with", Arrays.asList(new String [] {"provider"}));
					List<EpcProductSpecification> products = complexSearchInputService.searchProducts(allRequestParams,null,false);
					for (EpcProductMigration  epcProductMigrationDTO :retListOfEpcProductMigration){
						for(EpcProductSpecification product : products){
							if(product.getProductId() .equals( epcProductMigrationDTO.getTargetProductId())){
								epcProductMigrationDTO.setReservedMN(product.getProductMarketingName());
								epcProductMigrationDTO.setReservedSC(product.getProductShortCode());
								epcProductMigrationDTO.setReservedAL(product.getProductAssociationLevel());
								epcProductMigrationDTO.setReservedPPS(product.getPrimaryProviderSystem());
							}
						}
					}
				}
				
		     	return retListOfEpcProductMigration;
			}
	
	/**
	 * @param productMigration
	 * @param createdBy
	 * @return
	 */
	EpcProductMigration manageproductMigration(EpcProductMigration productMigration,
			String createdBy)
			{
			EpcProductMigration retproductMigration=null;
			
			switch(productMigration.getMetaInfo().get("OPERATION"))
			{
			case "CREATE":retproductMigration = createProductMigration(productMigration, createdBy);
						  break;
			case "UPDATE":retproductMigration = modifyProductMigration(productMigration, createdBy);
						  break;
			case "DELETE":retproductMigration = deleteProductMigration(productMigration);
						  break;
			default:
				throw new EPCException("not supported");
			}
			return retproductMigration;
			}
	
		/**
		 * @param productMigration
		 * @return
		 */
		EpcProductMigration deleteProductMigration(EpcProductMigration productMigration) {
			epcProductMigrationRepository.delete(productMigration.getProductMigrationId());
		return productMigration;
		}
		
		/**
		 * @param productMigration
		 * @param modifiedBy
		 * @return
		 */
		EpcProductMigration modifyProductMigration(EpcProductMigration productMigration, String modifiedBy) {
			productMigration.setModifiedBy(modifiedBy);
			productMigration.setModifiedDate(new Date());
		return epcProductMigrationRepository.modifyProductMigration(productMigration);
	    }

		/**
		 * @param productMigration
		 * @param createdBy
		 * @return
		 */
		EpcProductMigration createProductMigration(EpcProductMigration productMigration, String createdBy) {
			//logger.info("productMigration(in create Migration): "+productMigration);
			productMigration.setCreatedBy(createdBy);
			productMigration.setCreatedDate(new Date());
		epcProductMigrationRepository.save(productMigration);
		return productMigration;
	}
		
		/**
		 * @param query
		 * @return
		 */
		public List<EpcProductMigration> getEpcProductMigrationByQuery(String query) {
			List<EpcProductMigration> listOfEpcProductMigrationReturned = null;
			try {
				listOfEpcProductMigrationReturned = epcProductMigrationRepository.getList(query);
			} catch (Exception e) {
				throw new EPCException(
						"Error occurred while fetching results from database.\n"
								+ " Query: " + query + "\n"
								+ " Exception: " + e.getMessage(), e);
			}
			
			return listOfEpcProductMigrationReturned;
		}

	
}
