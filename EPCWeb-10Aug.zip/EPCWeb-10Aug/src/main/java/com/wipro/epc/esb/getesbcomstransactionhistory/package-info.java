@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.telenor.com.mm/GetESBCOMSTransactionHistory", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.wipro.epc.esb.getesbcomstransactionhistory;
