package com.wipro.epc.security.menu;

import java.util.List;

/**
 * @author Developer
 * @version 1.0
 * type UserDetailsForMenu
 */
public class UserDetailsForMenu {
	
	/**
	 * String UserDetailsForMenu.java
	 */
	private String userName;
	/**
	 * String UserDetailsForMenu.java
	 */
	private String role;
	/**
	 * List<String> UserDetailsForMenu.java
	 */
	private List<String> functions;
	/**
	 * Menu UserDetailsForMenu.java
	 */
	private Menu menuDetails;
	
	/**
	 * @return
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return
	 */
	public String getRole() {
		return role;
	}
	/**
	 * @param role
	 */
	public void setRole(String role) {
		this.role = role;
	}
	/**
	 * @return
	 */
	public List<String> getFunctions() {
		return functions;
	}
	/**
	 * @param functions
	 */
	public void setFunctions(List<String> functions) {
		this.functions = functions;
	}
	/**
	 * @return
	 */
	public Menu getMenuDetails() {
		return menuDetails;
	}
	/**
	 * @param menuDetails
	 */
	public void setMenuDetails(Menu menuDetails) {
		this.menuDetails = menuDetails;
	}
	
	
	

}
