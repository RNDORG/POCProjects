package com.wipro.epc.services;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.bind.JAXBException;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.config.service.ConfigService;
import com.wipro.epc.domain.EpcLookupMaster;
import com.wipro.epc.domain.EpcOrderChannelRule;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcProductAvailability;
import com.wipro.epc.domain.EpcProductCommunity;
import com.wipro.epc.domain.EpcProductCompatibility;
import com.wipro.epc.domain.EpcProductInitChannel;
import com.wipro.epc.domain.EpcProductLocation;
import com.wipro.epc.domain.EpcProductMigration;
import com.wipro.epc.domain.EpcProductProviderSystem;
import com.wipro.epc.domain.EpcProductSalesChannel;
import com.wipro.epc.domain.EpcProductSegment;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.CBIOResponse;
import com.wipro.epc.dto.ComplexSearchInput;
import com.wipro.epc.dto.QueryAvailabilityProductSpec;
import com.wipro.epc.dto.QueryAvailabilityResponse;
import com.wipro.epc.dto.QueryAvailabilitySearchInput;
import com.wipro.epc.esb.EsbRequestService;
import com.wipro.epc.ucip.AirRequestService;
import com.wipro.epc.util.Constants;
import com.wipro.epc.util.EPCUtils;


/**
 * @author Developer
 * @version 1.0
 * type ProductQueryAvailabilityService
 */
@Service
public class ProductQueryAvailabilityService {
	/**
	 * EpcLookupMasterService ProductQueryAvailabilityService.java
	 */
	@Autowired
	EpcLookupMasterService epcLookupMasterService;
	
	private static Logger logger = LoggerFactory.getLogger(ProductQueryAvailabilityService.class);
	/**
	 * EpcProductInitChannelService ProductQueryAvailabilityService.java
	 */
	@Autowired
	EpcProductInitChannelService epcProductInitChannelService;
	
	/**
	 * EpcProductAttributeService ProductQueryAvailabilityService.java
	 */
	@Autowired
	EpcProductAttributeService epcProductAttributeService;
	
	/**
	 * EpcLocationService ProductQueryAvailabilityService.java
	 */
	@Autowired
	EpcLocationService epcLocationService;
	
	/**
	 * EpcOrderChannelRuleService ProductQueryAvailabilityService.java
	 */
	@Autowired
	EpcOrderChannelRuleService epcOrderChannelRuleService;

	/**
	 * EpcAttributeMasterService ProductQueryAvailabilityService.java
	 */
	@Autowired
	EpcAttributeMasterService epcAttributeMasterService;
	
	/**
	 * ComplexSearchInputService ProductQueryAvailabilityService.java
	 */
	@Autowired
	ComplexSearchInputService complexSearchInputService;
	
	/**
	 * EpcProductCommunityService ProductQueryAvailabilityService.java
	 */
	@Autowired
	EpcProductCommunityService epcProductCommunityService;
	
	/**
	 * ConfigService ProductQueryAvailabilityService.java
	 */
	@Autowired
	ConfigService configService;
	
	/**
	 * EsbRequestService ProductQueryAvailabilityService.java
	 */
	@Autowired
	EsbRequestService esbRequestService;
	
	/**
	 * AirRequestService ProductQueryAvailabilityService.java
	 */
	@Autowired
	AirRequestService airRequestService;
	
	/**
	 * EpcProductProviderSystemService ProductQueryAvailabilityService.java
	 */
	@Autowired
	EpcProductProviderSystemService epcProductProviderSystemService;
	
	/**
	 * DateFormat ProductQueryAvailabilityService.java
	 */
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	
	/**
	 * ObjectMapper ProductQueryAvailabilityService.java
	 */
	@Autowired
	ObjectMapper mapper;
	
	/**
	 * EpcProductSpecificationService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductSpecificationService epcProductSpecificationService;
	
	/**
	 * EpcProductMigrationService ProductQueryEligibiltyService.java
	 */
	@Autowired
	EpcProductMigrationService epcProductMigrationService;
	
	/**
	 * @param searchInput
	 * @param allRequestParams
	 * @return
	 */
	@Transactional
	public QueryAvailabilityResponse queryAvailability(QueryAvailabilitySearchInput searchInput, Map<String, List<String>> allRequestParams)
	{
		
			QueryAvailabilityResponse queryAvailabilityResponse = new QueryAvailabilityResponse();
			if(StringUtils.isBlank(searchInput.getProductSubCategory()) 
				|| StringUtils.isBlank(searchInput.getInitiatingChannel()) || StringUtils.isBlank(searchInput.getStartDate())||(searchInput.getSubFamily() == null 
				|| (searchInput.getSubFamily() != null && searchInput.getSubFamily().size() ==0)) || (searchInput.getClassification() == null 
				|| (searchInput.getClassification() != null && searchInput.getClassification().isEmpty()))
				|| StringUtils.isBlank(searchInput.getCustomerRatePlanId()) || StringUtils.isBlank(searchInput.getSubscribedAddOnIds())){
				queryAvailabilityResponse.setRemarks("Mandatory Fields are missing. Please provide all mandatory fields (customerRatePlanId, subscribedAddOnIds, productSubCategory, initiatingChannel, startDate, classification, subFamily).");
				return queryAvailabilityResponse;
			}
			
			//Default values for the flags
			Boolean a2aCompatibilityFlag = false;
			Boolean nonNetworkVASCompatibilityFlag = false;
			Boolean roamingMigrationRuleFlag = false;
			
			if(searchInput.getA2aCompatibilityFlag() != null){
				a2aCompatibilityFlag = searchInput.getA2aCompatibilityFlag();
			}
			
			if(searchInput.getNonNetworkVASCompatibilityFlag() != null){
				nonNetworkVASCompatibilityFlag = searchInput.getNonNetworkVASCompatibilityFlag();
			}
			
			if(searchInput.getRoamingMigrationRuleFlag() != null){
				roamingMigrationRuleFlag = searchInput.getRoamingMigrationRuleFlag();
			}
			
			if( StringUtils.isNotBlank(searchInput.getSlabId()) && StringUtils.isBlank(searchInput.getCommunityId()) ){
				queryAvailabilityResponse.setRemarks("slabId cann't be provided without communityId.");
				return queryAvailabilityResponse;
			}
			
			
			List<String> supportedWith = Arrays.asList(new String []{"characteristic", "tariff", "provider", "initiatingChannel","all"});
			List<String> with = allRequestParams.get("with");
			if(with != null && !with.isEmpty()){
				for(String str : with){
					if(!supportedWith.contains(str)){
						if(!(str.contains("ta-") || str.contains("nta-") ) ){
							queryAvailabilityResponse.setRemarks("Unsupported with parameter ("+ str +") provided.");
							return queryAvailabilityResponse;
						}
					}
				}
			}
			List<String> classifications = searchInput.getClassification();
			List<String> subFamilies = searchInput.getSubFamily();
            
			Map<String, List<String>> requestParams = new HashMap<String, List<String>>();
			requestParams.put("lookupId", classifications);
			requestParams.put("lookupGroup", Arrays.asList("epc_product_specification"));	
			requestParams.put("lookupName", Arrays.asList("product_classification"));
			requestParams.put("parentLookupId", subFamilies);
			
			List<EpcLookupMaster> lookUps = epcLookupMasterService.searchLookUpMaster(requestParams);
			if(lookUps == null || (lookUps != null && lookUps.isEmpty())){
				queryAvailabilityResponse.setRemarks("Invalid classification is given in the request.");
				return queryAvailabilityResponse;
			}

			//logic for OCR check
			if(!StringUtils.isBlank(searchInput.getOrderType()) && !validateOrderChannelRule(searchInput.getOrderType(), searchInput.getInitiatingChannel(), searchInput.getSalesChannel())){
				queryAvailabilityResponse.setRemarks("Failed for Order Channel Rule check.");
				return queryAvailabilityResponse;
			}
			
			String nonNetworkVASClassifications  = configService.searchConfigKey("ext_api", "non_network_vas_classifications").getConfigValue();
			
			if(nonNetworkVASClassifications == null) {
				queryAvailabilityResponse.setRemarks("Non Network VAS Classifications is not defined in config table.");
				return queryAvailabilityResponse;
			}
			
			List<String> nonNetworkVASCompatibilitylist = new ArrayList<String>();
			
			String [] nonNetworkVASClassificationsList = nonNetworkVASClassifications.split(",");
			for(String str : nonNetworkVASClassificationsList){
				nonNetworkVASCompatibilitylist.add(str.trim());
			}
			
			
			//logic to fetch primary product and subscribed products from ESB-CBIO.	
			CBIOResponse cbioResponse = null;
			try {
				cbioResponse = fetchRatePlanAndSubscribedOffers(searchInput.getCustomerRatePlanId(),searchInput.getSubscribedAddOnIds());
			} catch (SQLException | XmlException | JAXBException e1) {
				logger.error(e1.getMessage());
				logger.error(ExceptionUtils.getStackTrace(e1));
				queryAvailabilityResponse.setRemarks("Error ocurred during connecting to Charging System for fetching GSM addons. Please try again later.");
				return queryAvailabilityResponse;
			}
			Integer prodId = cbioResponse.getRatePlanId();
			//System.out.println("Primary Product Id : "+prodId);
			EpcProductSpecification primaryProduct = null;
			if (prodId != null) {
				ComplexSearchInput complexSearchInput = new ComplexSearchInput();
				complexSearchInput.setProductId(String.valueOf(prodId));
				MultiValueMap<String, String> criteria = new LinkedMultiValueMap<String, String>();
				criteria.add("with", "segment");
				criteria.add("with", "location");
				criteria.add("with", "community");
				criteria.add("with", "availability");
				criteria.add("with", "compatibility");
				List<EpcProductSpecification> prodList = complexSearchInputService.searchComplex(complexSearchInput, criteria, false);
				if(prodList != null && !prodList.isEmpty()) {
					primaryProduct = prodList.get(0);
				} else{
					queryAvailabilityResponse.setRemarks("Product not found for the subscribed rate plan : "+prodId);
					return queryAvailabilityResponse;
				}
			}else{
				queryAvailabilityResponse.setRemarks("Invalid msisdn provided.");
				return queryAvailabilityResponse;
			}
			
			if (!(primaryProduct.getProductStatus().equals(Constants.PRODUCT_STATUS_LAUNCH))) {
				queryAvailabilityResponse
						.setRemarks("Rate plan is not in Launch status.");
				return queryAvailabilityResponse;
			}
			
			Set<String> oClassification = new HashSet<String>();
			if(subFamilies.contains("VAS")){	
				Map<String, List<String>> lookupParams = new HashMap<String, List<String>>();
				lookupParams.put("parentLookupId", Arrays.asList(new String []{"VAS"}));
				lookupParams.put("lookupGroup", Arrays.asList(new String []{"epc_product_specification"}));
				lookupParams.put("lookupName", Arrays.asList(new String []{"product_classification"}));
				List<EpcLookupMaster> lovs = epcLookupMasterService.searchLookUpMaster(lookupParams);
				for(EpcLookupMaster master : lovs){
					oClassification.add(master.getLookupId());
				}
			}else{
				oClassification.add(classifications.get(0));
			}
			//logic to fetch addOn products
			List<EpcProductSpecification> addOnProducts = null;
			List<Integer> addOnProdids = new ArrayList<Integer>();
			if( nonNetworkVASCompatibilitylist.contains(classifications.get(0)) && !nonNetworkVASCompatibilityFlag ){
				addOnProdids = complexSearchInputService.getProductidsByclassification(classifications.get(0));			
			}else{
				List<EpcProductCompatibility>  primaryProdCompatibilities = primaryProduct.getEpcProductCompatibility();
				if(primaryProdCompatibilities != null){
					for(EpcProductCompatibility epcProductCompatibility :primaryProdCompatibilities){
						addOnProdids.add(epcProductCompatibility.getOtherProductId());
					}
				}
			}
			
			try {
				logger.debug("Add on products >>>>"+mapper.writeValueAsString(addOnProdids));
			} catch (JsonProcessingException e1) {
				logger.warn("Exception during JSON conversion >>"+ExceptionUtils.getStackTrace(e1));
			}
			if(!addOnProdids.isEmpty() ){
				
				List<String> addOnProductids = new ArrayList<String>();
				for(Integer id : addOnProdids){
					addOnProductids.add(String.valueOf(id));
				}
				Map<String, List<String>> multiValueMap = new HashMap<String, List<String>>();
				//optimizing the with parameters
				multiValueMap.put("with", Arrays.asList("all"));
				multiValueMap.put("productId", addOnProductids);
				
				addOnProducts = complexSearchInputService.searchProducts(multiValueMap,null, false);
			}else{
				queryAvailabilityResponse.setOtherClassification(oClassification);
				queryAvailabilityResponse.setRemarks("There is no Addon products to be subscribed.");
				return queryAvailabilityResponse;
			}
			String message= "No products available for the given classification :"+classifications.get(0)+".";
			List<Integer> removedProdIds = new ArrayList<Integer>();
			
			if (!("0".equals(searchInput.getExcludeSubProducts()))) {
				//removing already subscribed products
				for (Iterator<EpcProductSpecification> iterator = addOnProducts
						.iterator(); iterator.hasNext();) {
					EpcProductSpecification epcProductSpecification = iterator
							.next();
					for (Integer productId : cbioResponse
							.getSubscribedProducts()) {
						if (productId.equals(epcProductSpecification
								.getProductId())) {
							removedProdIds.add(productId);
							iterator.remove();
						}
					}
				}
				if (addOnProducts.size() < 1) {
					queryAvailabilityResponse
							.setOtherClassification(oClassification);
					String devMsg = null;
					try {
						devMsg = "Already subscribed products removed :"
								+ mapper.writeValueAsString(removedProdIds);
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					queryAvailabilityResponse
							.setRemarks(message + "|" + devMsg);
					return queryAvailabilityResponse;
				}
				removedProdIds.clear();
			}
			//------------------------Addon 2 Addon compatibility flag check---------------
			if (a2aCompatibilityFlag) {
				for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
					EpcProductSpecification epcProductSpecification = iterator.next();
					List<Integer> addOnCompatibilityIds = new ArrayList<Integer>();
					if (epcProductSpecification.getEpcProductCompatibility() != null && !epcProductSpecification.getEpcProductCompatibility().isEmpty()) {
						for (EpcProductCompatibility epcProductCompatibility : epcProductSpecification
								.getEpcProductCompatibility()) {
							addOnCompatibilityIds.add(epcProductCompatibility
									.getOtherProductId());
						}
						List<String> aOIds = new ArrayList<String>();
						for (Integer id : addOnCompatibilityIds) {
							aOIds.add(String.valueOf(id));
						}
						Map<String, List<String>> addOnCompIdsParams = new HashMap<String, List<String>>();
						addOnCompIdsParams.put("productId", aOIds);
						List<EpcProductSpecification> addOnCompProds = epcProductSpecificationService
								.getBasicProductSpecByID(addOnCompIdsParams);
						List<Integer> finalAOIds = new ArrayList<Integer>();
						if (addOnCompProds != null && !addOnCompProds.isEmpty()) {
							for (EpcProductSpecification prd : addOnCompProds) {
								if (Constants.PRODUCT_TYPE_OPTIONAL.equalsIgnoreCase(prd
										.getProductType())) {
									finalAOIds.add(prd.getProductId());
								}
							}
						}
						if (!finalAOIds.isEmpty()) {
							finalAOIds.retainAll(cbioResponse
									.getSubscribedProducts());
							if (finalAOIds.isEmpty()) {
								removedProdIds.add(epcProductSpecification
										.getProductId());
								iterator.remove();
							}
						}
					}
				}
			}
			if( addOnProducts.size() < 1 ){
			queryAvailabilityResponse.setOtherClassification(oClassification);
				String devMsg = null;
				try {
					devMsg = "Products removed due to Addon to Addon compatibility flag check :"+mapper.writeValueAsString(removedProdIds);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
				return queryAvailabilityResponse;
			}
			removedProdIds.clear();
			if(roamingMigrationRuleFlag){
				List<EpcProductSpecification> subscribedRoamingProds = null;
				if(!cbioResponse.getSubscribedProducts().isEmpty()){
					List<String> safccProdIds = new ArrayList<String>();
					for(Integer id : cbioResponse.getSubscribedProducts()){
						safccProdIds.add(String.valueOf(id));
					}
					Map<String, List<String>> safccParams = new HashMap<String, List<String>>();
					safccParams.put("productId", safccProdIds);
					safccParams.put("isRoamingProduct", Arrays.asList(new String []{"1"}));
					subscribedRoamingProds = epcProductSpecificationService.getBasicProductSpecByID(safccParams);
				}
				if(subscribedRoamingProds != null && subscribedRoamingProds.size() == 1){
					Map<String, List<String>> migParams = new HashMap<String, List<String>>();
					migParams.put("sourceProductId", Arrays.asList(new String []{String.valueOf(subscribedRoamingProds.get(0).getProductId())}));
					List<EpcProductMigration> migrations = epcProductMigrationService.searchEpcProductMigration(migParams);
					if(migrations != null && !migrations.isEmpty()){
						Set<Integer> commonMig = new HashSet<Integer>();
						for (EpcProductMigration migration : migrations) {
							commonMig.add(migration
									.getTargetProductId());
						}
						for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
							EpcProductSpecification epcProductSpecification = iterator.next();
							if (epcProductSpecification.getIsRoamingProduct() == 1) {
								if (!commonMig.contains(epcProductSpecification
										.getProductId())) {
									removedProdIds.add(epcProductSpecification
											.getProductId());
									iterator.remove();
								}
							}
						}
					}else{
						queryAvailabilityResponse.setRemarks("No migration rule defined for the subscribed roaming product :"+subscribedRoamingProds.get(0).getProductShortCode());
						return queryAvailabilityResponse;
					}
				}else if(subscribedRoamingProds != null && subscribedRoamingProds.size() > 1){
					queryAvailabilityResponse.setRemarks("More than one roaming products have been subscribed.");
					return queryAvailabilityResponse;
				}
			}
			if( addOnProducts.size() < 1 ){
				queryAvailabilityResponse.setOtherClassification(oClassification);
				String devMsg = null;
				try {
					devMsg = "Products removed due to Roaming Migration Rule flag check :"+mapper.writeValueAsString(removedProdIds);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
				return queryAvailabilityResponse;
			}
			removedProdIds.clear();
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				//logic for basicinfo check
				
					if (subFamilies.contains(epcProductSpecification
							.getProductSubFamily())){
					//do nothing
					}else {
						removedProdIds.add(epcProductSpecification.getProductId());
					iterator.remove();
				 }
			}
			//System.out.println("AddOn products size after sub-family Check :"+addOnProducts.size());
			if( addOnProducts.size() < 1 ){
				queryAvailabilityResponse.setOtherClassification(oClassification);
				String devMsg = null;
				try {
					devMsg = "Products removed due to sub-family check failed :"+mapper.writeValueAsString(removedProdIds);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
				return queryAvailabilityResponse;
			}
			removedProdIds.clear();
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				//logic for basicinfo check
				if (primaryProduct.getProductAssociationLevel().equals(epcProductSpecification
						.getProductAssociationLevel())
						&& primaryProduct.getProductFamily().equals(epcProductSpecification
								.getProductFamily())
						&& EPCUtils.validateCategory(primaryProduct.getProductCategory(), epcProductSpecification.getProductCategory()) 
						) {
							if(StringUtils.isNotBlank(searchInput.getProductCategory())){
								if(EPCUtils.validateCategory(searchInput.getProductCategory(), epcProductSpecification.getProductCategory())){
									removedProdIds.add(epcProductSpecification.getProductId());
									iterator.remove();
								}
							}
				} else {
					removedProdIds.add(epcProductSpecification.getProductId());
					iterator.remove();
				}
				
				
			}
			//System.out.println("AddOn products size after Basic Check :"+addOnProducts.size());
			if( addOnProducts.size() < 1 ){
				queryAvailabilityResponse.setOtherClassification(oClassification);
				String devMsg = null;
				try {
					devMsg = "Products removed due to Basic check (family/category/association level) failed :"+mapper.writeValueAsString(removedProdIds);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
				return queryAvailabilityResponse;
			}
			removedProdIds.clear();
			//logic for init channel check
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				boolean initChannelCheck = false;
				List<EpcProductInitChannel> initChannels = epcProductSpecification.getEpcProductInitChannel();
				if (initChannels != null) {
					for (EpcProductInitChannel initChannel : initChannels) {
						if (searchInput.getInitiatingChannel().equals(
								String.valueOf(initChannel.getChannelId())) && Constants.INIT_CHANNEL_STATUS_ACTIVE.equals(initChannel.getStatus())) {
							initChannelCheck = true;
							break;
						}
					}
				}
				if(!initChannelCheck){
					removedProdIds.add(epcProductSpecification.getProductId());
					iterator.remove();
				}
			}
			//System.out.println("AddOn products size after init channel Check :"+addOnProducts.size());
			if( addOnProducts.size() < 1 ){
				queryAvailabilityResponse.setOtherClassification(oClassification);
				String devMsg = null;
				try {
					devMsg = "Products removed due to init channel failed :"+mapper.writeValueAsString(removedProdIds);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
				return queryAvailabilityResponse;
			}
			removedProdIds.clear();
			//logic for sales channel check	
			if(StringUtils.isNotBlank(searchInput.getSalesChannel())){
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				boolean salesChannelCheck = false;
				List<EpcProductSalesChannel> saleChannels = epcProductSpecification.getEpcProductSalesChannel();
				if (saleChannels != null) {
					for (EpcProductSalesChannel salesChannel : saleChannels) {
						if (searchInput.getSalesChannel().equals(
								String.valueOf(salesChannel.getPartnerType()))) {
							salesChannelCheck = true;
							break;
						}
					}
				}
				if(!salesChannelCheck){
					removedProdIds.add(epcProductSpecification.getProductId());
					iterator.remove();
				}
			}
			//System.out.println("AddOn products size after sales channel Check :"+addOnProducts.size());
			if( addOnProducts.size() < 1 ){
				queryAvailabilityResponse.setOtherClassification(oClassification);
				String devMsg = null;
				try {
					devMsg = "Products removed due to sales channel failed :"+mapper.writeValueAsString(removedProdIds);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
				return queryAvailabilityResponse;
			}
			}
			removedProdIds.clear();
			//logic for segment check
			if(StringUtils.isNotBlank(searchInput.getSegment()) || StringUtils.isNotBlank(searchInput.getSegmentType())){
				
				List<EpcProductSegment> primaryProductSegments = primaryProduct.getEpcProductSegment();
				boolean pSegmentFound = false;
				
				if(StringUtils.isNotBlank(searchInput.getSegment()) ){
					if (primaryProductSegments != null) {
						for (EpcProductSegment epcProductSegment : primaryProductSegments) {
							if (epcProductSegment.getSegment().equals(
									searchInput.getSegment())) {
								pSegmentFound = true;
								break;
							}
						}
					}
				if(!pSegmentFound){
					queryAvailabilityResponse.setOtherClassification(oClassification);
					queryAvailabilityResponse.setRemarks("Segment check failed for rate plan..");
					return queryAvailabilityResponse;	
				}
				}
				boolean pSegmentTypeFound = false;
				
				if(StringUtils.isNotBlank(searchInput.getSegmentType())){
					if (primaryProductSegments != null) {
						for (EpcProductSegment epcProductSegment : primaryProductSegments) {
							if (epcProductSegment.getSegmentType().equals(
									searchInput.getSegmentType())) {
								pSegmentTypeFound = true;
								break;
							}
						}
					}
					if(!pSegmentTypeFound){
						queryAvailabilityResponse.setOtherClassification(oClassification);
						queryAvailabilityResponse.setRemarks("Segment type check failed for rate plan..");
						return queryAvailabilityResponse;	
					}
				}
				if(StringUtils.isNotBlank(searchInput.getSegment())){
					for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
						EpcProductSpecification epcProductSpecification = iterator.next();
						boolean aSegmentFound = false;
						
						List<EpcProductSegment> addOnProdSegments = epcProductSpecification.getEpcProductSegment();
						if (primaryProductSegments != null
								&& addOnProdSegments != null) {
							
							if (addOnProdSegments != null) {
								for (EpcProductSegment epcProductSegment : addOnProdSegments) {
									if (epcProductSegment.getSegment().equals(
											searchInput.getSegment())) {
										aSegmentFound = true;
										break;
									}
								}
							}
							if (aSegmentFound) {
								//Do nothing
							}else{
								removedProdIds.add(epcProductSpecification.getProductId());
								iterator.remove();
							}
						}
					}
					//System.out.println("AddOn products size after segment Check :"+addOnProducts.size());
					if( addOnProducts.size() < 1 ){
						queryAvailabilityResponse.setOtherClassification(oClassification);
						String devMsg = null;
						try {
							devMsg = "Products removed due to segment check failed :"+mapper.writeValueAsString(removedProdIds);
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
						return queryAvailabilityResponse;
					}
				}
				removedProdIds.clear();
				if(StringUtils.isNotBlank(searchInput.getSegmentType())){
					for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
						EpcProductSpecification epcProductSpecification = iterator.next();
						boolean aSegmentTypeFound = false;
						
						List<EpcProductSegment> addOnProdSegments = epcProductSpecification.getEpcProductSegment();
						if (primaryProductSegments != null
								&& addOnProdSegments != null) {
							
							if (addOnProdSegments != null) {
								for (EpcProductSegment epcProductSegment : addOnProdSegments) {
									if (epcProductSegment.getSegmentType()
											.equals(searchInput
													.getSegmentType())) {
										aSegmentTypeFound = true;
										break;
									}
								}
							}
							if (aSegmentTypeFound) {
								//Do nothing
							}else{
								removedProdIds.add(epcProductSpecification.getProductId());
								iterator.remove();
							}
						}
					}
					//System.out.println("AddOn products size after segment type Check :"+addOnProducts.size());
					if( addOnProducts.size() < 1 ){
						queryAvailabilityResponse.setOtherClassification(oClassification);
						String devMsg = null;
						try {
							devMsg = "Products removed due to segment type check failed :"+mapper.writeValueAsString(removedProdIds);
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
						return queryAvailabilityResponse;
					}
				}
				removedProdIds.clear();
			}
			
			//logic for community check
			if(StringUtils.isNotBlank(searchInput.getCommunityId())){
				List<EpcProductCommunity>  primaryProductCommunities = primaryProduct.getEpcProductCommunity();
				boolean pFound = false;
				if (primaryProductCommunities != null) {
					for (EpcProductCommunity epcProductCommunity : primaryProductCommunities) {
						if (String
								.valueOf(epcProductCommunity.getCommunityId())
								.equals(searchInput.getCommunityId())) {
							pFound = true;
							break;
						}
					}
				}
				if( !pFound){
					queryAvailabilityResponse.setOtherClassification(oClassification);
					queryAvailabilityResponse.setRemarks("community id for rate plan doesn't match.");
					return queryAvailabilityResponse;
				}
				//System.out.println("AddOn products size after community Check :"+addOnProducts.size());
				/*if( addOnProducts.size() < 1 ){
					queryAvailabilityResponse.setRemarks("Nothing to be subscribed after community id check.");
					return queryAvailabilityResponse;
				}*/
			}
			removedProdIds.clear();
			
			List<EpcProductLocation>  primaryProductLocations = primaryProduct.getEpcProductLocation();
			if(StringUtils.isNotBlank(searchInput.getRegion())){
				boolean pFound = false;
				if (primaryProductLocations != null) {
					for (EpcProductLocation epcProductLoc : primaryProductLocations) {
						if (epcProductLoc.getLocationCode2().equals(
								searchInput.getRegion())) {
							pFound = true;
							break;
						}
					}
				}
				if( !pFound){
					queryAvailabilityResponse.setOtherClassification(oClassification);
					queryAvailabilityResponse.setRemarks("Region for rate plan doesn't match.");
					return queryAvailabilityResponse;
				}
			}
			if(StringUtils.isNotBlank(searchInput.getArea())){
				boolean pFound = false;
				if (primaryProductLocations != null) {
					for (EpcProductLocation epcProductLoc : primaryProductLocations) {
						if (epcProductLoc.getLocationCode3().equals(
								searchInput.getArea())) {
							pFound = true;
							break;
						}
					}
				}
				if( !pFound){
					queryAvailabilityResponse.setOtherClassification(oClassification);
					queryAvailabilityResponse.setRemarks("Area for rate plan doesn't match.");
					return queryAvailabilityResponse;
				}
			}
			if(StringUtils.isNotBlank(searchInput.getTerritory())){
				boolean pFound = false;
				if (primaryProductLocations != null) {
					for (EpcProductLocation epcProductLoc : primaryProductLocations) {
						if (epcProductLoc.getLocationCode4().equals(
								searchInput.getTerritory())) {
							pFound = true;
							break;
						}
					}
				}
				if( !pFound){
					queryAvailabilityResponse.setOtherClassification(oClassification);
					queryAvailabilityResponse.setRemarks("Territory for rate plan doesn't match.");
					return queryAvailabilityResponse;
				}
			}
			removedProdIds.clear();
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				List<EpcProductLocation>  addOnProdLocations = epcProductSpecification.getEpcProductLocation();
				//logic for Region check
				if(StringUtils.isNotBlank(searchInput.getRegion())){
					boolean aFound = false;
					if(primaryProductLocations != null &&  addOnProdLocations != null){
						
						for(EpcProductLocation epcProductLoc :addOnProdLocations){
							if(epcProductLoc.getLocationCode2() .equals( searchInput.getRegion())){
								aFound = true;
								break;
							}
						}
						if(aFound){
							//do nothing
						}else{
							removedProdIds.add(epcProductSpecification.getProductId());
							iterator.remove();
							//continue;
						}
					}
					
				}
				//System.out.println("AddOn products size after region Check :"+addOnProducts.size());
				if( addOnProducts.size() < 1 ){
					queryAvailabilityResponse.setOtherClassification(oClassification);
					String devMsg = null;
					try {
						devMsg = "Products removed due to region check failed :"+mapper.writeValueAsString(removedProdIds);
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
					return queryAvailabilityResponse;
				}
			}
				removedProdIds.clear();
				for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
					EpcProductSpecification epcProductSpecification = iterator.next();
					List<EpcProductLocation>  addOnProdLocations = epcProductSpecification.getEpcProductLocation();
				//logic for Area check
				if(StringUtils.isNotBlank(searchInput.getArea())){
					boolean aFound = false;
					if(primaryProductLocations != null &&  addOnProdLocations != null){
						
						for(EpcProductLocation epcProductLoc :addOnProdLocations){
							if(epcProductLoc.getLocationCode3() .equals( searchInput.getArea())){
								aFound = true;
								break;
							}
						}
						if(aFound){
							// do nothing 
						}else{
							removedProdIds.add(epcProductSpecification.getProductId());
							iterator.remove();
							//continue;
						}
					}
					
				}
				//System.out.println("AddOn products size after area Check :"+addOnProducts.size());
				if( addOnProducts.size() < 1 ){
					queryAvailabilityResponse.setOtherClassification(oClassification);
					String devMsg = null;
					try {
						devMsg = "Products removed due to area check failed :"+mapper.writeValueAsString(removedProdIds);
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
					return queryAvailabilityResponse;
				}
				}
				removedProdIds.clear();
				for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
					EpcProductSpecification epcProductSpecification = iterator.next();
					List<EpcProductLocation>  addOnProdLocations = epcProductSpecification.getEpcProductLocation();
				//logic for Territory check
				if(StringUtils.isNotBlank(searchInput.getTerritory())){
					boolean aFound = false;
					if(primaryProductLocations != null &&  addOnProdLocations != null){
						
						for(EpcProductLocation epcProductLoc :addOnProdLocations){
							if(epcProductLoc.getLocationCode4() .equals( searchInput.getTerritory())){
								aFound = true;
								break;
							}
						}
						if(aFound){
							// do nothing 
						}else{
							removedProdIds.add(epcProductSpecification.getProductId());
							iterator.remove();
							//continue;
						}
					}
					
				}
				//System.out.println("AddOn products size after territory Check :"+addOnProducts.size());
				if( addOnProducts.size() < 1 ){
					queryAvailabilityResponse.setOtherClassification(oClassification);
					String devMsg = null;
					try {
						devMsg = "Products removed due to territory check failed :"+mapper.writeValueAsString(removedProdIds);
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
					return queryAvailabilityResponse;
				}
			}
			removedProdIds.clear();
			//start date check
			Date startDate;
			try {
				startDate = df.parse(searchInput.getStartDate());
			} catch (ParseException e) {
				logger.error(ExceptionUtils.getStackTrace(e));
				queryAvailabilityResponse.setOtherClassification(oClassification);
				queryAvailabilityResponse.setRemarks("Start Date is not provided in proper format");
				return queryAvailabilityResponse;
			}
			//Add on product paused status and product status
			for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
				EpcProductSpecification epcProductSpecification = iterator.next();
				if(epcProductSpecification.getIsProductPaused() == 1){
					removedProdIds.add(epcProductSpecification.getProductId());
					iterator.remove();
					continue;
				}
				
				if(!(epcProductSpecification.getProductStatus() .equals(Constants.PRODUCT_STATUS_LAUNCH))){
					removedProdIds.add(epcProductSpecification.getProductId());
					iterator.remove();
					continue;
				}
				
				
				//start date check
				EpcProductAvailability availability = epcProductSpecification.getEpcProductAvailability().get(0);
				if(availability.getLifeValidityStartDate().before(startDate) && 
						availability.getLifeValidityEndDate().after(startDate) && 
						availability.getSubscriptionStartDate().before(startDate)&& 
						availability.getSubscriptionEndDate().after(startDate)&& 
						availability.getSellingStartDate().before(startDate)&& 
						availability.getSellingEndDate().after(startDate)
						){
					//do nothing 
				}else{
					removedProdIds.add(epcProductSpecification.getProductId());
					iterator.remove();
					continue;
				}
			}
			//System.out.println("AddOn products size after is paused,product status and start date Check :"+addOnProducts.size());
			if( addOnProducts.size() < 1 ){
				queryAvailabilityResponse.setOtherClassification(oClassification);
				String devMsg = null;
				try {
					devMsg = "Products removed due to product status/ispause/start date check failed :"+mapper.writeValueAsString(removedProdIds);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
				return queryAvailabilityResponse;
			}
			
			removedProdIds.clear();
			//product SubCategory check
			if(EPCUtils.validateSubCategory(primaryProduct.getProductSubCategory(),searchInput.getProductSubCategory())){
				if(Constants.PRODUCT_SUB_CATEGORY_REGULAR.equals(primaryProduct.getProductSubCategory())){
					for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
						EpcProductSpecification epcProductSpecification = iterator.next();
						//logic for basicinfo check
						if (Constants.PRODUCT_SUB_CATEGORY_REGULAR.equals(epcProductSpecification.getProductSubCategory())|| Constants.PRODUCT_SUB_CATEGORY_ALL.equals(epcProductSpecification.getProductSubCategory())) {
							//do nothing
						} else {
							removedProdIds.add(epcProductSpecification.getProductId());
							iterator.remove();
						}
					}
				}else if(Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(primaryProduct.getProductSubCategory()) || Constants.PRODUCT_SUB_CATEGORY_ALL.equals(primaryProduct.getProductSubCategory())){
					
					if(StringUtils.isBlank(searchInput.getCommunityId())){
						queryAvailabilityResponse.setOtherClassification(oClassification);
						queryAvailabilityResponse.setRemarks("Community Id is mandatory when productSubCategory is Corporate");
						return queryAvailabilityResponse;
					}
					Map<String, List<String>> communityParams = new HashMap<String, List<String>>();
					communityParams.put("productId", Arrays.asList(new String []{String.valueOf(primaryProduct.getProductId())}));
					communityParams.put("communityId", Arrays.asList(new String []{searchInput.getCommunityId()}));
					communityParams.put("applicableEmpBand", Arrays.asList(new String []{"ALL"}));
					List<EpcProductCommunity> communities = epcProductCommunityService.searchProductCommunity(communityParams);
					
					if(communities != null && communities.size() == 1){
						if(communities.get(0).getIsEmployeeAllowedToPurchase() == 1){
							
							List<Integer> nonGblCorpPoolIds = epcProductCommunityService.getAllNonGlobalCorpPoolProductIds();
							
							for( Iterator<EpcProductSpecification> itr = addOnProducts.iterator(); itr.hasNext();  ){
								EpcProductSpecification prod = itr.next();
								if (Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(prod.getProductSubCategory()) || Constants.PRODUCT_SUB_CATEGORY_ALL.equals(prod.getProductSubCategory())) {
									if(prod.getIsCorporateSpecific() != null && prod.getIsCorporateSpecific() == 1){
										
										boolean aFound = false;
										List<EpcProductCommunity>  addOnProdCommunities = prod.getEpcProductCommunity();
										
										if (addOnProdCommunities != null) {
											for (EpcProductCommunity epcProductCommunity : addOnProdCommunities) {
												if (searchInput.getCommunityId().equals(
														String.valueOf(epcProductCommunity
																.getCommunityId()))) {
													aFound = true;
													break;
												}
											}
										}
										if(aFound){
											// community check fine
										}else{
											removedProdIds.add(prod.getProductId());
											itr.remove();
											continue;
										}
									}else{
										//community check fine
									}
								} else {
									removedProdIds.add(prod.getProductId());
									itr.remove();
								}
							}
						}else{
							for( Iterator<EpcProductSpecification> iterator = addOnProducts.iterator(); iterator.hasNext();  ){
								EpcProductSpecification epcProductSpecification = iterator.next();
								
								if (Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(epcProductSpecification.getProductSubCategory()) || Constants.PRODUCT_SUB_CATEGORY_ALL.equals(epcProductSpecification.getProductSubCategory())) {
									boolean aFound = false;
									List<EpcProductCommunity> addOnProdCommunities = epcProductSpecification
											.getEpcProductCommunity();
									if (addOnProdCommunities != null) {
										for (EpcProductCommunity epcProductCommunity : addOnProdCommunities) {
											if (searchInput
													.getCommunityId()
													.equals(String
															.valueOf(epcProductCommunity
																	.getCommunityId()))) {
												aFound = true;
												break;
											}
										}
									}
									if (aFound) {
										// community check fine
									} else {
										removedProdIds
												.add(epcProductSpecification
														.getProductId());
										iterator.remove();
										continue;
									}
								}else{
									removedProdIds.add(epcProductSpecification.getProductId());
									iterator.remove();
								}
							}
						}
					}else{
						queryAvailabilityResponse.setOtherClassification(oClassification);
						queryAvailabilityResponse.setRemarks("Community check for corporate sub category failed.");
						return queryAvailabilityResponse;
					}
				}
				
			}else{
				queryAvailabilityResponse.setOtherClassification(oClassification);
				queryAvailabilityResponse.setRemarks("Product sub category check failed for primary product.");
				return queryAvailabilityResponse;
			}
			
			if( addOnProducts.size() < 1 ){
				queryAvailabilityResponse.setOtherClassification(oClassification);
				String devMsg = null;
				try {
					devMsg = "Products removed due to product sub category check failed :"+mapper.writeValueAsString(removedProdIds);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				queryAvailabilityResponse.setRemarks(message+"|"+devMsg);
				return queryAvailabilityResponse;
			}
			removedProdIds.clear();
			//to get the product as per with request params.
			List<String> finalProdIds = new ArrayList<String>();
			for(EpcProductSpecification epcProductSpecification : addOnProducts){
				finalProdIds.add(String.valueOf(epcProductSpecification.getProductId()));
			}
			//List<String> with = allRequestParams.get("with");
			if(with == null){
				with = new ArrayList<String>();
			}
			List<String> oldWith = new ArrayList<String>();
			boolean isNTA = false;
			boolean isTA = false;
			for(String str : with){
				oldWith.add(str);
				if(str.contains("nta-")){
					isNTA = true;
				}else if(str.contains("ta-")){
					isTA = true;
				}
			}
			with.add("initiatingChannel");
			with.add("provider");
			allRequestParams.put("productId", finalProdIds);
			allRequestParams.put("with",with);
			
			List<EpcProductCommunity> finalCommunities = null;
			if(StringUtils.isNotBlank(searchInput.getCommunityId()) && StringUtils.isNotBlank(searchInput.getSlabId()) && (oldWith.contains("tariff") || isTA )){
				Map<String, List<String>> communityParams = new HashMap<String, List<String>>();
				communityParams.put("productId", finalProdIds);
				communityParams.put("communityId", Arrays.asList(new String []{searchInput.getCommunityId()}));
				communityParams.put("applicableEmpBand", Arrays.asList(new String []{"ALL"}));
				communityParams.put("slabId", Arrays.asList(new String []{searchInput.getSlabId()}));
				finalCommunities = epcProductCommunityService.searchProductCommunity(communityParams);
			}
			
			
			//System.out.println("allRequestParams :"+allRequestParams);
			List<EpcProductSpecification> finalProds = complexSearchInputService.searchProducts(allRequestParams, searchInput.getOrderType(), true);
			
			//populating the product lists based on classification value
			Map<String, List<QueryAvailabilityProductSpec>> availableProduct = new HashMap<String, List<QueryAvailabilityProductSpec>>();
			Set<String> otherClassification = new TreeSet<String>();
			otherClassification.addAll(classifications);
			for(EpcProductSpecification epcProductSpecification : finalProds){
				String classification = epcProductSpecification.getProductClassification();
				
				if(classification != null && classifications.contains(classification)){
					if(availableProduct.containsKey(classification)){
						//System.out.println("classification inside the availableProduct .. :"+classification);
						//System.out.println("classification in availableProduct ... : "+availableProduct);
						try {
							availableProduct.get(classification).add(populateAvailableProduct(SerializationUtils.clone(epcProductSpecification), oldWith, searchInput, finalCommunities, isNTA, isTA));
						} catch (Exception e) {
							queryAvailabilityResponse.setRemarks(e.getMessage());
							return queryAvailabilityResponse;
						}
					}else{
						List<QueryAvailabilityProductSpec> epcProds = new ArrayList<QueryAvailabilityProductSpec>();
						try {
							epcProds.add(populateAvailableProduct(SerializationUtils.clone(epcProductSpecification), oldWith, searchInput, finalCommunities, isNTA, isTA));
						} catch (Exception e) {
							queryAvailabilityResponse.setRemarks(e.getMessage());
							return queryAvailabilityResponse;
						}
						availableProduct.put(classification, epcProds);
					}
				}else if (classification != null){
					otherClassification.add(classification);
				}
			}
			if(!subFamilies.contains("VAS")){	
				queryAvailabilityResponse.setOtherClassification(otherClassification);
			}else{
				queryAvailabilityResponse.setOtherClassification(oClassification);
			}
			queryAvailabilityResponse.setAvailableProduct(availableProduct);
			
			return queryAvailabilityResponse;
	}
	
	/**
	 * @param epcProductSpecification
	 * @param with
	 * @param searchInput
	 * @param finalCommunities
	 * @return
	 * @throws Exception
	 */
	private QueryAvailabilityProductSpec populateAvailableProduct(
			EpcProductSpecification epcProductSpecification, List<String> with, QueryAvailabilitySearchInput searchInput, List<EpcProductCommunity> finalCommunities, boolean isNTA, boolean isTA) throws Exception {
		//System.out.println("With values -->"+with);
		QueryAvailabilityProductSpec availabilityProductSpec = new QueryAvailabilityProductSpec();
		if(epcProductSpecification.getEpcProductInitChannel() != null){
			for( Iterator<EpcProductInitChannel> iterator = epcProductSpecification.getEpcProductInitChannel().iterator(); iterator.hasNext();  ){
				EpcProductInitChannel epcProductInitChannel = iterator.next();
				if(searchInput.getInitiatingChannel().equals(epcProductInitChannel.getChannelId())){
					availabilityProductSpec.setOfferId(epcProductInitChannel.getChannelLevelProductId());
					availabilityProductSpec.setOfferName(epcProductInitChannel.getChannelLevelMarketName());
				}
			}
		}
	
		if(epcProductSpecification.getEpcProductProvider() != null)  {
			for( Iterator<EpcProductProviderSystem> iterator = epcProductSpecification.getEpcProductProvider().iterator(); iterator.hasNext();  ){
				EpcProductProviderSystem epcProductProviderSystem = iterator.next();
				if(epcProductProviderSystem != null && epcProductProviderSystem.getIsPrimaryProvider() != null &&  epcProductProviderSystem.getIsPrimaryProvider() == 1){
					availabilityProductSpec.setOfferProvider(epcProductProviderSystem.getProviderSystemCode());
				}
			}
		}
		availabilityProductSpec.setDescription(epcProductSpecification.getProductDescription());
		availabilityProductSpec.setOfferType(epcProductSpecification.getProductSubFamily());
		availabilityProductSpec.setOfferLevel(epcProductSpecification.getProductAssociationLevel());
		
		if((with!= null && with.contains("characteristic")) || isNTA){
			if(epcProductSpecification.getEpcProductCharacteristic() != null){
				for( Iterator<EpcProductAttribute> iterator = epcProductSpecification.getEpcProductCharacteristic().iterator(); iterator.hasNext();  ){
					EpcProductAttribute epcProductAttribute = iterator.next();
					if(epcProductAttribute.getIsInputReqFromChannel() != null  && epcProductAttribute.getIsInputReqFromChannel() == 1 ){
						//do nothing
					}else{
						iterator.remove();
					}
				}
			}
			availabilityProductSpec.setProductCharacteristic(epcProductSpecification.getEpcProductCharacteristic());
		}
		if(with!= null && with.contains("provider")){
			availabilityProductSpec.setProductProvider(epcProductSpecification.getEpcProductProvider());
		}
		if((with!= null && with.contains("tariff")) || isTA ){
			
			boolean isSubFeeDefined = false;
			if(epcProductSpecification.getEpcProductTariff() != null && epcProductSpecification.getEpcProductTariff() .size() >0 ){
				for(EpcProductAttribute attr : epcProductSpecification.getEpcProductTariff()){
					if(Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr.getEpcAttributeMaster().getAttributeCtg()) && 
							Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr.getEpcAttributeMaster().getAttributeCtgType()) &&
							Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equals(attr.getEpcAttributeMaster().getAttributeName())){
						isSubFeeDefined = true;
						break;
					}
				}
			}
			
			if(!isSubFeeDefined){
				throw new Exception("Subscription fee for One Time Charge is not defined for Addon :"+epcProductSpecification.getProductShortCode());
			}
			
			if (Constants.PRODUCT_SUB_CATEGORY_CORPORATE.equals(epcProductSpecification.getProductSubCategory()) || Constants.PRODUCT_SUB_CATEGORY_ALL.equals(epcProductSpecification.getProductSubCategory())) {
				if (finalCommunities != null && !finalCommunities.isEmpty()) {
					boolean isSubFeeSet = false;
					// Used to break from both inner and outer for loop.
					for (EpcProductCommunity epcProductCommunity : finalCommunities) {
						if (isSubFeeSet)
							break;
						if (epcProductCommunity.getProductId().equals(
								epcProductSpecification.getProductId()) && Constants.COMMUNITY_STATUS_ACTIVE.equals(epcProductCommunity.getCommunityStatus())) {
							if (epcProductSpecification.getEpcProductTariff() != null
									&& epcProductSpecification
											.getEpcProductTariff().size() > 0) {
								for (EpcProductAttribute attr : epcProductSpecification
										.getEpcProductTariff()) {
									if (Constants.ATTRIBUTE_CTG_TARIFFCTG.equals(attr
											.getEpcAttributeMaster()
											.getAttributeCtg())
											&& Constants.ATTRIBUTE_CTG_TYPE_ONETIME.equals(attr
													.getEpcAttributeMaster()
													.getAttributeCtgType())
											&& Constants.ATTRIBUTE_NAME_SUBSCRIPTIONFEE.equals(attr
													.getEpcAttributeMaster()
													.getAttributeName())) {
										attr.setAttributeValue1(String
												.valueOf(epcProductCommunity
														.getDiscountedPrice()));
										isSubFeeSet = true;
										break;
									}
								}
							}
						}
					}

				}
			}
			availabilityProductSpec.setProductTariff(epcProductSpecification.getEpcProductTariff());
		}
		if(with!= null && with.contains("initiatingChannel")){
			availabilityProductSpec.setProductInitiatingChannel(epcProductSpecification.getEpcProductInitChannel());
		}
		return availabilityProductSpec;
	}

	/**
	 * @param orderType
	 * @param initChannel
	 * @param SalesChannel
	 * @return
	 */
	private boolean validateOrderChannelRule(
			String orderType, String initChannel, String SalesChannel) {
		StringBuilder query = new StringBuilder();
		query.append("where order_type ='").append(orderType).append("' and initiating_channel = '").append(initChannel).append("' and ");
		if(SalesChannel == null){
			query.append(" sales_channel is null");
		}else{
			query.append(" sales_channel ='").append(SalesChannel).append("' ");
		}
		query.append(" and status='").append("Active'");
		
		List<EpcOrderChannelRule> epcOrderChannelRules = epcOrderChannelRuleService.getOrderChannelRulesByWhereClause(query.toString());
		if(epcOrderChannelRules != null && !epcOrderChannelRules.isEmpty() ){
			return true;
		}
		return false;
	}

	/**
	 * @param msisdn
	 * @param nonNetworkVASCompatibilitylist
	 * @param classifications
	 * @return
	 * @throws SQLException
	 * @throws XmlException
	 * @throws JAXBException
	 */
	private CBIOResponse fetchRatePlanAndSubscribedOffers(
			String customerRatePlanId,String subscribedAddOnIds) throws SQLException, XmlException, JAXBException {

		String [] primaryIds = customerRatePlanId.split(":");
		String providerProdId = null;
		String providerSysCd = null;
		if (primaryIds.length == 2) {
			providerProdId = primaryIds[1];
			providerSysCd = primaryIds[0];
		}
		Integer prodId = null;
		if (StringUtils.isNotBlank(providerProdId) && StringUtils.isNotBlank(providerSysCd)) {
			Map<String, List<String>> providerSystemParams = new HashMap<String, List<String>>();
			providerSystemParams.put("providerProductId",
					Arrays.asList(new String[] { providerProdId }));
			providerSystemParams.put("providerSystemCode",
					Arrays.asList(new String[] {providerSysCd}));
			List<EpcProductProviderSystem> providers = epcProductProviderSystemService
					.searchProvider(providerSystemParams);
			if (providers != null && !providers.isEmpty()) {
				prodId = providers.get(0).getProductId();
			}
		}
		List<Map<String,String>> subscriptionVASList = null;
		logger.warn("stub_subscribed_vas_addons used: " + subscribedAddOnIds );
		subscriptionVASList = new ArrayList<Map<String,String>>();
		String [] addOnArray = subscribedAddOnIds.split(",");
		Map<String,String> map = null;
		if (addOnArray != null && addOnArray.length > 0) {
			for (String str : addOnArray) {
				map = new HashMap<String, String>();
				String[] addOn = str.split(":");
				if (addOn != null && addOn.length == 2) {
					map.put("providerSystemCode", addOn[0].trim());
					map.put("providerProductId", addOn[1].trim());
					subscriptionVASList.add(map);
				}
			}
		}
		Map<String, List<String>> providerSystemParams = null;
		List<EpcProductProviderSystem> providers = null;
		List<Integer> gsmAddonIds = new ArrayList<Integer>();
		for(Map<String,String> provider: subscriptionVASList){
			providerSystemParams = new HashMap<String, List<String>>();
			providerSystemParams.put("providerProductId", Arrays.asList(new String []{provider.get("providerProductId")}));
			providerSystemParams.put("providerSystemCode", Arrays.asList(new String []{provider.get("providerSystemCode")}));
			providers = epcProductProviderSystemService.searchProvider(providerSystemParams);
			if(providers != null && !providers.isEmpty()){
				gsmAddonIds .add(providers.get(0).getProductId());
			}
		}
		

		CBIOResponse cbioResponse = new CBIOResponse();
		cbioResponse.setRatePlanId(prodId);
		cbioResponse.setSubscribedProducts(gsmAddonIds);
		return cbioResponse;
	}
}
