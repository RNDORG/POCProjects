package com.wipro.epc.repositories;

import java.util.List;
import com.wipro.epc.domain.EpcTariffOverride;

/**
 * @author Developer
 * @version 1.0
 * type EpcTariffOverrideRepositoryCustom
 */
public interface EpcTariffOverrideRepositoryCustom {

	/**
	 * @param otherProductId1
	 * @param otherProductId2
	 * @param otherProductId3
	 * @param otherProductId4
	 * @param ratePlan
	 * @param addonProdId
	 * @return
	 */
	List<EpcTariffOverride> getList(String otherProductId1, String otherProductId2, String otherProductId3, String otherProductId4, String ratePlan, String addonProdId);
	
	EpcTariffOverride modifyTariffOverride(EpcTariffOverride override);
}
