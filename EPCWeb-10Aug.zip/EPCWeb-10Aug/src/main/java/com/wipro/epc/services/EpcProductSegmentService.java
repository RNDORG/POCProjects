package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductSegment;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.uam.definitions.MetaInfo;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductSegmentService
 */
@Service
public class EpcProductSegmentService {

	/**
	 * Logger EpcProductSegmentService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(EpcProductSegmentService.class);

	/**
	 * com.wipro.epc.repositories.EpcProductSegmentRepository EpcProductSegmentService.java
	 */
	@Autowired
	com.wipro.epc.repositories.EpcProductSegmentRepository epcProductSegmentRepository;

	// ?ProductSegmentname=admin&ProductSegmentname=guest&enabled=true
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductSegment> searchEpcProductSegment(
			Map<String, List<String>> allRequestParams) {
		if(allRequestParams.get("with")!=null) {
			allRequestParams.remove("with");
		}
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductSegment.class.getName(), null);
		List<EpcProductSegment> listOfEpcProductSegmentReturned = null;
		try {
				listOfEpcProductSegmentReturned = epcProductSegmentRepository.getList(queryBuilder);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		// //System.out.println(listOfEpcProductSegmentReturned);
		return listOfEpcProductSegmentReturned;
	}



	/**
	 * @param productSegmentList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductSegment> manageProductSegments(List<EpcProductSegment> productSegmentList, String createdBy )
	{
		List<EpcProductSegment> retListOfEpcProductSegment = new ArrayList<EpcProductSegment>();

		for (EpcProductSegment productSegment : productSegmentList) {
			
				productSegment = manageProductSegment(productSegment, createdBy);
				if((productSegment.getMetaInfo().get("STATUS")==null))
				{
					productSegment.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
				}
			
			
			retListOfEpcProductSegment.add(productSegment);
		}
		return retListOfEpcProductSegment;
	}
	
	/**
	 * @param productSegment
	 * @param createdBy
	 * @return
	 */
	EpcProductSegment manageProductSegment(EpcProductSegment productSegment, String createdBy)
	{
		EpcProductSegment retProductSegment = null;
		switch (productSegment.getMetaInfo().get("OPERATION")) {

		case "CREATE":
			retProductSegment = createProductSegment(productSegment, createdBy);
			break;
		case "UPDATE":
			retProductSegment = modifyProductSegment(productSegment, createdBy);
			break;
		case "DELETE":
			retProductSegment = deleteProductSegment(productSegment);
			break;
		default:
			throw new EPCException("not supported");
		}
		return retProductSegment;
		
	}
	/**
	 * @param productSegment
	 * @return
	 */
	EpcProductSegment deleteProductSegment(EpcProductSegment productSegment) {
		epcProductSegmentRepository.delete(productSegment.getProductSegmentId());
		return productSegment;
	}

	/**
	 * @param productSegment
	 * @param lastUpdatedBy
	 * @return
	 */
	EpcProductSegment modifyProductSegment(EpcProductSegment productSegment, String lastUpdatedBy) {
		productSegment.setModifiedBy(lastUpdatedBy);
		return epcProductSegmentRepository.modifyProductSegment(productSegment);
	}

	/**
	 * @param productSegment
	 * @param createdBy
	 * @return
	 */
	EpcProductSegment createProductSegment(EpcProductSegment productSegment, String createdBy) {
		productSegment.setCreatedBy(createdBy);
		productSegment.setCreatedDate(new Date());
	/*	productSegment.setStartDate(new Date());
		productSegment.setEndDate(new Date());*/
		epcProductSegmentRepository.save(productSegment);
		return productSegment;
	}

	
}
