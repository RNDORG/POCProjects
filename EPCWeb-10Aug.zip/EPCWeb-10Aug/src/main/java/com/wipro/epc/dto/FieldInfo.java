/**
 * EPC Application - FieldInfo.java
 */
package com.wipro.epc.dto;


/**
 * @author Developer
 * @version 1.0
 * type FieldInfo
 */
public class FieldInfo {
			
	@Override
	public String toString() {
		return "FieldInfo [fieldName=" + fieldName + ", fieldType=" + fieldType
				+ ", dbFieldName=" + dbFieldName + "]";
	}
	private String fieldName;
	private String fieldType;
	private String dbFieldName;
	
	/**
	 * @return
	 */
	public String getFieldName() {
		return fieldName;
	}
	/**
	 * @param fieldName
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	/**
	 * @return
	 */
	public String getFieldType() {
		return fieldType;
	}
	/**
	 * @param fieldType
	 */
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	/**
	 * @return
	 */
	public String getDbFieldName() {
		return dbFieldName;
	}
	/**
	 * @param dbFieldName
	 */
	public void setDbFieldName(String dbFieldName) {
		this.dbFieldName = dbFieldName;
	}
	
	
}
