package com.wipro.epc.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wipro.epc.domain.EpcActivityMaster;
/**
 * @version 1.0
 * @author VI251443
 *
 */
public class EpcActivityMasterRepositoryImpl implements EpcActivityMasterRepositoryCustom{
	
	private static Logger logger =LoggerFactory.getLogger(EpcActivityMasterRepositoryImpl.class);
	
	/**
	 * EntityManager EpcActivityMasterRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;
	
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcActivityMasterRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<Object[]> getList(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query).getResultList();
		
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.EpcActivityMasterRepositoryCustom#getSearchResult(java.lang.String)
	 */
	@Override
	public List<EpcActivityMaster> getSearchResult(String query) {
		logger.debug("#Query: "+query);
		return em.createNativeQuery(query,EpcActivityMaster.class).getResultList();
	}
	
/*	@Override
	public EpcActivityMaster modifyActivity(EpcActivityMaster activity) {
StringBuilder queryBuilder = new StringBuilder("update epc_activity_master set attribute_name="+activity.getActivityName());
		
		if(activity.getStatus()!=null && activity.getStatus()!=0)
			queryBuilder.append(",").append(" status = ").append(activity.getStatus());
		if(activity.getLocationCode1()!=null && activity.getLocationCode1()!=0)
	    	   queryBuilder.append(",").append(" location_code_1 = ").append(location.getLocationCode1());
		 if(activity.getLocationCode2()!=null && activity.getLocationCode2()!=0)
	    	   queryBuilder.append(",").append(" location_code_2 = ").append(location.getLocationCode2());
		 if(activity.getLocationCode3()!=null && activity.getLocationCode3()!=0)
	    	   queryBuilder.append(",").append(" location_code_3 = ").append(location.getLocationCode3());
		 if(activity.getLocationCode4()!=null && activity.getLocationCode4()!=0)
	    	   queryBuilder.append(",").append(" location_code_4 = ").append(location.getLocationCode4());	 
		queryBuilder.append(" where product_location_id =").append(location.getProductLocationId());
		String query = queryBuilder.toString();
		em.createNativeQuery(query).executeUpdate();
		//System.out.println(query);
		return activity;
	}*/

}
