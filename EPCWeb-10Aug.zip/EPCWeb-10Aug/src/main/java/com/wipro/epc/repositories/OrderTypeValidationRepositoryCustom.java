package com.wipro.epc.repositories;


import com.wipro.epc.domain.EpcOrderChannelRule;

/**
 * @author Developer
 * @version 1.0
 * type OrderTypeValidationRepositoryCustom
 */
public interface OrderTypeValidationRepositoryCustom {

	/**
	 * @param orderList
	 * @return
	 */
	int validateOrders(EpcOrderChannelRule orderList);

}
