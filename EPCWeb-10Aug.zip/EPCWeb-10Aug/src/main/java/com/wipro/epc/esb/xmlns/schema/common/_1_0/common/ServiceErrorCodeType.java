
package com.wipro.epc.esb.xmlns.schema.common._1_0.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ServiceErrorCodeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ServiceErrorCodeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="TNM-BIZERR-SER001"/>
 *     &lt;enumeration value="TNM-BIZERR-SER002"/>
 *     &lt;enumeration value="TNM-BIZERR-SER003"/>
 *     &lt;enumeration value="TNM-BIZERR-SER004"/>
 *     &lt;enumeration value="TNM-BIZERR-SER005"/>
 *     &lt;enumeration value="TNM-BIZERR-SER006"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ServiceErrorCodeType")
@XmlEnum
public enum ServiceErrorCodeType {

    @XmlEnumValue("TNM-BIZERR-SER001")
    TNM_BIZERR_SER_001("TNM-BIZERR-SER001"),
    @XmlEnumValue("TNM-BIZERR-SER002")
    TNM_BIZERR_SER_002("TNM-BIZERR-SER002"),
    @XmlEnumValue("TNM-BIZERR-SER003")
    TNM_BIZERR_SER_003("TNM-BIZERR-SER003"),
    @XmlEnumValue("TNM-BIZERR-SER004")
    TNM_BIZERR_SER_004("TNM-BIZERR-SER004"),
    @XmlEnumValue("TNM-BIZERR-SER005")
    TNM_BIZERR_SER_005("TNM-BIZERR-SER005"),
    @XmlEnumValue("TNM-BIZERR-SER006")
    TNM_BIZERR_SER_006("TNM-BIZERR-SER006");
    private final String value;

    ServiceErrorCodeType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ServiceErrorCodeType fromValue(String v) {
        for (ServiceErrorCodeType c: ServiceErrorCodeType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
