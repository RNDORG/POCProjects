package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.exception.GenericException;
import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcActivityChannelRule;
import com.wipro.epc.domain.EpcActivityDetail;
import com.wipro.epc.domain.EpcActivityMaster;
import com.wipro.epc.domain.EpcNotificationTemplate;
import com.wipro.epc.domain.EpcNotificationTemplateDetail;
import com.wipro.epc.dto.KeyValueDetail;
import com.wipro.epc.dto.ActivitySearchInput;
import com.wipro.epc.dto.ActivitySearchOutput;
import com.wipro.epc.dto.ActivityUtil;
import com.wipro.epc.repositories.EpcActivityChannelRuleRepository;
import com.wipro.epc.repositories.EpcNotificationTemplateDetailRepository;
import com.wipro.epc.repositories.EpcNotificationTemplateRepository;
//import com.wipro.epc.dto.ActivityUtil;
import com.wipro.epc.uam.definitions.MetaInfo;
import com.wipro.epc.util.Constants;

/**
 * @version 1.0
 * @author VI251443
 *
 */

@Service
public class EpcActivityMasterService {
	private static Logger logger = LoggerFactory.getLogger(EpcActivityMasterService.class);
	
	@Autowired
	com.wipro.epc.repositories.EpcActivityMasterRepository epcActivityMasterRepository;
	
	@Autowired
	com.wipro.epc.services.EpcActivityDetailsService epcActivityDetailService;

	@Autowired
	com.wipro.epc.repositories.EpcActivityDetailRepository epcActivityDetailRepository;
	
	@Autowired
	EpcActivityChannelRuleRepository epcActivityChannelRuleRepository;
	
	@Autowired
	EpcNotificationTemplateRepository epcNotificationTemplateRepository;
	
	@Autowired
	EpcNotificationTemplateDetailRepository epcNotificationTemplateDetailRepository;
	
	List<EpcActivityMaster> epcActivityMasterCache;
	
	@PersistenceContext
	EntityManager em;
	
	public void loadActivityMasterCache() {
		epcActivityMasterCache = epcActivityMasterRepository.getAllListofValues();
	}
	/**
	 * 
	 * @param allRequestParams
	 * @return
	 */
		public List<EpcActivityMaster> searchActivityMaster(Map<String, List<String>> allRequestParams) {
			
			String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,EpcActivityMaster.class.getName(), null);
			List<EpcActivityMaster> listOfActivityReturned = null;
			queryBuilder= queryBuilder+ " order by activity_name ";
			try {
				listOfActivityReturned = epcActivityMasterRepository.getSearchResult(queryBuilder.toString());
				
			} catch (Exception e) {
				throw new RuntimeException(
						"Error occurred while fetching results from database.\n"
								+ " Query: " + queryBuilder.toString() + "\n"
								+ " Exception: " + e.getMessage());
			}

			return listOfActivityReturned;
			
				
			
		}
		
		/**
		 * 
		 * @param id
		 * @return
		 */
	
		
		public String getLookupValue(Integer id) {
			//if (epcActivityMasterCache == null) {
				loadActivityMasterCache();
			//}
			for (EpcActivityMaster epcActivityMaster : epcActivityMasterCache) {
				if (epcActivityMaster != null
						&& epcActivityMaster.getActivityId().equals(id)) {
					//System.out.println("--------------"+epcActivityMaster.getActivityName());
					return epcActivityMaster.getActivityName();
				}
			}
			return null;
		}

		
		/**
		 * 
		 * @param activityName
		 * @param key
		 * @return
		 */
		public List<EpcActivityMaster> searchActivities(
				String activityName, String key) {
			String query = "select activity_name, epc_activity_detail.activity_id, activity_detail_id, activity_key, activity_value from    "+
	          " epc_activity_master left join epc_activity_detail on                            "+
	          " epc_activity_master.activity_id = epc_activity_detail.activity_id ";
			
			
			if(activityName!=null && !activityName.equals("")){
				query = query + "where activity_name ='"+activityName+"'";
			}
			if(key!=null && !key.equals("")) 
				query = query + "and activity_key like '%"+key+"%'";
                query = query + " order by activity_name";

			List<Object[]> listOfObjects = epcActivityMasterRepository.getList(query);
			List<EpcActivityMaster> masterList = new ArrayList<EpcActivityMaster>();
			//logger.info("Query generated is..."+query);
			List<String> activityNames = new ArrayList<String>();
			List<ActivityUtil> activityList = new ArrayList<ActivityUtil>();
			for(Object object[]: listOfObjects) 
			{
				EpcActivityMaster activityMaster = new EpcActivityMaster();
					ActivityUtil activity = new ActivityUtil();
					activity.setActivityName(object[0].toString());
					activity.setActivityId(object[1].toString());
					activity.setActivityDetailId(object[2].toString());
					activity.setActivityKey(object[3].toString());
					activity.setActivityValue(object[4].toString());
					activityList.add(activity);
					activityNames.add(object[0].toString());
			}
			boolean isDiff = true;
			for(int i=0; i<activityList.size(); i++)
			{
				if(isDiff) {
					EpcActivityMaster activityMaster = new EpcActivityMaster();
					activityMaster.setActivityName(activityList.get(i).getActivityName());
					activityMaster.setActivityId(Integer.parseInt(activityList.get(i).getActivityId()));
					List<EpcActivityDetail> activityDetails = new ArrayList<EpcActivityDetail>();
					for(int j=i; j<activityList.size(); j++)
					{
						EpcActivityDetail activityDetail = new EpcActivityDetail();
						activityDetail.setActivityDetailId(Integer.parseInt(activityList.get(j).getActivityDetailId()));
						activityDetail.setActivityKey(activityList.get(j).getActivityKey());
						activityDetail.setActivityValue(activityList.get(j).getActivityValue());
						activityDetails.add(activityDetail);
						if((j+1)<(activityList.size()))
						if(!activityNames.get(j+1).equals(activityNames.get(j)))
								break;
					}
					activityMaster.setEpcActivityDetail(activityDetails);
					masterList.add(activityMaster);
				}
				if((i+1)<activityList.size())
				if(activityNames.get(i+1).equals(activityNames.get(i))) {
					isDiff = false;
				}
				else {
					isDiff = true;
				}
			}
			
			
		return masterList;
		
			
		}
		
		/**
		 * 
		 * @param activityDetailsList
		 * @param createdBy
		 * @return
		 */
		@Transactional
		public List<EpcActivityMaster> manageActivities(List<EpcActivityMaster> activityDetailsList,
				String createdBy)
				{
					//List<EpcActivityMaster> retListOfActivities=new ArrayList<EpcActivityMaster>();
					
					for(EpcActivityMaster epcActivityMaster:activityDetailsList)
					{
						//epcActivityMaster=manageActivity(epcActivityMaster,createdBy);
					     manageActivity(epcActivityMaster,createdBy);
						if((epcActivityMaster.getMetaInfo().get("STATUS")==null))
						{
							epcActivityMaster.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
						}
					//	retListOfActivities.add(epcActivityMaster);
				}
			     	return activityDetailsList;
				}
		/**
		 * 
		 * @param productActivity
		 * @param createdBy
		 * @return
		 */
		EpcActivityMaster manageActivity(EpcActivityMaster productActivity,
				String createdBy)
				{
			
			productActivity.setStatus(Constants.COMMON_STATUS_ACTIVE);
			EpcActivityMaster retActivity=null;
				logger.info("The operation is "+productActivity.getMetaInfo().get("OPERATION"));
				switch(productActivity.getMetaInfo().get("OPERATION"))
				{
				case "CREATE":retActivity = createActivity(productActivity, createdBy);
											for(EpcActivityDetail detail : productActivity.getEpcActivityDetail()) {
												if(detail!=null) {
													
												detail.setActivityId(epcActivityMasterRepository.findByName(productActivity.getActivityName()));
												}
												else {
												productActivity.getEpcActivityDetail().remove(detail);
												}
											}
											epcActivityDetailService.manageActivitiesDetail(productActivity.getEpcActivityDetail(), createdBy);
							  break;
				case "UPDATE":retActivity = modifyActivity(productActivity, createdBy);
											for(EpcActivityDetail detail : productActivity.getEpcActivityDetail()) {
												if(detail!=null) {
													detail.setActivityId(epcActivityMasterRepository.findByName(productActivity.getActivityName()));
												}
											}
											epcActivityDetailService.manageActivitiesDetail(productActivity.getEpcActivityDetail(), createdBy);
							  break;
				case "DELETE":retActivity = deleteActivity(productActivity);
							  break;
				default:
					throw new RuntimeException("not supported");
				}
				return retActivity;
				}
		/**
		 * 
		 * @param activityDetail
		 * @return
		 */
			private EpcActivityMaster deleteActivity(
					EpcActivityMaster activityDetail) {
				epcActivityDetailRepository.deleteFromDetail(activityDetail.getActivityName());
				epcActivityMasterRepository.deleteFromMaster(activityDetail.getActivityName());
			return activityDetail;
			
			}
/**
 * 
 * @param activityDetail
 * @param createdBy
 * @return
 */
			private EpcActivityMaster modifyActivity(
					EpcActivityMaster activityDetail, String createdBy) {
			 epcActivityMasterRepository.modifyActivity(activityDetail.getActivityName(), activityDetail.getActivityId());
			 return activityDetail;
			}
/**
 * 
 * @param activityDetail
 * @param createdBy
 * @return
 */
			EpcActivityMaster createActivity(EpcActivityMaster activityDetail, String createdBy) {
				activityDetail.setStatus(Constants.COMMON_STATUS_ACTIVE);
				activityDetail.setCreatedBy(createdBy);
				activityDetail.setCreatedDate(new Date());
				epcActivityMasterRepository.save(activityDetail);
				return activityDetail;
		}
			/**
			 * 
			 * @param productCommunityList
			 * @param createdBy
			 * @param activityId
			 * @return
			 */
			@Transactional
			public List<EpcActivityMaster> updateActivities(
					List<EpcActivityMaster> productCommunityList,
					String createdBy, String activityId) {
				
				String query = "delete from epc_activity_detail " ;
				
				if(activityId!=null) {
						query = query + "where activity_id ="+ activityId +" ;";
			//logger.info("Query generated is  "+query);
				}
				
				em.createNativeQuery(query).executeUpdate();
				for(EpcActivityDetail detail: productCommunityList.get(0).getEpcActivityDetail())
				{
					detail.setActivityId(Integer.parseInt(activityId));
					System.out.println("Status before setting is "+detail.getStatus());
					System.out.println("Hi the status is "+Constants.COMMON_STATUS_ACTIVE);
					
					detail.setStatus(Constants.COMMON_STATUS_ACTIVE);
					System.out.println("Status after setting is "+detail.getStatus());
					detail.setCreatedBy(createdBy);
				}
				logger.info("Activity detail is "+productCommunityList.get(0).getEpcActivityDetail());
				epcActivityDetailRepository.save(productCommunityList.get(0).getEpcActivityDetail());
						
				return productCommunityList; 
			}
			/**
			 * 
			 * @param searchInput
			 * @param allRequestParams
			 * @return
			 */
			public ActivitySearchOutput updateActivityExt(
					ActivitySearchInput searchInput, Map<String, List<String>> allRequestParams) {
				if(StringUtils.isBlank(searchInput.getActivityName())  ){
						throw new GenericException("InvalidSearch", "Mandatory Fields are missing. "
								+ "Please provide all mandatory fields (acivityName)", "Mandatory Fields are missing.");
					}
				String activityName=searchInput.getActivityName();
				
				ActivitySearchOutput activityResponse=searchActivitiesExt(activityName,searchInput.getActivityKey(),searchInput.getActivityValue());
				List<String> with = allRequestParams.get("with");
				
				if(with == null){
					with = new ArrayList<String>();
				}
				if(with.contains("activity_channel_rule"))
				{
					
					List<EpcActivityChannelRule> channelRuleList=null;
					try {
						channelRuleList = epcActivityChannelRuleRepository.getActivityChannel(activityName);
					} catch (Exception e) {
						throw new RuntimeException(
								"Error occurred while fetching results from database.\n"
										+ " Query: " + "Select * from epc_activity_channel_rule." + "\n"
										+ " Exception: " + e.getMessage());
					}
					activityResponse.setEpcActivityChannelRule(channelRuleList);
					if(with.contains("notification"))
					{
						for(int i=0;i<channelRuleList.size();i++)
						{
							EpcNotificationTemplate epcNotificationTemplate1=new EpcNotificationTemplate();
							List<EpcNotificationTemplate> epcNotificationTemplate=new ArrayList<EpcNotificationTemplate>();;
						    epcNotificationTemplate=epcNotificationTemplateRepository.findNotificationByTemplateId(channelRuleList.get(i).getNotificationTemplateId());
						    if(epcNotificationTemplate.size()>0){
						    	channelRuleList.get(i).setEpcNotificationTemplate(epcNotificationTemplate.get(0));
						    	List<EpcNotificationTemplateDetail> epcNotificationTemplateDetail=null;
								epcNotificationTemplateDetail=epcNotificationTemplateDetailRepository.findByNotificationTemplateId(channelRuleList.get(i).getNotificationTemplateId());
								epcNotificationTemplate1.setEpcNotificationTemplateDetail(epcNotificationTemplateDetail);
						    	channelRuleList.get(i).getEpcNotificationTemplate().setEpcNotificationTemplateDetail(epcNotificationTemplateDetail);
						    }
							
							
							}
						activityResponse.setEpcActivityChannelRule(channelRuleList);
					}
					
				}
				if((!with.contains("activity_channel_rule")) && with.contains("notification"))
				{
					throw new GenericException("InvalidSearch", " with=activity_channel_rule is missing. "
							+ "Please provide with=activity_channel_rule", "with=activity_channel_rule is missing.");
				
				}
				return activityResponse;
			}
			
			
		   /**
		    * 
		    * @param activityName
		    * @param keys
		    * @return
		    */
			public ActivitySearchOutput searchActivitiesExt(
					
					String activityName, List<String> keys, String activityValue) {
				String query = "select activity_key, activity_value from    "+
		          " epc_activity_master left join epc_activity_detail on  "+
		          " epc_activity_master.activity_id = epc_activity_detail.activity_id ";
			//logger.info("#Query "+query);
			if(activityName!=null && !activityName.equals("")) {
					query = query + "where activity_name ='"+activityName+"'";
				}
//				if(key!=null && !key.equals(""))
//					query = query + "and activity_key ='"+key+"'";
				if(keys!=null ){
					if(keys.size()>0){
								query = query + " and ";
							
							int i=0;
							for(String key:keys){
								i++;
								query = query + "  activity_key = '"+key+"'";
								if(i!=keys.size()){
									query = query + " OR ";
								}
							}
					}
				}
				
				if(StringUtils.isNotBlank(activityValue)){
					query = query + " and activity_value like '"+activityValue+"'";
				}
				List<Object[]> listOfObjects = epcActivityMasterRepository.getList(query);
			
				ActivitySearchOutput detail=new ActivitySearchOutput();
				String key="";
				String value="";
				
				List<KeyValueDetail> keyValueDetails=new ArrayList<KeyValueDetail>();
				List<String> validKeys=new ArrayList<String>();
				for(Object object[]: listOfObjects) 
				{
					KeyValueDetail keyValue=new KeyValueDetail();
					key=object[0].toString();
					value=object[1].toString();
					keyValue.setKey(key);
					keyValue.setValue(value);
					keyValueDetails.add(keyValue);
					validKeys.add(object[0].toString().toLowerCase());
				}
				if( keys!=null){
				for(String key1:keys)
					{
					KeyValueDetail keyValueDetail2=new KeyValueDetail();
					 if(validKeys.size()<1 || validKeys==null)
						{ 
							 keyValueDetail2.setKey(key1);
							 keyValueDetail2.setValue("ERROR_INVALID_KEY");
							 keyValueDetails.add(keyValueDetail2);
						}
						else if(validKeys.size()>0)
						{
							if(!(validKeys.contains(key1.toLowerCase())))
							{
								keyValueDetail2.setKey(key1);
								keyValueDetail2.setValue("ERROR_INVALID_KEY");
								keyValueDetails.add(keyValueDetail2);
							}
						}
						
					}
				}
				detail.setActivityDetails(keyValueDetails);
			
			return detail;
			
				
			}
}
