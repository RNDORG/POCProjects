package com.wipro.epc.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wipro.epc.domain.CachedProductDetails;
import com.wipro.epc.repositories.CachedProductDetailsRepository;



@Service
public class CachedProductDetailsHelperService {
	
	@Autowired
	CachedProductDetailsRepository cachedProductDetailsRepository;  
	//@Transactional
	public void cacheOneProduct(CachedProductDetails cachedProduct) {
		cachedProductDetailsRepository.save(cachedProduct);
	}
}
