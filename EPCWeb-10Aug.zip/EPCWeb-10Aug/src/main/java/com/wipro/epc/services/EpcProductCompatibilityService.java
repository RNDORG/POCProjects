package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductCompatibility;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductCompatibilityRepository;
import com.wipro.epc.uam.definitions.MetaInfo;


/**
 * @author Developer
 * @version 1.0
 * type EpcProductCompatibilityService
 */
@Service
public class EpcProductCompatibilityService {
	
	/**
	 * Logger EpcProductCompatibilityService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(EpcProductCompatibilityService.class);
	
	/**
	 * EpcProductCompatibilityRepository EpcProductCompatibilityService.java
	 */
	@Autowired
	EpcProductCompatibilityRepository epcProductCompatibilityRepository;
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductCompatibility> searchEpcProductCompatibility(Map<String, List<String>> allRequestParams) {
		
		if (allRequestParams.get("with") != null) {
			allRequestParams.remove("with");
		}
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductCompatibility.class.getName(), null);
		List<EpcProductCompatibility> listOfCompatibilityReturned = null;
		try {
			listOfCompatibilityReturned = epcProductCompatibilityRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return listOfCompatibilityReturned;
		
	}

	
	/**
	 * @param ProductCompatibilityList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductCompatibility> manageProductCompatibilities(List<EpcProductCompatibility> ProductCompatibilityList, String createdBy )
	{
		List<EpcProductCompatibility> retListOfEpcProductCompatibility = new ArrayList<EpcProductCompatibility>();

		for (EpcProductCompatibility productCompatibility : ProductCompatibilityList) {
			
				productCompatibility = manageProductCompatibility(productCompatibility, createdBy);
				if((productCompatibility.getMetaInfo().get("STATUS")==null))
				{
					productCompatibility.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
				}
			
			
			retListOfEpcProductCompatibility.add(productCompatibility);
		}
		return retListOfEpcProductCompatibility;
	}
	
	/**
	 * @param productCompatibility
	 * @param createdBy
	 * @return
	 */
	EpcProductCompatibility manageProductCompatibility(EpcProductCompatibility productCompatibility, String createdBy)
	{
		EpcProductCompatibility retProductCompatibility = null;
		switch (productCompatibility.getMetaInfo().get("OPERATION")) {

		case "CREATE":
			retProductCompatibility = createProductCompatibility(productCompatibility, createdBy);
			break;
		case "UPDATE":
			retProductCompatibility = modifyProductCompatibility(productCompatibility, createdBy);
			break;
		case "DELETE":
			retProductCompatibility = deleteProductCompatibility(productCompatibility);
			break;
		default:
			throw new EPCException("not supported");
		}
		return retProductCompatibility;
		
	}
	/**
	 * @param ProductCompatibility
	 * @return
	 */
	EpcProductCompatibility deleteProductCompatibility(EpcProductCompatibility ProductCompatibility) {

		//logger.info("productCompatability: "+ProductCompatibility.getOtherProductId());
		logger.debug("Removing compatibilty for product id "+ProductCompatibility.getProductId() + " and other product id "+ProductCompatibility.getOtherProductId());
		epcProductCompatibilityRepository.removeProductFromCompatibility(ProductCompatibility.getProductId(),ProductCompatibility.getOtherProductId());
		//epcProductCompatibilityRepository.delete(ProductCompatibility.getProductCompatibilityId());
		if(!ProductCompatibility.getMetaInfo().get("OTHER_PRODUCT_TYPE").equalsIgnoreCase(ProductCompatibility.getMetaInfo().get("PRODUCT_TYPE"))){
			//deleting compatible entry
			logger.debug("Main product and Compatible product type not same. So. Removing reverse compatibilty for product id "+ProductCompatibility.getProductId() + " and other product id "+ProductCompatibility.getOtherProductId());
			epcProductCompatibilityRepository.removeProductFromCompatibility(ProductCompatibility.getOtherProductId(),ProductCompatibility.getProductId());
		}
		return ProductCompatibility;
	}

	/**
	 * @param ProductCompatibility
	 * @param lastUpdatedBy
	 * @return
	 */
	EpcProductCompatibility modifyProductCompatibility(EpcProductCompatibility ProductCompatibility, String lastUpdatedBy) {
		ProductCompatibility.setModifiedBy(lastUpdatedBy);
		return epcProductCompatibilityRepository.modifyProductCompatibility(ProductCompatibility);
	}

	/**
	 * @param ProductCompatibility
	 * @param createdBy
	 * @return
	 */
	EpcProductCompatibility createProductCompatibility(EpcProductCompatibility ProductCompatibility, String createdBy) {
		ProductCompatibility.setCreatedBy(createdBy);
		ProductCompatibility.setCreatedDate(new Date());		
		
		if(!ProductCompatibility.getMetaInfo().get("OTHER_PRODUCT_TYPE").equalsIgnoreCase(ProductCompatibility.getMetaInfo().get("PRODUCT_TYPE"))){
			logger.debug("Main product and Compatible product type not same. ");
			EpcProductCompatibility proCompatibilityNew = new EpcProductCompatibility();
			BeanUtils.copyProperties(ProductCompatibility, proCompatibilityNew);
			//set auto generated db id as null in case save method is called before copy properties
			proCompatibilityNew.setProductId(ProductCompatibility.getOtherProductId());
			proCompatibilityNew.setOtherProductId(ProductCompatibility.getProductId());			
			logger.debug("Adding reverse compatibilty for product id "+proCompatibilityNew.getProductId() + " with other product id "+proCompatibilityNew.getOtherProductId());
			epcProductCompatibilityRepository.save(proCompatibilityNew);
		}
		logger.debug("Creating compatibilty for product id "+ProductCompatibility.getProductId() + " with other product id "+ProductCompatibility.getOtherProductId());
		epcProductCompatibilityRepository.save(ProductCompatibility);
		return ProductCompatibility;
	}


	

}
