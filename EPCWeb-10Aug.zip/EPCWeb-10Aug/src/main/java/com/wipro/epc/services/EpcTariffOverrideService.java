package com.wipro.epc.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.epc.domain.EpcAttributeMaster;
import com.wipro.epc.domain.EpcProductAttribute;
import com.wipro.epc.domain.EpcTariffOverride;
import com.wipro.epc.dto.CorporatesAssociatedResponse;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.repositories.EpcProductSpecificationRepository;
import com.wipro.epc.repositories.EpcTariffOverrideRepository;
import com.wipro.epc.util.Constants;

/**
 * @author Developer
 * @version 1.0
 * type EpcTariffOverrideService
 */
@Service
public class EpcTariffOverrideService {
	
	
	private static Logger logger= LoggerFactory.getLogger(EpcTariffOverrideService.class);
	/**
	 * EpcTariffOverrideRepository EpcTariffOverrideService.java
	 */
	@Autowired
	EpcTariffOverrideRepository epcTariffOverrideReopsitory;
	
	@Autowired
	EpcProductSpecificationRepository epcProductSpecificationRepository;
	
	public List<CorporatesAssociatedResponse> getProductsFromQuery(String productType, String productId, String productClassification, String productSubFamily){
		
		String query = "";
		if(productType!=null){
			
			query = query + " and spec.product_type = '"+productType+"' ";
			if(productId!=null){
				productId = productId.replace("*", "%");
				query  = query + " and spec.product_short_code like '"+productId+"' ";
			}
			if(productClassification!=null){
				query = query + " and spec.product_classification ='"+productClassification+"'";
			}
			if(productSubFamily!=null) {
				query = query + " and spec.product_sub_family = '"+productSubFamily+"'";
			}
		}
		String queryToBeExecuted = "select distinct spec.product_id, spec.product_short_code,spec.product_marketing_name, spec.product_category,"
									+"spec.product_sub_category,spec.product_status, prodattr.attribute_value1 "
									+"from epc_product_attribute prodattr, epc_attribute_master attrmas, epc_product_specification spec "
									+", epc_product_community comm "
									+"where spec.product_id=prodattr.product_id and prodattr.attribute_id=attrmas.attribute_id and "
									+"attrmas.attribute_ctg='tariffCtg' and attribute_ctg_type ='OneTime' and "
									+"attribute_name in ('CONNECTION_FEE','SUBSCRIPTION_FEE') and product_status='Launch' "
									+query;
		return getProductsFromQuery(queryToBeExecuted);
	}
	private List<CorporatesAssociatedResponse> getProductsFromQuery(String query) {
		List<Object[]> productsDtoReturned = epcProductSpecificationRepository.getListOfObjects(query);
		List<CorporatesAssociatedResponse> returnList = new ArrayList<CorporatesAssociatedResponse>();
		for(Object[] object: productsDtoReturned){
			CorporatesAssociatedResponse singleElement = new CorporatesAssociatedResponse();
			singleElement.setProductId(object[0].toString());
			singleElement.setProductShortCode(object[1].toString());
			singleElement.setProductMarketingName(object[2].toString());
			singleElement.setProductCategory(object[3].toString());
			singleElement.setProductSubCategory(object[4].toString());
			singleElement.setStatus(object[5].toString());
			if(object[6]!=null) {
				singleElement.setFee(object[6].toString());
			}
			returnList.add(singleElement);
		}
		return returnList;
	}
	
	
	
	private List<EpcTariffOverride> epcTariffOverrideCachedList=null;
	/**
	 * @param OtherProd1
	 * @param OtherProd2
	 * @param OtherProd3
	 * @param OtherProd4
	 * @param ratePlanId
	 * @param addonProdId
	 * @return
	 */
	@Transactional
	public List<BigDecimal> getTariffOverrideAmount(String OtherProd1,String OtherProd2,
			String OtherProd3,String OtherProd4,String ratePlanId,String addonProdId) {
		List<BigDecimal> returnList = new ArrayList<BigDecimal>();
		List<EpcTariffOverride> returnedTariffOverride = null;
		try {
			returnedTariffOverride = epcTariffOverrideReopsitory.getList(OtherProd1,OtherProd2,OtherProd3,OtherProd4,ratePlanId,addonProdId);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Exception: " + e.getMessage(), e);
		}
		 
		
		for(EpcTariffOverride tariff: returnedTariffOverride) {
			returnList.add(tariff.getOverrideTariffAmount());
		}
			return returnList;
	}
	
	@Transactional
	public List<BigDecimal> getTariffOverrideAmountCached(String OtherProd1,String OtherProd2,
			String OtherProd3,String OtherProd4,String ratePlanId,String addonProdId) {
		
		List<BigDecimal> returnList = new ArrayList<BigDecimal>();
		List<EpcTariffOverride> returnedTariffOverride = new ArrayList<EpcTariffOverride>();
		
		if(epcTariffOverrideCachedList==null)
		{
			epcTariffOverrideCachedList=epcTariffOverrideReopsitory.getEpcTariffOverrideForCaching();
		}
		
		for(int i=0;i<epcTariffOverrideCachedList.size();i++)
		{
			EpcTariffOverride epcTariffOverride=epcTariffOverrideCachedList.get(i);
			
			if(compareProducts(OtherProd1,epcTariffOverride.getOtherProductId1())
				&&compareProducts(OtherProd1,epcTariffOverride.getOtherProductId1())
					&&compareProducts(OtherProd1,epcTariffOverride.getOtherProductId1())
						&&compareProducts(OtherProd1,epcTariffOverride.getOtherProductId1())
							&& compareProducts(addonProdId,epcTariffOverride.getAddonProductId())
							  && compareProducts(ratePlanId,epcTariffOverride.getRateplanProductId())
							    && compareProducts(epcTariffOverride.getAttributeName(),"SUBSCRIPTION_FEE"))
				{
				 returnedTariffOverride.add(epcTariffOverride);
			    }
			
		}
		for(EpcTariffOverride tariff: returnedTariffOverride) {
			returnList.add(tariff.getOverrideTariffAmount());
		}
		//logger.info("dicount price is : "+returnList.get(0));
			return returnList;
	}
	
	
	private Boolean compareProducts(String a, String b)
	{
		Boolean flag=false;
		if((a==null)&&(b==null))
		{
			flag=true;
		}
		else if((a!=null) && (b!=null))
		{
			flag= a.equals(b);
		}
		else if (((a==null)&&(b!=null))||((a!=null)&&(b==null)))
		{
			flag=false;
		}
		return flag;
	}
	
	public synchronized void loadTariffOverrideCache()
	{
		epcTariffOverrideCachedList=new ArrayList<EpcTariffOverride>();
		try {
			epcTariffOverrideCachedList = epcTariffOverrideReopsitory.getEpcTariffOverrideForCaching();
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Exception: " + e.getMessage(), e);
		}
		logger.info("size of the tariff cache is : "+epcTariffOverrideCachedList.size());
	}

	public List<EpcTariffOverride> getEpcTariffOverrideCachedList() {
		return epcTariffOverrideCachedList;
	}

	public List<EpcTariffOverride> manageTariffOverride(List<EpcTariffOverride> tariffOverride,
			String createdBy) {
		
		List<EpcTariffOverride> retTariffOverrideList=new ArrayList<EpcTariffOverride>();
		
		for (EpcTariffOverride override : tariffOverride) {
			override=manageTariffOverride(override, createdBy);
			
		
			if (override.getMetaInfo().get("STATUS") == null) {
				override.getMetaInfo().put(MetaInfo.STATUS,
						MetaInfo.SUCCESS);
			}
			retTariffOverrideList.add(override);

		}
		return retTariffOverrideList;
		
	
		
	}

	private EpcTariffOverride manageTariffOverride(EpcTariffOverride override,
			String createdBy) {
		EpcTariffOverride retTariffOverride = null;
		 
		switch(override.getMetaInfo().get("OPERATION")){		
		case "CREATE":
			
					retTariffOverride=createTariffOverride(override,createdBy);
						break;
				case "UPDATE":
					retTariffOverride=modifyTariffOverride(override, createdBy);
					break;
				case "DELETE":
					retTariffOverride=deleteTariffOverride(override);
						break;
				default:
						throw new EPCException("not supported");
		}
		
		return retTariffOverride;
	}

	private EpcTariffOverride deleteTariffOverride(EpcTariffOverride override) {
		epcTariffOverrideReopsitory.delete(override.getTariffOverrideId());
		return override;
	}

	private EpcTariffOverride modifyTariffOverride(EpcTariffOverride override,
			String lastUpdatedBy) {
		override.setModifiedBy(lastUpdatedBy);
		override.setModifiedDate(new Date());
		epcTariffOverrideReopsitory.modifyTariffOverride(override);
		return override;
	}

	private EpcTariffOverride createTariffOverride(EpcTariffOverride override,
			String createdBy) {
		override.setCreatedBy(createdBy);
		override.setCreatedDate(new Date());
		System.out.println("Inside tariff override save! :)"+override);
		epcTariffOverrideReopsitory.save(override);
		System.out.println("Save succesful :)"+override);
		
		return override;
	}
	
	

}
