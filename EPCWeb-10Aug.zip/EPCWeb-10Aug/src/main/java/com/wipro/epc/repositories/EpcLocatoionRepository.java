package com.wipro.epc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wipro.epc.domain.EpcLocation;

/**
 * @author Developer
 * @version 1.0
 * type EpcLocatoionRepository
 */
public interface EpcLocatoionRepository extends CrudRepository<EpcLocation, Integer> {
	/**
	 * @return
	 */
	@Query(value = "select * from epc_location", nativeQuery=true)
	List<EpcLocation> getAllLocations();
}
