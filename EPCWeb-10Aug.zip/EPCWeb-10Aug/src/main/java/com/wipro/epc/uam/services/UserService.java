package com.wipro.epc.uam.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.uam.definitions.MetaInfo;
import com.wipro.epc.uam.domain.Role;
import com.wipro.epc.uam.domain.Users;
import com.wipro.epc.uam.repositories.AuthorityRepository;
import com.wipro.epc.uam.repositories.RoleRepository;
import com.wipro.epc.uam.repositories.UserRoleMapRepository;
import com.wipro.epc.uam.repositories.UsersRepository;

/**
 * @author Developer
 * @version 1.0
 * type UserService
 */
@Service
public class UserService {

	/**
	 * Logger UserService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(UserService.class);

	/**
	 * UsersRepository UserService.java
	 */
	@Autowired
	UsersRepository usersRepository;

	/**
	 * RoleRepository UserService.java
	 */
	@Autowired
	RoleRepository roleRepository;

	/**
	 * AuthorityRepository UserService.java
	 */
	@Autowired
	AuthorityRepository authorityRepository;

	/**
	 * UserRoleMapRepository UserService.java
	 */
	@Autowired
	UserRoleMapRepository usersRoleMapRepository;

	// ?username=admin&username=guest&enabled=true
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<Users> searchUserSimple(
			Map<String, List<String>> allRequestParams) {
		String with = "";
		
		if (allRequestParams.get("with") != null) {
			with = allRequestParams.get("with").toString();
			with = with.substring(1, 4);
		}

		allRequestParams.remove("with");
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,Users.class.getName(), null);
		List<Users> listOfUsersReturned = null;
		try {
			listOfUsersReturned = usersRepository.getList(queryBuilder);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		// //System.out.println(listOfUsersReturned);

		if ("all".equals(with)) {
			return usersAlongWithRolesAndAuthorities(listOfUsersReturned);
		} else {
			return listOfUsersReturned;
		}
	}

	
	/**
	 * @param users
	 * @return
	 */
	List<Users> usersAlongWithRolesAndAuthorities(List<Users> users) {
		List<Users> usersReturned = new ArrayList<Users>();
		for (Users user : users) {
			user.setRoles(roleRepository.findRolesByUsername(user.getUsername()));
			//user.setAuthorities(authorityRepository.findByUsername(user.getUsername()));  //Removing authorities as not required Generally
			usersReturned.add(user);
		}
		return usersReturned;
	}

	/**
	 * @param userList
	 * @param txn
	 * @param mixOp
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<Users> updateUser(List<Users> userList, boolean txn,
			boolean mixOp, String createdBy) {
		return updateUsersCommon(userList, txn, mixOp, createdBy);
	}

	/**
	 * @param userList
	 * @param txn
	 * @param mixOp
	 * @param createdBy
	 * @return
	 */
	public List<Users> updateUserNonTxn(List<Users> userList, boolean txn,
			boolean mixOp, String createdBy) {
		return updateUsersCommon(userList, txn, mixOp, createdBy);
		
	}

	/**
	 * @param user
	 * @param createdBy
	 * @return
	 */
	Users updateUser(Users user, String createdBy) {
		return updateUserCommon(user, createdBy);
	}

	/**
	 * @param user
	 * @param createdBy
	 * @return
	 */
	@Transactional
	Users updateUserTxn(Users user, String createdBy) {
		return updateUserCommon(user, createdBy);
	}

	/**
	 * @param userList
	 * @param txn
	 * @param mix_op
	 * @param createdBy
	 * @return
	 */
	List<Users> updateUsersCommon(List<Users> userList, boolean txn, boolean mix_op, String createdBy )
	{
		List<Users> retListOfUsers = new ArrayList<Users>();

		for (Users user : userList) {
			try {
				if(txn) {
					user = updateUser(user, createdBy);
				} else {
					user = updateUserTxn(user, createdBy);
				}
				if((user.getMetaInfo().get("STATUS")==null))
				{
					user.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
				}
			} catch (Exception e) {
				if (txn) {
					throw e;
				} else {
					user.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.ERROR);
					user.getMetaInfo().put(MetaInfo.ERROR_MESSAGE,
							e.getMessage());
				}
			}
			retListOfUsers.add(user);
		}
		return retListOfUsers;
	}
	
	/**
	 * @param user
	 * @param createdBy
	 * @return
	 */
	Users updateUserCommon(Users user, String createdBy)
	{
		Users retUser = null;
		switch (user.getMetaInfo().get("OPERATION")) {

		case "CREATE":
			retUser = createUser(user, createdBy);
			break;
		case "UPDATE":
			retUser = modifyUser(user, createdBy);
			break;
		case "DELETE":
			retUser = deleteUser(user);
			break;
		default:
			throw new EPCException("not supported");
		}
		return retUser;
		
	}
	/**
	 * @param user
	 * @return
	 */
	Users deleteUser(Users user) {
		//authorityRepository.deleteFromAuthorities(user.getUsername());
		//usersRoleMapRepository.deleteFromUserRoleMap(user.getUsername());
		user.setEnabled("disabled");
		usersRepository.modifyUser(user);
		return user;
	}

	/**
	 * @param user
	 * @param lastUpdatedBy
	 * @return
	 */
	Users modifyUser(Users user, String lastUpdatedBy) {
		user.setModifiedBy(lastUpdatedBy);
		user.setModifiedDate(new Date());
		return usersRepository.modifyUser(user);
	}

	/**
	 * @param user
	 * @param createdBy
	 * @return
	 */
	Users createUser(Users user, String createdBy) {
		user.setCreatedBy(createdBy);
		user.setCreatedDate(new Date());
		if(usersRepository.findOne(user.getUsername())==null) {
			usersRepository.save(user);
			if(user.getRoles().size()>0) {
				addRolesAssociatedWithAnUser(user);
			}
		}
		else {
			user.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.ERROR);
			user.getMetaInfo().put(MetaInfo.ERROR_MESSAGE, MetaInfo.USER_EXISTS);
		}
		return user;
	}

	// adds roles as well as corresponding values into authorities table
	/**
	 * @param user
	 */
	void addRolesAssociatedWithAnUser(Users user) {
		usersRepository.addRolesAssociatedWithAnUser(user);
	}


	/**
	 * @return
	 */
	public List<Role> getAllRoles() {
		return (List<Role>) roleRepository.findAll();
	}

}
