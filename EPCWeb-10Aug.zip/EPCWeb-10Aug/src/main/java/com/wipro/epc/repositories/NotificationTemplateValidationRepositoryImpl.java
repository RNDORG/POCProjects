package com.wipro.epc.repositories;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NotificationTemplateValidationRepositoryImpl implements
NotificationTemplateValidationRepositoryCustom{
	
	private static Logger logger =LoggerFactory.getLogger(NotificationTemplateValidationRepositoryImpl.class);
	
	@PersistenceContext
	private EntityManager em;

	/* (non-Javadoc)
	 * @see com.wipro.epc.repositories.NotificationTemplateValidationRepositoryCustom#validateTemplateName(java.lang.String)
	 */
	@Override
	public int validateTemplateName(String templateName) {
		StringBuilder queryBuilder = new StringBuilder("select count(1) from epc_notification_template where template_name = '"+ templateName+"'");	
		String query = queryBuilder.toString();
		logger.debug("#Query: "+query);
		int maxValue = ((Number) em.createNativeQuery(query).getSingleResult()).intValue();
		
		
		
		
			
			return maxValue;
	}

}
