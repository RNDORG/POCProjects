package com.wipro.epc.dto;

/**
 * @author Developer
 * @version 1.0
 * type OrderTypeValidation
 */
public class OrderTypeValidation {

	private Integer orderType;
	private Integer salesChannel;
	private Integer initiatingChannel;
	/**
	 * @return the orderType
	 */
	public Integer getOrderType() {
		return orderType;
	}
	/**
	 * @param orderType the orderType to set
	 */
	public void setOrderType(Integer orderType) {
		this.orderType = orderType;
	}
	/**
	 * @return the salesChannel
	 */
	public Integer getSalesChannel() {
		return salesChannel;
	}
	/**
	 * @param salesChannel the salesChannel to set
	 */
	public void setSalesChannel(Integer salesChannel) {
		this.salesChannel = salesChannel;
	}
	/**
	 * @return the initiatingChannel
	 */
	public Integer getInitiatingChannel() {
		return initiatingChannel;
	}
	/**
	 * @param initiatingChannel the initiatingChannel to set
	 */
	public void setInitiatingChannel(Integer initiatingChannel) {
		this.initiatingChannel = initiatingChannel;
	}
	
	
}
