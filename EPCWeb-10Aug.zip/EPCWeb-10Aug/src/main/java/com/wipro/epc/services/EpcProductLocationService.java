package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductLocation;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.uam.definitions.MetaInfo;

/**
 * @author Developer
 * @version 1.0
 * type EpcProductLocationService
 */
@Service
public class EpcProductLocationService {
	private static Logger logger = LoggerFactory.getLogger(EpcProductSpecificationService.class);
	/**
	 * com.wipro.epc.repositories.EpcProductLocationRepository EpcProductLocationService.java
	 */
	@Autowired
	com.wipro.epc.repositories.EpcProductLocationRepository epcProductLocationRepository;
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductLocation> searchEpcProductLocation(
			Map<String, List<String>> allRequestParams) {
		String with = "";
		
		if (allRequestParams.get("with") != null) {
			with = allRequestParams.get("with").toString();
			with = with.substring(1, 4);
		}

		allRequestParams.remove("with");
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductLocation.class.getName(), null);
		List<EpcProductLocation> listOfEpcProductLocationReturned = null;
		try {
				listOfEpcProductLocationReturned = epcProductLocationRepository.getList(queryBuilder);
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		
		return listOfEpcProductLocationReturned;
	}

	
	/**
	 * @param productLocationList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductLocation> manageProductLocations(List<EpcProductLocation> productLocationList,
			String createdBy)
			{
				List<EpcProductLocation> retListOfEpcProductLocation=new ArrayList<EpcProductLocation>();
				
				for(EpcProductLocation productLocation:productLocationList)
				{
					productLocation=manageProductLocation(productLocation,createdBy);
					if((productLocation.getMetaInfo().get("STATUS")==null))
					{
						productLocation.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
					}
				retListOfEpcProductLocation.add(productLocation);
			}
		     	return retListOfEpcProductLocation;
			}
	
	/**
	 * @param productLocation
	 * @param createdBy
	 * @return
	 */
	EpcProductLocation manageProductLocation(EpcProductLocation productLocation,
			String createdBy)
			{
			EpcProductLocation retProductLocation=null;
			
			switch(productLocation.getMetaInfo().get("OPERATION"))
			{
			case "CREATE":logger.info("indside create");
				retProductLocation = createProductLocation(productLocation, createdBy);
						  break;
			case "UPDATE":retProductLocation = modifyProductLocation(productLocation, createdBy);
						  break;
			case "DELETE":retProductLocation = deleteProductLocation(productLocation);
						  break;
			default:
				throw new EPCException("not supported");
			}
			return retProductLocation;
			}
	
		/**
		 * @param productLocation
		 * @return
		 */
		private EpcProductLocation deleteProductLocation(
			EpcProductLocation productLocation) {
			epcProductLocationRepository.delete(productLocation.getProductLocationId());
		
		return productLocation;
		}

		/**
		 * @param productLocation
		 * @param createdBy
		 * @return
		 */
		private EpcProductLocation modifyProductLocation(
			EpcProductLocation productLocation, String createdBy) {
		
		return epcProductLocationRepository.modifyProductLocation(productLocation);
		}

	/**
	 * @param productLocation
	 * @param createdBy
	 * @return
	 */
	EpcProductLocation createProductLocation(EpcProductLocation productLocation, String createdBy) {
		productLocation.setCreatedBy(createdBy);
		productLocation.setCreatedDate(new Date());
		/*productLocation.setEndDate(new Date());
		productLocation.setStartDate(new Date());*/
		logger.info("indside create2");
		epcProductLocationRepository.save(productLocation);
		logger.info("indside create3");
		return productLocation;
	}


}
