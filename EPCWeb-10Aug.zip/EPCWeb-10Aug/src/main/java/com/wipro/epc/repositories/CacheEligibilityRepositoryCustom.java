package com.wipro.epc.repositories;

import java.util.List;
import com.wipro.epc.domain.CacheEligibility;

public interface CacheEligibilityRepositoryCustom {
	
	List<CacheEligibility> getList(String query);

}
