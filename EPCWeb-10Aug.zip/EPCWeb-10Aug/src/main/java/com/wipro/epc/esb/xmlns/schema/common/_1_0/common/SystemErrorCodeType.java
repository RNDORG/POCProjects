
package com.wipro.epc.esb.xmlns.schema.common._1_0.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SystemErrorCodeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SystemErrorCodeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="TNM-SYSERR-TRP001"/>
 *     &lt;enumeration value="TNM-SYSERR-TRP002"/>
 *     &lt;enumeration value="TNM-SYSERR-TRP003"/>
 *     &lt;enumeration value="TNM-SYSERR-TRP004"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SystemErrorCodeType")
@XmlEnum
public enum SystemErrorCodeType {

    @XmlEnumValue("TNM-SYSERR-TRP001")
    TNM_SYSERR_TRP_001("TNM-SYSERR-TRP001"),
    @XmlEnumValue("TNM-SYSERR-TRP002")
    TNM_SYSERR_TRP_002("TNM-SYSERR-TRP002"),
    @XmlEnumValue("TNM-SYSERR-TRP003")
    TNM_SYSERR_TRP_003("TNM-SYSERR-TRP003"),
    @XmlEnumValue("TNM-SYSERR-TRP004")
    TNM_SYSERR_TRP_004("TNM-SYSERR-TRP004");
    private final String value;

    SystemErrorCodeType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SystemErrorCodeType fromValue(String v) {
        for (SystemErrorCodeType c: SystemErrorCodeType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
