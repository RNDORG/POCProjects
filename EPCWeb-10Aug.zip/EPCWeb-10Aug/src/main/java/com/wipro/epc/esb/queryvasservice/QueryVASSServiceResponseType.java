
package com.wipro.epc.esb.queryvasservice;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.CustomRefType;
import com.wipro.epc.esb.xmlns.schema.common._1_0.common.TransactionReferenceType;


/**
 * <p>Java class for QueryVASSServiceResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="QueryVASSServiceResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}TransactionReference" minOccurs="0"/>
 *         &lt;element name="MSISDN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Current_Subscriptions" type="{http://www.telenor.com.mm/QueryVASService}Current_SubscriptionsType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}CustomRef" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryVASSServiceResponseType", propOrder = {
    "transactionReference",
    "msisdn",
    "currentSubscriptions",
    "status",
    "customRef"
})
public class QueryVASSServiceResponseType {

    @XmlElement(name = "TransactionReference", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected TransactionReferenceType transactionReference;
    @XmlElement(name = "MSISDN")
    protected String msisdn;
    @XmlElement(name = "Current_Subscriptions")
    protected List<CurrentSubscriptionsType> currentSubscriptions;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "CustomRef", namespace = "http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd")
    protected CustomRefType customRef;

    /**
     * Gets the value of the transactionReference property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionReferenceType }
     *     
     */
    public TransactionReferenceType getTransactionReference() {
        return transactionReference;
    }

    /**
     * Sets the value of the transactionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionReferenceType }
     *     
     */
    public void setTransactionReference(TransactionReferenceType value) {
        this.transactionReference = value;
    }

    /**
     * Gets the value of the msisdn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSISDN() {
        return msisdn;
    }

    /**
     * Sets the value of the msisdn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSISDN(String value) {
        this.msisdn = value;
    }

    /**
     * Gets the value of the currentSubscriptions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the currentSubscriptions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCurrentSubscriptions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrentSubscriptionsType }
     * 
     * 
     */
    public List<CurrentSubscriptionsType> getCurrentSubscriptions() {
        if (currentSubscriptions == null) {
            currentSubscriptions = new ArrayList<CurrentSubscriptionsType>();
        }
        return this.currentSubscriptions;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the customRef property.
     * 
     * @return
     *     possible object is
     *     {@link CustomRefType }
     *     
     */
    public CustomRefType getCustomRef() {
        return customRef;
    }

    /**
     * Sets the value of the customRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomRefType }
     *     
     */
    public void setCustomRef(CustomRefType value) {
        this.customRef = value;
    }

}
