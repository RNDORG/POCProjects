package com.wipro.epc.repositories;

import java.util.List;


import com.wipro.epc.domain.EpcNotificationTemplateDetail;



/**
 * @author KE334465
 *
 */
public interface EpcNotificationTemplateDetailRepositoryCustom {

	
	/**
	 * modifies the table notification_template_detail with new detial object
	 * @param detail
	 * @return
	 */
	EpcNotificationTemplateDetail modifyNotificationTemplateDetail(EpcNotificationTemplateDetail detail);
	
	/**
	 * executes the given query, and gets the list from the table notification_template_detail
	 * @param query
	 * @return
	 */
	List<EpcNotificationTemplateDetail> getList(String query);
}
