package com.wipro.epc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.repositories.EpcProductSpecificationRepository;

@RestController
public class PTTestController {
	
	@Autowired
	EpcProductSpecificationRepository epcProductSpecificationRepository;
	
	@RequestMapping(value="/rest/extapi/v1/ptTest", method=RequestMethod.GET)
	public String pTTest(@RequestParam (value="name", required=true) String name,
			@RequestParam (value="msgType",required=true) String msgType)
	{
		String result="";
		if(msgType.equalsIgnoreCase("nodb")) {
			return "No DB call";
		}
		else {
			result = epcProductSpecificationRepository.getProcedureForPTtest(name,msgType);
		}
		
			// TODO Auto-generated catch block
		//	result=e.getMessage();
			
		
		return result;
	}
}
