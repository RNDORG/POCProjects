package com.wipro.epc.services;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.gs.util.CommonUtils;
import com.wipro.epc.domain.EpcProductAvailability;
import com.wipro.epc.exception.EPCException;
import com.wipro.epc.uam.definitions.MetaInfo;


/**
 * @author KE334465
 *
 */
@Service
public class EpcProductAvailabilityService {
	private static Logger logger = LoggerFactory.getLogger(EpcProductAvailabilityService.class);

	/**
	 * 
	 */
	@Autowired
	private com.wipro.epc.repositories.EpcProductAvailabilityRepository epcProductAvailabilityRepository;

	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<EpcProductAvailability> searchAvailabilities(Map<String, List<String>> allRequestParams) {
		if (allRequestParams.get("with") != null) {
			allRequestParams.remove("with");
		}
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,
				EpcProductAvailability.class.getName(), null);
		List<EpcProductAvailability> listOfAvailabilitiesReturned = null;
		try {
			listOfAvailabilitiesReturned = epcProductAvailabilityRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new EPCException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
		
		return listOfAvailabilitiesReturned;
		
	}



	
	/**
	 * @param ProductAvailabilityList
	 * @param createdBy
	 * @return
	 */
	@Transactional
	public List<EpcProductAvailability> manageProductAvailabilities(List<EpcProductAvailability> ProductAvailabilityList, String createdBy )
	{
		//List<EpcProductAvailability> retListOfEpcProductAvailability = new ArrayList<EpcProductAvailability>();

		for (EpcProductAvailability productAvailability : ProductAvailabilityList) {
			
				productAvailability = manageProductAvailability(productAvailability, createdBy);
				if((productAvailability.getMetaInfo().get("STATUS")==null))
				{
					productAvailability.getMetaInfo().put(MetaInfo.STATUS, MetaInfo.SUCCESS);
				}
			
			
			//retListOfEpcProductAvailability.add(productAvailability);
		}
		return ProductAvailabilityList;
	}
	
	/**
	 * @param productAvailability
	 * @param createdBy
	 * @return
	 */
	EpcProductAvailability manageProductAvailability(EpcProductAvailability productAvailability, String createdBy)
	{
		EpcProductAvailability retProductAvailability = null;
		switch (productAvailability.getMetaInfo().get("OPERATION")) {

		case "CREATE":
			createProductAvailability(productAvailability, createdBy);
			break;
		case "UPDATE":
			modifyProductAvailability(productAvailability, createdBy);
			break;
		case "DELETE":
			deleteProductAvailability(productAvailability);
			break;
		default:
			throw new EPCException("not supported");
		}
		return productAvailability;
		
	}
	/**
	 * @param ProductAvailability
	 * @return
	 */
	EpcProductAvailability deleteProductAvailability(EpcProductAvailability ProductAvailability) {
		
		epcProductAvailabilityRepository.delete(ProductAvailability.getProductAvailabilityId());
		return ProductAvailability;
	}

	/**
	 * @param ProductAvailability
	 * @param lastUpdatedBy
	 * @return
	 */
	EpcProductAvailability modifyProductAvailability(EpcProductAvailability ProductAvailability, String lastUpdatedBy) {
		ProductAvailability.setModifiedBy(lastUpdatedBy);
		return epcProductAvailabilityRepository.modifyProductAvailability(ProductAvailability);
	}

	/**
	 * @param ProductAvailability
	 * @param createdBy
	 * @return
	 */
	EpcProductAvailability createProductAvailability(EpcProductAvailability ProductAvailability, String createdBy) {
		ProductAvailability.setCreatedBy(createdBy);
		ProductAvailability.setCreatedDate(new Date());
		epcProductAvailabilityRepository.save(ProductAvailability);
		return ProductAvailability;
	}




	/**
	 * @return
	 */
	public static Logger getLogger() {
		return logger;
	}




	/**
	 * @param logger
	 */
	public static void setLogger(Logger logger) {
		EpcProductAvailabilityService.logger = logger;
	}




	/**
	 * @return
	 */
	public com.wipro.epc.repositories.EpcProductAvailabilityRepository getEpcProductAvailabilityRepository() {
		return epcProductAvailabilityRepository;
	}




	/**
	 * @param epcProductAvailabilityRepository
	 */
	public void setEpcProductAvailabilityRepository(
			com.wipro.epc.repositories.EpcProductAvailabilityRepository epcProductAvailabilityRepository) {
		this.epcProductAvailabilityRepository = epcProductAvailabilityRepository;
	}

}
