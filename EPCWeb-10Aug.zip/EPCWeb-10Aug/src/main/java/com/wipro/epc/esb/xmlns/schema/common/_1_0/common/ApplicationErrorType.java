
package com.wipro.epc.esb.xmlns.schema.common._1_0.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ApplicationErrorType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ApplicationErrorType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}BaseErrorInfoType">
 *       &lt;sequence>
 *         &lt;element name="ErrorCode" type="{http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd}ApplicationErrorCodeType"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApplicationErrorType", propOrder = {
    "errorCode"
})
public class ApplicationErrorType
    extends BaseErrorInfoType
{

    @XmlElement(name = "ErrorCode", required = true)
    @XmlSchemaType(name = "string")
    protected ApplicationErrorCodeType errorCode;

    /**
     * Gets the value of the errorCode property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationErrorCodeType }
     *     
     */
    public ApplicationErrorCodeType getErrorCode() {
        return errorCode;
    }

    /**
     * Sets the value of the errorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationErrorCodeType }
     *     
     */
    public void setErrorCode(ApplicationErrorCodeType value) {
        this.errorCode = value;
    }

}
