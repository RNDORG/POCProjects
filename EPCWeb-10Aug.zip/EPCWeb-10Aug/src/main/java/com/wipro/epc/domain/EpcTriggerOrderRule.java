package com.wipro.epc.domain;


import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the epc_trigger_order_rule database table.
 * 
 * @author VI251443
 * @version 1.0
 */
@Entity
@Table(name="epc_trigger_order_rule")
@NamedQuery(name="EpcTriggerOrderRule.findAll", query="SELECT e FROM EpcTriggerOrderRule e")
public class EpcTriggerOrderRule  implements Serializable  {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="trigger_order_rule_id")
	private Integer triggerOrderRuleId;

	@JsonIgnore
	@Column(name="created_by")
	private String createdBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="created_date")
	private Date createdDate;

	@JsonIgnore
	@Column(name="modified_by")
	private String modifiedBy;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="rule_validation_duration")
	private Integer ruleValidationDuration;

	@Column(name="rule_validation_duration_uom")
	private String ruleValidationDurationUom;

	@Column(name="source_order_type")
	private String sourceOrderType;
	
	@Column(name="source_product_classification")
	private String sourceProductClassification;

	@Column(name="source_product_short_code")
	private String sourceProductShortCode;

	@Column(name="source_product_sub_family")
	private String sourceProductSubFamily;
	
	private String status;

	@Column(name="subscription_within_duration")
	private Integer subscriptionWithinDuration;

	@Column(name="subscription_within_duration_uom")
	private String subscriptionWithinDurationUom;

	@Column(name="triggered_order_type")
	private String triggeredOrderType;
	
	@Column(name="triggered_product_classification")
	private String triggeredProductClassification;

	@Column(name="triggered_product_short_code")
	private String triggeredProductShortCode;

	@Column(name="triggered_product_sub_family")
	private String triggeredProductSubFamily;
	
	@Transient
	private Map<String,String> metaInfo;

	/**
	 * 
	 */
	public EpcTriggerOrderRule() 
	{
	}

	/**
	 * @return
	 */
	public Map<String, String> getMetaInfo() {
		return metaInfo;
	}

	/**
	 * @param metaInfo
	 */
	public void setMetaInfo(Map<String, String> metaInfo) {
		this.metaInfo = metaInfo;
	}


	/**
	 * Getter for TriggerOrderRuleId
	 * @return
	 */
	public Integer getTriggerOrderRuleId() {
		return this.triggerOrderRuleId;
	}

	/**
	 * Setter for TriggerOrderRuleId
	 * @param triggerOrderRuleId
	 */
	public void setTriggerOrderRuleId(Integer triggerOrderRuleId) {
		this.triggerOrderRuleId = triggerOrderRuleId;
	}

	/**
	 * Getter for CreatedBy
	 * @return
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * Setter for CreatedBy
	 * @param createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Getter for  CreatedDate
	 * @return
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * Setter for CreatedDate
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Getter for ModifiedDate
	 * @return
	 */
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * Setter for ModifiedDate
	 * @param modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * Getter for ModifiedDate
	 * @return
	 */
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	/**
	 * Setter for ModifiedDate
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * Getter for RuleValidationDuration
	 * @return
	 */
	public Integer getRuleValidationDuration() {
		return this.ruleValidationDuration;
	}

	/**
	 * Setter for RuleValidationDuration
	 * @param ruleValidationDuration
	 */
	public void setRuleValidationDuration(Integer ruleValidationDuration) {
		this.ruleValidationDuration = ruleValidationDuration;
	}

	/**
	 * Getter for RuleValidationDurationUom
	 * @return
	 */
	public String getRuleValidationDurationUom() {
		return this.ruleValidationDurationUom;
	}

	/**
	 * Setter for RuleValidationDurationUom
	 * @param ruleValidationDurationUom
	 */
	public void setRuleValidationDurationUom(String ruleValidationDurationUom) {
		this.ruleValidationDurationUom = ruleValidationDurationUom;
	}

	/**
	 * Getter for SourceOrderType
	 * @return
	 */
	public String getSourceOrderType() {
		return this.sourceOrderType;
	}

	/**
	 * Setter for SourceOrderType
	 * @param sourceOrderType
	 */
	public void setSourceOrderType(String sourceOrderType) {
		this.sourceOrderType = sourceOrderType;
	}

	/**
	 * Getter for SourceProductClassification
	 * @return
	 */
	public String getSourceProductClassification() {
		return this.sourceProductClassification;
	}

	/**
	 * Setter for SourceProductClassification
	 * @param sourceProductClassification
	 */
	public void setSourceProductClassification(String sourceProductClassification) {
		this.sourceProductClassification = sourceProductClassification;
	}

	/**
	 * Getter for SourceProductShortCode
	 * @return
	 */
	public String getSourceProductShortCode() {
		return this.sourceProductShortCode;
	}

	/**
	 * setter for SourceProductShortCode
	 * @param sourceProductShortCode
	 */
	public void setSourceProductShortCode(String sourceProductShortCode) {
		this.sourceProductShortCode = sourceProductShortCode;
	}

	/**
	 * Getter for SourceProductSubFamily
	 * @return
	 */
	public String getSourceProductSubFamily() {
		return this.sourceProductSubFamily;
	}

	/**
	 * Setter for SourceProductSubFamily
	 * @param sourceProductSubFamily
	 */
	public void setSourceProductSubFamily(String sourceProductSubFamily) {
		this.sourceProductSubFamily = sourceProductSubFamily;
	}

	/**
	 * Getter for status
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * Setter for status
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Getter for SubscriptionWithinDuration
	 * @return
	 */
	public Integer getSubscriptionWithinDuration() {
		return this.subscriptionWithinDuration;
	}

	/**
	 * Setter for SubscriptionWithinDuration
	 * @param subscriptionWithinDuration
	 */
	public void setSubscriptionWithinDuration(Integer subscriptionWithinDuration) {
		this.subscriptionWithinDuration = subscriptionWithinDuration;
	}

	/**
	 * Getter for SubscriptionWithinDurationUom
	 * @return
	 */
	public String getSubscriptionWithinDurationUom() {
		return this.subscriptionWithinDurationUom;
	}

	/**
	 * Setter for SubscriptionWithinDurationUom
	 * @param subscriptionWithinDurationUom
	 */
	public void setSubscriptionWithinDurationUom(String subscriptionWithinDurationUom) {
		this.subscriptionWithinDurationUom = subscriptionWithinDurationUom;
	}

	/**
	 * Getter for TriggeredOrderType
	 * @return
	 */
	public String getTriggeredOrderType() {
		return this.triggeredOrderType;
	}

	/**
	 * Setter for TriggeredOrderType
	 * @param triggeredOrderType
	 */
	public void setTriggeredOrderType(String triggeredOrderType) {
		this.triggeredOrderType = triggeredOrderType;
	}

	/**
	 * Getter for TriggeredProductClassification
	 * @return
	 */
	public String getTriggeredProductClassification() {
		return this.triggeredProductClassification;
	}

	/**
	 * Setter for TriggeredProductClassification
	 * @param triggeredProductClassification
	 */
	public void setTriggeredProductClassification(String triggeredProductClassification) {
		this.triggeredProductClassification = triggeredProductClassification;
	}

	/** 
	 * Getter for TriggeredProductShortCode
	 * @return
	 */
	public String getTriggeredProductShortCode() {
		return this.triggeredProductShortCode;
	}

	/**
	 * Setter for TriggeredProductShortCode
	 * @param triggeredProductShortCode
	 */
	public void setTriggeredProductShortCode(String triggeredProductShortCode) {
		this.triggeredProductShortCode = triggeredProductShortCode;
	}

	/**
	 * Getter for TriggeredProductSubFamily
	 * @return
	 */
	public String getTriggeredProductSubFamily() {
		return this.triggeredProductSubFamily;
	}

	/**
	 * Setter for TriggeredProductSubFamily
	 * @param triggeredProductSubFamily
	 */
	public void setTriggeredProductSubFamily(String triggeredProductSubFamily) {
		this.triggeredProductSubFamily = triggeredProductSubFamily;
	}
}