package com.wipro.epc.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.wipro.common.gs.util.ServerDetails;
import com.wipro.epc.domain.BroadcastLogs;
import com.wipro.epc.repositories.BroadcastLogsRepository;

@Service
public class BroadcastService {
	private static Logger logger = LoggerFactory.getLogger(BroadcastService.class);
	
	@Autowired
	InstanceManagerService instanceManagerService;
	
	@Autowired
	ServerDetails serverDetails;
	
	@Autowired
	BroadcastLogsService broadcastLogsService;
	
	@Autowired
	BroadcastLogsRepository broadcastLogsRepository;
	
	public Map<String,String> getReplyService(MultiValueMap<String,String> allRequestParams){
		
		String urlForBroadcast = allRequestParams.toString();
		logger.info("The url is "+urlForBroadcast);
	
		String targetApi="/rest/extapi/v1";
		
		if(allRequestParams.get("api")==null || ((List<String>)allRequestParams.get("api")).get(0).isEmpty() ){
			
			logger.info("getReplyService() : "+" #Broadcast: Missing Mandatory fields to broadcast API. Mandatory fields [ to, api ] ");
			throw new RuntimeException("Broadcast: Missing Mandatory field to broadcast API. Mandatory fields [ to, api ] "); 
		
		}else if(allRequestParams.get("to")==null || ((List<String>)allRequestParams.get("to")).get(0).isEmpty()){
			
			logger.info("getReplyService : "+" #Broadcast: Missing Mandatory fields to broadcast API. Mandatory fields [ to, api ] ");
			throw new RuntimeException("Broadcast: Missing Mandatory fields to broadcast API. Mandatory fields [ to, api ] "); 
		
		}else{
			
			if(! ( (List<String>)allRequestParams.get("api") ).get(0).equalsIgnoreCase("broadcast") ){
				targetApi=targetApi+"/"+((List<String>) allRequestParams.get("api")).get(0);
			}
			
			String toValue = ((List<String>) allRequestParams.get("to")).get(0);
			String[] targetIpPort=instanceManagerService.getIpPort(toValue);
			
			if(targetIpPort.length>0){
				for(int i=0; i<targetIpPort.length; i++) {
				
					targetIpPort[i] = targetIpPort[i].trim();
					logger.info("Target ip port is "+targetIpPort[i]);
				}
			}else{
				throw new RuntimeException("Broadcast: no valid IP address found "); 
			}

			allRequestParams.remove("api");
			allRequestParams.remove("to");
			
			Iterator<String> it = allRequestParams.keySet().iterator();
			int count=0;
			while(it.hasNext()){
				
				String key=it.next();
				if(count<1) {
					targetApi=targetApi+"?"+key+"="+((List<String>)allRequestParams.get(key)).get(0);
				} else {
					targetApi=targetApi+"&"+key+"="+((List<String>)allRequestParams.get(key)).get(0);
				}
				count++;
			}
			
			Map<String,String> resp = instanceManagerService.notifyAll(targetApi,targetIpPort);
			
			
			BroadcastLogs broadcast = new BroadcastLogs();
			broadcast.setBroadcastTimestamp(new Date());
			broadcast.setResponse(resp.toString());
			broadcast.setBroadcastedFrom(serverDetails.getManagedSeverName());
			broadcast.setUrl(urlForBroadcast);
			
			broadcastLogsService.insertToBroadCastLog(broadcast);
			logger.info("#BroadCast Response : "+resp);
			return resp;
			}

		
	}



	public List<String> getBroadcastsService() {

		List<BroadcastLogs> broadCasts =  broadcastLogsRepository.findBroadCasts();
		List<String> returnList = new ArrayList<String>();
		for(BroadcastLogs log: broadCasts){
			returnList.add(log.getId().toString());
		}
		return returnList;
	}



	public List<BroadcastLogs> getBroadcastsByIdService(MultiValueMap allRequestParams) {

		List<String> ids = (List<String>) allRequestParams.get("id");
		List<BroadcastLogs> broadcastList = new ArrayList<BroadcastLogs>();
		if(ids!=null && ids.size()>0) {
		
		for(String id: ids) {
			
			broadcastList.add(broadcastLogsRepository.findOne(Integer.parseInt(id)));
		}
		return broadcastList;
		} else {
			broadcastList.add(broadcastLogsRepository.findTheRecentOne());
			return (broadcastList);
		}
	}

}
