package com.wipro.epc.controller;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.domain.EpcAttributeMaster;
import com.wipro.epc.services.EpcAttributeMasterService;


/**
 * @author Developer
 * @version 1.0
 * type EpcAttributeMasterController
 */
@RestController
public class EpcAttributeMasterController {
	
/**
 * EpcAttributeMasterService EpcAttributeMasterController.java
 */
@Autowired
EpcAttributeMasterService epcAttributeMasterService;
	
/**
 * Logger EpcAttributeMasterController.java
 */
private static Logger logger = LoggerFactory.getLogger(EpcAttributeMasterController.class);

/**
 * @param allRequestParams
 * @return
 */
@RequestMapping(value="rest/extapi/v1/productChars" , method=RequestMethod.GET)
public List<EpcAttributeMaster> searchCharExt(@RequestParam MultiValueMap allRequestParams)
{
			return epcAttributeMasterService.searchChar(allRequestParams);
}

//*******************************************************************************************************************

/**
 * @param charList
 * @return
 */
@RequestMapping(value="rest/extapi/v1/productChars" , method=RequestMethod.POST)
public List<EpcAttributeMaster> updateCharExt(@RequestBody List<EpcAttributeMaster> charList){
	
	String user = SecurityContextHolder.getContext().getAuthentication().getName();
	//System.out.println(user + "--------------------");
	
		return epcAttributeMasterService.updateCharacteristics(charList, user);
	
}


/**
 * @param allRequestParams
 * @return
 */
@RequestMapping(value="rest/api/v1/productChars" , method=RequestMethod.GET)
public List<EpcAttributeMaster> searchChar(@RequestParam MultiValueMap allRequestParams)
{
			return epcAttributeMasterService.searchChar(allRequestParams);
}

/**
 * @param attributeName
 * @param attributeDataType
 * @param attributeCtg
 * @param attributeCtgType
 * @return
 */
@RequestMapping(value="rest/api/v1/productCharsFromUI" , method=RequestMethod.GET)
public List<EpcAttributeMaster> searchCharFromUI(
		@RequestParam(value="attribute_name", required = false) String attributeName, @RequestParam(value="attribute_data_type", required = false)  String attributeDataType,
		@RequestParam(value="attribute_ctg", required = false)  String attributeCtg,@RequestParam(value="attribute_ctg_type", required = false)  String attributeCtgType)
{
	////System.out.println("Controller reached with values "+allRequestParams);
			return epcAttributeMasterService.searchCharFromUI(attributeName, attributeDataType, attributeCtg,attributeCtgType);
}
//*******************************************************************************************************************

/**
 * @param charList
 * @return
 */
@RequestMapping(value="rest/api/v1/productChars" , method=RequestMethod.POST)
public List<EpcAttributeMaster> updateChar(@RequestBody List<EpcAttributeMaster> charList){
	
	String user = SecurityContextHolder.getContext().getAuthentication().getName();
	//System.out.println(user + "--------------------");
	
		return epcAttributeMasterService.updateCharacteristics(charList, user);
	
}

/**
 * @return
 */
@RequestMapping(value="rest/api/v1/productCharsName" , method=RequestMethod.GET)
public List<String> searchCharName()
{
			return epcAttributeMasterService.searchCharName();
}

}
