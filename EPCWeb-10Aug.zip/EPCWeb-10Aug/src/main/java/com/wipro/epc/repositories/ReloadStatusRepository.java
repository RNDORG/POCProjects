package com.wipro.epc.repositories;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.epc.domain.ReloadStatus;


@Repository
public interface ReloadStatusRepository extends CrudRepository<ReloadStatus, Integer>,
ReloadStatusRepositoryCustom{

	@Query(value = "select remarks from reload_status where id = :id", nativeQuery=true)
	String getRemarksToAppend(@Param("id") Integer id);
	
	ReloadStatus getReloadStatusById(@Param("id") Integer id);
	
	@Modifying
	@Query(value ="update reload_status set status=:status, remarks=:remarks "
			+ ", modified_date=current_timestamp() where id = :id ", nativeQuery=true)
	Integer updateReloadStatus(@Param("id") Integer id,@Param("status") String status, @Param("remarks") String remarks);
	
	@Query(value = "select max(id) from reload_status", nativeQuery=true)
	Integer getMaxId();
	
	@Query(value = "select count(*) from reload_status where lower(request)=lower(:reqId) and modified_date>=TIMESTAMPADD(minute,-:gap,current_timestamp);", nativeQuery=true)
	Integer countReloadEntryOfRequestBeforeMinutes(@Param("reqId") String requestId, @Param("gap") Integer minuteGap);
}
