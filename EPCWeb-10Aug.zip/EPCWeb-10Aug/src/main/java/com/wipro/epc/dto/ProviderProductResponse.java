package com.wipro.epc.dto;

import com.wipro.epc.domain.EpcProductSpecification;

/**
 * @author Developer
 * @version 1.0
 * type ProviderProductResponse
 */
public class ProviderProductResponse {

	/**
	 * String ProviderProductResponse.java
	 */
	private String providerProductId;
	/**
	 * String ProviderProductResponse.java
	 */
	private String providerSystem;
	/**
	 * Boolean ProviderProductResponse.java
	 */
	private Boolean isUnsubsAllowedFromCRM;
	/**
	 * String ProviderProductResponse.java
	 */
	private String remarks;
	/**
	 * EpcProductSpecification ProviderProductResponse.java
	 */
	private EpcProductSpecification epcProductSpecification;
	
	
	/**
	 * @return
	 */
	public String getProviderProductId() {
		return providerProductId;
	}
	/**
	 * @param providerProductId
	 */
	public void setProviderProductId(String providerProductId) {
		this.providerProductId = providerProductId;
	}
	/**
	 * @return
	 */
	public String getProviderSystem() {
		return providerSystem;
	}
	/**
	 * @param providerSystem
	 */
	public void setProviderSystem(String providerSystem) {
		this.providerSystem = providerSystem;
	}
	/**
	 * @return
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	/**
	 * @return
	 */
	public EpcProductSpecification getEpcProductSpecification() {
		return epcProductSpecification;
	}
	/**
	 * @param epcProductSpecification
	 */
	public void setEpcProductSpecification(
			EpcProductSpecification epcProductSpecification) {
		this.epcProductSpecification = epcProductSpecification;
	}
	/**
	 * @return
	 */
	public Boolean getIsUnsubsAllowedFromCRM() {
		return isUnsubsAllowedFromCRM;
	}
	/**
	 * @param isUnsubsAllowedFromCRM
	 */
	public void setIsUnsubsAllowedFromCRM(Boolean isUnsubsAllowedFromCRM) {
		this.isUnsubsAllowedFromCRM = isUnsubsAllowedFromCRM;
	}
	

}
