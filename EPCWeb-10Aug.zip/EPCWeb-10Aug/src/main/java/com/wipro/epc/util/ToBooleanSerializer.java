package com.wipro.epc.util;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.wipro.epc.services.EpcLookupMasterService;

/**
 * @author Developer
 * @version 1.0
 * type ToBooleanSerializer
 */
public class ToBooleanSerializer extends StdSerializer<Byte> {
	/**
	 * 
	 */
	protected ToBooleanSerializer() {
		super(Byte.class);
		// TODO Auto-generated constructor stub
	}

	/**
	 * EpcLookupMasterService ToBooleanSerializer.java
	 */
	@Autowired
	EpcLookupMasterService epcLookupMasterService;
	
    /* (non-Javadoc)
     * @see com.fasterxml.jackson.databind.ser.std.StdSerializer#serialize(java.lang.Object, com.fasterxml.jackson.core.JsonGenerator, com.fasterxml.jackson.databind.SerializerProvider)
     */
    @Override
    public void serialize(Byte value, JsonGenerator jgen, SerializerProvider provider)
        throws IOException, JsonGenerationException
    {
    	boolean flag = ((value) == 0) ? false : true;
    	jgen.writeBoolean(flag);
    }
}