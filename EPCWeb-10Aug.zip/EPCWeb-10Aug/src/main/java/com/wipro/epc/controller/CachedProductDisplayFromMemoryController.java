package com.wipro.epc.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.epc.services.CachedProductDisplayFromMemoryService;


@RestController
public class CachedProductDisplayFromMemoryController {
	
	@Autowired
	CachedProductDisplayFromMemoryService memoryService;

	@RequestMapping(value="/rest/extapi/v1/cache/product/memoryLocal/dump", method=RequestMethod.GET)
	public String displayMemory(@RequestParam(value="id",required=true)  String ids){
	String[] id=ids.split(",");
		return memoryService.DisplayFromMemory( id);
	}
	
	@RequestMapping(value="/rest/extapi/v1/cache/product/memory", method=RequestMethod.GET)
	public Map<String,String> DisplayMemoryInfo(){
		return memoryService.memoryInfo();
	}
	
	@RequestMapping(value="/rest/extapi/v1/cache/product/memoryLocal", method=RequestMethod.GET)
	public String DisplayLocalMemoryInfo(){
		return memoryService.memoryLocalInfo();
	}
}	
