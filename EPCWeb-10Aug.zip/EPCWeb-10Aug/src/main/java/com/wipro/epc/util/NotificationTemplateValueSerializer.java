package com.wipro.epc.util;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.wipro.epc.services.EpcNotificationTemplateService;

/**
 * @author Developer
 * @version 1.0
 * type NotificationTemplateValueSerializer
 */
public class NotificationTemplateValueSerializer extends ToStringSerializer {
	
	/**
	 * EpcNotificationTemplateService NotificationTemplateValueSerializer.java
	 */
	@Autowired
	EpcNotificationTemplateService epcNotificationTemplateService;
	
    /* (non-Javadoc)
     * @see com.fasterxml.jackson.databind.ser.std.ToStringSerializer#serialize(java.lang.Object, com.fasterxml.jackson.core.JsonGenerator, com.fasterxml.jackson.databind.SerializerProvider)
     */
    @Override
	public void serialize(Object value, JsonGenerator jgen, SerializerProvider provider)
			throws IOException, JsonGenerationException
        
    {
        jgen.writeString(epcNotificationTemplateService.getLookupValue((Integer)value).getTemplateName());
    }

}
