package com.wipro.epc.uam.definitions;



/**
 * @author KE334465
 *
 */
public class MetaInfo {
	/**
	 * STATUS
	 */
	public static final String STATUS = "STATUS";
	/**
	 * SUCCESS
	 */
	public static final String SUCCESS = "SUCCESS";
	/**
	 * ERROR
	 */
	public static final String ERROR = "ERROR";
	/**
	 * ERROR_MESSAGE
	 */
	public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
	/**
	 * USER_EXISTS
	 */
	public static final String USER_EXISTS = "USER ALREADY EXISTS OR USERNAME ALREADY RESERVED, PLEASE TRY WITH DIFFERENT USERNAME";
	
}
