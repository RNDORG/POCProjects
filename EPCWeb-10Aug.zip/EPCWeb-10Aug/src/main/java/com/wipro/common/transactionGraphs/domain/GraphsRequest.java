package com.wipro.common.transactionGraphs.domain;

/**
 * @author Developer
 * @version 1.0
 * type GraphsRequest
 */
public class GraphsRequest {
/**
 * String GraphsRequest.java
 */
String to;
/**
 * String GraphsRequest.java
 */
String from;
/**
 * String GraphsRequest.java
 */
String num;
/**
 * @return
 */
public String getTo() {
	return to;
}
/**
 * @param to
 */
public void setTo(String to) {
	this.to = to;
}
/**
 * @return
 */
public String getFrom() {
	return from;
}
/**
 * @param from
 */
public void setFrom(String from) {
	this.from = from;
}
/**
 * @return
 */
public String getNum() {
	return num;
}
/**
 * @param num
 */
public void setNum(String num) {
	this.num = num;
}

}
