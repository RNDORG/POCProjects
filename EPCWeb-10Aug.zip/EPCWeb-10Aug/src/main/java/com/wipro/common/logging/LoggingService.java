package com.wipro.common.logging;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.wipro.common.config.domain.Config;
import com.wipro.common.config.service.ConfigService;
import com.wipro.common.config.service.ReloadListener;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.FileAppender;


@Service
public class LoggingService implements ReloadListener {
	
@Autowired
ConfigService configService;

@PostConstruct 
void postConstruct() {
	configService.addListener(this);
}

/*	static org.apache.log4j.core.Logger coreLogger =    
			(org.apache.logging.log4j.core.Logger)LogManager.getLogger(LoggingService.class.getName());
			static LoggerContext context = (LoggerContext)coreLogger.getContext();
	static BaseConfiguration configuration = (BaseConfiguration)context.getConfiguration();	*/
	Logger  logger1 = (Logger) LoggerFactory.getLogger(LoggingService.class);
	Logger  root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
	
	
	public String setLoggingLevel(String loggingLevel)
	{
		
		if (loggingLevel.equalsIgnoreCase("INFO")) {
			   root.setLevel(Level.INFO);
			}
		else if (loggingLevel.equalsIgnoreCase("ERROR")) {
			  root.setLevel(Level.ERROR);
			}
		else if (loggingLevel.equalsIgnoreCase("WARN")) {
			  root.setLevel(Level.WARN);
			}
		else if (loggingLevel.equalsIgnoreCase("TRACE")) {
			  root.setLevel(Level.TRACE);
			}
		else if (loggingLevel.equalsIgnoreCase("DEBUG")) {
			  root.setLevel(Level.DEBUG);
			}
		else {
			return "Wrong logging level has been set";
		}
		//String level=root.getLevel().toString();
		root.info("INFO LEVEL "+loggingLevel);
		root.debug("DEBUG LEVEL "+loggingLevel);
		root.error(loggingLevel);
		return "Logger level changed to : "+loggingLevel;
	}
	
	public String getLoggerLevel()
	{
		Logger  root1 = (Logger) LoggerFactory.getLogger(org.slf4j.Logger.ROOT_LOGGER_NAME);
		String level=root1.getLevel().toString();
		return level;
	}
	
	
	public String modifyFileAppender(String appenderName,Boolean isAppend)
	{
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
		  ch.qos.logback.classic.Logger logbackLogger = lc.getLogger(LoggingService.class);
		  logbackLogger.info("appendder name..... "+appenderName);
		FileAppender<ILoggingEvent> fileAppender =
                (FileAppender<ILoggingEvent>) logbackLogger.getAppender(appenderName);
		logbackLogger.addAppender(fileAppender);
           // if(fileAppender != null) {
              fileAppender.stop();
             
            //}
              logbackLogger.info("appendder name "+appenderName);
              logbackLogger.info("isAppend "+isAppend);
		

	
	return null;
	}


	@Override
	public void onReload(List<Config> oldConfig, List<Config> newConfig) {
		String group="LoggingService";
		String key="LoggingLevel";
		String oldLoggingLevelValue = configService.searchConfigKey(oldConfig,group,key).getConfigValue();
		String newLoggingLevelValue = configService.searchConfigKey(newConfig,group,key).getConfigValue();
		if (oldLoggingLevelValue!=null && newLoggingLevelValue!=null && !oldLoggingLevelValue.equals(newLoggingLevelValue))  {
			//System.out.println("Log level changed to "+newLoggingLevelValue);
			setLoggingLevel(newLoggingLevelValue);
		}	
	}
	
	
	public Map<String,String> findAllLoggersWithAppenders() {
	     LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
	     Map<String,String> strList = new HashMap<String, String>(); 
	      for (ch.qos.logback.classic.Logger log : lc.getLoggerList()) 
	      {
	       if(log.getLevel() != null || hasAppenders(log))
	       {
	    	  strList.put(log.getName(), log.getLevel().toString());
	       }
	     }
	     return strList;
	   }

	   boolean hasAppenders(ch.qos.logback.classic.Logger logger) {
	     Iterator<Appender<ILoggingEvent>> it = logger.iteratorForAppenders();
	     return it.hasNext();
	   }
	   
	   public Map<String,String> findAllLoggersWithNWithoutAppenders() {
			 String result="";
			 Map<String,String> strList = new HashMap<String, String>(); 
			 LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
		     for (ch.qos.logback.classic.Logger log : lc.getLoggerList())
		     {
		    	 result=result + "name : "+log.getName()+" || level : "+log.getLevel()+"\n";
		    	 if(log.getLevel()==null)
		    	 {
		    	 strList.put(log.getName(), null);
		    	 }
		    	 else
		    	 {
		    		 strList.put(log.getName(), log.getLevel().toString());
		    	 }
		     }
		   return strList;
		 }
	   
	   public Map<String,String> changeLoggingLevels(MultiValueMap allRequestParams)
	   {
		   Map<String,String> finalRes=new HashMap<String,String>();
		   String level="";
		   Logger log;
		   Map<String,String> result=findAllLoggersWithNWithoutAppenders();
			Set<String> validLoggers = result.keySet();
			Iterator it = allRequestParams.entrySet().iterator();
			 while (it.hasNext())
			 {
			        Map.Entry pair = (Map.Entry)it.next(); 
			        List<String> values =  (List<String>) pair.getValue();
			        String key = pair.getKey().toString();
			        if(validLoggers.contains(key) && !values.isEmpty())
			        {
			        	if(key.equals("ROOT"))
			        	{
			        		log =(Logger) LoggerFactory.getLogger(org.slf4j.Logger.ROOT_LOGGER_NAME);
			        		log.setLevel(Level.toLevel(values.get(0)));
			    			level=log.getLevel().toString();
			    		}
			        	else
			        	{
			        		 try{
			    				 log =(Logger) LoggerFactory.getLogger(key);
			    				 log.setLevel(Level.toLevel(values.get(0)));
			    				 level=log.getLevel().toString();
			    				 }
			    				catch(NullPointerException e)
			    				 {
			    					logger1.info("Exception!!"+e.getMessage());
			    				 }
			    		}
			        	finalRes.put(key, level);
			        }
			       
			        else
			        {
			        	finalRes.put(key, " INVALID LOGGER NAME!!");
			        }
			 }
		 return finalRes;
	   }
}