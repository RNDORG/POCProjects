
package com.wipro.common.gs.transactions.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;




import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.common.gs.transactions.domain.TransactionRequestRange;
import com.wipro.common.gs.transactions.domain.Transactions;
import com.wipro.common.gs.transactions.repository.TransactionsRepository;
import com.wipro.common.gs.transactions.services.TransactionsService;

/**
 * @author Developer
 * @version 1.0
 * type TransactionsController
 */
@RestController
public class TransactionsController {

	/**
	 * TransactionsService TransactionsController.java
	 */
	@Autowired
	TransactionsService service;
	
	@Autowired
	TransactionsRepository transactionRepository;
	
	/**
	 * @param allTransactionParams
	 * @return
	 */
	@RequestMapping(value="rest/api/v1/transactions", method=RequestMethod.GET)
	
	public List<Transactions> getTransactions(@RequestParam MultiValueMap allTransactionParams)
	{
		TransactionRequestRange request = new TransactionRequestRange();
		request.setRangefrom("19/08/2016 00:57:43");
		request.setRangeto("22/08/2016 00:57:43");
		return service.getTransactions(allTransactionParams);	
	
	}
/**
 * @param request
 * @return
 */
@RequestMapping(value="rest/api/v1/transactionsrange", method=RequestMethod.POST)
	
	public List<Transactions> getTransactions(@RequestParam TransactionRequestRange request)
	{
 			return service.getTransactions(request);	
	
	}

/**
 * @param allTransactionParams
 * @return
 * @throws ParseException
 */
@RequestMapping(value="rest/api/v1/transactionsR", method=RequestMethod.GET)

public List<Transactions> getTransactionsR(@RequestParam MultiValueMap allTransactionParams) throws ParseException
{
	
	System.out.println(allTransactionParams);
	Map<String, List<String>> allRequestParams = allTransactionParams;
	TransactionRequestRange request = new TransactionRequestRange();
	
	 //SimpleDateFormat UniversalFormatDB = new SimpleDateFormat("yyyy-MM-dd");
	 SimpleDateFormat UniversalFormatF = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	 
	/* if( allRequestParams.get("txn_from").get(0)!= null &&  !(allRequestParams.get("txn_from").get(0).equalsIgnoreCase("undefined")) && !(allRequestParams.get("txn_from").get(0).equalsIgnoreCase("")) ){
		 request.setRangefrom(UniversalFormatDB.format(UniversalFormatF.parse(allRequestParams.get("txn_from").get(0))));	 
	 }
	 if( allRequestParams.get("txn_to").get(0)!= null &&  !(allRequestParams.get("txn_to").get(0).equalsIgnoreCase("undefined")) && !(allRequestParams.get("txn_to").get(0).equalsIgnoreCase("")) ){
		 request.setRangeto(UniversalFormatDB.format(UniversalFormatF.parse(allRequestParams.get("txn_to").get(0))));
	 }*/
	 
	 if( allRequestParams.get("txn_from").get(0)!= null &&  !(allRequestParams.get("txn_from").get(0).equalsIgnoreCase("undefined")) && !(allRequestParams.get("txn_from").get(0).equalsIgnoreCase("")) ){
		 request.setRangefrom(UniversalFormatF.format(UniversalFormatF.parse(allRequestParams.get("txn_from").get(0))));	 
	 }
	 if( allRequestParams.get("txn_to").get(0)!= null &&  !(allRequestParams.get("txn_to").get(0).equalsIgnoreCase("undefined")) && !(allRequestParams.get("txn_to").get(0).equalsIgnoreCase("")) ){
		 request.setRangeto(UniversalFormatF.format(UniversalFormatF.parse(allRequestParams.get("txn_to").get(0))));
	 }
	 
	request.setId(allRequestParams.get("id").get(0));
	request.setTxntype(allRequestParams.get("txn_type").get(0));
	
	String str = allRequestParams.get("txn_code").get(0).replace('^', '#');
	str = str.replace('*', '%');
	request.setTxncode(str);
	
	request.setTxnrequest(allRequestParams.get("txn_request").get(0).replace('*', '%'));
	request.setTxnresponse(allRequestParams.get("txn_response").get(0).replace('*', '%'));
	
	/*System.out.println(request.getRangefrom());
	System.out.println(request.getRangefrom());
	System.out.println(request.getId());
	System.out.println(request.getTxntype());
	System.out.println(request.getTxncode());
	System.out.println(request.getTxnrequest());
	System.out.println(request.getTxnresponse());*/
	
	return service.getTransactions(request);	

}


@RequestMapping(value="rest/api/v1/transactions/type", method=RequestMethod.GET)
public List<String> getTransactionsType()
{
	return transactionRepository.getTxnType();

}
}