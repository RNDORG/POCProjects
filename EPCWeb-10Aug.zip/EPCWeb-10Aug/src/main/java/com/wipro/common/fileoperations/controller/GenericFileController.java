package com.wipro.common.fileoperations.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;








import com.wipro.common.fileoperations.domain.FileDownloadDTO;
import com.wipro.common.fileoperations.domain.GenericFile;
import com.wipro.common.fileoperations.service.GenericFileService;





/**
 * @author Developer
 * @version 1.0
 * type GenericFileController
 */
@RestController
public class GenericFileController {
	

	
	/**
	 * GenericFileService GenericFileController.java
	 */
	@Autowired
	GenericFileService genericFileService;
	/**
	 * @param file
	 * @param names
	 * @param fileType
	 * @param uploadCode
	 * @param createOrReplace
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "rest/api/v1/genericfile/fileUpload", method = RequestMethod.POST)
	public List<String> upload(@RequestParam("file") MultipartFile file,@RequestParam("names") String names,@RequestParam("fileType") String fileType,@RequestParam("uploadCode" ) String uploadCode,@RequestParam("createOrReplace") boolean createOrReplace) throws IOException {
		
		List<String> result = new ArrayList<String>();
		GenericFile fileUploadRequest  = new GenericFile();
		fileUploadRequest.setFile(file.getBytes());
		fileUploadRequest.setFileName(names);
		fileUploadRequest.setFileType(fileType);
		fileUploadRequest.setUploadId(uploadCode);
		fileUploadRequest.setCreateOrReplace(createOrReplace);
		result.add(genericFileService.genericFileUpload(fileUploadRequest));
		
		return	result;
		
	}
	
	
	/**
	 * @param response
	 * @param uploadId
	 * @throws IOException
	 */
	@RequestMapping(value="rest/api/v1/genericfile/fileDownload/{uploadId}", method = RequestMethod.GET) 
	public void fileDownload(HttpServletResponse response,@PathVariable("uploadId") String uploadId) throws IOException{
		GenericFile fileUploadRequest  = new GenericFile();
		FileDownloadDTO fileDownloadDto = genericFileService.genericFileDownload(uploadId);
		
		  response.setContentType(fileDownloadDto.getMimeType());
	       
	        response.setHeader("Content-Disposition",String.format("inline; filename=\""+fileDownloadDto.getHeader()+"\""));
	 
	       if(!(fileDownloadDto.getFileLength()==null)){
	    
	         
	        response.setContentLength(fileDownloadDto.getFileLength());
	        
	        
	        //System.out.println(fileDownloadDto.getMimeType()+"------"+fileDownloadDto.getHeader()+"------"+fileDownloadDto.getFileLength());
	        
	        FileCopyUtils.copy(fileDownloadDto.getInputStream(), response.getOutputStream());
	       }
		
	}
	 

}
