package com.wipro.common.gs.exception;

import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * @author Developer
 * @version 1.0
 * type GenericException
 */
public class GenericException extends RuntimeException {

	/**
	 * long GenericException.java
	 */
	private static final long serialVersionUID = -3862926553620452151L;
	/**
	 * String GenericException.java
	 */
	protected String errorCode;
	/**
	 * String GenericException.java
	 */
	protected String errorMessage = "";
	/**
	 * String GenericException.java
	 */
	protected String lowLevelError = "";
	/**
	 * Throwable GenericException.java
	 */
	protected Throwable exception;
	
	
	/**
	 * @param errorCode
	 * @param errorMessage
	 * @param lowLevelError
	 * @param exception
	 */
	public GenericException(String errorCode, String errorMessage,
			String lowLevelError, Throwable exception) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.lowLevelError = lowLevelError;
		this.exception = exception;
	}
	
	
	/**
	 * @param errorCode
	 * @param errorMessage
	 * @param lowLevelError
	 */
	public GenericException(String errorCode, String errorMessage,
			String lowLevelError) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.lowLevelError = lowLevelError;
	}


	/**
	 * @return
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * @param errorCode
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	/**
	 * @param errorMessage
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	/**
	 * @return
	 */
	public String getLowLevelError() {
		return lowLevelError;
	}
	/**
	 * @param lowLevelError
	 */
	public void setLowLevelError(String lowLevelError) {
		this.lowLevelError = lowLevelError;
	}
	/**
	 * @return
	 */
	public Throwable getException() {
		return exception;
	}
	/**
	 * @param exception
	 */
	public void setException(Throwable exception) {
		this.exception = exception;
	}
	
	/**
	 * @param throwable
	 * @return
	 */
	public static String stackTraceToString(Throwable throwable) {
		return ExceptionUtils.getStackTrace(throwable);
	}
	
	/**
	 * @return
	 */
	public String getStackTraceAsString() {
		return ExceptionUtils.getStackTrace(this);
	}
	/* (non-Javadoc)
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage(){
		return getErrorMessage();
	}
	
}
