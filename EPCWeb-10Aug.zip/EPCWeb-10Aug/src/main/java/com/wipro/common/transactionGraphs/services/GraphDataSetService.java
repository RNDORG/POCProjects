package com.wipro.common.transactionGraphs.services;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wipro.common.transactionGraphs.domain.GraphDatasets;
import com.wipro.common.transactionGraphs.repository.GraphDataSetRepository;

/**
 * @author Developer
 * @version 1.0
 * type GraphDataSetService
 */
@Component
public class GraphDataSetService {

	/**
	 * GraphDataSetRepository GraphDataSetService.java
	 */
	@Autowired
	GraphDataSetRepository graphDataset;
	/**
	 * Logger GraphDataSetService.java
	 */
	private static Logger logger = LoggerFactory
			.getLogger(GraphDataSetService.class);
	/**
	 * SimpleDateFormat GraphDataSetService.java
	 */
	private SimpleDateFormat UniversalFormatDB;
	/**
	 * SimpleDateFormat GraphDataSetService.java
	 */
	private SimpleDateFormat UniversalFormatF = new SimpleDateFormat(
			"dd/MM/yyyy HH:mm:ss");
	/**
	 * SimpleDateFormat GraphDataSetService.java
	 */
	private SimpleDateFormat UniversalFormatSys;
	/**
	 * SimpleDateFormat GraphDataSetService.java
	 */
	private SimpleDateFormat UniversalFormatSysF = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");
	// new ArrayList<Integer>();
	/**
	 * @param choice
	 * @return
	 */
	public List<GraphDatasets> getDataSets(String choice) {

		List<GraphDatasets> graphdatasetresp = new ArrayList<GraphDatasets>();
		List<Object[]> graphDataCount = graphDataset.getGraphData(choice);
		try {
			String type = graphDataCount.get(0)[2].toString();
			List<Integer> count = new ArrayList<Integer>();
			List<String> timestamp = new ArrayList<String>();
			List<String> timestampFinal = new ArrayList<String>();
			timestampFinal = generateWeekDays(choice);
			int increment = 0;
			for (Object[] obj : graphDataCount) {

				//logger.debugln("/*********************/");
				//logger.debugln(obj[0].toString());
				//logger.debugln("raw date:" + obj[1].toString());
				//logger.debugln("converted:"						+ dateFormatting(obj[1].toString(), choice));
				//logger.debugln(obj[2].toString());

				if (type.equals(obj[2].toString())) {
					/*
					 * if(timestamp.get(timestamp.size()-1).equals(dateFormatting
					 * (obj[1].toString(),choice))) {
					 * count.set(count.size()-1,count
					 * .get(count.size()-1)+Integer
					 * .parseInt(obj[0].toString()));
					 * 
					 * 
					 * 
					 * }else{
					 */

					count.add(Integer.parseInt(obj[0].toString()));
					timestamp.add(obj[1].toString());
					/* } */
				}
				if (!(type.equals(obj[2].toString()))) {

					//System.out.println("loop:" + increment + "----"+ graphDataCount.size() + "***"+ obj[2].toString());
					GraphDatasets graphdataSet = new GraphDatasets();
					graphdataSet.setCount(count);
					graphdataSet.setTimestamp(timestamp);
					graphdataSet.setType(type);
					graphdatasetresp.add(graphdataSet);
					// timestampFinal = generateWeekDays() ;
					count = new ArrayList<Integer>();
					timestamp = new ArrayList<String>();
					type = obj[2].toString();
					count.add(Integer.parseInt(obj[0].toString()));
					timestamp.add(obj[1].toString());
				}

				if ((increment == graphDataCount.size() - 1)) {

					GraphDatasets graphdataSet = new GraphDatasets();
					graphdataSet.setCount(count);
					graphdataSet.setTimestamp(timestamp);
					graphdataSet.setType(type);
					graphdatasetresp.add(graphdataSet);

				}
				// //logger.debugln(increment+"----"+graphDataCount.size()+"--"+type
				// );
				increment++;
			}

			/*
			 * Set<String> hs = new HashSet<>(); hs.addAll(timestampFinal);
			 */
			timestampFinal.clear();
			timestampFinal = generateWeekDays(choice);
			// //logger.debugln(timestampFinal);

			for (GraphDatasets gs : graphdatasetresp) {

				//logger.debugln(gs.getType() + "----" + gs.getCount()	+ "-----" + gs.getTimestamp());

			}

			for (int i = 0; i < graphdatasetresp.size(); i++) {

				type = graphdatasetresp.get(i).getType();
				count = graphdatasetresp.get(i).getCount();
				timestamp = graphdatasetresp.get(i).getTimestamp();
				//logger.debugln("type:" + type);
				int q = 0;
				boolean found = false;
				for (int k = 0; k < timestamp.size(); k++) {

					for (int j = q; j < timestampFinal.size(); j++) {

						if (timestampFinal.get(j).trim()
								.equals(timestamp.get(k).trim())) {

							// //logger.debugln(count.get(j)+"---"+timestampFinal.get(j));
							q = j + 1;
							if (k != timestamp.size() - 1) {
								break;
							}
						} else {

							//logger.debugln(timestamp.get(k).trim() + "---"		+ timestampFinal.get(j));

							count.add(j, 0);

						}

					}

				}

				//logger.debugln(type + count + "---" + timestampFinal);
				graphdatasetresp.get(i).setCount(count);
				graphdatasetresp.get(i).setTimestamp(timestampFinal);

			}

			// select count(*) as countT ,DATE_FORMAT(txn_timestamp,'%d/%m/%Y')
			// as timeT,txn_type as typeT from epctest.transactions group by
			// DATE_FORMAT(txn_timestamp,'%d/%m/%Y'),txn_type;

		} catch (Exception e) {

			logger.warn(e.getMessage() + "      " + "no transactions recorded");

		}
		/*for (GraphDatasets gs : graphdatasetresp) {

			//logger.debugln(gs.getType() + "----" + gs.getCount() + "-----"					+ gs.getTimestamp());

		}*/
		return graphdatasetresp;
	}

	// ========start and end date==//

	/**
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws ParseException
	 */
	public List<GraphDatasets> getDataSets(String startDate, String endDate)
			throws ParseException {
		//System.out.println("startDate: "+startDate);
		//System.out.println("endDate: "+endDate);
		List<GraphDatasets> graphdatasetresp = new ArrayList<GraphDatasets>();
		List<String> timestampFinal = new ArrayList<String>();
		timestampFinal = generateWeekDays(startDate, endDate);
		String d1 = UniversalFormatSysF.format(UniversalFormatF.parse(startDate));
		String d2 = UniversalFormatSysF.format(UniversalFormatF.parse(endDate));
		//System.out.println("d1:"+d1+" d2: "+d2);
		List<Object[]> graphDataCount = graphDataset.getGraphData(d1, d2);
		logger.debug("main function"+timestampFinal);
		//System.out.println("graphDataCount: "+graphDataCount);
		graphdatasetresp = graphDataEngine(graphDataFromDB(graphDataCount),
				timestampFinal);

		return graphdatasetresp;
	}

	// /--------------------------------db-------------//

	/**
	 * @param graphDataCount
	 * @return
	 * @throws ParseException
	 */
	List<GraphDatasets> graphDataFromDB(List<Object[]> graphDataCount)
			throws ParseException {
		
		List<GraphDatasets> graphdatasetresp = new ArrayList<GraphDatasets>();
		
			if(!graphDataCount.isEmpty()){
				
				List<Integer> count = new ArrayList<Integer>();
				List<String> timestamp = new ArrayList<String>();
			
				String frequency = "12";
				String type = graphDataCount.get(0)[2].toString();
				int increment = 0;
			
				for (Object[] obj : graphDataCount) {
					obj[1] = UniversalFormatSys.format(UniversalFormatSysF.parse(obj[1].toString().replace(".0","")));
				
					if (type.equals(obj[2].toString())) {
						count.add(Integer.parseInt(obj[0].toString()));
						timestamp.add(obj[1].toString());
					}
					if (!(type.equals(obj[2].toString()))) {
	
						//logger.debugln("loop:" + increment + "----"+ graphDataCount.size() + "***" + obj[2].toString());
						GraphDatasets graphdataSet = new GraphDatasets();
						graphdataSet.setCount(count);
						graphdataSet.setTimestamp(timestamp);
						graphdataSet.setType(type);
						graphdatasetresp.add(graphdataSet);
						// timestampFinal = generateWeekDays() ;
						count = new ArrayList<Integer>();
						timestamp = new ArrayList<String>();
						type = obj[2].toString();
						count.add(Integer.parseInt(obj[0].toString()));
						timestamp.add(obj[1].toString());
					}
	
					if ((increment == graphDataCount.size() - 1)) {
	
						GraphDatasets graphdataSet = new GraphDatasets();
						graphdataSet.setCount(count);
						graphdataSet.setTimestamp(timestamp);
						graphdataSet.setType(type);
						graphdatasetresp.add(graphdataSet);
						
					}
					// //logger.debugln(increment+"----"+graphDataCount.size()+"--"+type
					// );
					increment++;
				}
				
				
			}
			return graphdatasetresp;
	}

	// --------------------build data for graphs----------------------//

	/**
	 * @param graphdatasetresp
	 * @param timestampFinal
	 * @return
	 * @throws ParseException
	 */
	List<GraphDatasets> graphDataEngine(List<GraphDatasets> graphdatasetresp,
			List<String> timestampFinal) throws ParseException {

		logger.debug("engine:"+timestampFinal);
		for (int i = 0; i < graphdatasetresp.size(); i++) {

			String type = graphdatasetresp.get(i).getType();
			List<Integer> count = graphdatasetresp.get(i).getCount();
			List<String> timestamp = graphdatasetresp.get(i).getTimestamp();
			List<Integer> countBuckt = new ArrayList<Integer>();
			for(String helper:timestampFinal){
				
				countBuckt.add(0);
			}
			//logger.debugln("type:" + type);
			int q = 0;
			boolean found = false;
			for (int k = 0; k < timestamp.size(); k++) {

				for (int j = 0; j < timestampFinal.size(); j++) {

					Date dateDB = UniversalFormatSys.parse(timestamp.get(k).trim());
					Date dateCurnt = UniversalFormatSys.parse(timestampFinal.get(j).trim());
					Date dateNext=null;
					try{
						dateNext = UniversalFormatSys.parse(timestampFinal.get(j + 1).trim());
					}catch(IndexOutOfBoundsException e)
					{
					 dateNext = UniversalFormatSys.parse(timestampFinal.get(j).trim());
					}
				
					 if (dateCurnt.compareTo(dateDB)>=0) {
   
						 countBuckt.set(j,countBuckt.get(j)+count.get(k));
						 
					q = j;
						
							break;
					}
					

				}

			}

			//logger.debugln(type + count + "---" + timestampFinal+"--------"+countBuckt);
			graphdatasetresp.get(i).setCount(countBuckt);
			graphdatasetresp.get(i).setTimestamp(timestampFinal);

		}
		for (GraphDatasets gs : graphdatasetresp) {

			//logger.debugln(gs.getType() + "----" + gs.getCount() + "-----"					+ gs.getTimestamp());

		}
		return graphdatasetresp;
	}

	// ----------------------------------------
	/**
	 * @param dateStart
	 * @param dateStop
	 * @return
	 * @throws ParseException
	 */
	List<String> generateWeekDays(String dateStart, String dateStop)
			throws ParseException {
		
		Calendar c = Calendar.getInstance();
		/*
		 * String dateStart = "13/03/14 09:29:58"; String dateStop =
		 * "12/03/15 12:50:43";
		 */
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date d1 = format.parse(dateStart);
		Date d2 = format.parse(dateStop);

		long diff = d1.getTime() - d2.getTime();
		long diffSeconds = diff / 1000 % 60;
		long diffMinutes = diff / (60 * 1000) % 60;
		long diffHours = diff / (60 * 60 * 1000);
		int diffInDays = (int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
		logger.info("Difference in number of days (2) : " + diffInDays
				+ "--" + (-diffHours));
		int choiceG = Calendar.DATE;
		int freuency = 12;
		List<String> timestampFinal = new ArrayList<String>();
		c.setTime(d2);
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

		if (-diffHours < 24 && -diffHours > 0) {
			choiceG = Calendar.HOUR;
			logger.info("day data  : " + diffInDays);
			df = new SimpleDateFormat("dd/MM/yyyy HH");
			UniversalFormatSys = new SimpleDateFormat("dd/MM/yyyy HH");
			UniversalFormatDB = new SimpleDateFormat("yyyy-MM-dd HH");
			for (int i = 0; i < freuency; i++) {
				//logger.debugln(df.format(c.getTime()));
				timestampFinal.add(df.format(c.getTime()).toString());
				c.add(choiceG, -(24 / freuency));
				
			}

		} else if (diffInDays < 12) {
			logger.info("week data  : " + diffInDays);
			choiceG = Calendar.HOUR;
			int difInFrq = (int) (-1 * diffHours) / freuency;
			df = new SimpleDateFormat("dd/MM/yyyy HH");
			UniversalFormatSys = new SimpleDateFormat("dd/MM/yyyy HH");
			UniversalFormatDB = new SimpleDateFormat("yyyy-MM-dd HH");
			for (int i = 0; i < freuency; i++) {
				//logger.debugln(df.format(c.getTime()));
				timestampFinal.add(df.format(c.getTime()).toString());
				
				c.add(choiceG, -(difInFrq));
			}

		} else if (diffInDays < 365) {

			choiceG = Calendar.DATE;
			int difInFrq = (diffInDays) / freuency;
			df = new SimpleDateFormat("dd/MM/yyyy");
			UniversalFormatSys = new SimpleDateFormat("dd/MM/yyyy");
			UniversalFormatDB = new SimpleDateFormat("yyyy-MM-dd");
			for (int i = 0; i < freuency; i++) {
				//logger.debugln(df.format(c.getTime()));
				timestampFinal.add(df.format(c.getTime()).toString());
				
				c.add(choiceG, -(difInFrq));
			}

		} else if (diffInDays >= 365) {
			logger.info("minutes");

		} else {
			//logger.debugln("sorry");
		}
		Collections.reverse(timestampFinal);
		return timestampFinal;
	}

	// ---------------------
	/**
	 * @param choice
	 * @return
	 */
	List<String> generateWeekDays(String choice) {
		
		int choiceG = Calendar.DATE;
		int freuency = 7;

		List<String> timestampFinal = new ArrayList<String>();
		Calendar c = Calendar.getInstance();

		// Set the calendar to monday of the current week
		// c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

		// Print dates of the current week starting on Monday
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		if ("D".equals(choice)) {

			choiceG = Calendar.HOUR;
			freuency = 24;
			df = new SimpleDateFormat("dd/MM/yyyy HH");
		}

		for (int i = 0; i < freuency; i++) {
			//logger.debugln(df.format(c.getTime()));
			timestampFinal.add(df.format(c.getTime()).toString());

			c.add(choiceG, -1);

		}
		Collections.reverse(timestampFinal);
		return timestampFinal;
	}

	// -------------------

	/**
	 * @param dateInString
	 * @param choice
	 * @return
	 */
	public String dateFormatting(String dateInString, String choice) {
		SimpleDateFormat formatter;
		if ("D".equals(choice)) {
			formatter = new SimpleDateFormat("dd/MM/yyyy HH");

		} else {
			formatter = new SimpleDateFormat("dd/MM/yyyy");

		}

		String dateSplit[] = dateInString.split(" ")[0].split("-");
		String timeSplit[] = dateInString.split(" ")[1].split(":");
		Calendar calendar = new GregorianCalendar(
				Integer.parseInt(dateSplit[0]),
				Integer.parseInt(dateSplit[1]) - 1,
				Integer.parseInt(dateSplit[2]), Integer.parseInt(timeSplit[0]),
				Integer.parseInt(timeSplit[1]), 0);

		return formatter.format(calendar.getTime());

	}

}     
