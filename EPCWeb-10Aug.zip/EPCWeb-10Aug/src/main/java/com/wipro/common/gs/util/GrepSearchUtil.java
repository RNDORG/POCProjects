package com.wipro.common.gs.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GrepSearchUtil {
	
	
	public static List<String> grepSearchInFile(File file, String grep, String delim) {
		String content = "";
		List<String> returnList = new ArrayList<String>();
		try {
			//content = new String(Files.readAllBytes(Paths.get("./logs/"+file.getName().toString())));
			
			/*
			second method to read files 
			*/
			FileInputStream fis = new FileInputStream(file);
			byte[] data = new byte[(int) file.length()];
			fis.read(data);
			fis.close();

			content = new String(data, "UTF-8");
			
			
			String[] splitArray = content.split(delim);
			for(int i=0; i<splitArray.length; i++){
				
				 if(splitArray[i].contains(grep)){
					returnList.add(splitArray[i]);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return returnList;
	}
}
