/**
 * EPC Application - EpcVersionController.java
 */
package com.wipro.common.version;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.common.config.service.ServerStatusService;
import com.wipro.epc.services.BroadcastService;

/**
 * @author Developer
 * @version 1.0
 * type EpcVersionController
 */
@RestController
public class EpcVersionController {

	@Autowired
	ServerStatusService serverService;
	
	@Autowired
	BroadcastService broadcastService;
    
	
	@RequestMapping(value = "rest/extapi/v1/versionLocal", method=RequestMethod.GET)
	public List<String> epcVersion(){
		List<String> ls = new ArrayList<String>();
		ReadFileInMap readFile = new ReadFileInMap();
		ls.add(readFile.fileRead().get("Version")+"."+readFile.fileRead().get("Build_TimeStamp"));
		return ls;
	}
	
	@RequestMapping(value = "rest/extapi/v1/version", method=RequestMethod.GET)
	public Map<String,String> epcVersionFromAllManagedServers(){
		MultiValueMap allRequestParams=new LinkedMultiValueMap<>();
		Map<String, String> returneValue = new HashMap<String, String>();
		
		if(serverService.isCurrentlyUiServer()) {
		
		allRequestParams.add("api", "versionLocal");
		allRequestParams.add("to", "all");
		returneValue=broadcastService.getReplyService(allRequestParams);
		
		}
		else {
			returneValue.put("Not Allowed to do Broadcast", "Please check with Admin");
		}
		
		return returneValue;
	}
}
