/**
 * EPC Application - TypeTest.java
 *//*
package com.wipro.common.gs.util;

import com.wipro.epc.domain.EpcLookupMaster;
import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.TableInfo;

*//**
 * @author Developer
 * @version 1.0
 * type TypeTest
 *//*
public class TypeTest {
	*//**
	 *
	 *
	 **//*
	private static final long serialVersionUID = 1L;

	*//**
	 * @param args
	 *//*
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CommonUtils com =new CommonUtils();
		TableInfo ti = com.getTableInfo(EpcLookupMaster.class.getName());
		System.out.println(ti.toString());
		
	}
}
*/