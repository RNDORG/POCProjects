package com.wipro.common.config.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.common.config.domain.Config;


/**
 * @author Developer
 * @version 1.0
 * type ConfigRepository
 */
@Repository
public interface ConfigRepository extends CrudRepository<Config , Integer>{

	
/**
 * @param value
 * @param description
 * @param id
 * @param modifiedBy
 * @return
 */
@Modifying(clearAutomatically = true)
@Query(value="update config set config_value=:value,description=:desc, status=:stat, modified_by=:modifiedBy, modified_date=current_timestamp where id=:id",nativeQuery=true)
Integer configUpdateByID(@Param("value")  String value,@Param("desc") String description,@Param("id") Integer id, @Param("modifiedBy")String modifiedBy, @Param("stat") String status);
	
/**
 * @param groupName
 * @param keyName
 * @return
 */
@Query(value="select config_value from config where config_group = :name and config_key= :key", nativeQuery =true)
String getConfigValueFromDB(@Param(value="name") String groupName, @Param(value="key") String keyName);

/**
 * @param name
 * @param key
 * @return
 */
@Query(value="select config_value from config where config_group = :name and config_key= :key", nativeQuery =true)
List<String> getConfigValueForApplicability(@Param(value="name") String name, @Param(value="key") String key);

/**
 * @param group
 * @param key
 * @param value
 * @return
 */
@Modifying(clearAutomatically = true)
@Query(value="update config set config_value=:value,modified_by=:modifiedBy, modified_date=current_timestamp where config_group=:grp and config_key=:key",nativeQuery=true)
Integer configUpdateByGroupKey(@Param("grp") String group,@Param("key") String key,@Param("value")  String value,@Param("modifiedBy")String modifiedBy);

}
