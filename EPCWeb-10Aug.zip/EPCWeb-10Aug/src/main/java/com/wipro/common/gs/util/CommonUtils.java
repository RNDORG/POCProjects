package com.wipro.common.gs.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Table;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
import org.springframework.stereotype.Component;

import com.wipro.epc.domain.EpcProductSpecification;
import com.wipro.epc.dto.FieldInfo;
import com.wipro.epc.dto.TableInfo;

/**
 * @author Developer
 * @version 1.0
 * type CommonUtils
 */
@Component
public class CommonUtils {
	/**
	 * Logger CommonUtils.java
	 */
	private static Logger logger = LoggerFactory.getLogger(CommonUtils.class);
	
	/**
	 * MappingJackson2XmlHttpMessageConverter CommonUtils.java
	 */
	@Autowired
    private MappingJackson2XmlHttpMessageConverter xmlConverter;
	

	/**
	 * @param str
	 * @return
	 */
	private static String camelToSnakeCase(String str){
		if(str != null) {
			return str.replaceAll("(.)(\\p{Upper})", "$1_$2").toLowerCase();
		}
		return str;
	}
	
	/**
	 * @param list
	 * @return
	 */
	public String convertToXml(EpcProductSpecification list){
		try {
//			xmlConverter.configure(SerializationFeature.INDENT_OUTPUT, true);
			String res = xmlConverter.getObjectMapper().writeValueAsString(list);
			
			res=res.replaceAll("<productId>.*</productId>\r\n", "");
			res=res.replaceAll("productShortCode", "productId");
			res=res.replaceAll("vsmdComponent", "VSD Component");
			//res=res.replaceAll("<otherProductId>.*</otherProductId>\r\n", "");//<networkProfileId/>
			res=res.replaceAll("<networkProfileId/>\r\n", "");
			return res;
			//
		} catch (Exception e) {
			logger.error(ExceptionUtils.getStackTrace(e));
			return "failure";
		}                     
     }
	
	/**
	 * @param fullyQualifiedClassName
	 * @return
	 */
	public static TableInfo getTableInfo(String fullyQualifiedClassName){
		
		Class<?> targetClass = null;
		try {
			targetClass = Class.forName(fullyQualifiedClassName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			logger.error(ExceptionUtils.getStackTrace(e));
			throw new RuntimeException("ClassNotfoundException in getTableInfo(). Underlying error message - " + e.getMessage(), e );
		}
		
		Annotation annotation = targetClass.getAnnotation(Table.class);
		TableInfo tableInfo = new TableInfo(); 
		
		if(annotation instanceof Table){
			Table table = (Table) annotation;
			tableInfo.setTableName(table.name());
		}

		 
		  Map<String, FieldInfo> fieldMap = new HashMap<String, FieldInfo>();
		    Field[] allFields = targetClass.getDeclaredFields();
		    for (Field field : allFields) {	
		    	 Column column = field.getAnnotation(Column.class);
		        if (column!=null)//Modifier.isPrivate(field.getModifiers()) &&  --if private modifier only required
		        	{
		        	FieldInfo fieldInfo = new FieldInfo();		        	
		        	fieldInfo.setFieldName(field.getName());
		        	fieldInfo.setFieldType(field.getType().getSimpleName());
		        	fieldInfo.setDbFieldName(column.name());	
		            fieldMap.put(field.getName(), fieldInfo);
		        }
		    }
		    
		    tableInfo.setFields(fieldMap);
		   // System.out.println(tableInfo.getFields().keySet());
		    return tableInfo;
		
	}
	
	
	/**
	 * @param allRequestParams
	 * @param validKeys
	 * @param tableName
	 * @return
	 */
	public static String getQueryFromDB(Map<String, List<String>> allRequestParams,
			String className, List<String> withLikeFields) {
		
		String limit = "";
		/*//System.out.println("Valid keys are ");
		for(String validKey : validKeys){
			//System.out.println(" "+validKey);
		}*/
		if(allRequestParams.get("max_limit")!=null && !allRequestParams.get("max_limit").isEmpty())
		{
			limit = allRequestParams.get("max_limit").get(0);
		}
		
		List<String> orderBy = allRequestParams.get("sort");
		allRequestParams.remove("max_limit");
		allRequestParams.remove("sort");
		
		TableInfo tableInfo = getTableInfo(className);
		
		StringBuilder queryBuilder = new StringBuilder("select * from "+tableInfo.getTableName());
		//int sampleCounter1 =0;
		
		
		if ( !allRequestParams.isEmpty()) {
			queryBuilder.append(" where 1=1 ");
		}
		Iterator it = allRequestParams.entrySet().iterator();
		Map<String, FieldInfo> fields = tableInfo.getFields();
		Set<String> validKeys = tableInfo.getFields().keySet();
	    while (it.hasNext()) {
	    	int sampleCounter = 0;
	    	//sampleCounter1++;
	        Map.Entry pair = (Map.Entry)it.next(); 
	        List<String> values =  (List<String>) (pair.getValue());
	        List<String> notNullValues =  null;
	        String key = pair.getKey().toString();
	        if(validKeys.contains(key) && !values.isEmpty())
	        {
	        	notNullValues =  new ArrayList<String>();
	        	for(String value : values){
	        		if(StringUtils.isNotBlank(value) && (!("null".equalsIgnoreCase(value)))){
	        			notNullValues.add(value);
	        		}
	        	}
	        	if(notNullValues.size() > 1000){
	        		logger.warn("More than thousand items detected in common query creation logic.");
	        	}
	        	if (!notNullValues.isEmpty()) {
	        		FieldInfo field = fields.get(key);	        		
	        		 
	        		
	        		if("String".equals(field.getFieldType())){
	        			
	        			if(withLikeFields != null && !withLikeFields.isEmpty() && withLikeFields.contains(key)){
	        				for(int i=0; i<notNullValues.size(); i++){
	        					queryBuilder.append(" AND "+field.getDbFieldName()+ "like '"+ notNullValues.get(i)+"'");
	        				}
	        			}else{
	        				queryBuilder.append("AND ");
	        				queryBuilder.append(field.getDbFieldName()+" in ( ");
	        				for(int i=0; i<notNullValues.size(); i++){
	        					queryBuilder.append("'"+ notNullValues.get(i)+"'");
	        					if(i < notNullValues.size()-1){
	        						queryBuilder.append(",");
	        					}
	        				}
	        				queryBuilder.append("  ) ");
	        			}
	        			
	        		}else if("Date".equals(field.getFieldType())){
	        			String errMessage = " Date search is not applicable for " + pair.getKey();
	    	        	logger.info( errMessage );
	    	        	throw new RuntimeException( errMessage );
	        		}else{
	        			queryBuilder.append("AND ");
	        			queryBuilder.append(field.getDbFieldName()+" in ( ");
        				for(int i=0; i<notNullValues.size(); i++){
        					queryBuilder.append(notNullValues.get(i));
        					if(i < notNullValues.size()-1){
        						queryBuilder.append(",");
        					}
        				}
        				queryBuilder.append("  ) ");
	        		}
				}
	        } else {
	        	String errMessage = " '" + pair.getKey() + "' is not a valid search criteria.";
	        	logger.info( errMessage );
	        	throw new RuntimeException( errMessage );
	        }
	    }
	    if(orderBy!=null)
	    {
	    	if(!orderBy.isEmpty()) {
				queryBuilder.append(" order by ");
			}
	    	int sampleCounter2 = 0;
		    for(String orders: orderBy)
		    {
		    	sampleCounter2++;
		    	queryBuilder.append(orders);
		    	if(sampleCounter2<orderBy.size()) {
					queryBuilder.append(", ");
				}
		    }
	    }
	    if(!("".equals(limit))) {
			queryBuilder.append(" limit ").append(limit);
		}
	    
	   // logger.info("#Query: " + queryBuilder.toString());
	    return queryBuilder.toString();
	}
}
