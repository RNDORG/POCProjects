package com.wipro.common.config.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;
import com.wipro.common.config.domain.ServerStatus;
import com.wipro.common.config.repositories.ServerStatusRepository;
import com.wipro.common.config.service.ServerStatusService;
import com.wipro.common.gs.util.ServerDetails;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.hibernate.exception.JDBCConnectionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Developer
 * @version 1.0
 * type ServerStatusService
 */
@Component
public class ServerStatusService {

	/**
	 * Logger ServerStatusService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(ServerStatusService.class);
	/**
	 * ServerStatusRepository ServerStatusService.java
	 */
	@Autowired
	ServerStatusRepository serverStatusRepo;

	@Autowired
	ServerDetails currentServer;

	/**
	 * @return
	 */
	public List<ServerStatus> getServerStatus() {

		List<ServerStatus> serverStatus = new ArrayList<ServerStatus>();
		
		Iterator<ServerStatus> serverIt = serverStatusRepo.findAll().iterator();
		while (serverIt.hasNext()) {
			serverStatus.add(serverIt.next());
		}

		return serverStatus;
	}

	/**
	 * @param serverName
	 * @return
	 */
	public boolean needsReload(String serverName) {
		
		boolean needsReload;
		List<Integer> reloadFlagList=null; 
		
		try {
			
			reloadFlagList = serverStatusRepo.lookupServerStatus(serverName);
		}
		catch(JDBCConnectionException j)
		{
			logger.error(ExceptionUtils.getStackTrace(j));
		logger.error("Connection Exception Happened");	
		}
		catch( Exception e) {
			String errorMessage = "ServerStatus.needsReload() : server status lookup returned null for "+serverName+" server please check the table. getMessage() = " + e.getMessage(); 
			logger.error( errorMessage);
			throw new RuntimeException( errorMessage, e); 
		}
		
		if (reloadFlagList == null || reloadFlagList.size() <1) {				
			String errorMessage = "ServerStatus.needsReload() : server status returned null for "+serverName+" server. Please check the serverStatus Table data for errors.";
			logger.error( errorMessage );
			throw new RuntimeException( errorMessage); 
		}
		needsReload = reloadFlagList.get(0)==1 ? true : false;
		return needsReload;		
	}

	/**
	 * @param serverName
	 * @return
	 * @throws MySQLIntegrityConstraintViolationException
	 */
	@Transactional
	public ServerStatus insertServerStatus(ServerStatus serverName) throws MySQLIntegrityConstraintViolationException {

		return serverStatusRepo.save(serverName);
		
	}

	/**
	 * @param serverName
	 */
	@Transactional
	public void deleteServerStatus(String serverName) {
		
		serverStatusRepo.deleteServerStatus(serverName);
		logger.error("crash detected on : "+serverName );
	}

	/**
	 * @param serverStatus
	 * @return
	 */
	@Transactional
	public boolean updateServerValue(ServerStatus serverStatus) {

		int i = serverStatusRepo.updateServerStatus(serverStatus);
		
		return i < 1 ? false : true; 
				
	}
	/**
	 * @return
	 */
	@Transactional
	public boolean updateServerValue() {

		int i = serverStatusRepo.updateServerStatus();
		
		return i < 1 ? false : true; 
				
	}
	/**
	 * @return
	 */
	@Transactional
	public boolean updateLock() {

	
		int i = serverStatusRepo.updateLock();
		
		return i < 1 ? false : true; 
				
	}
	/**
	 * @param b
	 * @return
	 */
	@Transactional
	public boolean updateLock(String b) {

		int i = serverStatusRepo.updateLock(b);
		
		return i < 1 ? false : true; 
				
	}
	/**
	 * @return
	 */
	@Transactional
	public String configReload(){
		
		String message="";
		if(getLock())
		 {
			 logger.info("lock obtained");
			 
			serverReload();
			 
			
			releaseLock();
			
			message ="reloaded successfully ";
			 
		 }else{
			 message = "Cannot obtain the lock as  reload process is taking place ";
			 logger.warn(message);
			 return message;
			 
		 }
		  
		  return message;
		
	}
	
	
	
	/**
	 * @return
	 */
	@Transactional
	 int serverReload(){
		 logger.info("server reload  method called");
		 updateServerValue();
		  return 1;
	  }
	  

	  /**
	 * @return
	 */
	boolean getLock(){
			
		  logger.info("get lock method is called ");
			return updateLock();
		}

	  /**
	 * @return
	 */
	boolean releaseLock(){
		  
		  return updateLock("0");
		
	  }
	 
	@Transactional
	public void entryIntoServerStatus(ServerStatus serverDetails)  {
		try {
			ServerStatus server = 	serverStatusRepo.findServerStatusByServerName(serverDetails.getserverName());
		if(server!= null && server.getserverName()!=null) {
			serverStatusRepo.updateServerStatus(serverDetails);
		}
		else {
		//serverStatusRepo.deleteByServerName(serverDetails.getserverName());
		serverStatusRepo.save(serverDetails);
		}
		}
		catch (Exception e){
			logger.error(ExceptionUtils.getStackTrace(e));
		}
		
	}
	  
	public boolean isCurrentlyUiServer() {
		/*logger.info("Checking ui server or not");
		boolean isUi = false;
		ServerStatus server = serverStatusRepo.findServerStatusByServerName(currentServer.getIpPort());
		Integer statuVsalue = server!=null ? server.getValue() : 0 ;
		switch(statuVsalue) {
		case 0 : isUi = false;
					logger.info("Non Ui Server or Server Not listed");
					break;
		case 1 : isUi = true;
					logger.info("Ui Server");
					break;			
		}
		return isUi;*/
		logger.info("All Read/write servers now");
		return true;
	}
}
