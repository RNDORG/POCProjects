package com.wipro.common.gs.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.common.gs.transactions.domain.Transactions;
import com.wipro.common.gs.transactions.services.TransactionsService;

/**
 * @author Developer
 * @version 1.0 type TransactionStore
 */
@Component
public class EPCTxnInterceptor {

	private static Logger logger = LoggerFactory
			.getLogger(EPCTxnInterceptor.class);
	/**
	 * TransactionsService TransactionStore.java
	 */
	@Autowired
	TransactionsService transactionsLogging;

	/**
	 * ObjectMapper TransactionStore.java
	 */
	@Autowired
	ObjectMapper mapper;

	/**
	 * @param txnCode
	 * @param txnType
	 * @param txnRequest
	 * @param response
	 */

	/**
	 * @param txnCode
	 * @param txnType
	 * @param allRequestParams
	 * @param response
	 */

	/**
	 * @param allRequestParams
	 * @return
	 */
	public String formRequest(MultiValueMap allRequestParams) {
		String txnRequest = "";
		txnRequest = txnRequest + "Request-Parameters {\n";
		Iterator it = allRequestParams.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			for (String value : (List<String>) pair.getValue()) {
				txnRequest = txnRequest + pair.getKey() + " : ";
				txnRequest = txnRequest + '"' + value + '"' + "\n";
			}
			// txnRequest = txnRequest.substring(0, txnRequest.length()-1) +
			// " \n";
		}
		txnRequest = txnRequest + " } ";
		return txnRequest;
	}

	public String preTxn(String txnType, MultiValueMap withClause,
			Object requestBody) {
		String txnRequest = formRequest(withClause);
		String txnId = createEPCTxnId(txnType, null, true, requestBody);
		MDC.put("interfaceName", txnId);
		txnRequest = txnRequest + "\n" + " Request-Body ";
		String txnRequest1 = "";
		try {
			txnRequest1 = mapper.writeValueAsString(requestBody) + "\n ";
			logger.info(" Multi Line Request Message :\n" + txnRequest
					+ txnRequest1);

		} catch (Exception e) {
			logger.error(ExceptionUtils.getStackTrace(e));
		}
		String request = txnRequest + txnRequest1;
		return request;
	}

	public void postTxn(String txnType, String request, Object response) {
		Transactions loggingBean = new Transactions();
		try {
			String txnResponse = "Response-Body \n"
					+ mapper.writeValueAsString(response);
			loggingBean.setTxnCode(MDC.get("interfaceName").toString());
			loggingBean.setTxnType(txnType);
			loggingBean.setTxnTimestamp(new Date());
			loggingBean.setTxnRequest(request);
			loggingBean.setTxnResponse(txnResponse);
			logger.info(" Multi Line Response Message returned");
			logger.debug("\n" + txnResponse);
		} catch (Exception e) {
			String txnResponse = "exception found";
			loggingBean.setTxnResponse(txnResponse);
			logger.error(ExceptionUtils.getStackTrace(e));
		}
		transactionsLogging.createTransactions(loggingBean);
		MDC.remove("interfaceName");
	}

	public String createEPCTxnId(String apiName, String userName,
			boolean isExt, Object requestBody) {
		String timeInNano = ((Long) System.nanoTime()).toString();
		String transactionId = "";
		String clientRequestId = "";
		
		//To get the DateTime in 'yyyyMMddHHmmss' formate
		Date curDate = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		String DateToStr = format.format(curDate);
		format = new SimpleDateFormat("yyyyMMddHHmmss"); 
		DateToStr = format.format(curDate);
	
		if (isExt) 
		{
			if (requestBody != null) 
			{
				if (requestBody.toString().contains("clientRequestId")) 
				{
					try {
							Method m = requestBody.getClass().getMethod(
									"getClientRequestId");
							clientRequestId = (String) m.invoke(requestBody);
						} catch (SecurityException | NoSuchMethodException
								| IllegalAccessException | IllegalArgumentException
								| InvocationTargetException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						transactionId = "#extapi:" + apiName + ":"
								+ clientRequestId + ":" + timeInNano;
				} else {
					transactionId = "#extapi:" + apiName + ":"
							+ DateToStr + ":" + timeInNano;
				}
			}
		} else {
			transactionId = "#intapi:" + apiName + ":" + userName + ":"
					+ timeInNano;
		}
		logger.info("transaction id is " + transactionId);
		return transactionId;
	}
}
