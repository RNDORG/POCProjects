package com.wipro.common.gs.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SSHGetListController {
	
	@Autowired
	SSHGetListService sshService;
	
	 @RequestMapping(value="rest/extapi/v1/sshlist", method=RequestMethod.GET)
	    public String sshGetListService() {
	    	return sshService.sshGetList();
		
	    }
	 
}
