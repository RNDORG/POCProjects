package com.wipro.common.gs.transactions.repository;

import java.util.List;

import com.wipro.common.gs.transactions.domain.TransactionRequestRange;
import com.wipro.common.gs.transactions.domain.Transactions;


/**
 * @author Developer
 * @version 1.0
 * type TransactionsRepositoryCustom
 */
public interface TransactionsRepositoryCustom {
	
	 /**
	 * @param query
	 * @return
	 */
	List<Transactions> getList(String query);
	 /**
	 * @param request
	 * @return
	 */
	List<Transactions> getList(TransactionRequestRange request);
	}



