package com.wipro.common.gs.transactions.domain;

/**
 * @author Developer
 * @version 1.0
 * type TransactionRequestRange
 */
public class TransactionRequestRange {

	
	/**
	 * String TransactionRequestRange.java
	 */
	String id;
	/**
	 * String TransactionRequestRange.java
	 */
	String txncode;
	/**
	 * String TransactionRequestRange.java
	 */
	String txntype;
	/**
	 * String TransactionRequestRange.java
	 */
	String txnrequest;
	/**
	 * String TransactionRequestRange.java
	 */
	String txnresponse;
	/**
	 * String TransactionRequestRange.java
	 */
	String rangeto;
	/**
	 * String TransactionRequestRange.java
	 */
	String rangefrom;
	
	/**
	 * @return
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return
	 */
	public String getTxncode() {
		return txncode;
	}
	/**
	 * @param txncode
	 */
	public void setTxncode(String txncode) {
		this.txncode = txncode;
	}
	/**
	 * @return
	 */
	public String getTxntype() {
		return txntype;
	}
	/**
	 * @param txntype
	 */
	public void setTxntype(String txntype) {
		this.txntype = txntype;
	}
	/**
	 * @return
	 */
	public String getTxnrequest() {
		return txnrequest;
	}
	/**
	 * @param txnrequest
	 */
	public void setTxnrequest(String txnrequest) {
		this.txnrequest = txnrequest;
	}
	/**
	 * @return
	 */
	public String getTxnresponse() {
		return txnresponse;
	}
	/**
	 * @param txnresponse
	 */
	public void setTxnresponse(String txnresponse) {
		this.txnresponse = txnresponse;
	}
	/**
	 * @return
	 */
	public String getRangeto() {
		return rangeto;
	}
	/**
	 * @param rangeto
	 */
	public void setRangeto(String rangeto) {
		this.rangeto = rangeto;
	}
	/**
	 * @return
	 */
	public String getRangefrom() {
		return rangefrom;
	}
	/**
	 * @param rangefrom
	 */
	public void setRangefrom(String rangefrom) {
		this.rangefrom = rangefrom;
	}
}
