package com.wipro.common.transactionGraphs.domain;

import java.util.List;

/**
 * @author Developer
 * @version 1.0
 * type GraphDatasets
 */
public class GraphDatasets {

	/**
	 * List<Integer> GraphDatasets.java
	 */
	List<Integer> count ;
	/**
	 * String GraphDatasets.java
	 */
	String type;
	/**
	 * List<String> GraphDatasets.java
	 */
	List<String> timestamp;
	/**
	 * @return
	 */
	public List<Integer> getCount() {
		return count;
	}
	/**
	 * @param count
	 */
	public void setCount(List<Integer> count) {
		this.count = count;
	}
	/**
	 * @return
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return
	 */
	public List<String> getTimestamp() {
		return timestamp;
	}
	/**
	 * @param timestamp
	 */
	public void setTimestamp(List<String> timestamp) {
		this.timestamp = timestamp;
	}
	

}
