package com.wipro.common.transactionGraphs.controller;


import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.common.transactionGraphs.domain.GraphDatasets;
import com.wipro.common.transactionGraphs.domain.GraphsRequest;
import com.wipro.common.transactionGraphs.services.GraphDataSetService;

/**
 * @author Developer
 * @version 1.0
 * type GraphDataController
 */
@RestController
public class GraphDataController {
	
	/**
	 * GraphDataSetService GraphDataController.java
	 */
	@Autowired
	GraphDataSetService graphDataService;
	
	
	/**
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping("Graphs/week")
	public List<GraphDatasets> getTransactions() throws ParseException{
		
		return graphDataService.getDataSets("W");
	}
	/**
	 * @return
	 */
	@RequestMapping("/Graphs/day")
	public List<GraphDatasets> getTransactionsD(){
		
		
		return graphDataService.getDataSets("D");
	}
	
	/**
	 * @param request
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value="/extapi/v1/Graphs", method=RequestMethod.POST)
	public List<GraphDatasets>  searchProductsComplexExt(@RequestBody GraphsRequest request) throws ParseException
	{
		
	//System.out.println("in controller start:"+request.getTo()+" from:"+request.getFrom());	
		List<GraphDatasets> graphdata = graphDataService.getDataSets( request.getFrom(),request.getTo());
		return graphdata;
	}
}