package com.wipro.common.fileoperations.repositories;

import org.springframework.data.repository.CrudRepository;




import com.wipro.common.fileoperations.domain.GenericFile;

/**
 * @author Developer
 * @version 1.0
 * type GenericFileRepository
 */
public interface GenericFileRepository extends CrudRepository<GenericFile , String>,GenericFileRepositoryCustom {


	
}
