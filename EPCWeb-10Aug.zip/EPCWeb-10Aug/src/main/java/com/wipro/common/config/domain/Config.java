package com.wipro.common.config.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the CONFIG database table.
 * @author Developer
 * @version 1.0
 */

@Entity
@NamedQuery(name="Config.findAll", query="SELECT c FROM Config c")
public class Config implements Serializable {
	/**
	 * long Config.java
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * String Config.java
	 */
	@Column(name="CONFIG_GROUP")
	private String configGroup;

	/**
	 * String Config.java
	 */
	@Column(name="CONFIG_KEY")
	private String configKey;

	/**
	 * String Config.java
	 */
	@Column(name="CONFIG_VALUE")
	private String configValue;

	/**
	 * String Config.java
	 */
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="status")
	private String status;
	
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", length = 19)
	private Date createdDate;
	
	@JsonIgnore
	@Column(name = "created_by", nullable = false, length = 25)
	private String createdBy;
	
//	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", length = 19)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss z")
	private Date modifiedDate;
	
//	@JsonIgnore
	@Column(name = "modified_by", length = 25)
	private String modifiedBy;
	/**
	 * int Config.java
	 */
	@Id
	@Column(name="ID")
	private int id;

	
	public Config() {
	}

	/**
	 * @return
	 */
	public String getConfigGroup() {
		return this.configGroup;
	}

	/**
	 * @param configGroup
	 */
	public void setConfigGroup(String configGroup) {
		this.configGroup = configGroup;
	}

	/**
	 * @return
	 */
	public String getConfigKey() {
		return this.configKey;
	}

	/**
	 * @param configKey
	 */
	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}

	/**
	 * @return
	 */
	public String getConfigValue() {
		return this.configValue;
	}

	/**
	 * @param configValue
	 */
	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}

	/**
	 * @return
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return
	 */
	public int getId() {
		return this.id;
	}

	/**
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}