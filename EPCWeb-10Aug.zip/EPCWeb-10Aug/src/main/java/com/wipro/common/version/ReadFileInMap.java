/**
 * EPC Application - ReadFileInMap.java
 */
package com.wipro.common.version;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

/**
 * @author Developer
 * @version 1.0
 * type ReadFileInMap
 */

public class ReadFileInMap {
	
	private static Logger logger = LoggerFactory.getLogger(ReadFileInMap.class);


	private String resourceFileName="version.txt";
	/**
	 * Reading File:
	 * @param resourceFileName is file name inside resource folder
	 */
	public Map<String,String> fileRead() {
		Map<String, String> listMap = new HashMap<String, String>();
		
		try( BufferedReader br = new BufferedReader(new InputStreamReader(new ClassPathResource(resourceFileName).getInputStream()))) {			
		
		    String line = br.readLine();

		    while (line != null) {
		        String[] arr = line.split(":");
		        if ( (!line.startsWith("#")) && arr != null && arr.length >=2  ) { 
		        	listMap.put( arr[0].trim(), arr[1].trim() );
		        }
		        line = br.readLine();		        
		    }
		   // System.out.println( listMap.toString() );
		    br.close();
		}
	    catch(Exception e) {
				logger.error("Error Reading version file "+e.getMessage());				
				e.printStackTrace();
				listMap.put("Version", "No Version File");
		}
		return listMap;
	}
	
/*	*//**
	 * @return
	 *//*
	public List<String> getEpcVersion(){		
		List<String> version = new ArrayList<String>();

		Map<String, String> listMap = fileRead("version.txt");
		version.add(listMap.get("Build_Version")+"."+listMap.get("Build_TimeStamp"));

		//version.add(vers+"."+buildTime);
		System.out.println(System.getenv().toString());
		return version;
	}*/
}
