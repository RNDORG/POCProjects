package com.wipro.common.config.repositories;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wipro.common.config.domain.ServerStatus;

/**
 * @author Developer
 * @version 1.0
 * type ServerStatusRepositoryImpl
 */
public class ServerStatusRepositoryImpl implements ServerStatusRepositoryCustom {

	/**
	 * Logger ServerStatusRepositoryImpl.java
	 */
	private static Logger logger = LoggerFactory
			.getLogger(ServerStatusRepositoryImpl.class);
	
	/**
	 * EntityManager ServerStatusRepositoryImpl.java
	 */
	@PersistenceContext
	private EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.common.config.repositories.ServerStatusRepositoryCustom#lookupServerStatus(java.lang.String)
	 */
	@Override
	public List<Integer>  lookupServerStatus(String serverName) {

         String query="select value from server_status where server_name='"+serverName+"'";

         List<Integer> value=em.createNativeQuery(query).getResultList();
        
		return value;
	}

	/* (non-Javadoc)
	 * @see com.wipro.common.config.repositories.ServerStatusRepositoryCustom#deleteServerStatus(java.lang.String)
	 */
	@Override
	public int  deleteServerStatus(String serverName) {
		
		 String query="delete from server_status where server_name='"+serverName+"'";
		 
		return em.createNativeQuery(query).executeUpdate();
	}
	

	/* (non-Javadoc)
	 * @see com.wipro.common.config.repositories.ServerStatusRepositoryCustom#updateServerStatus(com.wipro.common.config.domain.ServerStatus)
	 */
	@Override
	public int updateServerStatus(ServerStatus serverStatus) {

		 String query="update server_status set value="+serverStatus.getValue()+" where server_name = '"+serverStatus.getserverName()+"'";
		 
		return em.createNativeQuery(query).executeUpdate();
		
	}

	/* (non-Javadoc)
	 * @see com.wipro.common.config.repositories.ServerStatusRepositoryCustom#updateServerStatus()
	 */
	@Override
	public int updateServerStatus() {
		String query="update server_status set value=1  where server_name not in  ('LOCK')";
		 
		return em.createNativeQuery(query).executeUpdate();
	}
	
	/* (non-Javadoc)
	 * @see com.wipro.common.config.repositories.ServerStatusRepositoryCustom#updateLock()
	 */
	@Override
	public int updateLock() {
		String query ;
	/*String query="update server_status set value=0  where server_name  in  ('LOCK') and "
				+ "0=(select count(*) from server_status where server_name not in ('LOCK') and value=0)"
				+ " and 1=(select value from server_status where server_name  in  ('LOCK'))";*/
		query="select count(*) from server_status where server_name not in ('LOCK') and value=1";
		List<BigInteger> rs = em.createNativeQuery(query).getResultList();
		query="select value from server_status where server_name  in  ('LOCK')";
		List<Integer> rs1 = em.createNativeQuery(query).getResultList();
		//System.out.println(rs.get(0)+"--"+rs1.get(0));
       String compare1 = rs.get(0).toString();
       String compare2 = rs1.get(0).toString();
		if("0".equals(compare1)&& "0".equals(compare2) ){
			query ="update server_status set value=1  where server_name  in  ('LOCK')";
			//System.out.println(query);
			return em.createNativeQuery(query).executeUpdate();
		}else{
			
			return 0;
		}
		
		
		
		
	}

	/* (non-Javadoc)
	 * @see com.wipro.common.config.repositories.ServerStatusRepositoryCustom#updateLock(java.lang.String)
	 */
	@Override
	public int updateLock(String a) {
		String query="update server_status set value=0  where server_name  in  ('LOCK')";
		 
		return em.createNativeQuery(query).executeUpdate();
	}
}
