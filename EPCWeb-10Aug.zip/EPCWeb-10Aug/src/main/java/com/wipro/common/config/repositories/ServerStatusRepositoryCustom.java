package com.wipro.common.config.repositories;

import java.util.List;

import com.wipro.common.config.domain.ServerStatus;

/**
 * @author Developer
 * @version 1.0
 * type ServerStatusRepositoryCustom
 */
public interface ServerStatusRepositoryCustom {
	
	 /**
	 * @param serverName
	 * @return
	 */
	List<Integer> lookupServerStatus(String serverName);


/**
 * @param serverName
 * @return
 */
int deleteServerStatus(String serverName);

/**
 * @param serverStatus
 * @return
 */
int updateServerStatus(ServerStatus serverStatus);
/**
 * @return
 */
int updateServerStatus();
/**
 * @return
 */
int updateLock();
/**
 * @param a
 * @return
 */
int updateLock(String a);
}
