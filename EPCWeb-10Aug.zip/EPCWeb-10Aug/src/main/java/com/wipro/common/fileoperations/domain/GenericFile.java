package com.wipro.common.fileoperations.domain;



import javax.persistence.*;


/**
 * The persistent class for the genericFile database table.
 * 
 */
/**
 * @author Developer
 * @version 1.0
 * type GenericFile
 */
@Entity
@Table(name="generic_file")
public class GenericFile {
	

	/**
	 * String GenericFile.java
	 */
	@Id
	@Column(name="upload_id")
	private String uploadId;

	/**
	 * byte[] GenericFile.java
	 */
	@Lob
	private byte[] file;

	/**
	 * String GenericFile.java
	 */
	@Column(name="file_name")
	private String fileName;

	/**
	 * String GenericFile.java
	 */
	@Column(name="file_type")
	private String fileType;
	/**
	 * boolean GenericFile.java
	 */
	@Transient
	private boolean createOrReplace;

	/**
	 * 
	 */
	public GenericFile() {
	}

	/**
	 * @return
	 */
	public String getUploadId() {
		return this.uploadId;
	}

	/**
	 * @param uploadId
	 */
	public void setUploadId(String uploadId) {
		this.uploadId = uploadId;
	}

	/**
	 * @return
	 */
	public final byte[] getFile() {
		return this.file;
	}

	/**
	 * @param file
	 */
	public void setFile(byte[] file) {
		this.file = file;
	}

	/**
	 * @return
	 */
	public String getFileName() {
		return this.fileName;
	}

	/**
	 * @param fileName
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return
	 */
	public String getFileType() {
		return this.fileType;
	}

	/**
	 * @param fileType
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	/**
	 * @return
	 */
	public boolean getCreateOrReplace() {
		return createOrReplace;
	}

	/**
	 * @param createOrReplace
	 */
	public void setCreateOrReplace(boolean createOrReplace) {
		this.createOrReplace = createOrReplace;
	}

}