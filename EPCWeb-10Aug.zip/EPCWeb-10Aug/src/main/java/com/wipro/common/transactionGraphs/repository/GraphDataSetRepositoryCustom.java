package com.wipro.common.transactionGraphs.repository;

import java.util.List;

/**
 * @author Developer
 * @version 1.0
 * type GraphDataSetRepositoryCustom
 */
public interface GraphDataSetRepositoryCustom {
	
	
    /**
     * @param freq
     * @return
     */
    List<Object[]> getGraphData(String freq);
    /**
     * @param startDate
     * @param endDate
     * @return
     */
    List<Object[]> getGraphData(String startDate,String endDate);
}
