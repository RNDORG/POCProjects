package com.wipro.common.fileoperations.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URLConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.fileoperations.domain.FileDownloadDTO;
import com.wipro.common.fileoperations.domain.GenericFile;
import com.wipro.common.fileoperations.repositories.GenericFileRepository;
import com.wipro.common.fileoperations.util.DataEngineApp;

/**
 * @author Developer
 * @version 1.0
 * type GenericFileService
 */
@Component
public class GenericFileService {

/**
 * GenericFileRepository GenericFileService.java
 */
@Autowired
GenericFileRepository fileRepository;

/**
 * @param fileuploadrequest
 * @return
 */
@Transactional
public String genericFileUpload(GenericFile fileuploadrequest){
	
	String message="";
	GenericFile fileGetResultSave = new GenericFile();
    GenericFile fileGetResult = fileRepository.findOne(fileuploadrequest.getUploadId());
    if (fileGetResult==null ){
    	
    	 fileGetResultSave =fileRepository.save(fileuploadrequest);
    }  
    if(fileGetResult!=null && fileuploadrequest.getCreateOrReplace())
    {
    	fileRepository.delete(fileuploadrequest.getUploadId());
    	fileGetResultSave =fileRepository.save(fileuploadrequest);
    	
    	/*fileRepository.GenericFileUpdate(fileuploadrequest);
    	fileGetResultSave.setUploadId(fileuploadrequest.getUploadId());*/
    	
    } 
	
    if(fileGetResultSave!=null)
    	message = fileGetResultSave.getUploadId();
	
	return message;
}


/**
 * @param uploadId
 * @return
 * @throws FileNotFoundException
 */
public FileDownloadDTO genericFileDownload(String uploadId) throws FileNotFoundException{
	
	FileDownloadDTO fileDownloadDTO = new FileDownloadDTO();
	 
	GenericFile fileGetResult = fileRepository.findOne(uploadId);
	
	if (fileGetResult==null)
		return fileDownloadDTO;
	DataEngineApp fileDownloadData = new DataEngineApp();
	
	String fileUrl = fileDownloadData.getFile(fileGetResult);
	//System.out.println(fileUrl);
	
	 File file = new File(fileUrl);
	 String mimeType= URLConnection.guessContentTypeFromName(file.getName());
     if(mimeType==null){
         //System.out.println("mimetype is not detectable, will take default");
         mimeType = "application/octet-stream";
     }
     //System.out.println("mimetype : "+mimeType);
     InputStream inputStream = new ByteArrayInputStream(fileGetResult.getFile());
     fileDownloadDTO.setMimeType(mimeType);
     fileDownloadDTO.setHeader(file.getName());
     fileDownloadDTO.setFileLength((int)file.length());
     fileDownloadDTO.setInputStream(inputStream);

     
	
	return fileDownloadDTO;
}


}
