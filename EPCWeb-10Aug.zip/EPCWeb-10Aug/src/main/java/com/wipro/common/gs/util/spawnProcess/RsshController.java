package com.wipro.common.gs.util.spawnProcess;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RsshController {
	
	@Autowired
	RsshService sshService;
	
	 @RequestMapping(value="rest/extapi/v1/rssh", method=RequestMethod.GET)
	    public String sshGetListService
	           (@RequestParam(value="host", required=false) String host,
	    		@RequestParam(value="user", required=false) String user,
	    		@RequestParam(value="pwd", required=false) String pwd,
	    		@RequestParam(value="cmd", required=false) String cmd) {
	    	return sshService.sshGetList(host, user, pwd, cmd);
		
	    }
	 
}
