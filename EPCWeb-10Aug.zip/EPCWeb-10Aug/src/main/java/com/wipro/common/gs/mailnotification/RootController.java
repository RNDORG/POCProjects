package com.wipro.common.gs.mailnotification;


import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;





/**
 * @author Developer
 * @version 1.0
 * type RootController
 */
@RestController
public class RootController {
	
	
	
	/**
	 * SmtpMailSender RootController.java
	 */
	@Autowired
	private SmtpMailSender smtpMailSender;

	/**
	 * @throws MessagingException
	 */
	@RequestMapping("/send-mail")
	public void sendMail() throws MessagingException {
		
		
		
		
		
		smtpMailSender.send("supratim.sen@wipro.com","","", "Test mail from Spring", "Howdy",null);
		
	}
	

}
