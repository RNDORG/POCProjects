package com.wipro.common.config.repositories;



import org.springframework.data.repository.CrudRepository;


import com.wipro.common.config.domain.ServerStatus;

/**
 * @author Developer
 * @version 1.0
 * type ServerStatusRepository
 */
public interface ServerStatusRepository extends CrudRepository<ServerStatus , Integer>,ServerStatusRepositoryCustom {

	
	public void deleteByServerName(String serverName);
	
	ServerStatus findServerStatusByServerName(String serverName);
	
	/*@Modifying(clearAutomatically = true)
	@Query(value="update server_status set server_name=:name, value=:val where serial_num=:id" , nativeQuery=true)
	int updateServerStatus(@Param("name")String name, @Param("val") Integer val, @Param("id") Integer id);
	*/
}
