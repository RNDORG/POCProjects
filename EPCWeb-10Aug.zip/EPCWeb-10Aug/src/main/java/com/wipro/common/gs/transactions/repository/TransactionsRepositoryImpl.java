package com.wipro.common.gs.transactions.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wipro.EPCWebApplication;
import com.wipro.common.gs.transactions.domain.TransactionRequestRange;
import com.wipro.common.gs.transactions.domain.Transactions;



/**
 * @author Developer
 * @version 1.0
 * type TransactionsRepositoryImpl
 */
public class TransactionsRepositoryImpl implements TransactionsRepositoryCustom {
	private static Logger logger = LoggerFactory.getLogger(TransactionsRepositoryImpl.class);
	/**
	 * EntityManager TransactionsRepositoryImpl.java
	 */
	@PersistenceContext
	EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.wipro.common.gs.transactions.repository.TransactionsRepositoryCustom#getList(java.lang.String)
	 */
	@Override
	public List<Transactions> getList(String query){
			return em.createNativeQuery(query, Transactions.class).getResultList();
		}

	/* (non-Javadoc)
	 * @see com.wipro.common.gs.transactions.repository.TransactionsRepositoryCustom#getList(com.wipro.common.gs.transactions.domain.TransactionRequestRange)
	 */
	@Override
	public List<Transactions> getList(TransactionRequestRange request) {
		// TODO Auto-generated method stub
		
		String query = "select * from transactions where 1=1";
				
		if(request.getRangefrom()!=null && !request.getRangefrom().equals("") && !request.getRangefrom().equals("undefined")){
			query +=(" And txn_timestamp >='"+request.getRangefrom()+"' ");
		}
		if(request.getRangeto()!=null && !request.getRangeto().equals("") && !request.getRangeto().equals("undefined")){
			query +=(" And txn_timestamp<='"+request.getRangeto()+"' ");
		}
		if(request.getId()!=null && !request.getId().equals("") && !request.getId().equals("undefined")){
			query +=(" And id='"+request.getId()+"' ");
		}
        if(request.getTxncode()!=null && !request.getTxncode().equals("") && !request.getTxncode().equals("undefined")){
        	query +=(" And txn_code like '"+request.getTxncode()+"' ");
		}
        if(request.getTxntype()!=null && !request.getTxntype().equals("") && !request.getTxntype().equals("undefined")){
        	  query +=(" And txn_type='"+request.getTxntype()+"' ");
		}
        if(request.getTxnrequest()!=null && !request.getTxnrequest().equals("") && !request.getTxnrequest().equals("undefined")){
      	  query +=(" And txn_request like '"+request.getTxnrequest()+"' ");
		}
        if(request.getTxnresponse()!=null && !request.getTxnresponse().equals("") && !request.getTxnresponse().equals("undefined")){
      	  query +=(" And txn_response like '"+request.getTxnresponse()+"' ");
		}
        query+=(" ORDER BY txn_timestamp DESC LIMIT 100");
		System.out.println(query);
          logger.debug("#Query: ",query);
		return em.createNativeQuery(query, Transactions.class).getResultList();
	}

	}