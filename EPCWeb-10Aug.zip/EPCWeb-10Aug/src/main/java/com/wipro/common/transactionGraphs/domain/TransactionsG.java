package com.wipro.common.transactionGraphs.domain;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;


/**
 * The persistent class for the "transactions" database table.
 * This Transaction package depends on CommonUtils.java for fetching the data from DB
 * com.wipro.common.gs.util.CommonUtils.java
 */
/**
 * @author Developer
 * @version 1.0
 * type TransactionsG
 */
@Entity
@Table(name = "transactions")
public class TransactionsG implements java.io.Serializable {

	/**
	 * Integer TransactionsG.java
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id",unique = true, nullable = false)
	private Integer id;
	/**
	 * String TransactionsG.java
	 */
	@Column(name = "txn_code", length = 200)
	private String txnCode; 
	/**
	 * String TransactionsG.java
	 */
	@Column(name = "txn_type", length = 200)
	private String txnType;
	/**
	 * String TransactionsG.java
	 */
	@Column(name = "txn_request", length = 4000)
	private String txnRequest;
	/**
	 * String TransactionsG.java
	 */
	@Lob
	@Column(name = "txn_response")
	private String txnResponse;
	/**
	 * Date TransactionsG.java
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "txn_timestamp", length = 7)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date txnTimestamp;

	/**
	 * 
	 */
	public TransactionsG() {
	}

	/**
	 * @param id
	 */
	public TransactionsG(Integer id) {
		this.id = id;
	}

	/**
	 * @param id
	 * @param txnCode
	 * @param txnType
	 * @param txnRequest
	 * @param txnResponse
	 * @param txnTimestamp
	 */
	public TransactionsG(Integer id, String txnCode, String txnType,
			String txnRequest, String txnResponse, Date txnTimestamp) {
		this.id = id;
		this.txnCode = txnCode;
		this.txnType = txnType;
		this.txnRequest = txnRequest;
		this.txnResponse = txnResponse;
		this.txnTimestamp = txnTimestamp;
	}

	/**
	 * @return
	 */
		
	public Integer getId() {
		return this.id;
	}

	/**
	 * @param id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return
	 */
	
	public String getTxnCode() {
		return this.txnCode;
	}

	/**
	 * @param txnCode
	 */
	public void setTxnCode(String txnCode) {
		this.txnCode = txnCode;
	}

	/**
	 * @return
	 */
	
	public String getTxnType() {
		return this.txnType;
	}

	/**
	 * @param txnType
	 */
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	/**
	 * @return
	 */
	
	public String getTxnRequest() {
		return this.txnRequest;
	}

	/**
	 * @param txnRequest
	 */
	public void setTxnRequest(String txnRequest) {
		this.txnRequest = txnRequest;
	}

	/**
	 * @return
	 */
	
	public String getTxnResponse() {
		return this.txnResponse;
	}

	/**
	 * @param txnResponse
	 */
	public void setTxnResponse(String txnResponse) {
		this.txnResponse = txnResponse;
	}

	/**
	 * @return
	 */
	
	public Date getTxnTimestamp() {
		return this.txnTimestamp;
	}

	/**
	 * @param txnTimestamp
	 */
	public void setTxnTimestamp(Date txnTimestamp) {
		this.txnTimestamp = txnTimestamp;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Transactions [id=" + id + ", txnCode=" + txnCode + ", txnType="
				+ txnType + ", txnRequest=" + txnRequest + ", txnResponse="
				+ txnResponse + ", txnTimestamp=" + txnTimestamp + "]";
	}


}
