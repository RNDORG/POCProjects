package com.wipro.common.transactionGraphs.repository;

import org.springframework.data.repository.CrudRepository;

import com.wipro.common.transactionGraphs.domain.TransactionsG;

/**
 * @author Developer
 * @version 1.0
 * type GraphDataSetRepository
 */
public interface GraphDataSetRepository extends CrudRepository<TransactionsG , Integer>,GraphDataSetRepositoryCustom {

}
