package com.wipro.common.fileoperations.controller;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.common.config.service.ConfigService;
import com.wipro.common.gs.util.GrepSearchUtil;
import com.wipro.common.logging.GetLogLocationController;
import com.wipro.epc.services.BroadcastService;


@RestController
public class LoggersGrepSearch {

	@Autowired
	ConfigService configService;
	
	@Autowired
	GetLogLocationController getLogLocationController;
	
	@Autowired
	BroadcastService broadcastService;
    
	
	@RequestMapping(value = "rest/extapi/v1/logs/dummy", method = RequestMethod.GET)
	public List<String> sample()
	{
		MultiValueMap map  = new LinkedMultiValueMap<String, String>();
		File file = new File("./logs/EPCLOG.log");
		return GrepSearchUtil.grepSearchInFile(file, "", "->");
	
	}
	
	
	@RequestMapping(value = "rest/extapi/v1/logs", method = RequestMethod.GET)
	public String searchResutls(@RequestParam MultiValueMap map)
	{
		System.out.println("Loggers filepath did not work ");
		String outputString = "";
		List<String> ports = new ArrayList<String>();
		ports.add((configService.getConfigValueFromDb("log", "node")).trim());
		System.out.println();
		List<String> localLogs = new ArrayList<String>();
		localLogs.add("locallogs");
		for(String port:ports) {
			System.out.println("Ports are "+port);
		}
		map.put("to", ports);
		map.put("api", localLogs);
		Map<String, String> output =  broadcastService.getReplyService(map);
		
		List<String> l = new ArrayList<String>(output.values());
		
		if(map.get("limit")!=null && ((List<String>)map.get("limit")).size()>0) {
			l = l.subList(0, Integer.parseInt(((List<String>) map.get("limit")).get(0)));
		}
		else {
			if(l.size()>10) {
				System.out.println("List is "+l);
				System.out.println("Size of l is "+l.size());
				l = l.subList(0, 10);
			}
		}
		int z = 0;
		for(String s: l){
			if(!l.contains("") && z==0) {
				outputString = outputString + s+"\n";
			} else {
				outputString = outputString + s;
			}
			z++;
		}
		return outputString ;
	}
	
	
	@RequestMapping(value = "rest/extapi/v1/locallogs", method = RequestMethod.GET)
	//@RequestMapping(value = "rest/extapiauth/v1/config/logs", method = RequestMethod.GET)
	public String searchResutls(@RequestParam(value="grep", defaultValue="") String grep, 
			@RequestParam(value="limit", defaultValue="10") Integer limit,
		@RequestParam(value="delim", defaultValue="->") String delim) {

		List<String> returnList = new ArrayList<String>();
		
		FilenameFilter fileNameFilter = new FilenameFilter() {
			   
            @Override
            public boolean accept(File dir, String name) {
               if(name.lastIndexOf('.')>0) {
               
                  // get last index for '.' char
                  int lastIndex = name.lastIndexOf('.');
                  
                  // get extension
                  String str = name.substring(lastIndex);
                  
                  // match path name extension
                  if(str.equals(".log")) {
                     return true;
                  }
               }
               
               return false;
            }
         };
		
        File file = new File(getLogLocationController.setTestingController());
		//String folderAddress = ("./logs/");
        String folderAddress = file.getParentFile().getName();
		File folder = new File(folderAddress);
        // File folder = new File("C:/Users/KE334465/Desktop/Code/3rd March/EPCWeb/sampleFolder/");
		File[] listOfFiles = folder.listFiles(fileNameFilter);

		Arrays.sort( listOfFiles, new Comparator()
		{
		    @Override
			public int compare(Object o1, Object o2) {

		        if (((File)o1).lastModified() > ((File)o2).lastModified()) {
		            return -1;
		        } else if (((File)o1).lastModified() < ((File)o2).lastModified()) {
		            return +1;
		        } else {
		            return 0;
		        }
		    }

		});
		Collections.reverse(Arrays.asList(listOfFiles));
		//List<String> splitDataFull = new ArrayList<String>();
		StringBuffer response = new StringBuffer();
		
		
		for(int i=0; i<listOfFiles.length; i++) {
			System.out.println(listOfFiles[i].getName());
			if(listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(".log")){
				try {
			//Reader fileOne = new FileReader("C:/Users/KE334465/Desktop/Code/3rd March/EPCWeb/sampleFolder/"+listOfFiles[i].getName().toString());
//				Reader fileOne = new FileReader("./logs/"+listOfFiles[i].getName().toString());
//				
//				BufferedReader br = new BufferedReader(fileOne) ;
//				String fileData = "";
//				    String line;
//				   // fileOne.toString()
//						while ((line = br.readLine()) != null) {
//							fileData = fileData+line+"\n";
//						   
//						}
				String content = new String(Files.readAllBytes(Paths.get(folderAddress+"/"+listOfFiles[i].getName().toString())));
				
				
			if(!grep.equals("")){
					String[] splitArray = content.split(delim);
					for(int j=0; j<splitArray.length;j++){
						 if(splitArray[j].contains(grep)){
							returnList.add(splitArray[j]);
							if(returnList.size()>limit) {
								break;
							}
						 }
					}
					
			}
			else {
					String[] splitArray = content.split(delim);
					for(int k=0; k<splitArray.length; k++){
							returnList.add(splitArray[k]);
							if(returnList.size()>limit) {
								break;
							}
					}
				}

			if(returnList.size()>limit) {
					break;
			}
				
				
				} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
			
		}
		}
		List<String> returnListWithLimit = null;
		if(returnList.size()>limit) {
			if(!grep.equals("")) {
				returnListWithLimit = new ArrayList<String>(returnList.subList(0, limit));
			} else {
				returnListWithLimit = new ArrayList<String>(returnList.subList(0, limit+1));
			}
		} else {
			returnListWithLimit = returnList;
		}
		
		int m =0;
		for(String s: returnListWithLimit){
			if(m!=0) {
				response.append(delim).append(s);
			} else {
				response.append(s);
			}
			m++;
		}
		
		return response.toString();
	}
}
