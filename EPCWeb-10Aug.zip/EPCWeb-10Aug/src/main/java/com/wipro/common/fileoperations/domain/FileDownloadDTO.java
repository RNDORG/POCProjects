package com.wipro.common.fileoperations.domain;

import java.io.InputStream;

/**
 * @author Developer
 * @version 1.0
 * type FileDownloadDTO
 */
public class FileDownloadDTO {
	/**
	 * InputStream FileDownloadDTO.java
	 */
	InputStream inputStream;
	/**
	 * String FileDownloadDTO.java
	 */
	String  mimeType;
	/**
	 * String FileDownloadDTO.java
	 */
	String header;
	/**
	 * Integer FileDownloadDTO.java
	 */
	Integer fileLength;
	/**
	 * @return
	 */
	public InputStream getInputStream() {
		return inputStream;
	}
	/**
	 * @param inputStream
	 */
	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}
	/**
	 * @return
	 */
	public String getMimeType() {
		return mimeType;
	}
	/**
	 * @param mimeType
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	/**
	 * @return
	 */
	public String getHeader() {
		return header;
	}
	/**
	 * @param header
	 */
	public void setHeader(String header) {
		this.header = header;
	}
	/**
	 * @return
	 */
	public Integer getFileLength() {
		return fileLength;
	}
	/**
	 * @param fileLength
	 */
	public void setFileLength(Integer fileLength) {
		this.fileLength = fileLength;
	}
	
}
