package com.wipro.common.fileoperations.repositories;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wipro.common.fileoperations.domain.GenericFile;

/**
 * @author Developer
 * @version 1.0
 * type GenericFileRepositoryImpl
 */
public class GenericFileRepositoryImpl implements GenericFileRepositoryCustom {

	/**
	 * Logger GenericFileRepositoryImpl.java
	 */
	private static Logger logger = LoggerFactory
			.getLogger(GenericFileRepositoryImpl.class);
	
	/**
	 * EntityManager GenericFileRepositoryImpl.java
	 */
	@PersistenceContext
	private EntityManager em; 
/*

********************************** Below two methods are not working at all *****************************************SAMPATH*********************
*
*
*
*/
	/* (non-Javadoc)
	 * @see com.wipro.common.fileoperations.repositories.GenericFileRepositoryCustom#GenericFileSave(com.wipro.common.fileoperations.domain.GenericFile)
	 */
	@Override
	public String GenericFileSave(GenericFile file) {
		String result="insert failed";
		String query ="INSERT INTO `generic_file` (`upload_id`, `file_name`, `file_type`, `file`) VALUES ('"+file.getUploadId()+"', '"+file.getFileName()+"', '"+file.getFileType()+"',"+file.getFile()+");";
		//System.out.println("IQUERY ["+query +"] \n filename [" + file.getFile() + "]" );
		int i = em.createNativeQuery(query).executeUpdate();
		if(i>0)
		result = file.getUploadId();
		return result;
	}

	/* (non-Javadoc)
	 * @see com.wipro.common.fileoperations.repositories.GenericFileRepositoryCustom#GenericFileUpdate(com.wipro.common.fileoperations.domain.GenericFile)
	 */
	@Override
	public String GenericFileUpdate(GenericFile file) {
/*		String query = "update generic_file set file_name='"+file.getFileName()+"' , file="+file.getFile()+" where upload_id='"+file.getUploadId()+"' and file_type='"+file.getFileType()+"';";
		//System.out.println("UQUERY ["+query +"] \n filename [" + file.getFile() + "]" );
		
		int i = em.createNativeQuery(query).executeUpdate();
		
		return String.valueOf(i);
*/
		// Temporary Fix - Delete and insert instead of update as update query is crashing. Need to fix this properly later. 
		String result="insertion failed";
		if( GenericFileDelete(file) >0 )
			result= GenericFileSave(file);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.wipro.common.fileoperations.repositories.GenericFileRepositoryCustom#GenericFileDelete(com.wipro.common.fileoperations.domain.GenericFile)
	 */
	@Override
	public Integer GenericFileDelete(GenericFile File) {
		// TODO Auto-generated method stub
		String query="delete from generic_file where upload_id='"+File.getUploadId()+"';";
		 
		return em.createNativeQuery(query).executeUpdate();
	}

	/* (non-Javadoc)
	 * @see com.wipro.common.fileoperations.repositories.GenericFileRepositoryCustom#GenericFileGet()
	 */
	@Override
	public String GenericFileGet() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.wipro.common.fileoperations.repositories.GenericFileRepositoryCustom#GenericFileGet(java.lang.String)
	 */
	@Override
	public String GenericFileGet(String uploadCode) {
		String query = "select * from generic_file where upload_id ='"+uploadCode+"'";
		em.createNativeQuery(query).getResultList();
		return null;
	}

}
