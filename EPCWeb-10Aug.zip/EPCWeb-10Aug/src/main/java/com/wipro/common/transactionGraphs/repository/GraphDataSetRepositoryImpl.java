
package com.wipro.common.transactionGraphs.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wipro.EPCWebApplication;

/**
 * @author Developer
 * @version 1.0
 * type GraphDataSetRepositoryImpl
 */
public class GraphDataSetRepositoryImpl  implements GraphDataSetRepositoryCustom{
	private static Logger logger = LoggerFactory.getLogger(GraphDataSetRepositoryImpl.class);
	/**
	 * EntityManager GraphDataSetRepositoryImpl.java
	 */
	@PersistenceContext
	private EntityManager em;
	/**
	 * List<Object[]> GraphDataSetRepositoryImpl.java
	 */
	List<Object[]> result = new ArrayList<Object[]>();
	/* (non-Javadoc)
	 * @see com.wipro.common.transactionGraphs.repository.GraphDataSetRepositoryCustom#getGraphData(java.lang.String)
	 */
	@Override
	public List<Object[]> getGraphData(String freq) {
		String query="";
		
		if("W".equals(freq)){
			query="select count(*) as countT ,txn_timestamp as timeT,txn_type as typeT from transactions WHERE txn_timestamp >= curdate() - INTERVAL DAYOFWEEK(curdate())+4 DAY "
					+ " group by txn_timestamp,txn_type   order by  typeT,timeT;";
		}else if ("D".equals(freq)){
			
			query="select count(*) as countT ,txn_timestamp as timeT,txn_type as typeT from transactions WHERE txn_timestamp >= now() - INTERVAL 1 DAY"
					+ " group by txn_timestamp,txn_type   order by  typeT,timeT";
		
			
		}
		try{
		result =em.createNativeQuery(query).getResultList();
		}catch(Exception  e){
		
			if("W".equals(freq)){
				query="select count(*) as countT ,FORMATDATETIME(txn_timestamp,'dd/mm/yyyy') as timeT,txn_type as typeT from transactions WHERE txn_timestamp >= now()-7 "
						+ " group by   timeT ,txn_type   order by typeT,timeT;";
			}else if ("D".equals(freq)){
				
				query="select count(*) as countT ,FORMATDATETIME(txn_timestamp,'dd/mm/yyyy HH') as timeT,txn_type as typeT from transactions WHERE txn_timestamp= now()  "
						+ "group by   timeT ,txn_type   order by typeT,timeT;";
			
				
			}
			
			result =em.createNativeQuery(query).getResultList();
		}
        
        logger.info("Transaction query when given frequency as input : ",query);
        
        
        
        return result;
	}
	/* (non-Javadoc)
	 * @see com.wipro.common.transactionGraphs.repository.GraphDataSetRepositoryCustom#getGraphData(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> getGraphData(String startDate, String endDate) {
		
		String query = "SELECT count(*) as countT,txn_timestamp as timeT,txn_type as typeT FROM transactions"
				+ " WHERE  (txn_timestamp BETWEEN '"+startDate+"' AND '"+endDate+"') "
						+ " group by   timeT ,txn_type   order by typeT,timeT;"; //startDate.split(" ")[0]
		//System.out.println(query);
		logger.info("Transaction query when given start and end date as inputs : ",query);
		List<Object[]> result=em.createNativeQuery(query).getResultList();
		return result;
	}
	
	
	
	
	
}
