package com.wipro.common.config.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jcraft.jsch.Logger;
import com.wipro.common.config.domain.Config;
import com.wipro.common.config.service.ConfigService;
import com.wipro.common.config.service.ServerStatusService;
import com.wipro.epc.services.BroadcastService;

/**
 * @author SU288598
 * @version 1.0
 *
 */
@RestController
public class ConfigurationController {

	/**
	 * Config Service
	 */
	@Autowired
	ConfigService configService;
	
	@Autowired
	ServerStatusService serverService;

	@Autowired
	BroadcastService broadcastService;
    
    /**
     * @return
     */
    @RequestMapping("rest/extapi/v1/config")
    public List<Config> getConfig() {
    	return configService.getConfigsFromDB();
    }
    
    
    /**
     * @param key
     * @param group
     * @return
     */
    @RequestMapping(value="rest/api/v1/configKeys",method=RequestMethod.GET)
    public List<String> getKey(@RequestParam(value="config_key")String key, @RequestParam(value="config_group") String group) {
    	
    	return configService.getConfigValueForApplicability(group, key);
    }
    
    /**
     * @param conf
     * @return
     */
    @RequestMapping(value = "rest/api/v1/config",  method=RequestMethod.POST)
    public  List<Config> updateConfig(@RequestBody  @Valid List<Config> conf) {
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String user=auth.getName();
    	if(configService.updateConfig(conf,user)) {
    		return configService.getConfigsFromDB();}
    	else {
    		return null;}
    	
    }
    
    @RequestMapping("rest/extapi/v1/cache/config")
    public List<Config> getConfigCache() {
    	return configService.getConfigs();
    }
    
    @RequestMapping(value = "rest/extapiauth/v1/cache/config/update",  method=RequestMethod.GET)
    public  Map<String, String> updateConfigDataAndReload(@RequestParam(value="group") String group, @RequestParam(value="key") String key, @RequestParam(value="value") String value) {
    	
    	Map<String, String> response = new HashMap<String, String>();
    	if(serverService.isCurrentlyUiServer() && StringUtils.isNotBlank(group) && StringUtils.isNotBlank(key) && StringUtils.isNotBlank(value)) {
    		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    		String user=auth.getName();
    		int count =configService.updateConfig(group, key, value, user);
    		if (count>0) {
    			MultiValueMap allRequestParams=new LinkedMultiValueMap<>();
    			allRequestParams.add("api", "cache/config/reloadLocal");
    			allRequestParams.add("to", "all");
    			response = broadcastService.getReplyService(allRequestParams);
    			
    		}
    		else {response.put("Update Failed", "Wrong Config Data!!");}
    	}
    	else {
    		response.put ("Wrong Input Provided OR The application restricted from this Update","Please Try from Correct application server");
    	}
    	
    	return response;
    }
    
}
