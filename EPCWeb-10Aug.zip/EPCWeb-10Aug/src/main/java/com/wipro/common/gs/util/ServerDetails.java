/**
 * EPC Application - ServerDetails.java
 */
package com.wipro.common.gs.util;

import java.net.InetAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Developer
 * @version 1.0
 * type ServerDetails
 */
@Service
public class ServerDetails {

@Autowired
private GetPortAddressController getPortAddressController;
	
	
public String getManagedSeverName() {	
	String managedServerName="";
	try {
	final String ip = InetAddress.getLocalHost().getHostAddress().trim();
	final String host =InetAddress.getLocalHost().getHostName().trim();
	String server = System.getProperty("jboss.server.name");
	
	managedServerName=(server==null ? host : server)+"@"+ip+":"+getPortAddressController.returnPortNumber();
	
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return managedServerName;
}

public String getIpPort() {
	String ipPort="";
	try {
			final String ip = InetAddress.getLocalHost().getHostAddress().trim();
			ipPort=ip+":"+getPortAddressController.returnPortNumber();
	}
	finally {
		return ipPort;
	}
}
	
}
