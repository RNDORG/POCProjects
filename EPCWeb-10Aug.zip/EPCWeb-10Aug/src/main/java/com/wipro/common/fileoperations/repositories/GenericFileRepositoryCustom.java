package com.wipro.common.fileoperations.repositories;

import com.wipro.common.fileoperations.domain.GenericFile;

/**
 * @author Developer
 * @version 1.0
 * type GenericFileRepositoryCustom
 */
public interface GenericFileRepositoryCustom {

	/**
	 * @param file
	 * @return
	 */
	String GenericFileSave(GenericFile file);
	/**
	 * @param file
	 * @return
	 */
	String GenericFileUpdate(GenericFile file);
	/**
	 * @param File
	 * @return
	 */
	Integer GenericFileDelete(GenericFile File);
	/**
	 * @return
	 */
	String GenericFileGet();
	/**
	 * @param uploadCode
	 * @return
	 */
	String GenericFileGet(String uploadCode);
	
}
