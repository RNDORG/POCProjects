package com.wipro.common.config.exception;

/**
 * @author Developer
 * @version 1.0
 * type NoStatusFound
 */
public class NoStatusFound extends Exception {

	/**
	 * long NoStatusFound.java
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param s
	 */
	public NoStatusFound(String s) {
	      super(s);
	   }

}
