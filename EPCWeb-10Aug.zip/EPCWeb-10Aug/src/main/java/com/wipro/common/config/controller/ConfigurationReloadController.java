package com.wipro.common.config.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.common.config.service.ConfigService;
import com.wipro.epc.services.BroadcastService;
import com.wipro.common.config.service.ServerStatusService;




/**
 * @author Developer
 * @version 1.0
 * type ConfigurationReloadController
 */
@RestController
public class ConfigurationReloadController {
	/**
	 * Logger ConfigurationReloadController.java
	 */
	private static Logger logger = LoggerFactory.getLogger(ConfigurationReloadController.class);
	
	/**
	 * ConfigService ConfigurationReloadController.java
	 */
	@Autowired
	ConfigService configService;	 
	
	@Autowired
	BroadcastService broadcastService;
    
	@Autowired
	ServerStatusService serverService;

	  /**
	 * @return
	 */
	@RequestMapping("rest/extapi/v1/cache/config/reloadLocal")
	  public List<String> reloadSwitch() {	
		
		  List<String> list = new ArrayList();
		/*  Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		  String user =auth.getName();
		 Long currentTime = System.currentTimeMillis();
		 int interval = Integer.parseInt(configService.getPollingInterval().toString())/60000;
		  //list.add(serviceStatusService.configReload());
		  int count = configService.updateConfig("Config", "LastModifiedTime", currentTime.toString(),user);
		  logger.info("Update the lastmodifiedTime (0?1)" + count);*/
		  
		  configService.reloadConfigs();
		  /*if(count>0)
			  list.add("Reload Operation Intiated, may take upto "+ interval +" minutes");
		  else
			  list.add("Reload Crashed");*/
		 list.add("Reloaded the config cache and notification sent to listners");
		 logger.info("Reloaded the config cache");
		  return list;
		
	    }
	
	@RequestMapping("rest/extapi/v1/cache/config/reload")
	  public Map<String,String> reloadSwitchBroadcast() {	
		MultiValueMap allRequestParams=new LinkedMultiValueMap<>();
		Map<String, String> returneValue = new HashMap<String, String>();
		
		if(serverService.isCurrentlyUiServer()) {
		
		allRequestParams.add("api", "cache/config/reloadLocal");
		allRequestParams.add("to", "all");
		logger.info("Broadcasting Config Reload");
		returneValue=broadcastService.getReplyService(allRequestParams);
		
		}
		else {
			logger.warn("Not Allowed Server to do Broadcast");
			returneValue.put("Not Allowed to do Broadcast", "Please check with Admin");
		}
		
		return returneValue;
		
	    }
	  
	  
	

}
 

