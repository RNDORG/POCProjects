package com.wipro.common.gs.transactions.domain;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;


/**
 * The persistent class for the "transactions" database table.
 * This Transaction package depends on CommonUtils.java for fetching the data from DB
 * com.wipro.common.gs.util.CommonUtils.java
 */
/**
 * @author Developer
 * @version 1.0
 * type Transactions
 */
@Entity
@Table(name = "transactions")
public class Transactions implements java.io.Serializable {

	/**
	 * Integer Transactions.java
	 */
	private Integer id;
	/**
	 * String Transactions.java
	 */
	private String txnCode; 
	/**
	 * String Transactions.java
	 */
	private String txnType;
	/**
	 * String Transactions.java
	 */
	private String txnRequest;
	/**
	 * String Transactions.java
	 */
	private String txnResponse;
	/**
	 * Date Transactions.java
	 */
	private Date txnTimestamp;

	/**
	 * 
	 */
	public Transactions() {
	}

	/**
	 * @param id
	 */
	public Transactions(Integer id) {
		this.id = id;
	}

	/**
	 * @param id
	 * @param txnCode
	 * @param txnType
	 * @param txnRequest
	 * @param txnResponse
	 * @param txnTimestamp
	 */
	public Transactions(Integer id, String txnCode, String txnType,
			String txnRequest, String txnResponse, Date txnTimestamp) {
		this.id = id;
		this.txnCode = txnCode;
		this.txnType = txnType;
		this.txnRequest = txnRequest;
		this.txnResponse = txnResponse;
		this.txnTimestamp = txnTimestamp;
	}

	/**
	 * @return
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id",unique = true, nullable = false)	
	public Integer getId() {
		return this.id;
	}

	/**
	 * @param id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return
	 */
	@Column(name = "txn_code", length = 200)
	public String getTxnCode() {
		return this.txnCode;
	}

	/**
	 * @param txnCode
	 */
	public void setTxnCode(String txnCode) {
		this.txnCode = txnCode;
	}

	/**
	 * @return
	 */
	@Column(name = "txn_type", length = 200)
	public String getTxnType() {
		return this.txnType;
	}

	/**
	 * @param txnType
	 */
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	/**
	 * @return
	 */
	@Column(name = "txn_request", length = 4000)
	public String getTxnRequest() {
		return this.txnRequest;
	}

	/**
	 * @param txnRequest
	 */
	public void setTxnRequest(String txnRequest) {
		this.txnRequest = txnRequest;
	}

	/**
	 * @return
	 */
	@Lob
	@Column(name = "txn_response")
	public String getTxnResponse() {
		return this.txnResponse;
	}

	/**
	 * @param txnResponse
	 */
	public void setTxnResponse(String txnResponse) {
		this.txnResponse = txnResponse;
	}

	/**
	 * @return
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "txn_timestamp", length = 7)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	public Date getTxnTimestamp() {
		return this.txnTimestamp;
	}

	/**
	 * @param txnTimestamp
	 */
	public void setTxnTimestamp(Date txnTimestamp) {
		this.txnTimestamp = txnTimestamp;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Transactions [id=" + id + ", txnCode=" + txnCode + ", txnType="
				+ txnType + ", txnRequest=" + txnRequest + ", txnResponse="
				+ txnResponse + ", txnTimestamp=" + txnTimestamp + "]";
	}


}
