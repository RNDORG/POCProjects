package com.wipro.common.config.exception;

/**
 * @author Developer
 * @version 1.0
 * type DuplicateValue
 */
public class DuplicateValue extends Exception {
	/**
	 * long DuplicateValue.java
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param s
	 */
	public DuplicateValue(String s) {
	      super(s);
	   }

}
