package com.wipro.common.fileoperations.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wipro.common.fileoperations.domain.GenericFile;

/**
 * @author Developer
 * @version 1.0
 * type DataEngineApp
 */
public class DataEngineApp {

	/**
	 * @param file
	 * @return
	 */
	
	private static Logger logger = LoggerFactory.getLogger(DataEngineApp.class);
	public String getFile(GenericFile file) {

		String fileUrl = "";
		String rootPath = "ProductFileDownloads";
		byte[] bytes = file.getFile();
		File dir = new File(rootPath + File.separator + "tmpFiles");
		if (!dir.exists()) {
			dir.mkdirs();
		}

		File downloadDirectory = new File(dir.getAbsolutePath()
				+ File.separator + file.getFileName());
		try {
			BufferedOutputStream stream = new BufferedOutputStream(
					new FileOutputStream(downloadDirectory));

			stream.write(bytes);
			stream.close();
			//System.out.println("Location="					+ downloadDirectory.getAbsolutePath());
			fileUrl = downloadDirectory.getAbsolutePath();
		} catch (FileNotFoundException e) {

			logger.error(ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {

			logger.error(ExceptionUtils.getStackTrace(e));
		}

		return fileUrl;
	}

}
