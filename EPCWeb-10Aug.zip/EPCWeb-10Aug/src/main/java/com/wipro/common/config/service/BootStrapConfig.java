/*package com.wipro.common.config.service;

import java.net.InetAddress;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;
import com.wipro.common.config.domain.ServerStatus;

@Component
public class BootStrapConfig {

	private static Logger logger = LoggerFactory.getLogger(BootStrapConfig.class);
	
	final static String environmentLookupKey = "Server";  // TODO: Test if this works on Wildfly.
	 
	@Autowired
	ServerStatusService serverStatusService;

	@Autowired
	ConfigService configService;
	@Value("${config.managed_server_prefix}")
	public String managedServerPrefix;

	@Value("${spring.profiles.active}")
	private String activeProfile;
	
	@Value("${config.dynamic_configuration}")
	private String dynamicConfigurationFlag;
	
	@Value("${config.polling_Interval}")
	private String pollingIntervalP;
    
	public String envServerName; 
	
	private boolean cleanupjob=false;

	@PreDestroy
	public void deleteServerStatus() {

		//System.out.println("-------"+envServerName);
		
		if ( !dynamicConfigurationFlag.trim().equalsIgnoreCase("true")) {
			return;
		}
		
		if ( !configService.isBootStrapConfigCompleted() && !cleanupjob) { 			 
			logger.warn("WatchDog: WatchDog deleteServerStatus Method invoked before completion of WatchDog Initialization. ");
			return; 
		}
		try {		
			serverStatusService.deleteServerStatus(envServerName);
		
			cleanupjob=false;
		
		}
		catch (Exception e) {			
			logger.warn("Everything is fine error message :"+ e.getMessage()); 
		e.printStackTrace();			
		}
	}
		
	@PostConstruct
	public void initializeWatchDog() throws Exception {

		if ( !dynamicConfigurationFlag.trim().equalsIgnoreCase("true")) {
			return;
		}

		envServerName = System.getenv().get(environmentLookupKey);
		
		////System.out.println("-------"+envServerName);//+"..."+managedServerPrefix+"-----"+InetAddress.getLocalHost().toString());

		if (envServerName == null) {
			envServerName = managedServerPrefix+InetAddress.getLocalHost().toString();
		}
		//System.out.println(activeProfile);

			if (1==1) {
				// This is probably a locally running embedded H2 database with "messed up" data, so let us clean it.  
				logger.info("Checking for crashes");
				
				cleanupjob=true;
				deleteServerStatus();
			}

			try {
				ServerStatus serverStatus = new ServerStatus(envServerName,0);
				serverStatusService.insertServerStatus(serverStatus);
			} catch (MySQLIntegrityConstraintViolationException e) {  

				String errorMsg = "Unable to start up application on \"" + envServerName + "\". Possible reasons are - \n"
						+ "1. Application was not shutdown properly last time. If this is the case, truncate all rows in Database table server status table and restart application \n "
						+ "2. An instance of the application is already running on this server \"" + envServerName + "\"";
				logger.error(errorMsg);
				logger.error("\n Exception Class: " + e.getClass().getName() + "\n Message : " + e.getMessage() );				
				e.printStackTrace();
				throw new Exception(errorMsg);
			}catch (Exception e){
				logger.error("Unexpected Error : " + e.getMessage());
				logger.error("\n Exception Class: " + e.getClass().getName() + "\n Message : " + e.getMessage() );
				e.printStackTrace();
				throw new Exception(e.getMessage());
		}		
		configService.setBootStrapConfigCompleted( true );
		
	}

	@Scheduled(fixedDelayString= "${config.polling_Interval}")
	public void watchDog()  {
		
		if ( !dynamicConfigurationFlag.trim().equalsIgnoreCase("true")) {
			return;
		}
		
		if ( !configService.isBootStrapConfigCompleted() ) { 			// Defensive Check 
			logger.warn("WatchDog: WatchDog Polling Method invoked before WatchDog Initialization. ");
			return; 
		}

		try{
			logger.info(envServerName+":  WatchDog: Heartbeat after " + Integer.parseInt(pollingIntervalP)/1000 + " seconds. " );
			if (serverStatusService.needsReload(envServerName)  ) {
				logger.info("WatchDog: Reloading Configuration Data on Server \"" + envServerName + "\"");
				configService.reloadConfigs();
				serverStatusService.updateServerValue( new ServerStatus(envServerName,0 ) );
			}
		}  catch (Exception e) {			
			logger.error("Error occured in WatchDog Poller : " + e.getClass().getName() + " : " + e.getMessage() ); 
			e.printStackTrace();			
		}
	}

	
}


*/