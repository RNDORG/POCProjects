package com.wipro.common.gs.transactions.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.wipro.common.gs.transactions.domain.Transactions;


/**
 * @author Developer
 * @version 1.0
 * type TransactionsRepository
 */
public interface TransactionsRepository extends CrudRepository<Transactions, Integer>, TransactionsRepositoryCustom{

	
	@Query(value="select distinct txn_type  from transactions where txn_type <> 'null'", nativeQuery=true)
	List<String> getTxnType();
	
}
