/**
 * EPC Application - ReloadListener.java
 */
package com.wipro.common.config.service;

import java.util.List;

import com.wipro.common.config.domain.Config;

/**
 * @author Developer
 * @version 1.0
 * type ReloadListener
 */
public interface ReloadListener {
	/**
	 *ReloadListener.java
	 *
	 **/
	
	void onReload(final List<Config> oldConfig, final List<Config> newConfig );
	
	
}
