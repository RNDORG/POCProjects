package com.wipro.common.logging;

import java.io.File;
import java.util.Iterator;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.FileAppender;

@Service 
public class GetLogLocationService {
	
	//private static Logger log = LoggerFactory.getLogger(Testing.class);
	Logger  log = (Logger) LoggerFactory.getLogger(Logger.class);
	
	
	
	public String getLocation(){
		
		File clientLogFile;
		FileAppender<ILoggingEvent> fileAppender = null;
		
	LoggerContext context = (LoggerContext)LoggerFactory.getILoggerFactory();
	{
	for (Logger logger : context.getLoggerList()) {
	        for (Iterator<Appender<ILoggingEvent>> index = logger.iteratorForAppenders(); index.hasNext();)
	        {
	           // Appender<ILoggingEvent> appender = index.next();
 			Object enumElement = index.next();
           		if (enumElement instanceof FileAppender) {
              	       fileAppender = (FileAppender<ILoggingEvent>) enumElement;
           	}
	        }
	    }
	
	if (fileAppender != null) {
	     clientLogFile=new File(fileAppender.getFile());
	}
	else {
	     clientLogFile = null;
	}

	//log.d("logfile path", clientLogFile.getAbsolutePath());
	
 }
	if(clientLogFile!=null) {
		return clientLogFile.getAbsolutePath();
	} else {
		return "./logs/sample";
	}
}
}