package com.wipro.common.config.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.common.config.domain.Config;
import com.wipro.common.config.repositories.ConfigRepository;
import com.wipro.epc.util.Constants;

/**
 * @author Developer
 * @version 1.0
 * type ConfigService
 */
@Component
public class ConfigService {
	/**
	 * Logger ConfigService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(ConfigService.class);
	
	
    // Time elapsed in milliseconds since epoch. 
    /**
     * long ConfigService.java
     */
    private long lastReadTime;  // Initialized in reload()  


    List<Config> oldConfigCache;
    
	/**
	 * List<Config> ConfigService.java
	 */
	List<Config> configCache;
	
	
	/**
	 * ConfigRepository ConfigService.java
	 */
	@Autowired
	ConfigRepository configRepo;

	/**
	 * String ConfigService.java
	 */
	//@Value("${config.dynamic_configuration}")       
	private String dynamicConfigurationFlag;

    /**
     * String ConfigService.java
     */
  //  @Value("${config.polling_Interval}")
    private Long pollingInterval;  
    
   /**
    *  
    * @return pollingInterval
    */
  public Long getPollingInterval() {
		return pollingInterval;
	}

  
  

/**
 * @return
 */
  /*  
	@PostConstruct
    public void initIt() {    	
		dynamicConfigurationFlag=configRepo.getConfigValueFromDB("Config", "dynamic_configuration");
		if(dynamicConfigurationFlag==null){
			dynamicConfigurationFlag="false";
		}
		String pollingIntervalStr = configRepo.getConfigValueFromDB("Config", "polling_Interval");
		if(pollingIntervalStr!=null){
			try{
				pollingInterval = Long.parseLong(pollingIntervalStr);
			}
			catch(NumberFormatException e){
			pollingInterval=(long) 120000;
			logger.warn("Wrong polling interval provied. Changing to default 12000 milisecs");
		}
		}
		else{
			pollingInterval=(long) 120000;
			logger.warn("No polling interval provied. Default set to 12000 milisecs");
		}
    }
    
    */
public  List<Config> getConfigsFromDB(){
	  
	  List<Config> configs = new ArrayList<Config>();
	  Iterator<Config> configIt=  configRepo.findAll().iterator();
	  	
	  while (configIt.hasNext()) {
		  configs.add(configIt.next());
	  }  	  
	  return configs;
  } 
  
  /**
 * @param config
 */
@Transactional
  public void insertConfig(List<Config> config){
	  
	  configRepo.save(config);
  }

  /**
 * @param config
 */
@Transactional
  public void insertConfig(Config config){
	  
	  configRepo.save(config);
  }
  /**
 * @param config
 * @return
 */
@Transactional
  public Boolean updateConfig(List<Config> config, String user){
	  Integer Count = 0;
	  for(Config child : config){
		  try{
		 Count = configRepo.configUpdateByID(child.getConfigValue(), child.getDescription(), child.getId(), user, child.getStatus());		
		  }
		  catch(Exception e){
			  e.getMessage();
			  logger.error("Update failed for config value with "+child.getConfigValue()+" and id : "+child.getId());
		  }
	  }
	 if(Count >0) {
		 return true;
	 }
	 else
		 {return false;}
	  
  }

	/**
	 * @return
	 */
	/*public List<Config> getConfigs() {

		if ( configCache == null ) {
			logger.debug("Cache Creating");
			reloadConfigs();
		}
		
		boolean dynamicConfiguration = dynamicConfigurationFlag.trim().equalsIgnoreCase("true");
		
        if ( dynamicConfiguration && ((lastReadTime + pollingInterval) < System.currentTimeMillis() )) {  // Enter this loop every polling Interval seconds.
            long lastModifiedTime = Long.parseLong(configRepo.getConfigValueFromDB("Config", "LastModifiedTime"));  // DB hit for 1 row
            
            if ( lastReadTime < lastModifiedTime ) {                                                                // DB hit for config table, if someone modified configs in DB
            	logger.debug("lastReadTime : "+lastReadTime+ " | lastModifiedTime : " +lastModifiedTime);
            	reloadConfigs();   // This will reset lastReadTime internally.
            	notifyAllListeners(oldConfigCache, configCache);
            } else {
            	lastReadTime = System.currentTimeMillis();	
            }
            
        }		
		
		return configCache;

	}
	*/

public List<Config> getConfigs() {

	if ( configCache == null ) {
		logger.debug("Cache Creating");
		configCache = getConfigsFromDB();
	}
	
	return configCache;
}

	private List<ReloadListener> reloadListeners = new ArrayList<ReloadListener>();
	
	public void addListener(ReloadListener r) {
		reloadListeners.add(r );
	}
	/**
	 * 
	 */
	private void notifyAllListeners(final List<Config> oldConfig, final List<Config> newConfig ) {
		
		for( ReloadListener listener : reloadListeners ) {
			try{
				
				listener.onReload(oldConfig, newConfig);
			}
			catch(Exception e){
				logger.error("Error.. TBD " + e.getMessage());
			}
		}				
	}


	/**
	 *   Refreshes the internal configs that are managed by ConfigService. 
	 *     
	 */
/*	synchronized public final void reloadConfigs() {
		oldConfigCache = configCache;
		configCache = getConfigsFromDB();
		lastReadTime = System.currentTimeMillis();
		logger.debug("Inside reload method and setting lastReadTime "+lastReadTime);
	}*/
	synchronized public void reloadConfigs() {
		oldConfigCache = configCache;
		configCache = null;
		notifyAllListeners(oldConfigCache, getConfigs());
	}
	
	
	/**
	 * @param ConfigList
	 * @param group
	 * @param key
	 * @return
	 */
	public Config searchConfigKey(List<Config> ConfigList, String group,String key){
		Config searchConfig = new Config();
		//List<Config> allConfigs = getConfigs();
		for(Config conf : ConfigList)
		{
			if(conf.getConfigKey().equals(key) && conf.getConfigGroup().equals(group) && conf.getStatus().equals(Constants.COMMON_STATUS_ACTIVE)){
				
				searchConfig =conf;
			}
			
			
			
		}
		return searchConfig;
		
	}
	
	/**
	 * @param group
	 * @param key
	 * @return
	 */
	public Config searchConfigKey(String group,String key){
		return searchConfigKey(getConfigs(), group,key);
	}

	/**
	 * @param groupName
	 * @param keyName
	 * @return
	 */
	public String getConfigValueFromDb(String groupName, String keyName){
		
		return configRepo.getConfigValueFromDB(groupName, keyName);
	}

/**
 * @param groupName
 * @param keyName
 * @return
 */
public List<String> getConfigValueForApplicability(String groupName, String keyName){
		
		return configRepo.getConfigValueForApplicability(groupName, keyName);
	}

/**
 * @param group
 * @param key
 * @param value
 * @return
 */
@Transactional
public int updateConfig(String group,String key,String value, String user){
	return configRepo.configUpdateByGroupKey(group, key, value,user);
}

}
