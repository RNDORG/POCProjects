package com.wipro.common.logging;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ch.qos.logback.classic.Logger;

@RestController
public class LoggingController {
	
	@Autowired
	LoggingService loggingService;
	
	 @RequestMapping(value="rest/api/v1/fileAppender", method=RequestMethod.GET)
	    public String setLoggingLevelController(@RequestParam(value="Appender_Name") String appenderName,
	    		@RequestParam(value="is_Append") Boolean isAppend) {
	    	return loggingService.modifyFileAppender(appenderName,isAppend);
	    }
	 
	   
	   @RequestMapping(value="rest/extapi/v1/logger", method=RequestMethod.GET)
		public Map<String,String> loggerFunction(@RequestParam MultiValueMap allRequestParams)
		{
	    Map<String,String> result=new HashMap<String, String>();
		if (allRequestParams.size()==0)
		{
			result=loggingService.findAllLoggersWithAppenders();
		}
		else
		{
			result=loggingService.changeLoggingLevels(allRequestParams);
		}
		return result;
		}
	   
	   @RequestMapping(value="rest/extapi/v1/logger/all", method=RequestMethod.GET)
		public Map<String,String> finaAllLoggers(@RequestParam MultiValueMap allRequestParams)
		{
		   Map<String,String> result=new HashMap<String, String>();
		   result=loggingService.findAllLoggersWithNWithoutAppenders();
		   return result;
		}
	   
	   @RequestMapping(value="rest/extapi/v1/logger/help", method=RequestMethod.GET)
		public String sampleLoggers(@RequestParam MultiValueMap allRequestParams)
		{
		  String result="Examples - "+"\n"+
				  		"/rest/extapi/v1/logger                  // Prints logger that have appenders."+"\n"+
				  		"/rest/extapi/v1/logger/all              // Prints all loggers of application. "+"\n"+
				  		"/rest/extapi/v1/logger?ROOT=INFO&org.hibernate.SQL=DEBUG    // Sets logging level of loggers. "+"\n"+
				  		"/rest/extapi/v1/logger/sample           // Prints sample logs.";
		  
		   return result;
		}
	   
	   @RequestMapping(value="rest/extapi/v1/logger/sample", method=RequestMethod.GET)
		public void helpOrExamples(@RequestParam MultiValueMap allRequestParams)
		{
		   Logger  logger = (Logger) LoggerFactory.getLogger(LoggingController.class);
		   logger.trace("This is a sample TRACE LOG");
		   logger.debug("This is a sample DEBUG LOG");
		   logger.info("This is a sample INFO LOG");
		   logger.warn("This is a sample WARN LOG");
		   logger.error("This is a sample ERROR LOG");
		}
}
