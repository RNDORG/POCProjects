package com.wipro.common.gs.util.spawnProcess;

import java.io.*;

public class SpawnProcess {
  public static String executeACommand(String str){
	  String response = "";
    try {
      String line;
      
      //Process p = Runtime.getRuntime().exec("cmd /c dir");
      Process p = Runtime.getRuntime().exec(str);
      BufferedReader bri = new BufferedReader
        (new InputStreamReader(p.getInputStream()));
      BufferedReader bre = new BufferedReader
        (new InputStreamReader(p.getErrorStream()));
      while ((line = bri.readLine()) != null) {
    	  response = line+response+"\n";
        System.out.print(line);
      }
      bri.close();
      while ((line = bre.readLine()) != null) {
     //   System.out.println(line);
      }
      bre.close();
      p.waitFor();
      System.out.println("Done.");
    }
    catch (Exception err) {
      err.printStackTrace();
    }
    
    return response;
  }
}
