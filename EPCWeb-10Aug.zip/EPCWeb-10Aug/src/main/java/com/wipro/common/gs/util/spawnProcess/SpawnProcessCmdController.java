package com.wipro.common.gs.util.spawnProcess;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpawnProcessCmdController {
	@Autowired 
	SpawnProcessCmdService spawnProcessCmdService;
	
	 @RequestMapping(value="rest/extapi/v1/system", method=RequestMethod.GET)
	    public String sshGetListService(@RequestParam(value="cmd", required=false) String cmd) {
	    	return spawnProcessCmdService.executeACommand(cmd);
		
	    }

}
