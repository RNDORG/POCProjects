package com.wipro.common.gs.util;

import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.util.Set;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.Query;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class GetPortAddressController {

	@Value("${spring.profiles.active}")
	private String profile; 
		
	@RequestMapping(value="rest/extapi/v1/getPort", method=RequestMethod.GET)
	public String returnPortNumber(){
		
		 if(profile.contains("nonjndi")) {
			MBeanServer beanServer = ManagementFactory.getPlatformMBeanServer();
	        String host;
	        String ipadd = "";
			try {
				Set<ObjectName> objectNames = beanServer.queryNames(new ObjectName("*:type=Connector,*"),
		                Query.match(Query.attr("protocol"), Query.value("HTTP/1.1")));
				host = InetAddress.getLocalHost().getHostAddress();
				 String port = objectNames.iterator().next().getKeyProperty("port");
			        ipadd =port;
			        System.out.println(ipadd);
			        return ipadd;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return ipadd;
		 }
		 else
		 {
			 MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
				ObjectName socketBindingMBean;
				Integer port = 0;
				try {
					socketBindingMBean = new ObjectName("jboss.as:socket-binding-group=full-ha-sockets,socket-binding=http");
					//String  host = (String)  mBeanServer.getAttribute(socketBindingMBean, "boundAddress");
					//System.out.println("Host is "+host);full-ha-sockets/full-sockets/
					port = (Integer) mBeanServer.getAttribute(socketBindingMBean, "boundPort");
					System.out.println("Port is "+port);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				
				return port.toString();
		 }
	       
	}
	
}
