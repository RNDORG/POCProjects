package com.wipro.common.gs.mailnotification;

import java.util.Properties;

import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.wipro.common.config.service.ConfigService;

/**
 * @author Developer
 * @version 1.0
 * type SmtpMailSender
 */
@Component
public class SmtpMailSender {
	/**
	 * ConfigService SmtpMailSender.java
	 */
	
	private static Logger logger = LoggerFactory.getLogger(SmtpMailSender.class);
	@Autowired
	ConfigService configService;
	/*@Autowired
	private JavaMailSender javaMailSender;	
	*/
	/**
	 * @param to
	 * @param bcc
	 * @param cc
	 * @param subject
	 * @param body
	 * @param file
	 */
	public void send(String to,String bcc,String cc, String subject, String body,FileSystemResource file[]) {
	configService.searchConfigKey("Mail", "");
		 JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
	        Properties mailProperties = new Properties();
	    try{
	    	
	        mailProperties.put("mail.smtp.auth",configService.searchConfigKey("Mail", "smtp_auth").getConfigValue());
	        mailProperties.put("mail.smtp.starttls.enable",false);
	        mailSender.setJavaMailProperties(mailProperties);
	        mailSender.setHost(configService.searchConfigKey("Mail", "smtp_host").getConfigValue());
	        mailSender.setPort(Integer.parseInt(configService.searchConfigKey("Mail", "smtp_port").getConfigValue()));
	        mailSender.setProtocol("smtp");
	        if(mailProperties.getProperty("mail.smtp.auth").equalsIgnoreCase("true")){
	       mailSender.setUsername(configService.searchConfigKey("Mail", "smtp_username").getConfigValue());
	       mailSender.setPassword(configService.searchConfigKey("Mail", "smtp_password").getConfigValue());
	        }
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper;
		
		helper = new MimeMessageHelper(message, true,"UTF-8"); // true indicates
		// multipart message
		
		//message.setText(body, "UTF-8");	//---enabling this attachment not going
		
		message.setSubject(subject,"UTF-8");
		String[] toList = to.split(","); // "to" should be delimited with "," for multiple receipients  
		helper.setTo(toList);
		//helper.setText(body, true); // true indicates html 
		helper.setFrom(configService.searchConfigKey("Mail", "smtp_from").getConfigValue()); //"CRM360_5"
		 helper.setText("<html><body><pre>"+body +"<br><br><img src='cid:company-logo'></body></html>", true);
		 helper.addInline("company-logo", new ClassPathResource("static/assets/img/mini-logo.png"));
		helper.setFrom(configService.searchConfigKey("Mail", "smtp_from").getConfigValue()); //"CRM360_5"
		
		if(file!=null){
		for(FileSystemResource fileAttachment : file) {
			helper.addAttachment(fileAttachment.getFilename(), fileAttachment);
		}
		}
		if(StringUtils.isNotBlank(bcc)){
			String[] bccList = bcc.split(",");// "bcc" should be delimited with "," for multiple receipients
			helper.setBcc(bccList);			 
		}
 		
		if(StringUtils.isNotBlank(cc)){
			String[] ccList = cc.split(",");// "cc" should be delimited with "," for multiple receipients 
			helper.setCc(ccList);
		}
 		
 		mailSender.send(message);
	    }catch (Exception e){
	    	
	    	logger.error(ExceptionUtils.getStackTrace(e));
	    	
	    	
	    }
		
	}

}
