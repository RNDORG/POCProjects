package com.wipro.common.gs.transactions.services;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.common.config.service.ConfigService;
import com.wipro.common.gs.transactions.domain.TransactionRequestRange;
import com.wipro.common.gs.transactions.domain.Transactions;
import com.wipro.common.gs.transactions.repository.TransactionsRepository;
import com.wipro.common.gs.util.CommonUtils;

/**
 * @author Developer
 * @version 1.0
 * type TransactionsService
 */
@Service
public class TransactionsService {

	/**
	 * TransactionsRepository TransactionsService.java
	 */
	@Autowired
	TransactionsRepository trnRepository;
	/**
	 * ConfigService TransactionsService.java
	 */
	@Autowired
	ConfigService configService;
	
	/*@PersistenceContext 
	EntityManager em;*/
	
	/**
	 * Logger TransactionsService.java
	 */
	private static Logger logger = LoggerFactory.getLogger(TransactionsService.class);
	
	//--------------------------------CreateTransactions-------------------------------------------------------
	/**
	 * @param epcTransaction
	 */
	public void createTransactions(Transactions epcTransaction)
	{
		
		  List<Transactions> epcTransaction1 = new ArrayList<Transactions>();
		if(configService.searchConfigKey("Transaction", "Control").getConfigValue().equals("true")){
			
 this.trnRepository.save(epcTransaction);
		
		}
	
	}
	
	//--------------------------------GetTransactions----------------------------------------------------------
	
	/**
	 * @param allRequestParams
	 * @return
	 */
	public List<Transactions> getTransactions(
			Map<String, List<String>> allRequestParams) {
		String queryBuilder = CommonUtils.getQueryFromDB(allRequestParams,Transactions.class.getName(), null);
    
		//System.out.println("Query Builder is >>>"+queryBuilder);
		List<Transactions> listOfTransactionsReturned = null;
		try {
			//listOfTransactionsReturned = em.createNativeQuery(queryBuilder, Transactions.class).getResultList();
			listOfTransactionsReturned = this.trnRepository.getList(queryBuilder.toString());
		} catch (Exception e) {
			throw new RuntimeException(
					"Error occurred while fetching results from database.\n"
							+ " Query: " + queryBuilder.toString() + "\n"
							+ " Exception: " + e.getMessage(), e);
		}
			return listOfTransactionsReturned;
	}	
	
	
	/**
	 * @param request
	 * @return
	 */
	public List<Transactions> getTransactions(TransactionRequestRange request) {
		List<Transactions> listOfTransactionsReturned = trnRepository.getList(request);
		return listOfTransactionsReturned;
	}
 }                                                                                                                                         
