package com.wipro;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.UnknownHostException;

import javax.annotation.PostConstruct;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

/**
 * @author Developer
 * @version 1.0
 * type TrayIconHelper
 */
@Component
public class TrayIconHelper {

	private static Logger logger = LoggerFactory.getLogger(TrayIconHelper.class);
	/**
	 * String TrayIconHelper.java
	 */
	@Value("#{'${server.port:8080}'}")
	public String port;

	
	/**
	 * String TrayIconHelper.java
	 */
	@Value("#{'${spring.datasource.url:jdbc:h2:~/h2dir/no_default_specified;MODE=MYSQL}'}")
	public String jdbcURL;

	/**
	 * @throws UnknownHostException
	 */
	@PostConstruct
	public void trayIcon() throws UnknownHostException {

		// ****************************************Lets Begin
		// **********************************************************************(*
		final TrayIcon trayIcon;
		// getting ip and port
		final String ip = InetAddress.getLocalHost().getHostAddress().trim();
		// System.getProperty()
		if (SystemTray.isSupported()) {
			//System.out.println("supported");

			// get the SystemTray instance
			SystemTray tray = SystemTray.getSystemTray();
			// load an image
			ClassPathResource cpr = new ClassPathResource(
					"static/assets/img/mini-logo.png");
			URL imageURL = null;
			try {
				imageURL = cpr.getURL();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.error(ExceptionUtils.getStackTrace(e));

			}
			Image image = Toolkit.getDefaultToolkit().getImage(imageURL);
			// construct a TrayIcon
			trayIcon = new TrayIcon(image, "EPC");
			trayIcon.setImageAutoSize(true);

			PopupMenu popup = new PopupMenu();

			// create menu item for the action
			// CheckboxMenuItem cb=new CheckboxMenuItem("change ToolTip");
			MenuItem consoleItem = new MenuItem("Console");
			MenuItem exitItem = new MenuItem("Exit");
			MenuItem statusItem = new MenuItem("Database");

			// add MenuItem to PopUpMenu
			// popup.add(cb);
			popup.add(consoleItem);
			popup.add(statusItem);
			popup.add(exitItem);

			// set PopupMenu to TrayIcon
			trayIcon.setPopupMenu(popup);

			// Associate actionListener to Exit MenuItem
			exitItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					//System.out.println("Exiting...");
					System.exit(0);
				}
			});

			statusItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					try {
						String consoleURL = "http://" + ip + ":" + port
								+ "/db-console";

						JFrame jframe = new JFrame("Database Details - ");
						JPanel panel = new JPanel();
						panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

						JPanel p1 = new JPanel();
						JPanel p2 = new JPanel();
						panel.add(p1);
						panel.add(p2);

						String jdbc_url = jdbcURL;
						TextField jdbcURL = new TextField(jdbc_url);
						jdbcURL.setEditable(false);

						TextField console_URL = new TextField(consoleURL);
						console_URL.setEditable(false);

						p1.add(new JLabel("Database Console: "));
						p1.add(console_URL);

						p2.add(new JLabel("JDBC URL: "));
						p2.add(jdbcURL);

						jframe.setContentPane(panel);
						JFrame.setDefaultLookAndFeelDecorated(false);

						jframe.setVisible(true);
						jframe.setTitle("Database Details");

						jframe.pack();
						Dimension dim = Toolkit.getDefaultToolkit()
								.getScreenSize();
						jframe.setLocation(dim.width / 2
								- jframe.getSize().width / 2, dim.height / 2
								- jframe.getSize().height / 2);

					} catch (Exception e2) {
						logger.error(ExceptionUtils.getStackTrace(e2));
					}
				}

			});

			// Associate Listener to CheckBoxMenuItem
			consoleItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					URI uri;
					try {
						// InetAddress url =InetAddress.getLocalHost();
						//System.out.println("localHost: "	+ InetAddress.getLocalHost());

						uri = new URI("http://" + ip + ":" + port + "/");
						java.awt.Desktop.getDesktop().browse(uri);
					} catch (URISyntaxException e1) {
						// TODO Auto-generated catch block
						logger.error(ExceptionUtils.getStackTrace(e1));
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						logger.error(ExceptionUtils.getStackTrace(e1));
					}

				}
			});

			// add mouseListner to trayIcon
			trayIcon.addMouseListener(new MouseListener() {

				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
				}

				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
				}

				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
				}

				// ***********************LeftClick on TrayIcon,Index page
				// Should Open********************

				@Autowired
				@Override
				public void mouseClicked(MouseEvent e) {

					int clickType = e.getModifiers();// return Integer value
														// corresponding to
														// click(right/left/middle)
					// //System.out.println("clickType "+clickType);

					if (clickType == 16) {
						URI uri;
						try {
							uri = new URI("http://" + ip + ":" + port + "/");
							java.awt.Desktop.getDesktop().browse(uri);
						} catch (URISyntaxException e1) {
							// TODO Auto-generated catch block
							logger.error(ExceptionUtils.getStackTrace(e1));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							logger.error(ExceptionUtils.getStackTrace(e1));
						}
					}
				}

				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub

				}
			});

			try {
				tray.add(trayIcon);
				//System.out.println("**********Now EPCApp is in ToolBar Section**********");
				//System.out.println();
			} catch (AWTException e) {
				//System.out.println("TrayIcon is not Added");
			}

		} else {
			//System.out.println("not supported");
			// System Tray is not supported

		}
		// ***************************************************************************************************************
	}

}
