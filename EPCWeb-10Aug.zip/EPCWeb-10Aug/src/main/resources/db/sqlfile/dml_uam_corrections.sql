delete from authorities where username='spclproduser';
delete from user_role_map where role_id =(select role_id from role where name ='role_privileged_prod_team');
delete from role_function_map where role_id=(select role_id from role where name ='role_privileged_prod_team');
delete from role where name ='role_privileged_prod_team';
delete from users where username='spclproduser';

Insert into users (username,password,enabled,fname,created_by,created_date) 
values ('CRM360_1','Grameen432','true','CRM360_1','admin',current_timestamp());

Insert into user_role_map (user_name,role_id,created_by,created_date) 
values ('CRM360_1',1,'admin',current_timestamp());

Insert into authorities (username,authority,created_by,created_date) 
values 
('CRM360_1','Page_Home','admin',current_timestamp()),
('CRM360_1','add_new_user','admin',current_timestamp()),
('CRM360_1','update_user','admin',current_timestamp()),
('CRM360_1', 'Page_CreateProduct', 'admin',current_timestamp()),
('CRM360_1', 'Page_SearchProduct', 'admin',current_timestamp()),
('CRM360_1', 'Page_UserAccessManagement', 'admin',current_timestamp()),
('CRM360_1', 'Page_ProductApproval', 'admin',current_timestamp()),
('CRM360_1', 'Page_CreateViewCharacteristics', 'admin',current_timestamp()),
('CRM360_1', 'Page_NotificationTemplate', 'admin',current_timestamp()),
('CRM360_1', 'Page_PublishProduct', 'admin',current_timestamp()),
('CRM360_1', 'Page_Database', 'admin',current_timestamp()),
('CRM360_1', 'Page_ManageOrder', 'admin',current_timestamp()),
('CRM360_1', 'Page_Configuration', 'admin',current_timestamp()),
('CRM360_1', 'Page_TransactionGraphs', 'admin',current_timestamp()),
('CRM360_1', 'Page_ManageCommunity', 'admin',current_timestamp()),
('CRM360_1', 'Page_ManageActivity', 'admin',current_timestamp()),
('CRM360_1', 'Edit_Product', 'admin',current_timestamp()),
('CRM360_1', 'Edit_Product_Post_Submit', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Submitted_Approved', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved_Tested', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Tested_Approved by RAFM', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved by RAFM_Approved by DM', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved by DM_Launch', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Draft_Suspend', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Submitted_Suspend', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved_Suspend', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Tested_Suspend', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved by RAFM_Suspend', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved by DM_Suspend', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Submitted_Tested', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Submitted_Approved by RAFM', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Submitted_Approved by DM', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Submitted_Launch', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved_Approved by RAFM', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved_Approved by DM', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved_Launch', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Tested_Approved by DM', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Tested_Launch', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Approved by RAFM_Launch', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Launch_Retire', 'admin',current_timestamp()),
('CRM360_1' , 'Transition_Suspend_Draft', 'admin',current_timestamp());