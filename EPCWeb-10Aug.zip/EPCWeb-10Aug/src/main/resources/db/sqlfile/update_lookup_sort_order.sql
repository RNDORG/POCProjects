update epc_lookup_master mst
inner join (
	 SELECT lookup_id, lookup_group, lookup_name, parent_lookup_value,lookup_display_value, lookup_sort_order,
			(CASE CONCAT(lookup_group, lookup_name, ifnull(parent_lookup_value, 'NA')) 
			WHEN @cur_crew_type
			THEN @curRow := @curRow + 1
			ELSE @curRow := 0 END) + 1 AS cnt,
			@cur_crew_type := CONCAT(lookup_group, lookup_name, ifnull(parent_lookup_value, 'NA')) AS cur_crew_type
	   FROM epc_lookup_master t, (SELECT @curRow := 0, @cur_crew_type := '') counter
	   where t.lookup_name != 'sequence_id'
	  ORDER BY lookup_group, lookup_name, ifnull(parent_lookup_value, 'NA'),lookup_display_value) lcl
on mst.lookup_id = lcl.lookup_id      
set mst.lookup_sort_order = lcl.cnt; 