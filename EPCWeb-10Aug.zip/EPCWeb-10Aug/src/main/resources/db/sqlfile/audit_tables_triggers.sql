-- 
-- Audit logging can be user configurable in "db_audit_control" table:
-- trigger_action = Insert/Update/Delete.
-- global_audit_table = to log transactions into global audit table, provide the table name 'epc_audit_log'.
-- specific_tables = specify all the tables needed logging at individual table level. Removing a table name from this list will disable table level logging for the same.
-- status = 1--> makes above 2 conditions valid.  "Other than 1" --> will make above conditions InValid, i.e Logging at Global and Individual table level will be disabled, even if the table names are mentioned in global_audit_table and specific_tables columns.
-- 

CREATE TABLE IF NOT EXISTS db_audit_control (
    trigger_control_id INT unsigned NOT NULL AUTO_INCREMENT,
    trigger_action VARCHAR(50),
    global_audit_table varchar(50),
    specific_tables VARCHAR(1500),
    status VARCHAR(25) NOT NULL,
    created_by VARCHAR(25) NOT NULL,
    created_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_by VARCHAR(25),
    modified_date DATETIME,
    CONSTRAINT pk_audit_control_id PRIMARY KEY (trigger_control_id),
   -- CONSTRAINT fk_audit_control_status FOREIGN KEY (status)
    ---    REFERENCES epc_lookup_master (lookup_id),
    CONSTRAINT fk_audit_control_created_by FOREIGN KEY (created_by)
        REFERENCES users (username),
    CONSTRAINT fk_audit_control_modified_by FOREIGN KEY (modified_by)
        REFERENCES users (username),
    CONSTRAINT uk_db_audit_control unique key(trigger_action, status)
        
)  $$


insert into db_audit_control (trigger_action, global_audit_table, specific_tables, status, created_by)
values
('insert','epc_audit_log','authorities,custom_configs,epc_activity_charge,epc_attribute_master,epc_location,epc_lookup_master,epc_notification_template,epc_order_channel_rule,epc_product_attribute,epc_product_availability,epc_product_community,epc_product_compatibility,epc_product_decomposition,epc_product_heirarchy,epc_product_init_channel,epc_product_location,epc_product_migration,epc_product_network_tpl,epc_product_network_tpl_map,epc_product_process_flow,epc_product_sales_channel,epc_product_segment,epc_product_specification,epc_product_status_history,epc_product_testsuit,epc_trigger_order_rule,function,role,role_function_map,user_role_map,users,epc_trigger_order_rule','Active','admin'),
('update','epc_audit_log','authorities,custom_configs,epc_activity_charge,epc_attribute_master,epc_location,epc_lookup_master,epc_notification_template,epc_order_channel_rule,epc_product_attribute,epc_product_availability,epc_product_community,epc_product_compatibility,epc_product_decomposition,epc_product_heirarchy,epc_product_init_channel,epc_product_location,epc_product_migration,epc_product_network_tpl,epc_product_network_tpl_map,epc_product_process_flow,epc_product_sales_channel,epc_product_segment,epc_product_specification,epc_product_status_history,epc_product_testsuit,epc_trigger_order_rule,function,role,role_function_map,user_role_map,users,epc_trigger_order_rule','Active','admin'),
('delete','epc_audit_log','authorities,custom_configs,epc_activity_charge,epc_attribute_master,epc_location,epc_lookup_master,epc_notification_template,epc_order_channel_rule,epc_product_attribute,epc_product_availability,epc_product_community,epc_product_compatibility,epc_product_decomposition,epc_product_heirarchy,epc_product_init_channel,epc_product_location,epc_product_migration,epc_product_network_tpl,epc_product_network_tpl_map,epc_product_process_flow,epc_product_sales_channel,epc_product_segment,epc_product_specification,epc_product_status_history,epc_product_testsuit,epc_trigger_order_rule,function,role,role_function_map,user_role_map,users,epc_trigger_order_rule','Active','admin')
ON DUPLICATE KEY UPDATE trigger_control_id =LAST_INSERT_ID(trigger_control_id);

 $$
-- 
-- This table is for Logging all transactions. Just a summary sort of thing.
-- 

create table if not exists epc_audit_log(
audit_log_id int unsigned not null auto_increment,
username varchar(25),
table_name	varchar(100),
action_date	datetime,
action_performed varchar(10),	-- Insert, Update, Delete
constraint pk_audit_log_id primary key (audit_log_id)
)$$


------------------

CREATE TABLE IF NOT EXISTS aud_authorities
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM authorities Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_config
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM config Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_activity_channel_rule
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_activity_channel_rule Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_activity_charge
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_activity_charge Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_activity_detail
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_activity_detail Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_activity_master
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_activity_master Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_attribute_master
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_attribute_master Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_flexi_plan
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_flexi_plan Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_location
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_location Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_lookup_master
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_lookup_master Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_notification_template
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_notification_template Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_notification_template_detail
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_notification_template_detail Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_order_channel_rule
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_order_channel_rule Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_order_charge
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_order_charge Where 1=2; $$ 


 
CREATE TABLE IF NOT EXISTS aud_epc_partner_msisdn
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_partner_msisdn Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_attribute
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_attribute Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_availability
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_availability Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_community
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_community Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_compatibility
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_compatibility Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_decomposition
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_decomposition Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_heirarchy
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_heirarchy Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_init_channel
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_init_channel Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_location
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_location Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_migration
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_migration Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_network_tpl
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_network_tpl Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_network_tpl_map
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_network_tpl_map Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_process_flow
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_process_flow Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_provider_system
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_provider_system Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_sales_channel
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_sales_channel Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_segment
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_segment Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_specification
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_specification Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_status_history
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_status_history Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_product_testsuit
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_product_testsuit Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_tariff_override
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_tariff_override Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_epc_trigger_order_rule
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM epc_trigger_order_rule Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_function
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM function Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_role
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM role Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_role_function_map
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM role_function_map Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_user_role_map
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM user_role_map Where 1=2; $$ 


CREATE TABLE IF NOT EXISTS aud_users
(audit_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, operation VARCHAR(1) ,operation_date DATETIME, operation_by varchar(50)) 
 as SELECT * FROM users Where 1=2; $$ 

 

 DROP TRIGGER IF EXISTS trg_ai_authorities; $$ 
 create trigger trg_ai_authorities
 after insert on authorities for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'authorities,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_authorities(operation, operation_date, operation_by, authority_id,username,authority,created_date,created_by) 
 values ('I', current_timestamp(), current_user(), NEW.authority_id,NEW.username,NEW.authority,NEW.created_date,NEW.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'authorities', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_config; $$ 
 create trigger trg_ai_config
 after insert on config for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'config,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_config(operation, operation_date, operation_by, id,config_group,config_key,config_value,description,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.id,NEW.config_group,NEW.config_key,NEW.config_value,NEW.description,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'config', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_activity_channel_rule; $$ 
 create trigger trg_ai_epc_activity_channel_rule
 after insert on epc_activity_channel_rule for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_channel_rule,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_channel_rule(operation, operation_date, operation_by, activity_channel_rule_id,activity_id,sales_channel,initiating_channel,is_consent_required,notification_template_id,is_future_date,currency,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.activity_channel_rule_id,NEW.activity_id,NEW.sales_channel,NEW.initiating_channel,NEW.is_consent_required,NEW.notification_template_id,NEW.is_future_date,NEW.currency,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_activity_channel_rule', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_activity_charge; $$ 
 create trigger trg_ai_epc_activity_charge
 after insert on epc_activity_charge for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_charge,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_charge(operation, operation_date, operation_by, activity_charge_id,activity_channel_rule_id,occ_code,activity_charge_fee,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.activity_charge_id,NEW.activity_channel_rule_id,NEW.occ_code,NEW.activity_charge_fee,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_activity_charge', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_activity_detail; $$ 
 create trigger trg_ai_epc_activity_detail
 after insert on epc_activity_detail for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_detail,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_detail(operation, operation_date, operation_by, activity_detail_id,activity_id,activity_key,activity_value,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.activity_detail_id,NEW.activity_id,NEW.activity_key,NEW.activity_value,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_activity_detail', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_activity_master; $$ 
 create trigger trg_ai_epc_activity_master
 after insert on epc_activity_master for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_master,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_master(operation, operation_date, operation_by, activity_id,activity_name,activity_description,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.activity_id,NEW.activity_name,NEW.activity_description,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_activity_master', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_attribute_master; $$ 
 create trigger trg_ai_epc_attribute_master
 after insert on epc_attribute_master for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_attribute_master,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_attribute_master(operation, operation_date, operation_by, attribute_id,attribute_ctg,attribute_ctg_type,attribute_name,attribute_description,attribute_data_type,attribute_data_length,is_visible,is_cfs,is_rfs,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.attribute_id,NEW.attribute_ctg,NEW.attribute_ctg_type,NEW.attribute_name,NEW.attribute_description,NEW.attribute_data_type,NEW.attribute_data_length,NEW.is_visible,NEW.is_cfs,NEW.is_rfs,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_attribute_master', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_authorities; $$ 
 create trigger trg_au_authorities
 after update on authorities for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'authorities,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_authorities(operation, operation_date, operation_by,authority_id,username,authority,created_date,created_by) 
 values ('U', current_timestamp(), current_user(), OLD.authority_id,OLD.username,OLD.authority,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'authorities', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_config; $$ 
 create trigger trg_au_config
 after update on config for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'config,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_config(operation, operation_date, operation_by,id,config_group,config_key,config_value,description,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.id,OLD.config_group,OLD.config_key,OLD.config_value,OLD.description,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'config', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_activity_channel_rule; $$ 
 create trigger trg_au_epc_activity_channel_rule
 after update on epc_activity_channel_rule for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_channel_rule,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_channel_rule(operation, operation_date, operation_by,activity_channel_rule_id,activity_id,sales_channel,initiating_channel,is_consent_required,notification_template_id,is_future_date,currency,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.activity_channel_rule_id,OLD.activity_id,OLD.sales_channel,OLD.initiating_channel,OLD.is_consent_required,OLD.notification_template_id,OLD.is_future_date,OLD.currency,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_activity_channel_rule', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_activity_charge; $$ 
 create trigger trg_au_epc_activity_charge
 after update on epc_activity_charge for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_charge,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_charge(operation, operation_date, operation_by,activity_charge_id,activity_channel_rule_id,occ_code,activity_charge_fee,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.activity_charge_id,OLD.activity_channel_rule_id,OLD.occ_code,OLD.activity_charge_fee,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_activity_charge', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_activity_detail; $$ 
 create trigger trg_au_epc_activity_detail
 after update on epc_activity_detail for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_detail,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_detail(operation, operation_date, operation_by,activity_detail_id,activity_id,activity_key,activity_value,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.activity_detail_id,OLD.activity_id,OLD.activity_key,OLD.activity_value,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_activity_detail', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_activity_master; $$ 
 create trigger trg_au_epc_activity_master
 after update on epc_activity_master for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_master,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_master(operation, operation_date, operation_by,activity_id,activity_name,activity_description,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.activity_id,OLD.activity_name,OLD.activity_description,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_activity_master', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_attribute_master; $$ 
 create trigger trg_au_epc_attribute_master
 after update on epc_attribute_master for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_attribute_master,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_attribute_master(operation, operation_date, operation_by,attribute_id,attribute_ctg,attribute_ctg_type,attribute_name,attribute_description,attribute_data_type,attribute_data_length,is_visible,is_cfs,is_rfs,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.attribute_id,OLD.attribute_ctg,OLD.attribute_ctg_type,OLD.attribute_name,OLD.attribute_description,OLD.attribute_data_type,OLD.attribute_data_length,OLD.is_visible,OLD.is_cfs,OLD.is_rfs,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_attribute_master', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_authorities; $$ 
 create trigger trg_ad_authorities
 after delete on authorities for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'authorities,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_authorities(operation, operation_date, operation_by,authority_id,username,authority,created_date,created_by) 
 values ('D', current_timestamp(), current_user(), OLD.authority_id,OLD.username,OLD.authority,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'authorities', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_config; $$ 
 create trigger trg_ad_config
 after delete on config for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'config,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_config(operation, operation_date, operation_by,id,config_group,config_key,config_value,description,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.id,OLD.config_group,OLD.config_key,OLD.config_value,OLD.description,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'config', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_activity_channel_rule; $$ 
 create trigger trg_ad_epc_activity_channel_rule
 after delete on epc_activity_channel_rule for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_channel_rule,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_channel_rule(operation, operation_date, operation_by,activity_channel_rule_id,activity_id,sales_channel,initiating_channel,is_consent_required,notification_template_id,is_future_date,currency,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.activity_channel_rule_id,OLD.activity_id,OLD.sales_channel,OLD.initiating_channel,OLD.is_consent_required,OLD.notification_template_id,OLD.is_future_date,OLD.currency,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_activity_channel_rule', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_activity_charge; $$ 
 create trigger trg_ad_epc_activity_charge
 after delete on epc_activity_charge for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_charge,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_charge(operation, operation_date, operation_by,activity_charge_id,activity_channel_rule_id,occ_code,activity_charge_fee,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.activity_charge_id,OLD.activity_channel_rule_id,OLD.occ_code,OLD.activity_charge_fee,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_activity_charge', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_activity_detail; $$ 
 create trigger trg_ad_epc_activity_detail
 after delete on epc_activity_detail for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_detail,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_detail(operation, operation_date, operation_by,activity_detail_id,activity_id,activity_key,activity_value,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.activity_detail_id,OLD.activity_id,OLD.activity_key,OLD.activity_value,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_activity_detail', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_activity_master; $$ 
 create trigger trg_ad_epc_activity_master
 after delete on epc_activity_master for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_activity_master,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_activity_master(operation, operation_date, operation_by,activity_id,activity_name,activity_description,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.activity_id,OLD.activity_name,OLD.activity_description,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_activity_master', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_attribute_master; $$ 
 create trigger trg_ad_epc_attribute_master
 after delete on epc_attribute_master for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_attribute_master,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_attribute_master(operation, operation_date, operation_by,attribute_id,attribute_ctg,attribute_ctg_type,attribute_name,attribute_description,attribute_data_type,attribute_data_length,is_visible,is_cfs,is_rfs,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.attribute_id,OLD.attribute_ctg,OLD.attribute_ctg_type,OLD.attribute_name,OLD.attribute_description,OLD.attribute_data_type,OLD.attribute_data_length,OLD.is_visible,OLD.is_cfs,OLD.is_rfs,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_attribute_master', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_flexi_plan; $$ 
 create trigger trg_ai_epc_flexi_plan
 after insert on epc_flexi_plan for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_flexi_plan,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_flexi_plan(operation, operation_date, operation_by, flexi_plan_id,flexi_plan_type,validity_in_days,data_range_start,data_range_end,voice_range_start,voice_range_end,sms_range_start,sms_range_end,price,status,created_by,created_date,modified_by,modified_date) 
 values ('I', current_timestamp(), current_user(), NEW.flexi_plan_id,NEW.flexi_plan_type,NEW.validity_in_days,NEW.data_range_start,NEW.data_range_end,NEW.voice_range_start,NEW.voice_range_end,NEW.sms_range_start,NEW.sms_range_end,NEW.price,NEW.status,NEW.created_by,NEW.created_date,NEW.modified_by,NEW.modified_date); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_flexi_plan', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_location; $$ 
 create trigger trg_ai_epc_location
 after insert on epc_location for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_location,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_location(operation, operation_date, operation_by, location_id,location_type,parent_location_id,location_name,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.location_id,NEW.location_type,NEW.parent_location_id,NEW.location_name,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_location', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_lookup_master; $$ 
 create trigger trg_ai_epc_lookup_master
 after insert on epc_lookup_master for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_lookup_master,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_lookup_master(operation, operation_date, operation_by, lookup_id,lookup_group,lookup_name,lookup_value,lookup_display_value,parent_lookup_value,lookup_description,lookup_sort_order,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.lookup_id,NEW.lookup_group,NEW.lookup_name,NEW.lookup_value,NEW.lookup_display_value,NEW.parent_lookup_value,NEW.lookup_description,NEW.lookup_sort_order,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_lookup_master', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_notification_template; $$ 
 create trigger trg_ai_epc_notification_template
 after insert on epc_notification_template for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_notification_template,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_notification_template(operation, operation_date, operation_by, notification_template_id,template_name,template_type,source_system,mode_of_delivery,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.notification_template_id,NEW.template_name,NEW.template_type,NEW.source_system,NEW.mode_of_delivery,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_notification_template', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_notification_template_detail; $$ 
 create trigger trg_ai_epc_notification_template_detail
 after insert on epc_notification_template_detail for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_notification_template_detail,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_notification_template_detail(operation, operation_date, operation_by, notification_template_detail_id,notification_template_id,template_language,template_subject,template_body,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.notification_template_detail_id,NEW.notification_template_id,NEW.template_language,NEW.template_subject,NEW.template_body,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_notification_template_detail', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_order_channel_rule; $$ 
 create trigger trg_ai_epc_order_channel_rule
 after insert on epc_order_channel_rule for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_order_channel_rule,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_order_channel_rule(operation, operation_date, operation_by, order_channel_rule_id,order_type,product_sub_family,product_classification,sales_channel,initiating_channel,is_consent_required,notification_template_id,is_future_date,currency,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.order_channel_rule_id,NEW.order_type,NEW.product_sub_family,NEW.product_classification,NEW.sales_channel,NEW.initiating_channel,NEW.is_consent_required,NEW.notification_template_id,NEW.is_future_date,NEW.currency,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_order_channel_rule', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_order_charge; $$ 
 create trigger trg_ai_epc_order_charge
 after insert on epc_order_charge for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_order_charge,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_order_charge(operation, operation_date, operation_by, order_charge_id,order_channel_rule_id,occ_code,order_charge_fee,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.order_charge_id,NEW.order_channel_rule_id,NEW.occ_code,NEW.order_charge_fee,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_order_charge', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_flexi_plan; $$ 
 create trigger trg_au_epc_flexi_plan
 after update on epc_flexi_plan for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_flexi_plan,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_flexi_plan(operation, operation_date, operation_by,flexi_plan_id,flexi_plan_type,validity_in_days,data_range_start,data_range_end,voice_range_start,voice_range_end,sms_range_start,sms_range_end,price,status,created_by,created_date,modified_by,modified_date) 
 values ('U', current_timestamp(), current_user(), OLD.flexi_plan_id,OLD.flexi_plan_type,OLD.validity_in_days,OLD.data_range_start,OLD.data_range_end,OLD.voice_range_start,OLD.voice_range_end,OLD.sms_range_start,OLD.sms_range_end,OLD.price,OLD.status,OLD.created_by,OLD.created_date,OLD.modified_by,OLD.modified_date); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_flexi_plan', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_location; $$ 
 create trigger trg_au_epc_location
 after update on epc_location for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_location,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_location(operation, operation_date, operation_by,location_id,location_type,parent_location_id,location_name,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.location_id,OLD.location_type,OLD.parent_location_id,OLD.location_name,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_location', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_lookup_master; $$ 
 create trigger trg_au_epc_lookup_master
 after update on epc_lookup_master for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_lookup_master,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_lookup_master(operation, operation_date, operation_by,lookup_id,lookup_group,lookup_name,lookup_value,lookup_display_value,parent_lookup_value,lookup_description,lookup_sort_order,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.lookup_id,OLD.lookup_group,OLD.lookup_name,OLD.lookup_value,OLD.lookup_display_value,OLD.parent_lookup_value,OLD.lookup_description,OLD.lookup_sort_order,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_lookup_master', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_notification_template; $$ 
 create trigger trg_au_epc_notification_template
 after update on epc_notification_template for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_notification_template,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_notification_template(operation, operation_date, operation_by,notification_template_id,template_name,template_type,source_system,mode_of_delivery,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.notification_template_id,OLD.template_name,OLD.template_type,OLD.source_system,OLD.mode_of_delivery,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_notification_template', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_notification_template_detail; $$ 
 create trigger trg_au_epc_notification_template_detail
 after update on epc_notification_template_detail for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_notification_template_detail,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_notification_template_detail(operation, operation_date, operation_by,notification_template_detail_id,notification_template_id,template_language,template_subject,template_body,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.notification_template_detail_id,OLD.notification_template_id,OLD.template_language,OLD.template_subject,OLD.template_body,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_notification_template_detail', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_order_channel_rule; $$ 
 create trigger trg_au_epc_order_channel_rule
 after update on epc_order_channel_rule for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_order_channel_rule,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_order_channel_rule(operation, operation_date, operation_by,order_channel_rule_id,order_type,product_sub_family,product_classification,sales_channel,initiating_channel,is_consent_required,notification_template_id,is_future_date,currency,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.order_channel_rule_id,OLD.order_type,OLD.product_sub_family,OLD.product_classification,OLD.sales_channel,OLD.initiating_channel,OLD.is_consent_required,OLD.notification_template_id,OLD.is_future_date,OLD.currency,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_order_channel_rule', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_order_charge; $$ 
 create trigger trg_au_epc_order_charge
 after update on epc_order_charge for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_order_charge,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_order_charge(operation, operation_date, operation_by,order_charge_id,order_channel_rule_id,occ_code,order_charge_fee,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.order_charge_id,OLD.order_channel_rule_id,OLD.occ_code,OLD.order_charge_fee,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_order_charge', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_flexi_plan; $$ 
 create trigger trg_ad_epc_flexi_plan
 after delete on epc_flexi_plan for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_flexi_plan,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_flexi_plan(operation, operation_date, operation_by,flexi_plan_id,flexi_plan_type,validity_in_days,data_range_start,data_range_end,voice_range_start,voice_range_end,sms_range_start,sms_range_end,price,status,created_by,created_date,modified_by,modified_date) 
 values ('D', current_timestamp(), current_user(), OLD.flexi_plan_id,OLD.flexi_plan_type,OLD.validity_in_days,OLD.data_range_start,OLD.data_range_end,OLD.voice_range_start,OLD.voice_range_end,OLD.sms_range_start,OLD.sms_range_end,OLD.price,OLD.status,OLD.created_by,OLD.created_date,OLD.modified_by,OLD.modified_date); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_flexi_plan', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_location; $$ 
 create trigger trg_ad_epc_location
 after delete on epc_location for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_location,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_location(operation, operation_date, operation_by,location_id,location_type,parent_location_id,location_name,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.location_id,OLD.location_type,OLD.parent_location_id,OLD.location_name,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_location', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_lookup_master; $$ 
 create trigger trg_ad_epc_lookup_master
 after delete on epc_lookup_master for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_lookup_master,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_lookup_master(operation, operation_date, operation_by,lookup_id,lookup_group,lookup_name,lookup_value,lookup_display_value,parent_lookup_value,lookup_description,lookup_sort_order,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.lookup_id,OLD.lookup_group,OLD.lookup_name,OLD.lookup_value,OLD.lookup_display_value,OLD.parent_lookup_value,OLD.lookup_description,OLD.lookup_sort_order,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_lookup_master', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_notification_template; $$ 
 create trigger trg_ad_epc_notification_template
 after delete on epc_notification_template for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_notification_template,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_notification_template(operation, operation_date, operation_by,notification_template_id,template_name,template_type,source_system,mode_of_delivery,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.notification_template_id,OLD.template_name,OLD.template_type,OLD.source_system,OLD.mode_of_delivery,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_notification_template', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_notification_template_detail; $$ 
 create trigger trg_ad_epc_notification_template_detail
 after delete on epc_notification_template_detail for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_notification_template_detail,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_notification_template_detail(operation, operation_date, operation_by,notification_template_detail_id,notification_template_id,template_language,template_subject,template_body,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.notification_template_detail_id,OLD.notification_template_id,OLD.template_language,OLD.template_subject,OLD.template_body,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_notification_template_detail', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_order_channel_rule; $$ 
 create trigger trg_ad_epc_order_channel_rule
 after delete on epc_order_channel_rule for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_order_channel_rule,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_order_channel_rule(operation, operation_date, operation_by,order_channel_rule_id,order_type,product_sub_family,product_classification,sales_channel,initiating_channel,is_consent_required,notification_template_id,is_future_date,currency,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.order_channel_rule_id,OLD.order_type,OLD.product_sub_family,OLD.product_classification,OLD.sales_channel,OLD.initiating_channel,OLD.is_consent_required,OLD.notification_template_id,OLD.is_future_date,OLD.currency,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_order_channel_rule', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_order_charge; $$ 
 create trigger trg_ad_epc_order_charge
 after delete on epc_order_charge for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_order_charge,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_order_charge(operation, operation_date, operation_by,order_charge_id,order_channel_rule_id,occ_code,order_charge_fee,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.order_charge_id,OLD.order_channel_rule_id,OLD.occ_code,OLD.order_charge_fee,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_order_charge', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_partner_msisdn; $$ 
 create trigger trg_ai_epc_partner_msisdn
 after insert on epc_partner_msisdn for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_partner_msisdn,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_partner_msisdn(operation, operation_date, operation_by, partner_msisdn_id,partner_msisdn,created_date,created_by) 
 values ('I', current_timestamp(), current_user(), NEW.partner_msisdn_id,NEW.partner_msisdn,NEW.created_date,NEW.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_partner_msisdn', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_attribute; $$ 
 create trigger trg_ai_epc_product_attribute
 after insert on epc_product_attribute for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_attribute,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_attribute(operation, operation_date, operation_by, product_attribute_id,product_id,attribute_id,attribute_value1,attribute_value2,attribute_uom,default_value1,default_value2,is_priceing_attribute,is_otc_attribute,is_child_product_attribute,is_mandatory,is_input_req_from_channel,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_attribute_id,NEW.product_id,NEW.attribute_id,NEW.attribute_value1,NEW.attribute_value2,NEW.attribute_uom,NEW.default_value1,NEW.default_value2,NEW.is_priceing_attribute,NEW.is_otc_attribute,NEW.is_child_product_attribute,NEW.is_mandatory,NEW.is_input_req_from_channel,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_attribute', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_availability; $$ 
 create trigger trg_ai_epc_product_availability
 after insert on epc_product_availability for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_availability,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_availability(operation, operation_date, operation_by, product_availability_id,product_id,life_validity_start_date,life_validity_end_date,launch_date,selling_start_date,selling_end_date,subscription_start_date,subscription_end_date,active_business_hour_from,active_business_hour_to,subscription_duration,subscription_duration_uom,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_availability_id,NEW.product_id,NEW.life_validity_start_date,NEW.life_validity_end_date,NEW.launch_date,NEW.selling_start_date,NEW.selling_end_date,NEW.subscription_start_date,NEW.subscription_end_date,NEW.active_business_hour_from,NEW.active_business_hour_to,NEW.subscription_duration,NEW.subscription_duration_uom,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_availability', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_community; $$ 
 create trigger trg_ai_epc_product_community
 after insert on epc_product_community for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_community,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_community(operation, operation_date, operation_by, product_community_id,product_id,community_id,applicable_emp_band,community_name,discounted_price,slab_id,is_employee_allowed_to_purchase,status,created_date,created_by,modified_date,modified_by,cug_id,community_short_code,is_vat_exempted,remarks) 
 values ('I', current_timestamp(), current_user(), NEW.product_community_id,NEW.product_id,NEW.community_id,NEW.applicable_emp_band,NEW.community_name,NEW.discounted_price,NEW.slab_id,NEW.is_employee_allowed_to_purchase,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by,NEW.cug_id,NEW.community_short_code,NEW.is_vat_exempted,NEW.remarks); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_community', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_compatibility; $$ 
 create trigger trg_ai_epc_product_compatibility
 after insert on epc_product_compatibility for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_compatibility,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_compatibility(operation, operation_date, operation_by, product_compatibility_id,product_id,other_product_id,inclusive_or_exclusive,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_compatibility_id,NEW.product_id,NEW.other_product_id,NEW.inclusive_or_exclusive,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_compatibility', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_decomposition; $$ 
 create trigger trg_ai_epc_product_decomposition
 after insert on epc_product_decomposition for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_decomposition,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_decomposition(operation, operation_date, operation_by, product_decomposition_id,order_type,service_id_sequence,task,task_type,param_name,param_value,product_sub_family,product_classification,product_short_code,node_type,node_id,url_string,integration_mode,is_notification_required,notification_template_id,start_date,end_date,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_decomposition_id,NEW.order_type,NEW.service_id_sequence,NEW.task,NEW.task_type,NEW.param_name,NEW.param_value,NEW.product_sub_family,NEW.product_classification,NEW.product_short_code,NEW.node_type,NEW.node_id,NEW.url_string,NEW.integration_mode,NEW.is_notification_required,NEW.notification_template_id,NEW.start_date,NEW.end_date,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_decomposition', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_heirarchy; $$ 
 create trigger trg_ai_epc_product_heirarchy
 after insert on epc_product_heirarchy for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_heirarchy,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_heirarchy(operation, operation_date, operation_by, product_heirarchy_id,parent_product_id,child_product_id,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_heirarchy_id,NEW.parent_product_id,NEW.child_product_id,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_heirarchy', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_init_channel; $$ 
 create trigger trg_ai_epc_product_init_channel
 after insert on epc_product_init_channel for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_init_channel,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_init_channel(operation, operation_date, operation_by, product_init_channel_id,product_id,channel_id,channel_level_product_id,channel_level_market_name,channel_short_code,action_type,service_keyword,service_keyword_other,url_string,is_notification_required,notification_template_id,alias,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_init_channel_id,NEW.product_id,NEW.channel_id,NEW.channel_level_product_id,NEW.channel_level_market_name,NEW.channel_short_code,NEW.action_type,NEW.service_keyword,NEW.service_keyword_other,NEW.url_string,NEW.is_notification_required,NEW.notification_template_id,NEW.alias,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_init_channel', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_partner_msisdn; $$ 
 create trigger trg_au_epc_partner_msisdn
 after update on epc_partner_msisdn for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_partner_msisdn,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_partner_msisdn(operation, operation_date, operation_by,partner_msisdn_id,partner_msisdn,created_date,created_by) 
 values ('U', current_timestamp(), current_user(), OLD.partner_msisdn_id,OLD.partner_msisdn,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_partner_msisdn', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_attribute; $$ 
 create trigger trg_au_epc_product_attribute
 after update on epc_product_attribute for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_attribute,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_attribute(operation, operation_date, operation_by,product_attribute_id,product_id,attribute_id,attribute_value1,attribute_value2,attribute_uom,default_value1,default_value2,is_priceing_attribute,is_otc_attribute,is_child_product_attribute,is_mandatory,is_input_req_from_channel,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_attribute_id,OLD.product_id,OLD.attribute_id,OLD.attribute_value1,OLD.attribute_value2,OLD.attribute_uom,OLD.default_value1,OLD.default_value2,OLD.is_priceing_attribute,OLD.is_otc_attribute,OLD.is_child_product_attribute,OLD.is_mandatory,OLD.is_input_req_from_channel,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_attribute', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_availability; $$ 
 create trigger trg_au_epc_product_availability
 after update on epc_product_availability for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_availability,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_availability(operation, operation_date, operation_by,product_availability_id,product_id,life_validity_start_date,life_validity_end_date,launch_date,selling_start_date,selling_end_date,subscription_start_date,subscription_end_date,active_business_hour_from,active_business_hour_to,subscription_duration,subscription_duration_uom,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_availability_id,OLD.product_id,OLD.life_validity_start_date,OLD.life_validity_end_date,OLD.launch_date,OLD.selling_start_date,OLD.selling_end_date,OLD.subscription_start_date,OLD.subscription_end_date,OLD.active_business_hour_from,OLD.active_business_hour_to,OLD.subscription_duration,OLD.subscription_duration_uom,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_availability', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_community; $$ 
 create trigger trg_au_epc_product_community
 after update on epc_product_community for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_community,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_community(operation, operation_date, operation_by,product_community_id,product_id,community_id,applicable_emp_band,community_name,discounted_price,slab_id,is_employee_allowed_to_purchase,status,created_date,created_by,modified_date,modified_by,cug_id,community_short_code,is_vat_exempted,remarks) 
 values ('U', current_timestamp(), current_user(), OLD.product_community_id,OLD.product_id,OLD.community_id,OLD.applicable_emp_band,OLD.community_name,OLD.discounted_price,OLD.slab_id,OLD.is_employee_allowed_to_purchase,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by,OLD.cug_id,OLD.community_short_code,OLD.is_vat_exempted,OLD.remarks); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_community', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_compatibility; $$ 
 create trigger trg_au_epc_product_compatibility
 after update on epc_product_compatibility for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_compatibility,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_compatibility(operation, operation_date, operation_by,product_compatibility_id,product_id,other_product_id,inclusive_or_exclusive,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_compatibility_id,OLD.product_id,OLD.other_product_id,OLD.inclusive_or_exclusive,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_compatibility', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_decomposition; $$ 
 create trigger trg_au_epc_product_decomposition
 after update on epc_product_decomposition for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_decomposition,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_decomposition(operation, operation_date, operation_by,product_decomposition_id,order_type,service_id_sequence,task,task_type,param_name,param_value,product_sub_family,product_classification,product_short_code,node_type,node_id,url_string,integration_mode,is_notification_required,notification_template_id,start_date,end_date,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_decomposition_id,OLD.order_type,OLD.service_id_sequence,OLD.task,OLD.task_type,OLD.param_name,OLD.param_value,OLD.product_sub_family,OLD.product_classification,OLD.product_short_code,OLD.node_type,OLD.node_id,OLD.url_string,OLD.integration_mode,OLD.is_notification_required,OLD.notification_template_id,OLD.start_date,OLD.end_date,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_decomposition', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_heirarchy; $$ 
 create trigger trg_au_epc_product_heirarchy
 after update on epc_product_heirarchy for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_heirarchy,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_heirarchy(operation, operation_date, operation_by,product_heirarchy_id,parent_product_id,child_product_id,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_heirarchy_id,OLD.parent_product_id,OLD.child_product_id,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_heirarchy', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_init_channel; $$ 
 create trigger trg_au_epc_product_init_channel
 after update on epc_product_init_channel for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_init_channel,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_init_channel(operation, operation_date, operation_by,product_init_channel_id,product_id,channel_id,channel_level_product_id,channel_level_market_name,channel_short_code,action_type,service_keyword,service_keyword_other,url_string,is_notification_required,notification_template_id,alias,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_init_channel_id,OLD.product_id,OLD.channel_id,OLD.channel_level_product_id,OLD.channel_level_market_name,OLD.channel_short_code,OLD.action_type,OLD.service_keyword,OLD.service_keyword_other,OLD.url_string,OLD.is_notification_required,OLD.notification_template_id,OLD.alias,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_init_channel', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_partner_msisdn; $$ 
 create trigger trg_ad_epc_partner_msisdn
 after delete on epc_partner_msisdn for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_partner_msisdn,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_partner_msisdn(operation, operation_date, operation_by,partner_msisdn_id,partner_msisdn,created_date,created_by) 
 values ('D', current_timestamp(), current_user(), OLD.partner_msisdn_id,OLD.partner_msisdn,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_partner_msisdn', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_attribute; $$ 
 create trigger trg_ad_epc_product_attribute
 after delete on epc_product_attribute for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_attribute,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_attribute(operation, operation_date, operation_by,product_attribute_id,product_id,attribute_id,attribute_value1,attribute_value2,attribute_uom,default_value1,default_value2,is_priceing_attribute,is_otc_attribute,is_child_product_attribute,is_mandatory,is_input_req_from_channel,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_attribute_id,OLD.product_id,OLD.attribute_id,OLD.attribute_value1,OLD.attribute_value2,OLD.attribute_uom,OLD.default_value1,OLD.default_value2,OLD.is_priceing_attribute,OLD.is_otc_attribute,OLD.is_child_product_attribute,OLD.is_mandatory,OLD.is_input_req_from_channel,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_attribute', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_availability; $$ 
 create trigger trg_ad_epc_product_availability
 after delete on epc_product_availability for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_availability,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_availability(operation, operation_date, operation_by,product_availability_id,product_id,life_validity_start_date,life_validity_end_date,launch_date,selling_start_date,selling_end_date,subscription_start_date,subscription_end_date,active_business_hour_from,active_business_hour_to,subscription_duration,subscription_duration_uom,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_availability_id,OLD.product_id,OLD.life_validity_start_date,OLD.life_validity_end_date,OLD.launch_date,OLD.selling_start_date,OLD.selling_end_date,OLD.subscription_start_date,OLD.subscription_end_date,OLD.active_business_hour_from,OLD.active_business_hour_to,OLD.subscription_duration,OLD.subscription_duration_uom,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_availability', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_community; $$ 
 create trigger trg_ad_epc_product_community
 after delete on epc_product_community for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_community,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_community(operation, operation_date, operation_by,product_community_id,product_id,community_id,applicable_emp_band,community_name,discounted_price,slab_id,is_employee_allowed_to_purchase,status,created_date,created_by,modified_date,modified_by,cug_id,community_short_code,is_vat_exempted,remarks) 
 values ('D', current_timestamp(), current_user(), OLD.product_community_id,OLD.product_id,OLD.community_id,OLD.applicable_emp_band,OLD.community_name,OLD.discounted_price,OLD.slab_id,OLD.is_employee_allowed_to_purchase,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by,OLD.cug_id,OLD.community_short_code,OLD.is_vat_exempted,OLD.remarks); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_community', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_compatibility; $$ 
 create trigger trg_ad_epc_product_compatibility
 after delete on epc_product_compatibility for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_compatibility,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_compatibility(operation, operation_date, operation_by,product_compatibility_id,product_id,other_product_id,inclusive_or_exclusive,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_compatibility_id,OLD.product_id,OLD.other_product_id,OLD.inclusive_or_exclusive,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_compatibility', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_decomposition; $$ 
 create trigger trg_ad_epc_product_decomposition
 after delete on epc_product_decomposition for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_decomposition,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_decomposition(operation, operation_date, operation_by,product_decomposition_id,order_type,service_id_sequence,task,task_type,param_name,param_value,product_sub_family,product_classification,product_short_code,node_type,node_id,url_string,integration_mode,is_notification_required,notification_template_id,start_date,end_date,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_decomposition_id,OLD.order_type,OLD.service_id_sequence,OLD.task,OLD.task_type,OLD.param_name,OLD.param_value,OLD.product_sub_family,OLD.product_classification,OLD.product_short_code,OLD.node_type,OLD.node_id,OLD.url_string,OLD.integration_mode,OLD.is_notification_required,OLD.notification_template_id,OLD.start_date,OLD.end_date,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_decomposition', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_heirarchy; $$ 
 create trigger trg_ad_epc_product_heirarchy
 after delete on epc_product_heirarchy for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_heirarchy,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_heirarchy(operation, operation_date, operation_by,product_heirarchy_id,parent_product_id,child_product_id,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_heirarchy_id,OLD.parent_product_id,OLD.child_product_id,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_heirarchy', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_init_channel; $$ 
 create trigger trg_ad_epc_product_init_channel
 after delete on epc_product_init_channel for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_init_channel,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_init_channel(operation, operation_date, operation_by,product_init_channel_id,product_id,channel_id,channel_level_product_id,channel_level_market_name,channel_short_code,action_type,service_keyword,service_keyword_other,url_string,is_notification_required,notification_template_id,alias,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_init_channel_id,OLD.product_id,OLD.channel_id,OLD.channel_level_product_id,OLD.channel_level_market_name,OLD.channel_short_code,OLD.action_type,OLD.service_keyword,OLD.service_keyword_other,OLD.url_string,OLD.is_notification_required,OLD.notification_template_id,OLD.alias,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_init_channel', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_location; $$ 
 create trigger trg_ai_epc_product_location
 after insert on epc_product_location for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_location,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_location(operation, operation_date, operation_by, product_location_id,product_id,location_code_1,location_code_2,location_code_3,location_code_4,location_code_5,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_location_id,NEW.product_id,NEW.location_code_1,NEW.location_code_2,NEW.location_code_3,NEW.location_code_4,NEW.location_code_5,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_location', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_migration; $$ 
 create trigger trg_ai_epc_product_migration
 after insert on epc_product_migration for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_migration,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_migration(operation, operation_date, operation_by, product_migration_id,source_category,source_product_id,target_category,target_product_id,migration_channel,inclusive_or_exclusive,migration_remark,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_migration_id,NEW.source_category,NEW.source_product_id,NEW.target_category,NEW.target_product_id,NEW.migration_channel,NEW.inclusive_or_exclusive,NEW.migration_remark,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_migration', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_network_tpl; $$ 
 create trigger trg_ai_epc_product_network_tpl
 after insert on epc_product_network_tpl for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_network_tpl,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_network_tpl(operation, operation_date, operation_by, network_template_id,template_type,template_name,access_service_id,access_service_name,access_service_description,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.network_template_id,NEW.template_type,NEW.template_name,NEW.access_service_id,NEW.access_service_name,NEW.access_service_description,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_network_tpl', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_network_tpl_map; $$ 
 create trigger trg_ai_epc_product_network_tpl_map
 after insert on epc_product_network_tpl_map for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_network_tpl_map,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_network_tpl_map(operation, operation_date, operation_by, product_template_map_id,product_id,template_name,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_template_map_id,NEW.product_id,NEW.template_name,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_network_tpl_map', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_process_flow; $$ 
 create trigger trg_ai_epc_product_process_flow
 after insert on epc_product_process_flow for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_process_flow,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_process_flow(operation, operation_date, operation_by, product_process_flow_id,function_id,from_status,to_status,state_transition_remarks,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_process_flow_id,NEW.function_id,NEW.from_status,NEW.to_status,NEW.state_transition_remarks,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_process_flow', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_provider_system; $$ 
 create trigger trg_ai_epc_product_provider_system
 after insert on epc_product_provider_system for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_provider_system,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_provider_system(operation, operation_date, operation_by, product_provider_system_id,product_id,provider_system_code,provider_product_id,provider_product_description,is_primary_provider,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_provider_system_id,NEW.product_id,NEW.provider_system_code,NEW.provider_product_id,NEW.provider_product_description,NEW.is_primary_provider,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_provider_system', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_sales_channel; $$ 
 create trigger trg_ai_epc_product_sales_channel
 after insert on epc_product_sales_channel for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_sales_channel,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_sales_channel(operation, operation_date, operation_by, product_sales_channel_id,product_id,partner_type,partners_list,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_sales_channel_id,NEW.product_id,NEW.partner_type,NEW.partners_list,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_sales_channel', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_segment; $$ 
 create trigger trg_ai_epc_product_segment
 after insert on epc_product_segment for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_segment,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_segment(operation, operation_date, operation_by, product_segment_id,product_id,segment_type,segment_value,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_segment_id,NEW.product_id,NEW.segment_type,NEW.segment_value,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_segment', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_location; $$ 
 create trigger trg_au_epc_product_location
 after update on epc_product_location for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_location,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_location(operation, operation_date, operation_by,product_location_id,product_id,location_code_1,location_code_2,location_code_3,location_code_4,location_code_5,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_location_id,OLD.product_id,OLD.location_code_1,OLD.location_code_2,OLD.location_code_3,OLD.location_code_4,OLD.location_code_5,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_location', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_migration; $$ 
 create trigger trg_au_epc_product_migration
 after update on epc_product_migration for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_migration,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_migration(operation, operation_date, operation_by,product_migration_id,source_category,source_product_id,target_category,target_product_id,migration_channel,inclusive_or_exclusive,migration_remark,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_migration_id,OLD.source_category,OLD.source_product_id,OLD.target_category,OLD.target_product_id,OLD.migration_channel,OLD.inclusive_or_exclusive,OLD.migration_remark,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_migration', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_network_tpl; $$ 
 create trigger trg_au_epc_product_network_tpl
 after update on epc_product_network_tpl for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_network_tpl,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_network_tpl(operation, operation_date, operation_by,network_template_id,template_type,template_name,access_service_id,access_service_name,access_service_description,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.network_template_id,OLD.template_type,OLD.template_name,OLD.access_service_id,OLD.access_service_name,OLD.access_service_description,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_network_tpl', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_network_tpl_map; $$ 
 create trigger trg_au_epc_product_network_tpl_map
 after update on epc_product_network_tpl_map for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_network_tpl_map,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_network_tpl_map(operation, operation_date, operation_by,product_template_map_id,product_id,template_name,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_template_map_id,OLD.product_id,OLD.template_name,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_network_tpl_map', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_process_flow; $$ 
 create trigger trg_au_epc_product_process_flow
 after update on epc_product_process_flow for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_process_flow,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_process_flow(operation, operation_date, operation_by,product_process_flow_id,function_id,from_status,to_status,state_transition_remarks,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_process_flow_id,OLD.function_id,OLD.from_status,OLD.to_status,OLD.state_transition_remarks,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_process_flow', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_provider_system; $$ 
 create trigger trg_au_epc_product_provider_system
 after update on epc_product_provider_system for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_provider_system,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_provider_system(operation, operation_date, operation_by,product_provider_system_id,product_id,provider_system_code,provider_product_id,provider_product_description,is_primary_provider,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_provider_system_id,OLD.product_id,OLD.provider_system_code,OLD.provider_product_id,OLD.provider_product_description,OLD.is_primary_provider,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_provider_system', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_sales_channel; $$ 
 create trigger trg_au_epc_product_sales_channel
 after update on epc_product_sales_channel for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_sales_channel,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_sales_channel(operation, operation_date, operation_by,product_sales_channel_id,product_id,partner_type,partners_list,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_sales_channel_id,OLD.product_id,OLD.partner_type,OLD.partners_list,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_sales_channel', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_segment; $$ 
 create trigger trg_au_epc_product_segment
 after update on epc_product_segment for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_segment,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_segment(operation, operation_date, operation_by,product_segment_id,product_id,segment_type,segment_value,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_segment_id,OLD.product_id,OLD.segment_type,OLD.segment_value,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_segment', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_location; $$ 
 create trigger trg_ad_epc_product_location
 after delete on epc_product_location for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_location,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_location(operation, operation_date, operation_by,product_location_id,product_id,location_code_1,location_code_2,location_code_3,location_code_4,location_code_5,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_location_id,OLD.product_id,OLD.location_code_1,OLD.location_code_2,OLD.location_code_3,OLD.location_code_4,OLD.location_code_5,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_location', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_migration; $$ 
 create trigger trg_ad_epc_product_migration
 after delete on epc_product_migration for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_migration,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_migration(operation, operation_date, operation_by,product_migration_id,source_category,source_product_id,target_category,target_product_id,migration_channel,inclusive_or_exclusive,migration_remark,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_migration_id,OLD.source_category,OLD.source_product_id,OLD.target_category,OLD.target_product_id,OLD.migration_channel,OLD.inclusive_or_exclusive,OLD.migration_remark,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_migration', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_network_tpl; $$ 
 create trigger trg_ad_epc_product_network_tpl
 after delete on epc_product_network_tpl for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_network_tpl,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_network_tpl(operation, operation_date, operation_by,network_template_id,template_type,template_name,access_service_id,access_service_name,access_service_description,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.network_template_id,OLD.template_type,OLD.template_name,OLD.access_service_id,OLD.access_service_name,OLD.access_service_description,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_network_tpl', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_network_tpl_map; $$ 
 create trigger trg_ad_epc_product_network_tpl_map
 after delete on epc_product_network_tpl_map for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_network_tpl_map,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_network_tpl_map(operation, operation_date, operation_by,product_template_map_id,product_id,template_name,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_template_map_id,OLD.product_id,OLD.template_name,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_network_tpl_map', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_process_flow; $$ 
 create trigger trg_ad_epc_product_process_flow
 after delete on epc_product_process_flow for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_process_flow,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_process_flow(operation, operation_date, operation_by,product_process_flow_id,function_id,from_status,to_status,state_transition_remarks,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_process_flow_id,OLD.function_id,OLD.from_status,OLD.to_status,OLD.state_transition_remarks,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_process_flow', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_provider_system; $$ 
 create trigger trg_ad_epc_product_provider_system
 after delete on epc_product_provider_system for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_provider_system,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_provider_system(operation, operation_date, operation_by,product_provider_system_id,product_id,provider_system_code,provider_product_id,provider_product_description,is_primary_provider,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_provider_system_id,OLD.product_id,OLD.provider_system_code,OLD.provider_product_id,OLD.provider_product_description,OLD.is_primary_provider,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_provider_system', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_sales_channel; $$ 
 create trigger trg_ad_epc_product_sales_channel
 after delete on epc_product_sales_channel for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_sales_channel,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_sales_channel(operation, operation_date, operation_by,product_sales_channel_id,product_id,partner_type,partners_list,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_sales_channel_id,OLD.product_id,OLD.partner_type,OLD.partners_list,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_sales_channel', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_segment; $$ 
 create trigger trg_ad_epc_product_segment
 after delete on epc_product_segment for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_segment,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_segment(operation, operation_date, operation_by,product_segment_id,product_id,segment_type,segment_value,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_segment_id,OLD.product_id,OLD.segment_type,OLD.segment_value,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_segment', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_specification; $$ 
 create trigger trg_ai_epc_product_specification
 after insert on epc_product_specification for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_specification,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_specification(operation, operation_date, operation_by, product_id,copied_from_product_id,retire_previous_product,product_short_code,product_description,product_marketing_name,downstream_system,product_type,product_family,product_sub_family,product_classification,product_category,product_sub_category,product_status,min_subscription,max_subscription,product_quota,product_quota_uom,product_quota_duration,product_quota_duration_uom,product_association_level,is_auto_renewal_allowed,is_mandatory_in_bundle,is_bundle,is_hybrid,is_special_product,is_usage_product,is_discount_product,is_contract_product,is_template_product,is_roaming_product,is_product_paused,is_otc_allowed,is_rc_allowed,is_uc_allowed,vsmd_component,api_indicator,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_id,NEW.copied_from_product_id,NEW.retire_previous_product,NEW.product_short_code,NEW.product_description,NEW.product_marketing_name,NEW.downstream_system,NEW.product_type,NEW.product_family,NEW.product_sub_family,NEW.product_classification,NEW.product_category,NEW.product_sub_category,NEW.product_status,NEW.min_subscription,NEW.max_subscription,NEW.product_quota,NEW.product_quota_uom,NEW.product_quota_duration,NEW.product_quota_duration_uom,NEW.product_association_level,NEW.is_auto_renewal_allowed,NEW.is_mandatory_in_bundle,NEW.is_bundle,NEW.is_hybrid,NEW.is_special_product,NEW.is_usage_product,NEW.is_discount_product,NEW.is_contract_product,NEW.is_template_product,NEW.is_roaming_product,NEW.is_product_paused,NEW.is_otc_allowed,NEW.is_rc_allowed,NEW.is_uc_allowed,NEW.vsmd_component,NEW.api_indicator,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_specification', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_status_history; $$ 
 create trigger trg_ai_epc_product_status_history
 after insert on epc_product_status_history for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_status_history,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_status_history(operation, operation_date, operation_by, product_status_history_id,product_id,product_status,reason,more_info,created_date,created_by) 
 values ('I', current_timestamp(), current_user(), NEW.product_status_history_id,NEW.product_id,NEW.product_status,NEW.reason,NEW.more_info,NEW.created_date,NEW.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_status_history', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_product_testsuit; $$ 
 create trigger trg_ai_epc_product_testsuit
 after insert on epc_product_testsuit for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_testsuit,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_testsuit(operation, operation_date, operation_by, testsuit_id,product_id,testsuit_file_name,testsuit_file_desc,testsuit_file_path,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.testsuit_id,NEW.product_id,NEW.testsuit_file_name,NEW.testsuit_file_desc,NEW.testsuit_file_path,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_product_testsuit', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_tariff_override; $$ 
 create trigger trg_ai_epc_tariff_override
 after insert on epc_tariff_override for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_tariff_override,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_tariff_override(operation, operation_date, operation_by, tariff_override_id,addon_product_id,attribute_name,priority,rateplan_product_id,other_product_id_1,other_product_id_2,other_product_id_3,other_product_id_4,attribute_name_0,attribute_value_0,attribute_name_1,attribute_value_1,attribute_name_2,attribute_value_2,attribute_name_3,attribute_value_3,attribute_name_4,attribute_value_4,attribute_name_5,attribute_value_5,attribute_name_6,attribute_value_6,attribute_name_7,attribute_value_7,attribute_name_8,attribute_value_8,attribute_name_9,attribute_value_9,override_tariff_amount,tariff_currency,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.tariff_override_id,NEW.addon_product_id,NEW.attribute_name,NEW.priority,NEW.rateplan_product_id,NEW.other_product_id_1,NEW.other_product_id_2,NEW.other_product_id_3,NEW.other_product_id_4,NEW.attribute_name_0,NEW.attribute_value_0,NEW.attribute_name_1,NEW.attribute_value_1,NEW.attribute_name_2,NEW.attribute_value_2,NEW.attribute_name_3,NEW.attribute_value_3,NEW.attribute_name_4,NEW.attribute_value_4,NEW.attribute_name_5,NEW.attribute_value_5,NEW.attribute_name_6,NEW.attribute_value_6,NEW.attribute_name_7,NEW.attribute_value_7,NEW.attribute_name_8,NEW.attribute_value_8,NEW.attribute_name_9,NEW.attribute_value_9,NEW.override_tariff_amount,NEW.tariff_currency,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_tariff_override', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_epc_trigger_order_rule; $$ 
 create trigger trg_ai_epc_trigger_order_rule
 after insert on epc_trigger_order_rule for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_trigger_order_rule,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_trigger_order_rule(operation, operation_date, operation_by, trigger_order_rule_id,source_order_type,source_product_classification,source_product_sub_family,source_product_short_code,triggered_order_type,triggered_product_classification,triggered_product_sub_family,triggered_product_short_code,rule_validation_duration,rule_validation_duration_uom,subscription_within_duration,subscription_within_duration_uom,status,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.trigger_order_rule_id,NEW.source_order_type,NEW.source_product_classification,NEW.source_product_sub_family,NEW.source_product_short_code,NEW.triggered_order_type,NEW.triggered_product_classification,NEW.triggered_product_sub_family,NEW.triggered_product_short_code,NEW.rule_validation_duration,NEW.rule_validation_duration_uom,NEW.subscription_within_duration,NEW.subscription_within_duration_uom,NEW.status,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'epc_trigger_order_rule', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_function; $$ 
 create trigger trg_ai_function
 after insert on function for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'function,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_function(operation, operation_date, operation_by, function_id,name,description,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.function_id,NEW.name,NEW.description,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'function', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_role; $$ 
 create trigger trg_ai_role
 after insert on role for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'role,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_role(operation, operation_date, operation_by, role_id,name,role_description,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.role_id,NEW.name,NEW.role_description,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'role', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_role_function_map; $$ 
 create trigger trg_ai_role_function_map
 after insert on role_function_map for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'role_function_map,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_role_function_map(operation, operation_date, operation_by, role_function_map_id,role_id,function_id,created_date,created_by) 
 values ('I', current_timestamp(), current_user(), NEW.role_function_map_id,NEW.role_id,NEW.function_id,NEW.created_date,NEW.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'role_function_map', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_user_role_map; $$ 
 create trigger trg_ai_user_role_map
 after insert on user_role_map for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'user_role_map,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_user_role_map(operation, operation_date, operation_by, user_role_map_id,user_name,role_id,created_date,created_by) 
 values ('I', current_timestamp(), current_user(), NEW.user_role_map_id,NEW.user_name,NEW.role_id,NEW.created_date,NEW.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'user_role_map', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ai_users; $$ 
 create trigger trg_ai_users
 after insert on users for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'users,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='insert' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_users(operation, operation_date, operation_by, username,password,enabled,fname,lname,mname,dob,address,email,mobile_number,employee_no,created_date,created_by,modified_date,modified_by) 
 values ('I', current_timestamp(), current_user(), NEW.username,NEW.password,NEW.enabled,NEW.fname,NEW.lname,NEW.mname,NEW.dob,NEW.address,NEW.email,NEW.mobile_number,NEW.employee_no,NEW.created_date,NEW.created_by,NEW.modified_date,NEW.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.created_by, current_user()), 'users', current_timestamp(), 'Insert'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_specification; $$ 
 create trigger trg_au_epc_product_specification
 after update on epc_product_specification for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_specification,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_specification(operation, operation_date, operation_by,product_id,copied_from_product_id,retire_previous_product,product_short_code,product_description,product_marketing_name,downstream_system,product_type,product_family,product_sub_family,product_classification,product_category,product_sub_category,product_status,min_subscription,max_subscription,product_quota,product_quota_uom,product_quota_duration,product_quota_duration_uom,product_association_level,is_auto_renewal_allowed,is_mandatory_in_bundle,is_bundle,is_hybrid,is_special_product,is_usage_product,is_discount_product,is_contract_product,is_template_product,is_roaming_product,is_product_paused,is_otc_allowed,is_rc_allowed,is_uc_allowed,vsmd_component,api_indicator,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_id,OLD.copied_from_product_id,OLD.retire_previous_product,OLD.product_short_code,OLD.product_description,OLD.product_marketing_name,OLD.downstream_system,OLD.product_type,OLD.product_family,OLD.product_sub_family,OLD.product_classification,OLD.product_category,OLD.product_sub_category,OLD.product_status,OLD.min_subscription,OLD.max_subscription,OLD.product_quota,OLD.product_quota_uom,OLD.product_quota_duration,OLD.product_quota_duration_uom,OLD.product_association_level,OLD.is_auto_renewal_allowed,OLD.is_mandatory_in_bundle,OLD.is_bundle,OLD.is_hybrid,OLD.is_special_product,OLD.is_usage_product,OLD.is_discount_product,OLD.is_contract_product,OLD.is_template_product,OLD.is_roaming_product,OLD.is_product_paused,OLD.is_otc_allowed,OLD.is_rc_allowed,OLD.is_uc_allowed,OLD.vsmd_component,OLD.api_indicator,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_specification', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_status_history; $$ 
 create trigger trg_au_epc_product_status_history
 after update on epc_product_status_history for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_status_history,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_status_history(operation, operation_date, operation_by,product_status_history_id,product_id,product_status,reason,more_info,created_date,created_by) 
 values ('U', current_timestamp(), current_user(), OLD.product_status_history_id,OLD.product_id,OLD.product_status,OLD.reason,OLD.more_info,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_status_history', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_product_testsuit; $$ 
 create trigger trg_au_epc_product_testsuit
 after update on epc_product_testsuit for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_testsuit,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_testsuit(operation, operation_date, operation_by,testsuit_id,product_id,testsuit_file_name,testsuit_file_desc,testsuit_file_path,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.testsuit_id,OLD.product_id,OLD.testsuit_file_name,OLD.testsuit_file_desc,OLD.testsuit_file_path,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_product_testsuit', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_tariff_override; $$ 
 create trigger trg_au_epc_tariff_override
 after update on epc_tariff_override for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_tariff_override,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_tariff_override(operation, operation_date, operation_by,tariff_override_id,addon_product_id,attribute_name,priority,rateplan_product_id,other_product_id_1,other_product_id_2,other_product_id_3,other_product_id_4,attribute_name_0,attribute_value_0,attribute_name_1,attribute_value_1,attribute_name_2,attribute_value_2,attribute_name_3,attribute_value_3,attribute_name_4,attribute_value_4,attribute_name_5,attribute_value_5,attribute_name_6,attribute_value_6,attribute_name_7,attribute_value_7,attribute_name_8,attribute_value_8,attribute_name_9,attribute_value_9,override_tariff_amount,tariff_currency,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.tariff_override_id,OLD.addon_product_id,OLD.attribute_name,OLD.priority,OLD.rateplan_product_id,OLD.other_product_id_1,OLD.other_product_id_2,OLD.other_product_id_3,OLD.other_product_id_4,OLD.attribute_name_0,OLD.attribute_value_0,OLD.attribute_name_1,OLD.attribute_value_1,OLD.attribute_name_2,OLD.attribute_value_2,OLD.attribute_name_3,OLD.attribute_value_3,OLD.attribute_name_4,OLD.attribute_value_4,OLD.attribute_name_5,OLD.attribute_value_5,OLD.attribute_name_6,OLD.attribute_value_6,OLD.attribute_name_7,OLD.attribute_value_7,OLD.attribute_name_8,OLD.attribute_value_8,OLD.attribute_name_9,OLD.attribute_value_9,OLD.override_tariff_amount,OLD.tariff_currency,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_tariff_override', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_epc_trigger_order_rule; $$ 
 create trigger trg_au_epc_trigger_order_rule
 after update on epc_trigger_order_rule for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_trigger_order_rule,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_trigger_order_rule(operation, operation_date, operation_by,trigger_order_rule_id,source_order_type,source_product_classification,source_product_sub_family,source_product_short_code,triggered_order_type,triggered_product_classification,triggered_product_sub_family,triggered_product_short_code,rule_validation_duration,rule_validation_duration_uom,subscription_within_duration,subscription_within_duration_uom,status,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.trigger_order_rule_id,OLD.source_order_type,OLD.source_product_classification,OLD.source_product_sub_family,OLD.source_product_short_code,OLD.triggered_order_type,OLD.triggered_product_classification,OLD.triggered_product_sub_family,OLD.triggered_product_short_code,OLD.rule_validation_duration,OLD.rule_validation_duration_uom,OLD.subscription_within_duration,OLD.subscription_within_duration_uom,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'epc_trigger_order_rule', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_function; $$ 
 create trigger trg_au_function
 after update on function for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'function,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_function(operation, operation_date, operation_by,function_id,name,description,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.function_id,OLD.name,OLD.description,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'function', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_role; $$ 
 create trigger trg_au_role
 after update on role for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'role,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_role(operation, operation_date, operation_by,role_id,name,role_description,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.role_id,OLD.name,OLD.role_description,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'role', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_role_function_map; $$ 
 create trigger trg_au_role_function_map
 after update on role_function_map for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'role_function_map,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_role_function_map(operation, operation_date, operation_by,role_function_map_id,role_id,function_id,created_date,created_by) 
 values ('U', current_timestamp(), current_user(), OLD.role_function_map_id,OLD.role_id,OLD.function_id,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'role_function_map', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_user_role_map; $$ 
 create trigger trg_au_user_role_map
 after update on user_role_map for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'user_role_map,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_user_role_map(operation, operation_date, operation_by,user_role_map_id,user_name,role_id,created_date,created_by) 
 values ('U', current_timestamp(), current_user(), OLD.user_role_map_id,OLD.user_name,OLD.role_id,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'user_role_map', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_au_users; $$ 
 create trigger trg_au_users
 after update on users for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'users,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='update' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_users(operation, operation_date, operation_by,username,password,enabled,fname,lname,mname,dob,address,email,mobile_number,employee_no,created_date,created_by,modified_date,modified_by) 
 values ('U', current_timestamp(), current_user(), OLD.username,OLD.password,OLD.enabled,OLD.fname,OLD.lname,OLD.mname,OLD.dob,OLD.address,OLD.email,OLD.mobile_number,OLD.employee_no,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(ifnull(new.modified_by, current_user()), 'users', current_timestamp(), 'Update'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_specification; $$ 
 create trigger trg_ad_epc_product_specification
 after delete on epc_product_specification for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_specification,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_specification(operation, operation_date, operation_by,product_id,copied_from_product_id,retire_previous_product,product_short_code,product_description,product_marketing_name,downstream_system,product_type,product_family,product_sub_family,product_classification,product_category,product_sub_category,product_status,min_subscription,max_subscription,product_quota,product_quota_uom,product_quota_duration,product_quota_duration_uom,product_association_level,is_auto_renewal_allowed,is_mandatory_in_bundle,is_bundle,is_hybrid,is_special_product,is_usage_product,is_discount_product,is_contract_product,is_template_product,is_roaming_product,is_product_paused,is_otc_allowed,is_rc_allowed,is_uc_allowed,vsmd_component,api_indicator,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_id,OLD.copied_from_product_id,OLD.retire_previous_product,OLD.product_short_code,OLD.product_description,OLD.product_marketing_name,OLD.downstream_system,OLD.product_type,OLD.product_family,OLD.product_sub_family,OLD.product_classification,OLD.product_category,OLD.product_sub_category,OLD.product_status,OLD.min_subscription,OLD.max_subscription,OLD.product_quota,OLD.product_quota_uom,OLD.product_quota_duration,OLD.product_quota_duration_uom,OLD.product_association_level,OLD.is_auto_renewal_allowed,OLD.is_mandatory_in_bundle,OLD.is_bundle,OLD.is_hybrid,OLD.is_special_product,OLD.is_usage_product,OLD.is_discount_product,OLD.is_contract_product,OLD.is_template_product,OLD.is_roaming_product,OLD.is_product_paused,OLD.is_otc_allowed,OLD.is_rc_allowed,OLD.is_uc_allowed,OLD.vsmd_component,OLD.api_indicator,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_specification', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_status_history; $$ 
 create trigger trg_ad_epc_product_status_history
 after delete on epc_product_status_history for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_status_history,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_status_history(operation, operation_date, operation_by,product_status_history_id,product_id,product_status,reason,more_info,created_date,created_by) 
 values ('D', current_timestamp(), current_user(), OLD.product_status_history_id,OLD.product_id,OLD.product_status,OLD.reason,OLD.more_info,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_status_history', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_product_testsuit; $$ 
 create trigger trg_ad_epc_product_testsuit
 after delete on epc_product_testsuit for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_product_testsuit,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_product_testsuit(operation, operation_date, operation_by,testsuit_id,product_id,testsuit_file_name,testsuit_file_desc,testsuit_file_path,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.testsuit_id,OLD.product_id,OLD.testsuit_file_name,OLD.testsuit_file_desc,OLD.testsuit_file_path,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_product_testsuit', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_tariff_override; $$ 
 create trigger trg_ad_epc_tariff_override
 after delete on epc_tariff_override for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_tariff_override,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_tariff_override(operation, operation_date, operation_by,tariff_override_id,addon_product_id,attribute_name,priority,rateplan_product_id,other_product_id_1,other_product_id_2,other_product_id_3,other_product_id_4,attribute_name_0,attribute_value_0,attribute_name_1,attribute_value_1,attribute_name_2,attribute_value_2,attribute_name_3,attribute_value_3,attribute_name_4,attribute_value_4,attribute_name_5,attribute_value_5,attribute_name_6,attribute_value_6,attribute_name_7,attribute_value_7,attribute_name_8,attribute_value_8,attribute_name_9,attribute_value_9,override_tariff_amount,tariff_currency,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.tariff_override_id,OLD.addon_product_id,OLD.attribute_name,OLD.priority,OLD.rateplan_product_id,OLD.other_product_id_1,OLD.other_product_id_2,OLD.other_product_id_3,OLD.other_product_id_4,OLD.attribute_name_0,OLD.attribute_value_0,OLD.attribute_name_1,OLD.attribute_value_1,OLD.attribute_name_2,OLD.attribute_value_2,OLD.attribute_name_3,OLD.attribute_value_3,OLD.attribute_name_4,OLD.attribute_value_4,OLD.attribute_name_5,OLD.attribute_value_5,OLD.attribute_name_6,OLD.attribute_value_6,OLD.attribute_name_7,OLD.attribute_value_7,OLD.attribute_name_8,OLD.attribute_value_8,OLD.attribute_name_9,OLD.attribute_value_9,OLD.override_tariff_amount,OLD.tariff_currency,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_tariff_override', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_epc_trigger_order_rule; $$ 
 create trigger trg_ad_epc_trigger_order_rule
 after delete on epc_trigger_order_rule for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'epc_trigger_order_rule,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_epc_trigger_order_rule(operation, operation_date, operation_by,trigger_order_rule_id,source_order_type,source_product_classification,source_product_sub_family,source_product_short_code,triggered_order_type,triggered_product_classification,triggered_product_sub_family,triggered_product_short_code,rule_validation_duration,rule_validation_duration_uom,subscription_within_duration,subscription_within_duration_uom,status,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.trigger_order_rule_id,OLD.source_order_type,OLD.source_product_classification,OLD.source_product_sub_family,OLD.source_product_short_code,OLD.triggered_order_type,OLD.triggered_product_classification,OLD.triggered_product_sub_family,OLD.triggered_product_short_code,OLD.rule_validation_duration,OLD.rule_validation_duration_uom,OLD.subscription_within_duration,OLD.subscription_within_duration_uom,OLD.status,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'epc_trigger_order_rule', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_function; $$ 
 create trigger trg_ad_function
 after delete on function for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'function,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_function(operation, operation_date, operation_by,function_id,name,description,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.function_id,OLD.name,OLD.description,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'function', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_role; $$ 
 create trigger trg_ad_role
 after delete on role for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'role,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_role(operation, operation_date, operation_by,role_id,name,role_description,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.role_id,OLD.name,OLD.role_description,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'role', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_role_function_map; $$ 
 create trigger trg_ad_role_function_map
 after delete on role_function_map for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'role_function_map,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_role_function_map(operation, operation_date, operation_by,role_function_map_id,role_id,function_id,created_date,created_by) 
 values ('D', current_timestamp(), current_user(), OLD.role_function_map_id,OLD.role_id,OLD.function_id,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'role_function_map', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_user_role_map; $$ 
 create trigger trg_ad_user_role_map
 after delete on user_role_map for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'user_role_map,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_user_role_map(operation, operation_date, operation_by,user_role_map_id,user_name,role_id,created_date,created_by) 
 values ('D', current_timestamp(), current_user(), OLD.user_role_map_id,OLD.user_name,OLD.role_id,OLD.created_date,OLD.created_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'user_role_map', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 



 DROP TRIGGER IF EXISTS trg_ad_users; $$ 
 create trigger trg_ad_users
 after delete on users for each row 
 begin 
 select instr(lower(concat(specific_tables, ',')),'users,' ), lower(global_audit_table) into @cnt ,@is_global_audit from db_audit_control where lower(trigger_action) ='delete' and status='Active' limit 1;
 if @cnt > 0 then 
 insert into aud_users(operation, operation_date, operation_by,username,password,enabled,fname,lname,mname,dob,address,email,mobile_number,employee_no,created_date,created_by,modified_date,modified_by) 
 values ('D', current_timestamp(), current_user(), OLD.username,OLD.password,OLD.enabled,OLD.fname,OLD.lname,OLD.mname,OLD.dob,OLD.address,OLD.email,OLD.mobile_number,OLD.employee_no,OLD.created_date,OLD.created_by,OLD.modified_date,OLD.modified_by); 
 end if; 
 if @is_global_audit = 'epc_audit_log' then 
 insert into epc_audit_log(username ,table_name, action_date, action_performed) values(current_user(), 'users', current_timestamp(), 'Delete'); 
 end if; 
 END; $$ 

