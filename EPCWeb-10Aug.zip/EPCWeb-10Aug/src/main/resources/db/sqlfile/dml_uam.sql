Insert into users (username,password,enabled,fname,created_by,created_date,modified_by,modified_date) 
values 
('admin','admin','true','Admin','admin',current_timestamp(),'admin',current_timestamp()),
('guest','guest','true','Guest','admin',current_timestamp(),'admin',current_timestamp()),
('prodadmin','prodadmin','true','Product Admin','admin',current_timestamp(),'admin',current_timestamp()),
('prodapprover','prodapprover','true','Product Approver','admin',current_timestamp(),'admin',current_timestamp()),
('tester','tester','true','Tester','admin',current_timestamp(),'admin',current_timestamp()),
('rafmuser','rafmuser','true','RAFM','admin',current_timestamp(),'admin',current_timestamp()),
('dmuser','dmuser','true','DM','admin',current_timestamp(),'admin',current_timestamp()),
('spclproduser','spclproduser','true','Special','admin',current_timestamp(),'admin',current_timestamp());

      
Insert into role (role_id,name,role_description,created_by,created_date,modified_by,modified_date) 
values 
('1','role_admin','Admin','admin',current_timestamp(),'admin',current_timestamp()),
('2','role_guest','Guest','admin',current_timestamp(),'admin',current_timestamp()),
('3','role_product_admin','Product Admin','admin',current_timestamp(),'admin',current_timestamp()),
('4','role_product_approver','Product Approver','admin',current_timestamp(),'admin',current_timestamp()),
('5','role_test_team','Test Team','admin',current_timestamp(),'admin',current_timestamp()),
('6','role_rafm_team','RAFM Team','admin',current_timestamp(),'admin',current_timestamp()),
('7','role_dm_team','DM Team','admin',current_timestamp(),'admin',current_timestamp()),
('8','role_privileged_prod_team','Product Team (Privileged)','admin',current_timestamp(),'admin',current_timestamp());


Insert into function (function_id,name,description,created_by,created_date,modified_by,modified_date) 
values 
('1','Page_Home','Home','admin',current_timestamp(),'admin',current_timestamp()),
('2','add_new_user','Add New User','admin',current_timestamp(),'admin',current_timestamp()),
('3','update_user','Update User','admin',current_timestamp(),'admin',current_timestamp()),
('4', 'Page_CreateProduct', 'Create/Copy Product', 'admin',current_timestamp(),'admin',current_timestamp()),
('5', 'Page_SearchProduct', 'Search/View Product', 'admin',current_timestamp(),'admin',current_timestamp()),
('6', 'Page_UserAccessManagement', 'User Access Management', 'admin',current_timestamp(),'admin',current_timestamp()),
('7', 'Page_ProductApproval', 'Product Approval', 'admin',current_timestamp(),'admin',current_timestamp()),
('8', 'Page_CreateViewCharacteristics', 'Add/View Characteristics', 'admin',current_timestamp(),'admin',current_timestamp()),
('9', 'Page_NotificationTemplate', 'Notification Template', 'admin',current_timestamp(),'admin',current_timestamp()),
('10', 'Page_PublishProduct', 'Publish Product', 'admin',current_timestamp(),'admin',current_timestamp()),
('11', 'Page_Database', 'Database Details', 'admin',current_timestamp(),'admin',current_timestamp()),
('12', 'Page_ManageOrder', 'Manage Order', 'admin',current_timestamp(),'admin',current_timestamp()),
('13', 'Page_Configuration', 'Manage Configurations', 'admin',current_timestamp(),'admin',current_timestamp()),
('14', 'Page_TransactionGraphs', 'Transaction graphs', 'admin',current_timestamp(),'admin',current_timestamp()),
('15', 'Page_ManageCommunity', 'Manage Community', 'admin',current_timestamp(),'admin',current_timestamp()),
('16', 'Page_ManageActivity', 'Manage Activity', 'admin',current_timestamp(),'admin',current_timestamp()),
('17', 'Edit_Product', 'Edit Product', 'admin',current_timestamp(),'admin',current_timestamp()),
('18', 'Edit_Product_Post_Submit', 'Edit submitted Product(limited)', 'admin',current_timestamp(),'admin',current_timestamp());

Insert into user_role_map (user_role_map_id,user_name,role_id,created_by,created_date) 
values 
('1','admin','1','admin',current_timestamp()),
('2','guest','2','admin',current_timestamp()),
('3','prodadmin','3','admin',current_timestamp()),
('4','prodapprover','4','admin',current_timestamp()),
('5','tester','5','admin',current_timestamp()),
('6','rafmuser','6','admin',current_timestamp()),
('7','dmuser','7','admin',current_timestamp()),
('8','spclproduser','8','admin',current_timestamp()); 

Insert into role_function_map (role_function_map_id,role_id,function_id,created_by,created_date) 
values 
('1','1','1','admin',current_timestamp()),
('2','1','2','admin',current_timestamp()),
('3','1','3','admin',current_timestamp()),
('4','2','1','admin',current_timestamp()),
('5', '1', '4', 'admin',current_timestamp()),
('6', '1', '5', 'admin',current_timestamp()),
('7', '1', '6', 'admin',current_timestamp()),
('8', '1', '7', 'admin',current_timestamp()),
('9', '1', '8', 'admin',current_timestamp()),
('10', '1', '9', 'admin',current_timestamp()),
('11', '1', '10', 'admin',current_timestamp()),
('12', '1', '11', 'admin',current_timestamp()),
('13', '1', '12', 'admin',current_timestamp()),
('14', '1', '13', 'admin',current_timestamp()),
('15', '1', '14', 'admin',current_timestamp()),
('16', '1', '15', 'admin',current_timestamp()),
('17', '1', '16', 'admin',current_timestamp()),
('18', '2', '5', 'admin',current_timestamp());

Insert into authorities (username,authority,created_by,created_date) 
values 
('admin','Page_Home','admin',current_timestamp()),
('admin','add_new_user','admin',current_timestamp()),
('admin','update_user','admin',current_timestamp()),
('guest','Page_Home','admin',current_timestamp()),
('admin', 'Page_CreateProduct', 'admin',current_timestamp()),
('admin', 'Page_SearchProduct', 'admin',current_timestamp()),
('admin', 'Page_UserAccessManagement', 'admin',current_timestamp()),
('admin', 'Page_ProductApproval', 'admin',current_timestamp()),
('admin', 'Page_CreateViewCharacteristics', 'admin',current_timestamp()),
('admin', 'Page_NotificationTemplate', 'admin',current_timestamp()),
('admin', 'Page_PublishProduct', 'admin',current_timestamp()),
--('admin', 'Page_Transactions', 'admin',current_timestamp()),
('admin', 'Page_Database', 'admin',current_timestamp()),
('admin', 'Page_ManageOrder', 'admin',current_timestamp()),
('admin', 'Page_Configuration', 'admin',current_timestamp()),
('admin', 'Page_TransactionGraphs', 'admin',current_timestamp()),
('admin', 'Page_ManageCommunity', 'admin',current_timestamp()),
('admin', 'Page_ManageActivity', 'admin',current_timestamp()),
( 'guest' , 'Page_SearchProduct', 'admin',current_timestamp());