INSERT INTO epc_notification_template (notification_template_id, template_name, template_type, source_system, mode_of_delivery, status, created_date, created_by, modified_date, modified_by) VALUES (5,'Product_Approval_NotificationTemplate','Product Approval','EPC','Email','Active','2016-09-27 13:52:39','admin','2016-09-27 13:52:39','admin');
INSERT INTO epc_notification_template_detail ( notification_template_id, template_language, template_subject, template_body, status, created_date, created_by, modified_date, modified_by) VALUES 
(5,'English','EPC- Product(s) (<productShortCodes>) state change from <fromState> to <toState>','Dear Concern,

New Product(s) with product details provided below <stateRemarks>  by  <userBy>.

  <productsDetail>

For details/to proceed for the next steps, click the below link.
<linkAdrs>

Regards,
GP EPC','Active','2016-09-27 13:52:39','admin','2016-09-27 13:52:39','admin');
