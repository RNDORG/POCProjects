INSERT INTO config (config_group, config_key, config_value,description,status,created_by) VALUES
('Config', 'LastModifiedTime', '0', 'Used by Config Module.  Should  not be configured ', 'Active','epcSys'), 
('Config', 'dynamic_configuration', 'true', 'Type - LOV ( ''true'', ''false'' )
Default - true
Desc - Enable or Disable dynamic configuration. Takes configuration reflects only after application restart.', 'Active','epcSys'),
('Config', 'polling_Interval', '120000', 'Type - Number 
Default - 12000
Desc - Time in milliseconds. 
If dynamic_configuration is set, then changes to configuration reflect within this time.', 'Active','epcSys'),  
('Mail', 'smtp_from', 'CRM360_5', 'Host account name', 'Active','epcSys'), 
('Mail', 'smtp_host', '10.10.19.37', 'SMTP host server IP', 'Active','epcSys'),
('Mail', 'smtp_username', '', 'Should be specified if smpt_auth is set to true', 'Active','epcSys'),
('Mail', 'smtp_password', '', 'Should be specified if smpt_auth is set to true', 'Active','epcSys'),
('Mail', 'smtp_auth', 'false', 'default:false', 'Active','epcSys'),
('Mail', 'smtp_port', '25', 'default:25', 'Active','epcSys'),
('Mail', 'smtp_class','javax.net.ssl.SSLSocketFactory', 'default:javax.net.ssl.SSLSocketFactory', 'Active','epcSys'),
('Mail', 'smtp_fallback', 'false', 'default:false', 'Active','epcSys'),
('Publish Product', 'To', 'PCM@grameenphone.com', null, 'Active','epcSys'),
('Publish Product', 'Subject', 'Product(s) Published', null, 'Active','epcSys'),
('Publish Product', 'Body', 'Please find the attachment for published Product(s).', null, 'Active','epcSys'),
('Product Approval', 'UrlLink', 'http://10.10.21.27:8090/EPCWeb/#/ProductApproval', 'Link address to open product Approval page', 'Active','epcSys'),
('CustomConfig', 'CustomType', 'CUSTOM_LDAP', 'CUSTOM_LDAP / CUSTOM_JDBC', 'Active','epcSys'),              
('CustomConfig', 'CustomLDAP_SecurityAuthentication', 'simple', 'default value is simple', 'Active','epcSys'),
('CustomConfig', 'CustomLDAP_Domain', '', '', 'Active','epcSys'),                  
('CustomConfig', 'CustomLDAP_URL', '', null, 'Active','epcSys'),
('ext_api', 'stub_subscribed_rateplan', '144', 'Stub for subscribed rate plan', 'Active','epcSys'),
('ext_api', 'stub_subscribed_gsm_addons', '145,146,147', 'Stub for subscribed GSM Addons (comma separated provider product ids )', 'Active','epcSys'),
('ext_api', 'stub_subscribed_vas_addons', 'CBIO-154, CBIO-155', 'Stub for subscribed VAS Addons ( comma separated provider system code hyphen(-) provider product id )', 'Active','epcSys'),
('ext_api', 'non_network_vas_classifications', 'CRBT, Content Service, Music Radio', 'Non Network VAS Classifications list', 'Active','epcSys'),
('ext_api', 'non_network_vas_compatibility_flag', 'false', 'Non Network VAS Compatibility flag', 'Active','epcSys'),
('ext_api', 'stub_always_eligible', 'false', 'Stub for eligibilityCheck', 'Active','epcSys'),
('ext_api', 'esb_VASSubscriptiondetails_Url','http://10.10.23.191:7001/VASSubscriptiondetails/PS/VASSubscriptiondetailsPS?wsdl', 'URL for ESB Call', 'Active','epcSys'),
('ext_api', 'with_characteristic_ctg', 'nta-ProductCtg,GlobalCtg', 'with characteristic new value in ctg format', 'Active','epcSys'),
('ext_api', 'with_tariff_ctg', 'ta-TariffCtg', 'with tariff new value in ctg format', 'Active','epcSys'),
('ext_api', 'a2a_compatibility_flag', 'false', 'Default: false', 'Active','epcSys'),
('Transaction', 'Control', 'true','Type - LOV ( ''true'', ''false'' )
Default - true
Desc - If true, then all integration transactions are logged to database.', 'Active','epcSys'),
('Product', 'channels_applicable_for_channel_short_code', '', '','Active','epcSys'),
('Product', 'EDIT_CHILD_PRODUCT_FLAG', 'false', 'Type - LOV ( ''true'', ''false'' )
Default: false
Desc - If true, child product can be editable','Active','epcSys');