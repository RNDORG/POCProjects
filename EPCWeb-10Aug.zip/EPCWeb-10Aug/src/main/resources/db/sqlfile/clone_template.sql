INSERT INTO epc_notification_template ( template_name, template_type, source_system, mode_of_delivery, status, created_by) VALUES ('Retire_Product_NotificationTemplate','Clone Product','EPC','Email','Active','admin');
INSERT INTO epc_notification_template_detail ( notification_template_id, template_language, template_subject, template_body, status, created_by) VALUES 
((select notification_template_id from epc_notification_template where template_name='Retire_Product_NotificationTemplate' and template_type = 'Clone Product'),
'English','EPC- Need to Retire Product- <toRetireProducts>','Dear Concern,

Launched Product/Retired Product Info - 

  <toRetireProductDetails>

To proceed for the next steps, click the below link.
<linkAdrs>

Regards,
GP EPC','Active','admin');