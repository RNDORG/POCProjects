INSERT INTO epc_attribute_master
(attribute_id, attribute_ctg, attribute_ctg_type, attribute_name,
attribute_description,attribute_data_type,attribute_data_length,
is_visible,is_cfs,is_rfs,status,created_by,created_date,modified_by,modified_date)
VALUES   
(1, 'Product characteristic attributes', 
null, 
'reward points', 'reward points',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 'Product characteristic attributes', 
null, 
'MAX_FNF_COUNT', 'MAX_FNF_COUNT',
'Simple', 4, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 'Product characteristic attributes', 
null, 
'TM Code', 'TM Code',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 'Product characteristic attributes', 
null, 
'white-list_offer_count', 'white-list_offer_count',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(5, 'Product characteristic attributes', 
null, 
'black-list_offer_count', 'black-list_offer_count',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(6, 'Product characteristic attributes', 
null, 
'default-credit-limit', 'default-credit-limit',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(7, 'Tariff definition attribute', 
'One time charge', 
'First time Setup fee', 'First time Setup fee',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(8, 'Tariff definition attribute', 
'One time charge', 
'New Connection Fee', 'New Connection Fee',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(9, 'Tariff definition attribute', 
'One time charge', 
'Change IMSI fee', 'Change IMSI fee',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(10, 'Tariff definition attribute', 
'Recurring charge', 
'Monthly Charge', 'Monthly Charge',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(11, 'Tariff definition attribute', 
'Recurring charge', 
'Tax', 'Tax',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(12, 'Tariff definition attribute', 
'Usage charge', 
'Usage Tariff_ FnF', 'Usage Tariff_ FnF',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(13, 'Tariff definition attribute', 
'Usage charge', 
'Usage Tariff 1', 'Usage Tariff 1',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(14, 'Tariff definition attribute', 
'Other charge', 
'Other charge 1', 'Other charge 1',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(15, 'Tariff definition attribute', 
'Other charge', 
'Other charge 2', 'Other charge 2',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(16, 'Product characteristic attributes', 
null, 
'Service Class', 'Service Class',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(17, 'Product characteristic attributes', 
null, 
'Service Class ID', 'Service Class ID',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(18, 'Product characteristic attributes', 
null, 
'SOB Bits', 'SOB Bits',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(19, 'Product characteristic attributes', 
null, 
'Temp Block', 'Temp Block',
'Simple', 5, 
1,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()); 


INSERT INTO epc_product_network_tpl
(template_type, template_name,
access_service_id, access_service_name,access_service_description,
status, created_by,created_date,modified_by,modified_date)
VALUES
('Base Plan',
 'Temaplte1',
101,'AccessService101','AccessService101',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Base Plan',
 'Temaplte1',
102,'AccessService102','AccessService102',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Base Plan',
 'Temaplte1',
103,'AccessService103','AccessService103',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Base Plan',
 'Temaplte2',
201,'AccessService201','AccessService201',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Base Plan',
 'Temaplte2',
202,'AccessService202','AccessService202',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Network',
 'Temaplte3',
301,'AccessService301','AccessService301',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Network',
 'Temaplte3',
302,'AccessService302','AccessService302',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Network',
 'Temaplte4',
402,'AccessService402','AccessService402',
'Active','admin',current_timestamp(),'admin',current_timestamp());



INSERT INTO epc_notification_template
(notification_template_id, template_name, template_type,source_system,
mode_of_delivery, status, created_by,created_date,modified_by,modified_date)
VALUES
(1, 'Activation_BillShock_NotificationTemplate', 
'Product Level', 
'CIM',
'SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'Activation_BillShock_Unlimited_NotificationTemplate', 
'Product Level', 
'CIM',
'SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 'Activation_SocialPack _NotificationTemplate', 
'Product Level', 
'CIM',
'SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 'View_SocialPack_NotificationTemplate', 
'Product Level', 
'COMS',
'Email', 'Active', 'admin',current_timestamp(),'admin',current_timestamp());
/*(5, 'Product_Approval_NotificationTemplate', 
'Product Approval', 
'EPC',
'Email', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()); */


INSERT INTO epc_notification_template_detail
( notification_template_id ,  template_language ,  template_subject ,  template_body ,
status, created_by,created_date,modified_by,modified_date)
VALUES
(1, 'English', null, 'Activation_BillShock_NotificationTemplate', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'English', null, 'Activation_BillShock_Unlimited_NotificationTemplate', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 'English', null, 'Activation_SocialPack _NotificationTemplate', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 'English', 'View SocialPack Notification', 'View_SocialPack_NotificationTemplate', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
/*(5, 'English', 'Product Approval Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp()), */
(1, 'Bengali', null, 'Activation_BillShock_NotificationTemplate', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'Bengali', null, 'Activation_BillShock_Unlimited_NotificationTemplate', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 'Bengali', null, 'Activation_SocialPack _NotificationTemplate', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 'Bengali', 'View SocialPack Notification', 'View_SocialPack_NotificationTemplate', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp());
/*(5, 'Bengali', 'Product Approval Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 
 'Active', 'admin',current_timestamp(),'admin',current_timestamp()); */


update  epc_notification_template_detail set template_body= 'এই নমুনা বাংলা তথ্য' where notification_template_id = 1 and template_language='Bengali';
update  epc_notification_template_detail set template_body= 'অ্যাক্টিভেশন বিল শক আনলিমিটেড বিজ্ঞপ্তি টেমপ্লেট' where notification_template_id = 2 and template_language='Bengali';
update  epc_notification_template_detail set template_body= 'সক্রিয় সামাজিক প্যাক নোটিফিকেশন টেমপ্লেট' where notification_template_id = 3 and template_language='Bengali';
update  epc_notification_template_detail set template_body= 'দেখুন সামাজিক প্যাক নোটিফিকেশন টেমপ্লেট' where notification_template_id = 4 and template_language='Bengali';
update  epc_notification_template_detail set template_body= 'স্থানান্তরণ থেকে <1> থেকে <3> শর্ট <3> সঙ্গে পণ্যের জন্য সম্পন্ন. উপরন্তু দয়া করে এগিয়ে যান. কেশন টেমপ্লেট' where notification_template_id = 5 and template_language='Bengali';

update  epc_notification_template_detail set template_subject= 'দেখুন সামাজিক প্যাক নোটিফিকেশন টেমপ্লেট' where notification_template_id = 4 and template_language='Bengali';
update  epc_notification_template_detail set template_subject= 'পণ্যের অনুমোদন বিজ্ঞপ্তি' where notification_template_id = 5 and template_language='Bengali';


INSERT INTO epc_product_specification
(product_id, copied_from_product_id,
product_short_code,product_description,product_marketing_name,
downstream_system,
product_type,product_family,product_sub_family,product_classification,
product_category,product_sub_category,product_status,min_subscription,max_subscription,
product_quota,product_quota_uom,product_quota_duration,product_quota_duration_uom,product_association_level,
is_auto_renewal_allowed,is_mandatory_in_bundle,is_bundle,is_hybrid,api_indicator,
is_special_product,is_usage_product,is_discount_product,is_contract_product,is_template_product,
is_roaming_product,is_product_paused,is_uc_allowed,is_rc_allowed,is_otc_allowed,vsmd_component,created_by,created_date,modified_by,modified_date)
VALUES
(1, null,
'P-Postpaid-01','PoastPaid Test Product','Unlimited Postpaid',
'ESB',
'Primary',
'GSM',
'Data',
'RegularPack',
'Postpaid',
'Regular',
'Launch',1, 5, 
1000, 'Minutes',
1, 'Month',
'Customer',
1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 'YNNN','admin',current_timestamp(),'admin',current_timestamp()),
(2, null,
'P-Postpaid-02','PoastPaid Test Product','Limited Postpaid',
'COMS',
'Primary',
'GSM',
'Voice',
null,
'Postpaid',
'Regular',
'Approved',1, 5, 
100, 'Minutes',
1, 'Month',
'Customer',
1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 'YNNN','admin',current_timestamp(),'admin',current_timestamp()),
(3, null,
'P-Prepaid-03','PrePaid Test Product','Limited PrepaidData',
'ESB',
'Primary',
'GSM',
'Data',
'Volume Pack',
'Prepaid',
'Regular',
'Approved',1, 5, 
2, 'GB',
1, 'Day',
'Customer',
1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 'YYYY','admin',current_timestamp(),'admin',current_timestamp()),
(4, null,
'P-Postpaid-04','PrePaid Test Product','UnLimited Prepaid Data',
'ESB',
'Primary',
'GSM',
'Data',
'Volume',
'Postpaid',
'Regular',
'Draft',1, 5, 
100, 'GB',
1, 'Month',
'Customer',
1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 'YYYY','admin',current_timestamp(),'admin',current_timestamp()),
(5, null,
'P-MCA-01','Missed Call Alert (MCA)','Missed Call Alert (MCA)',
'ESB',
'Optional',
'GSM',
'VAS',
null,
'Prepaid',
'Regular',
'Launch',1, 1, 
null,null,
1,
'Month',
'Customer',
1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null,'admin',current_timestamp(),'admin',current_timestamp()),
(6, null,
'P-DSI-01','Daily International SMS Bundle Offer','Daily International SMS Bundle Offer',
'COMS',
'Optional',
'GSM',
'SMS',
null,
'Prepaid',
'Regular',
'Launch',1, 1, 
50,'NA',
1,
'Day',
'Customer',
1, 1, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null,'admin',current_timestamp(),'admin',current_timestamp()),
(7, null,
'P-RCP-01','Bondhu Rate Cutter','Bondhu Rate Cutter',
'COMS',
'Optional',
'GSM',
'Voice',
null,
'Prepaid',
'Regular',
'Launch',1, 1, 
null,null,
1,
'Month',
'Customer',
1, 1, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null,'admin',current_timestamp(),'admin',current_timestamp());




INSERT INTO epc_product_status_history
(product_id, product_status, reason, more_info, created_by,created_date)
VALUES
(1, 'Draft', null,null, 'admin',current_timestamp()),
(1, 'Submitted', null,null, 'admin',current_timestamp()),
(2, 'Draft', null,null, 'admin',current_timestamp()),
(2, 'Submitted', null,null, 'admin',current_timestamp()),
(2, 'Approved', null,null, 'admin',current_timestamp()),
(3, 'Draft', null,null, 'admin',current_timestamp()),
(3, 'Submitted', null,null, 'admin',current_timestamp()),
(3, 'Approved', null,null, 'admin',current_timestamp()),
(4, 'Draft', null,null, 'admin',current_timestamp()),
(5, 'Draft', null,null, 'admin',current_timestamp()),
(5, 'Submitted', null,null, 'admin',current_timestamp()),
(5, 'Approved', null,null, 'admin',current_timestamp()),
(5, 'Tested', null,null, 'admin',current_timestamp()),
(5, 'Approved by RAFM', null,null, 'admin',current_timestamp()),
(5, 'Approved by DM', null,null, 'admin',current_timestamp()),
(5, 'Launch', null,null, 'admin',current_timestamp()),
(6, 'Draft', null,null, 'admin',current_timestamp()),
(6, 'Submitted', null,null, 'admin',current_timestamp()),
(6, 'Approved', null,null, 'admin',current_timestamp()),
(6, 'Tested', null,null, 'admin',current_timestamp()),
(6, 'Approved by RAFM', null,null, 'admin',current_timestamp()),
(6, 'Approved by DM', null,null, 'admin',current_timestamp()),
(6, 'Launch', null,null, 'admin',current_timestamp()),
(7, 'Draft', null,null, 'admin',current_timestamp()),
(7, 'Submitted', null,null, 'admin',current_timestamp()),
(7, 'Approved', null,null, 'admin',current_timestamp()),
(7, 'Tested', null,null, 'admin',current_timestamp()),
(7, 'Approved by RAFM', null,null, 'admin',current_timestamp()),
(7, 'Approved by DM', null,null, 'admin',current_timestamp()),
(7, 'Launch', null,null, 'admin',current_timestamp());

INSERT INTO epc_product_attribute
(
product_id, attribute_id, attribute_value1, attribute_value2, attribute_uom,
default_value1, default_value2,
is_priceing_attribute, is_otc_attribute, is_child_product_attribute,
is_mandatory, status, created_by,created_date,modified_by,modified_date)
VALUES  
(1, 17, '11',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 18, '78',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 19, '91',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 1, '100',null, 'Minutes', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 2, '5',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 3, 'TMCode',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 4, '10',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 5, '5',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 6, '120.50',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 1, '50',null, 'Minutes', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 2, '10',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 3, 'TMCode1',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 4, '50',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 5, '10',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 6, '150.50',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 1, '25',null, 'Minutes', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 2, '5',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 3, 'p3a3',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 1, '45',null, 'Minutes', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 2, '1',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 3, 'p4a3',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 7, '100',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 8, '10',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 9, '20',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 10, '23.5',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 11, '56',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 12, '12',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 13, '24',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 7, '100',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 8, '10',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 9, '20',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 10, '23.5',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 11, '56',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 12, '12',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 13, '24',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 7, '100',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 8, '10',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 9, '20',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 10, '23.5',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 11, '56',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 12, '12',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 13, '24',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 7, '100',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 8, '10',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 9, '20',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 10, '23.5',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 11, '56',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 12, '12',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 13, '24',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 14, '34',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 15, '44',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 16, '5',null, 'NA', null,null, 0,0,0,0,'Active','admin',current_timestamp(),'admin',current_timestamp()); 


INSERT INTO epc_product_heirarchy
(parent_product_id, child_product_id, status, created_by,created_date,modified_by,modified_date)
VALUES
(1,5,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1,6,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1,7,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4,5,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4,6,'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4,7,'Active','admin',current_timestamp(),'admin',current_timestamp());


INSERT INTO epc_product_availability
(
product_id, life_validity_start_date, life_validity_end_date, launch_date,
selling_start_date, selling_end_date, subscription_start_date, subscription_end_date,
active_business_hour_from, active_business_hour_to, subscription_duration, subscription_duration_uom,
status, created_by,created_date,modified_by,modified_date)
VALUES
(1, '2016-07-01' , '2017-07-01', '2016-07-30',
'2016-08-05', '2016-08-30', '2016-08-10', '2016-09-10',
'09:00:01', '19:30:00', 1, 'Month', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, '2016-07-01' , '2017-07-01', '2016-07-30',
'2016-08-05', '2016-08-30', '2016-08-10', '2016-09-10',
'09:00:01', '19:30:00', 1, 'Month', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, '2016-08-10' , '2017-08-10', '2016-08-20',
'2016-08-15', '2016-08-30', '2016-08-17', '2016-09-17',
'09:00:01', '19:30:00', 1, 'Month', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, '2016-09-01' , '2017-09-01', '2016-09-30',
'2016-09-05', '2016-09-30', '2016-09-10', '2016-10-10',
'09:00:01', '19:30:00', 1, 'Month', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()); 

INSERT INTO epc_product_segment
(
product_id, segment_type, segment_value,
status,created_by,created_date,modified_by,modified_date)
VALUES
(1, 
'Customer Class',
'Gold', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(1, 
'Customer Class',
'Silver', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 
'Customer Class',
'Gold', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 
'Customer Class',
'Silver', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 
'Customer Type',
'Corporate Individual', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 
'Customer Type',
'Students', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 
'Customer Type',
'Students', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 
'Customer Type',
'Doctors', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 
'Customer Class',
'Gold', 'Active', 'admin',current_timestamp(),'admin',current_timestamp());


INSERT INTO epc_product_location
(
product_id,location_code_1,location_code_2,location_code_3,location_code_4, status,created_by,created_date,modified_by,modified_date)
VALUES
(1, 'BANGLADESH', 
    'Barisal', 'BARISAL METRO AREA', 
    'BHOLA SADAR TERRITORY', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
(1, 'BANGLADESH', 
    'Chittagong',null, null, 'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 'BANGLADESH', 
    'Rajshahi', null, null, 'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 'BANGLADESH', 
    'Comilla', 
    'COMILLA OUTER AREA', null, 'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 'BANGLADESH', 
    'Khulna', null, null, 'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 'BANGLADESH', 
    'Chittagong', null, null, 'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 'BANGLADESH', 
    'Barisal', 
    'BARISAL METRO AREA', 
    'BHOLA SADAR TERRITORY','Active','admin',current_timestamp(),'admin',current_timestamp());



INSERT INTO epc_product_init_channel
(
product_id, channel_id,
channel_level_market_name, channel_short_code, channel_level_product_id,
action_type, 
service_keyword, service_keyword_other, url_string, 
is_notification_required, notification_template_id, alias, status, created_by,created_date,modified_by,modified_date)
VALUES
(1, 'CRM',
'BrandNew Unlimited Postpaid','*123*23#', 'bup-1',
'Confirmation',
null, null, null, 
1, 1,null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(1, 'My GP (GP APP & E-care)',
'BrandNew Unlimited Postpaid','*124*23#', 'bup-1',
'Confirmation',
null, null, null, 
1, 1,null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(1, 'WOWBOX',
'BrandNew Unlimited Postpaid','*125*23#', 'bup-1',
'Confirmation',
null, null, null, 
1, 1,null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'CRM',
'BrandNew Unlimited Postpaid','*123*23#', 'bup-2',
'Confirmation',
null, null, null, 
1, 2,null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'My GP (GP APP & E-care)',
'BrandNew Unlimited Postpaid','*124*23#', 'bup-2',
'Confirmation',
null, null, null, 
1, 2,null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'WOWBOX',
'BrandNew Unlimited Postpaid','*125*23#', 'bup-2',
'Confirmation',
null, null, null, 
1, 2,null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 'CRM',
'BrandNew Unlimited Postpaid','*123*23#', 'bup-3',
'Confirmation',
null, null, null, 
1, 3,null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 'My GP (GP APP & E-care)',
'BrandNew Unlimited Postpaid','*124*23#', 'bup-3',
'Confirmation',
null, null, null, 
1, 3,null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 'My GP (GP APP & E-care)',
'BrandNew Unlimited Postpaid','*124*23#', 'bup-4',
'Confirmation',
null, null, null, 
1, 4,null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp());



INSERT INTO epc_product_sales_channel
(
product_id,partner_type,
partners_list,status, created_by,created_date,modified_by,modified_date)
VALUES
(1, 'IPC',
'Partner1, Partner2, Partner3', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(1, 'GPC',
'Partner1, Partner2, Partner3', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(1, 'GPCF',
'Partner1, Partner2, Partner3', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'GPCF',
'Partner4, Partner5, Partner6', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'GPC',
'Partner1, Partner2, Partner3', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 'GPCF',
'Partner4, Partner5, Partner6', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 'GPC',
'Partner1, Partner2, Partner3', 'Active', 'admin',current_timestamp(),'admin',current_timestamp());


INSERT INTO epc_product_network_tpl_map
(
product_id, template_name, status, created_by,created_date,modified_by,modified_date)
VALUES
(1, 'Temaplte1', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'Temaplte2', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 'Temaplte3', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 'Temaplte4', 'Active', 'admin',current_timestamp(),'admin',current_timestamp());


INSERT INTO epc_product_community
(
product_id,community_id,applicable_emp_band,community_name, discounted_price,slab_id,is_employee_allowed_to_purchase, status,created_by,created_date,modified_by,modified_date)
VALUES
(1, 92, 'Manager', 'Airtel Mobility', 10, 'Slab1', 0, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 1234, 'Manager', 'GrameenPhone', 10, 'Slab2', 0, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 1234, 'CEO', 'GrameenPhone', 100, 'Slab3', 0, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(3, 1333, 'Manager', 'Docomo Mobility', 10, 'Slab4', 1, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(4, 92, 'Manager', 'Vodafone Mobility', 10, 'Slab5', 0, 'Active', 'admin',current_timestamp(),'admin',current_timestamp());


INSERT INTO epc_product_compatibility
(product_id,other_product_id,inclusive_or_exclusive,status,created_by,created_date,modified_by,modified_date)
VALUES
(1,5, 'Inclusion','Active','admin',current_timestamp(),'admin',current_timestamp()),
(1,6, 'Inclusion','Active','admin',current_timestamp(),'admin',current_timestamp()),
(1,7, 'Inclusion','Active','admin',current_timestamp(),'admin',current_timestamp()),
(2,5, 'Inclusion','Active','admin',current_timestamp(),'admin',current_timestamp()),
(2,6, 'Inclusion','Active','admin',current_timestamp(),'admin',current_timestamp()),
(4,6, 'Inclusion','Active','admin',current_timestamp(),'admin',current_timestamp()),
(4,7, 'Inclusion','Active','admin',current_timestamp(),'admin',current_timestamp()),
(4,1, 'Inclusion','Active','admin',current_timestamp(),'admin',current_timestamp());  

INSERT INTO epc_product_migration
(source_category, source_product_id, target_category,target_product_id,
inclusive_or_exclusive,migration_remark,status,created_by,created_date,modified_by,modified_date)
VALUES
('Prepaid',null,
'Postpaid',null,
'Inclusion',null,'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Prepaid',null,
'Postpaid',null,
'Inclusion',null,'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Postpaid',4,
'Prepaid',5,
'Inclusion',null,'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Postpaid',4,
'Prepaid',7,
'Inclusion',null,'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Postpaid',4,
'Postpaid',1,
'Inclusion',null,'Active','admin',current_timestamp(),'admin',current_timestamp()); 


/*INSERT INTO epc_order_channel_rule
(order_channel_rule_id,order_type, sales_channel, initiating_channel, is_consent_required,
notification_template_id, is_future_date, currency, status,created_by,created_date,modified_by,modified_date)
VALUES
(1,'PREPAID_REGULAR_ACTIVATION', 'GPCF', 'CRM', 
0, 1,0, 'Bangladeshi Taka','Active','admin',current_timestamp(),'admin',current_timestamp()),
(2,'TINTIN_ACTIVATION', 'GPCF', 'CRM', 
0, 1,0, 'Bangladeshi Taka','Active','admin',current_timestamp(),'admin',current_timestamp()),
(3,'CHANGE_SIM', 'IPC', 'My GP (GP APP & E-care)', 
0, 1,0, 'Bangladeshi Taka','Active','admin',current_timestamp(),'admin',current_timestamp()),
(4,'CHANGE_SIM_TINTIN', 'GPCF', 'WOWBOX', 
0, 1,0, 'Bangladeshi Taka','Active','admin',current_timestamp(),'admin',current_timestamp());
*/
/*
INSERT INTO epc_order_charge
(order_channel_rule_id,order_charge_fee,occ_code,status,created_by,created_date,modified_by,modified_date)
VALUES
(1,  10.50, 'Change SIM fee','Active','admin',current_timestamp(),'admin',current_timestamp()),
(2,  20.50, 'New Connection Fee','Active','admin',current_timestamp(),'admin',current_timestamp()),
(3,  30.50, 'Change Billing Address Fee','Active','admin',current_timestamp(),'admin',current_timestamp()),
(4,  40.50, 'Migrate Product Fee','Active','admin',current_timestamp(),'admin',current_timestamp());
*/


/*INSERT INTO epc_product_decomposition(order_type,PRODUCT_SUB_FAMILY, PRODUCT_CLASSIFICATION,PRODUCT_SHORT_CODE, service_id_sequence,task,task_type,param_name,param_value,node_type,node_id,url_string,is_notification_required,notification_template_id,start_date,end_date,status,created_by,created_date,modified_by,modified_date)VALUES                
('PREPAID_REGULAR_ACTIVATION','Voice',null,null,'1','VALIDATE_MSISDN',NULL,null,null, 'RMS',null,null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_REGULAR_ACTIVATION','Data','Volume Pack',null,'2','ADD_MEMBER_TO_GROUP',NULL,null,null, 'DMS',null,null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_REGULAR_ACTIVATION','SMS','National',null,'3','UPDATE_ACCUMULATOR_FLAG',NULL,null,null, 'DMS',null,null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_REGULAR_ACTIVATION',null,null,'P-Postpaid-04','4','SUBSCRIBE_SERVICE','PROCESS',null,null, 'EC',null,null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_REGULAR_ACTIVATION',null,null,'P-Postpaid-02','5','NOTIFICATION','NOTIFY',null,null, 'CIM',null,null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_REGULAR_ACTIVATION',null,null,null,'6','UNSUBSCRIBE_SERVICE','PROCESS',null,null, 'VAS Server','Node_7',null,1,(select notification_template_id from epc_notification_template where template_name='Activation_BillShock_NotificationTemplate'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_REGULAR_ACTIVATION','VAS',null,null,'7','SUBSCRIBE_SERVICE','PROCESS',null,null, 'VAS Server','Node_8',null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_REGULAR_ACTIVATION','VAS',null,null,'8','ADD_MEMBER_TO_GROUP','PROCESS',null,null, 'VAS Server','Node_10',null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_CORPORATE_ACTIVATION',null,null,null,'1','CHANGE_SIM_ON_NE','PROCESS',null,null, 'HLR',null,null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_CORPORATE_ACTIVATION',null,null,null,'2','CHANGE_CUSTOMER_GROUP','PROCESS',null,null, 'EMA',null,null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_CORPORATE_ACTIVATION',null,null,null,'3','PUBLISH','PUBLISH',null,null, 'CBIO',null,null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp()),
('PREPAID_CORPORATE_ACTIVATION',null,null,null,'4','UNSUBSCRIBE_IR','PROCESS',null,null, 'COMS',null,null,1,(select notification_template_id from epc_notification_template where template_name='NotifLife1'),'2016-07-01', '2016-08-01', 'Active','admin',current_timestamp(),'admin',current_timestamp());
*/


INSERT INTO epc_trigger_order_rule(source_order_type, source_product_sub_family, source_product_classification, source_product_short_code,triggered_order_type, triggered_product_sub_family, triggered_product_classification, triggered_product_short_code,rule_validation_duration, rule_validation_duration_uom, subscription_within_duration, subscription_within_duration_uom,status, created_by,created_date,modified_by,modified_date)
VALUES	('PREPAID_REGULAR_ACTIVATION','Data','Social Pack',null,'CHANGE_SIM','Voice',null,null,1,'Week',1,'Month','Active','admin',current_timestamp(),'admin',current_timestamp()),
	('PREPAID_REGULAR_ACTIVATION',null,null,null,'POSTPAID_CORPORATE_ACTIVATION',null,null,'P-Postpaid-02',1, 'Month',2, 'Month','Active','admin',current_timestamp(),'admin',current_timestamp()),
	('PREPAID_CORPORATE_ACTIVATION',null,null,'P-Postpaid-04','TINTIN_ACTIVATION','Data','Social Pack',null,1, 'Month',1, 'Month','Active','admin',current_timestamp(),'admin',current_timestamp());



insert into epc_activity_master(
    activity_id ,    activity_name,    activity_description ,    status ,    created_by ,created_date , modified_by,    modified_date  )
values
(1, 'Call Details', null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'Data Info', null, 'Active', 'admin',current_timestamp(),'admin',current_timestamp());


insert into epc_activity_detail(
    activity_id	,    activity_key ,    activity_value ,    status ,    created_by ,created_date , modified_by,    modified_date  )
values
(1, 'Key1', 'Value1','Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(2, 'Key2', 'Value2','Active', 'admin',current_timestamp(),'admin',current_timestamp());


insert into epc_activity_channel_rule ( activity_channel_rule_id, activity_id ,sales_channel ,initiating_channel ,is_consent_required ,notification_template_id ,
    is_future_date, currency, status ,created_by ,created_date , modified_by,    modified_date  )
values
(1, 1, 'IPC', 'E-Commerce', 
 1, 1,0, 'Bangladeshi Taka','Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 2, 'GPCF', 'CRM', 
 1, 1,0, 'Bangladeshi Taka','Active','admin',current_timestamp(),'admin',current_timestamp());

insert into epc_activity_charge(activity_channel_rule_id,activity_charge_fee,occ_code,status,created_by,created_date,modified_by,modified_date)
VALUES
(1,  10.50,  'Change SIM fee','Active','admin',current_timestamp(),'admin',current_timestamp()),
(2,  20.50,  'Migrate Product Fee','Active','admin',current_timestamp(),'admin',current_timestamp());

INSERT INTO epc_product_provider_system
(product_id, 
provider_system_code,provider_product_id,provider_product_description,
status,created_by,created_date,modified_by,modified_date)
VALUES
(1, 
'CBIO',141,'Provider PoastPaid Test Product',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
(2, 
'SIVR',142,'Provider PoastPaid Test Product',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
(3, 
'CBIO',143,'Provider PrePaid Test Product',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
(4, 
'SIVR',144,'Provider PrePaid Test Product',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
(5, 
'CBIO',145,'Provider Missed Call Alert',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
(6, 
'SIVR',146,'Provider Daily International SMS',
'Active','admin',current_timestamp(),'admin',current_timestamp()),
(7, 
'CBIO',147,'Provider Bondhu Rate Cutter',
'Active','admin',current_timestamp(),'admin',current_timestamp());


INSERT INTO epc_product_migration
(source_category, source_product_id, target_category,target_product_id,migration_channel,
inclusive_or_exclusive,migration_remark,status,created_by,created_date,modified_by,modified_date)
VALUES
('Prepaid',null,
'Postpaid',null,'Omni',
'Inclusion',null,'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Prepaid',null,
'Postpaid',null,'Roaming',
'Inclusion',null,'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Postpaid',4,
'Prepaid',5,'CRM',
'Inclusion',null,'Active','admin',current_timestamp(),'admin',current_timestamp()),
('Postpaid',4,
'Prepaid',7,'CRM',
'Inclusion',null,'Active','admin',current_timestamp(),'admin',current_timestamp());

INSERT INTO epc_notification_template(notification_template_id, template_name, template_type,source_system,mode_of_delivery, status, created_by,created_date,modified_by,modified_date)VALUES
(100,'Product_Bundle_Voice_English','Product_Bundle_Voice','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(101,'Product_Data_RegularPack_English','Product_Data_RegularPack','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(102,'Product_Data_SocialPack_English','Product_Data_SocialPack','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(103,'Product_Data_BoosterPlan_English','Product_Data_BoosterPlan','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(104,'Product_Data_Bundle_English','Product_Data_Bundle','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(105,'Product_Data_Blackberry_English','Product_Data_Blackberry','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(106,'Product_Data_Emergency_English','Product_Data_Emergency','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(107,'Product_Data_Employee Data Pack_English','Product_Data_Employee Data Pack','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(108,'Product_Data_Others_English','Product_Data_Others','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(109,'Product_Data_Roaming_English','Product_Data_Roaming','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(110,'Product_Data_WiFi_English','Product_Data_WiFi','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(111,'Product_Data_Work Order_English','Product_Data_Work Order','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(112,'Product_Data_Wowbox_English','Product_Data_Wowbox','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(113,'Product_NA_NA_English','Product_NA_NA','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(114,'Product_SMS_SMS_English','Product_SMS_SMS','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(115,'Product_SMS_Roaming_English','Product_SMS_Roaming','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(116,'Product_Special_Tracker_English','Product_Special_Tracker','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(117,'Product_VAS_CRBT_English','Product_VAS_CRBT','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(118,'Product_VAS_Content service_English','Product_VAS_Content service','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(119,'Product_VAS_Music Radio_English','Product_VAS_Music Radio','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(120,'Product_VAS_GP-VAS_English','Product_VAS_GP-VAS','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(121,'Product_Voice_Bundle_English','Product_Voice_Bundle','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(122,'Product_Voice_Commitment and Discount_English','Product_Voice_Commitment and Discount','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(123,'Product_Voice_Tracker_English','Product_Voice_Tracker','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(124,'Product_Voice_Promotional_English','Product_Voice_Promotional','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(125,'Product_Voice_Roaming_English','Product_Voice_Roaming','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(126,'Product_Voice_Emergency_English','Product_Voice_Emergency','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(127,'Product_Voice_FnF_English','Product_Voice_FnF','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(128,'Product_Voice_Voice_English','Product_Voice_Voice','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(129,'Product_Voice_Rate cutter_English','Product_Voice_Rate cutter','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(130,'Product_Voice_Roaming_Bengali','Product_Voice_Roaming','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(131,'Product_Voice_Emergency_Bengali','Product_Voice_Emergency','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(132,'Product_Voice_FnF_Bengali','Product_Voice_FnF','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(133,'Product_Voice_Voice_Bengali','Product_Voice_Voice','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(134,'Product_Voice_Rate cutter_Bengali','Product_Voice_Rate cutter','CIM','SMS', 'Active', 'admin',current_timestamp(),'admin',current_timestamp());



INSERT INTO epc_notification_template_detail( notification_template_id ,  template_language ,  template_subject ,  template_body ,status, created_by,created_date,modified_by,modified_date)VALUES 
(100,'English','Product_Bundle_Voice Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(101,'English','Product_Data_RegularPack Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(102,'English','Product_Data_SocialPack Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(103,'English','Product_Data_BoosterPlan Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(104,'English','Product_Data_Bundle Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(105,'English','Product_Data_Blackberry Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(106,'English','Product_Data_Emergency Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(107,'English','Product_Data_Employee Data Pack Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(108,'English','Product_Data_Others Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(109,'English','Product_Data_Roaming Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(110,'English','Product_Data_WiFi Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(111,'English','Product_Data_Work Order Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(112,'English','Product_Data_Wowbox Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(113,'English','Product_NA_NA Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(114,'English','Product_SMS_SMS Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(115,'English','Product_SMS_Roaming Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(116,'English','Product_Special_Tracker Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(117,'English','Product_VAS_CRBT Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(118,'English','Product_VAS_Content service Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(119,'English','Product_VAS_Music Radio Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(120,'English','Product_VAS_GP-VAS Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(121,'English','Product_Voice_Bundle Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(122,'English','Product_Voice_Commitment and Discount Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(123,'English','Product_Voice_Tracker Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(124,'English','Product_Voice_Promotional Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(125,'English','Product_Voice_Roaming Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(126,'English','Product_Voice_Emergency Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(127,'English','Product_Voice_FnF Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(128,'English','Product_Voice_Voice Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(129,'English','Product_Voice_Rate cutter Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(130,'Bengali','Product_Voice_Roaming Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(131,'Bengali','Product_Voice_Emergency Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(132,'Bengali','Product_Voice_FnF Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(133,'Bengali','Product_Voice_Voice Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp()),
(134,'Bengali','Product_Voice_Rate cutter Notification','Transition from <fromState> to <toState> completed for products with Short Code <productShortCodes>. Please proceed Further.', 'Active', 'admin',current_timestamp(),'admin',current_timestamp());


update  epc_notification_template_detail set template_body= 'এই নমুনা বাংলা তথ্য' where notification_template_id = 130 and template_language='Bengali';
update  epc_notification_template_detail set template_body= 'অ্যাক্টিভেশন বিল শক আনলিমিটেড বিজ্ঞপ্তি টেমপ্লেট' where notification_template_id = 131 and template_language='Bengali';
update  epc_notification_template_detail set template_body= 'সক্রিয় সামাজিক প্যাক নোটিফিকেশন টেমপ্লেট' where notification_template_id = 132 and template_language='Bengali';
update  epc_notification_template_detail set template_body= 'দেখুন সামাজিক প্যাক নোটিফিকেশন টেমপ্লেট' where notification_template_id = 133 and template_language='Bengali';
update  epc_notification_template_detail set template_body= 'স্থানান্তরণ থেকে <1> থেকে <3> শর্ট <3> সঙ্গে পণ্যের জন্য সম্পন্ন. উপরন্তু দয়া করে এগিয়ে যান. কেশন টেমপ্লেট' where notification_template_id = 134 and template_language='Bengali';
update  epc_notification_template_detail set template_subject= 'পণ্যের অনুমোদন বিজ্ঞপ্তি' where template_language='Bengali';


insert into epc_flexi_plan(
FLEXI_PLAN_TYPE ,VALIDITY_IN_DAYS ,
DATA_RANGE_START,DATA_RANGE_END ,
VOICE_RANGE_START,VOICE_RANGE_END ,
SMS_RANGE_START,SMS_RANGE_END ,
PRICE ,STATUS ,CREATED_BY ,CREATED_DATE)
values 
	('SMS', 1,  0,0,  0,0, 0,10, 5, 'Active', 'admin', current_timestamp()),
    ('SMS', 1,  0,0,  0,0, 11,20, 6, 'Active', 'admin', current_timestamp()),
    ('SMS', 1,  0,0,  0,0, 21,30, 8, 'Active', 'admin', current_timestamp()),
    ('SMS', 1,  0,0,  0,0, 31,40, 9, 'Active', 'admin', current_timestamp()),
    ('SMS', 7,  0,0,  0,0, 0,10, 11, 'Active', 'admin', current_timestamp()),
    ('SMS', 7,  0,0,  0,0, 11,20, 15, 'Active', 'admin', current_timestamp()),
    ('SMS', 15,  0,0,  0,0, 0,10, 10, 'Active', 'admin', current_timestamp()),
    ('SMS', 15,  0,0,  0,0, 11,20, 17, 'Active', 'admin', current_timestamp()),
    ('SMS', 15,  0,0,  0,0, 21,30, 19, 'Active', 'admin', current_timestamp()),
    ('SMS', 30,  0,0,  0,0, 31,40, 17, 'Active', 'admin', current_timestamp()),
    ('SMS', 30,  0,0,  0,0, 41,50, 19, 'Active', 'admin', current_timestamp()),


	('Voice_Any_Net', 1,  0,10,  0,10, 0,0, 10, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 1,  0,10,  11,20, 0,0, 15, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 1,  0,10,  21,30, 0,0, 17, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 1,  0,10,  31,40, 0,0, 19, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 1,  0,10,  41,50, 0,0, 21, 'Active', 'admin', current_timestamp()),
	('Voice_Any_Net', 1,  11,20,  0,10, 0,0, 11, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 1,  11,20,  11,20, 0,0, 17, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 1,  11,20,  21,30, 0,0, 18, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 1,  21,30,  0,10, 0,0, 19, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 1,  21,30,  11,20, 0,0, 20, 'Active', 'admin', current_timestamp()),    
	('Voice_Any_Net', 7,  11,20,  0,10, 0,0, 15, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 7,  11,20,  11,20, 0,0, 17, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 7,  11,20,  21,30, 0,0, 19, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 15,  21,30,  0,10, 0,0, 21, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 15,  21,30,  11,20, 0,0, 22, 'Active', 'admin', current_timestamp()),    
	('Voice_Any_Net', 30,  11,20,  0,10, 0,0, 25, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 30,  11,20,  11,20, 0,0, 27, 'Active', 'admin', current_timestamp()),
    ('Voice_Any_Net', 30,  11,20,  21,30, 0,0, 28, 'Active', 'admin', current_timestamp()),

	('Voice_On_Net', 1,  0,10,  0,10, 0,0, 1, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 1,  0,10,  11,20, 0,0, 5, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 1,  0,10,  21,30, 0,0, 7, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 1,  0,10,  31,40, 0,0, 9, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 1,  0,10,  41,50, 0,0, 11, 'Active', 'admin', current_timestamp()),
	('Voice_On_Net', 1,  11,20,  0,10, 0,0, 1, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 1,  11,20,  11,20, 0,0, 5, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 1,  21,30,  21,30, 0,0, 7, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 1,  21,30,  0,10, 0,0, 9, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 1,  21,30,  11,20, 0,0, 11, 'Active', 'admin', current_timestamp()),        
	('Voice_On_Net', 7,  11,20,  0,10, 0,0, 17, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 7,  11,20,  11,20, 0,0, 19, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 7,  11,20,  21,30, 0,0, 21, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 15,  21,30,  0,10, 0,0, 22, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 15,  21,30,  11,20, 0,0, 23, 'Active', 'admin', current_timestamp()),    
	('Voice_On_Net', 30,  11,20,  0,10, 0,0, 25, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 30,  11,20,  11,20, 0,0, 28, 'Active', 'admin', current_timestamp()),
    ('Voice_On_Net', 30,  11,20,  21,30, 0,0, 29, 'Active', 'admin', current_timestamp()),

    
	('Data', 1,  0,10,  0,10, 0,0, 0.1, 'Active', 'admin', current_timestamp()),
    ('Data', 1,  0,10,  11,20, 0,0, 0.5, 'Active', 'admin', current_timestamp()),
    ('Data', 1,  0,10,  21,30, 0,0, 0.7, 'Active', 'admin', current_timestamp()),
    ('Data', 1,  0,10,  31,40, 0,0, 0.9, 'Active', 'admin', current_timestamp()),
    ('Data', 1,  0,10,  41,50, 0,0, 1.1, 'Active', 'admin', current_timestamp()),
	('Data', 1,  11,20,  0,10, 0,0, 1.2, 'Active', 'admin', current_timestamp()),
    ('Data', 1,  11,20,  11,20, 0,0, 1.5, 'Active', 'admin', current_timestamp()),
    ('Data', 1,  21,30,  21,30, 0,0, 1.7, 'Active', 'admin', current_timestamp()),
    ('Data', 1,  21,30,  0,10, 0,0, 1.9, 'Active', 'admin', current_timestamp()),
    ('Data', 1,  21,30,  11,20, 0,0, 2.1, 'Active', 'admin', current_timestamp()),            

	('Data', 7,  0,10,  0,10, 0,0, 0.2, 'Active', 'admin', current_timestamp()),
    ('Data', 7,  0,10,  11,20, 0,0, 0.6, 'Active', 'admin', current_timestamp()),
    ('Data', 7,  0,10,  21,30, 0,0, 0.8, 'Active', 'admin', current_timestamp()),
    ('Data', 15,  0,10,  31,40, 0,0, 0.9, 'Active', 'admin', current_timestamp()),
    ('Data', 15,  0,10,  41,50, 0,0, 1.12, 'Active', 'admin', current_timestamp()),
	('Data', 15,  11,20,  0,10, 0,0, 1.12, 'Active', 'admin', current_timestamp()),
    ('Data', 30,  11,20,  11,20, 0,0, 1.15, 'Active', 'admin', current_timestamp()),
    ('Data', 30,  21,30,  21,30, 0,0, 1.17, 'Active', 'admin', current_timestamp()),
    ('Data', 30,  21,30,  0,10, 0,0, 1.19, 'Active', 'admin', current_timestamp()),
    ('Data', 30,  21,30,  11,20, 0,0, 2.21, 'Active', 'admin', current_timestamp());