delete from config where config_group='CustomConfig' and config_key like 'Custom%';

INSERT INTO config (config_group, config_key, config_value,description,status,created_by) VALUES
('Authentication', 'AuthenticationType', 'CUSTOM', 'Type - LOV(JDBC_BASIC,CUSTOM,LDAP,JDBC_CUSTOM)
Default - CUSTOM
Desc - Specifies spring security authentication mechanism. Changes to this value reflects after server restart.
Can be further fine tuned via CustomType key, if value is set as CUSTOM.', 'Active','epcSys'),
('LDAPConfig', 'contextSource', 'ldap://localhost:389/dc=maxcrc,dc=com', 'Specifies the server ip and port.', 'Active','epcSys'),
('LDAPConfig', 'managerDn', 'cn=Manager,dc=maxcrc,dc=com', 'Specifies the ManagerDn/username.', 'Active','epcSys'),              
('LDAPConfig', 'managerPassword', 'secret', 'Specifies the password for authentication.', 'Active','epcSys'),                   
('LDAPConfig', 'userSearchFilter', '(uid={0})', 'Specifies the search criteria.', 'Active','epcSys'),
('CustomConfig', 'CustomType', 'CUSTOM_JDBC', 'CUSTOM_LDAP / CUSTOM_JDBC', 'Active','epcSys'),              
('CustomConfig', 'CustomLDAP_SecurityAuthentication', 'simple', 'default value is simple', 'Active','epcSys'),
('CustomConfig', 'CustomLDAP_Domain', 'grameenphone.com', 'ldap domain', 'Active','epcSys'),              
('CustomConfig', 'CustomLDAP_URL', 'ldap://10.10.16.143:389 ldap://10.10.16.142:389', 'multiple ldap url can be passed. Automatically it will choose the best one', 'Active','epcSys'),                     
('CustomConfig', 'CustomLDAP_Timeout', '1000', 'ldap url connection time out in milliSecs', 'Active','epcSys');
