package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmSupplierAddress;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="ESM_SUPPLIER_ADDRESS")
public class EsmSupplierAddressTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="org_id")
  private String                    org_id;
  @Column(name="supplier_id")
  private String                 supplier_id;
  @Column(name="address_type")
  private String                 address_type;
  @Column(name="address_field_seq")
  private int                address_field_seq;
  @Column(name="address_ctg")
  private String                 address_ctg;
  @Column(name="address_field_name")
  private String              address_field_name;
  @Column(name="address_field_value")
  private String             address_field_value;
  @Column(name="expiration_date")
  private String               expiration_date;
  @Column(name="effective_date")
  private String                effective_date;



  public String getorg_id()                           { return org_id; }
  public String getsupplier_id()                        { return supplier_id; }
  public String getaddress_type()                        { return address_type; }
  public int getaddress_field_seq()                       { return address_field_seq; }
  public String getaddress_ctg()                        { return address_ctg; }
  public String getaddress_field_name()                     { return address_field_name; }
  public String getaddress_field_value()                    { return address_field_value; }
  public String getexpiration_date()                      { return expiration_date; }
  public String geteffective_date()                       { return effective_date; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setsupplier_id(String supplier_id )               { this.supplier_id = supplier_id; }
  public void  setaddress_type(String address_type )              { this.address_type = address_type; }
  public void  setaddress_field_seq(int address_field_seq )           { this.address_field_seq = address_field_seq; }
  public void  setaddress_ctg(String address_ctg )               { this.address_ctg = address_ctg; }
  public void  setaddress_field_name(String address_field_name )        { this.address_field_name = address_field_name; }
  public void  setaddress_field_value(String address_field_value )       { this.address_field_value = address_field_value; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
}