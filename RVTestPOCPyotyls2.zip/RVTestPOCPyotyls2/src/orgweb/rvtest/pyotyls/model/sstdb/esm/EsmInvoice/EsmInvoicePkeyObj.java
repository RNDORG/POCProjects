package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmInvoice;


public class EsmInvoicePkeyObj
{
  public String                                 invoice_num;
}