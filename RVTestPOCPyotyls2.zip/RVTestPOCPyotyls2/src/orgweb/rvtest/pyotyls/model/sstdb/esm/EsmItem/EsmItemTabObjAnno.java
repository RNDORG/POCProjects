package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="ESM_ITEM")
@IdClass(EsmItemPkeyObj.class)
public class EsmItemTabObjAnno implements Serializable
{
	
  private static final long serialVersionUID = 1L;

  @Transient
  private String                                 tab_rowid;
  @Id
  @Column(name="org_id")
  private String                    org_id;
  @Id
  @Column(name="item_code")
  private String                  item_code;
  @Column(name="group_0")
  private String                   group_0;
  @Column(name="group_1")
  private String                   group_1;
  @Column(name="group_2")
  private String                   group_2;
  @Column(name="group_3")
  private String                   group_3;
  @Column(name="group_4")
  private String                   group_4;
  @Column(name="group_5")
  private String                   group_5;
  @Column(name="group_6")
  private String                   group_6;
  @Column(name="size_uom")
  private String                   size_uom;
  @Column(name="l")
  private String                      l;
  @Column(name="w")
  private String                      w;
  @Column(name="h")
  private String                      h;
  @Column(name="related_item_code")
  private String              related_item_code;
  @Column(name="accessory_flag")
  private String                accessory_flag;
  @Column(name="tax_flag")
  private String                   tax_flag;
  @Column(name="tax_percent")
  private float                  tax_percent;
  @Column(name="item_type")
  private String                  item_type;
  @Column(name="item_desc")
  private String                  item_desc;
  @Column(name="item_desc_cust")
  private String                item_desc_cust;
  @Column(name="item_part_num")
  private String                item_part_num;
  @Column(name="uom_per_qty")
  private String                 uom_per_qty;
  @Column(name="weight_per_qty")
  private int                 weight_per_qty;
  @Column(name="chees_pcs")
  private int                    chees_pcs;
  @Column(name="finish_pcs")
  private int                   finish_pcs;
  @Column(name="min_stock_qty")
  private int                  min_stock_qty;
  @Column(name="item_seq_num")
  private int                  item_seq_num;



  public String getorg_id()                           { return org_id; }
  public String getitem_code()                         { return item_code; }
  public String getgroup_0()                          { return group_0; }
  public String getgroup_1()                          { return group_1; }
  public String getgroup_2()                          { return group_2; }
  public String getgroup_3()                          { return group_3; }
  public String getgroup_4()                          { return group_4; }
  public String getgroup_5()                          { return group_5; }
  public String getgroup_6()                          { return group_6; }
  public String getsize_uom()                          { return size_uom; }
  public String getl()                             { return l; }
  public String getw()                             { return w; }
  public String geth()                             { return h; }
  public String getrelated_item_code()                     { return related_item_code; }
  public String getaccessory_flag()                       { return accessory_flag; }
  public String gettax_flag()                          { return tax_flag; }
  public float gettax_percent()                         { return tax_percent; }
  public String getitem_type()                         { return item_type; }
  public String getitem_desc()                         { return item_desc; }
  public String getitem_desc_cust()                       { return item_desc_cust; }
  public String getitem_part_num()                       { return item_part_num; }
  public String getuom_per_qty()                        { return uom_per_qty; }
  public int getweight_per_qty()                        { return weight_per_qty; }
  public int getchees_pcs()                           { return chees_pcs; }
  public int getfinish_pcs()                          { return finish_pcs; }
  public int getmin_stock_qty()                         { return min_stock_qty; }
  public int getitem_seq_num()                         { return item_seq_num; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setitem_code(String item_code )                 { this.item_code = item_code; }
  public void  setgroup_0(String group_0 )                   { this.group_0 = group_0; }
  public void  setgroup_1(String group_1 )                   { this.group_1 = group_1; }
  public void  setgroup_2(String group_2 )                   { this.group_2 = group_2; }
  public void  setgroup_3(String group_3 )                   { this.group_3 = group_3; }
  public void  setgroup_4(String group_4 )                   { this.group_4 = group_4; }
  public void  setgroup_5(String group_5 )                   { this.group_5 = group_5; }
  public void  setgroup_6(String group_6 )                   { this.group_6 = group_6; }
  public void  setsize_uom(String size_uom )                  { this.size_uom = size_uom; }
  public void  setl(String l )                         { this.l = l; }
  public void  setw(String w )                         { this.w = w; }
  public void  seth(String h )                         { this.h = h; }
  public void  setrelated_item_code(String related_item_code )         { this.related_item_code = related_item_code; }
  public void  setaccessory_flag(String accessory_flag )            { this.accessory_flag = accessory_flag; }
  public void  settax_flag(String tax_flag )                  { this.tax_flag = tax_flag; }
  public void  settax_percent(float tax_percent )                { this.tax_percent = tax_percent; }
  public void  setitem_type(String item_type )                 { this.item_type = item_type; }
  public void  setitem_desc(String item_desc )                 { this.item_desc = item_desc; }
  public void  setitem_desc_cust(String item_desc_cust )            { this.item_desc_cust = item_desc_cust; }
  public void  setitem_part_num(String item_part_num )             { this.item_part_num = item_part_num; }
  public void  setuom_per_qty(String uom_per_qty )               { this.uom_per_qty = uom_per_qty; }
  public void  setweight_per_qty(int weight_per_qty )              { this.weight_per_qty = weight_per_qty; }
  public void  setchees_pcs(int chees_pcs )                   { this.chees_pcs = chees_pcs; }
  public void  setfinish_pcs(int finish_pcs )                  { this.finish_pcs = finish_pcs; }
  public void  setmin_stock_qty(int min_stock_qty )               { this.min_stock_qty = min_stock_qty; }
  public void  setitem_seq_num(int item_seq_num )                { this.item_seq_num = item_seq_num; }
}