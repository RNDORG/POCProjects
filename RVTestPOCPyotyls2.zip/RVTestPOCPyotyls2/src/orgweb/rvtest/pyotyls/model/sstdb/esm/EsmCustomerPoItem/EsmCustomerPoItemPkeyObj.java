package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPoItem;


public class EsmCustomerPoItemPkeyObj
{
  public String                                 oa_num;
  public String                                 item_code;
  public String                                 make_id;
}