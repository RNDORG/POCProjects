package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPoIaddr;


public class EsmCustomerPoIaddrPkeyObj
{
  public String                                 oa_num;
  public String                                 item_code;
  public String                                 make_id;
}