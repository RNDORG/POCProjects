package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem;

import java.io.Serializable;

public class EsmItemPkeyObj implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String                                 org_id;
	public String                                 item_code;

	public EsmItemPkeyObj() {}

	public EsmItemPkeyObj(String orgId, String itemCode) {
		// TODO Auto-generated constructor stub
		this.org_id = orgId;
		this.item_code = itemCode;
	}

}