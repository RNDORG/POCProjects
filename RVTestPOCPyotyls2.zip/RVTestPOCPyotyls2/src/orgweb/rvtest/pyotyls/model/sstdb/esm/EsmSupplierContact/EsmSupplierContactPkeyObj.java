package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmSupplierContact;


public class EsmSupplierContactPkeyObj
{
  public String                                 org_id;
  public String                                 supplier_id;
  public String                                 contact_person;
  public String                                 contact_num;
}