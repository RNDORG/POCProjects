package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerAddress;


public class EsmCustomerAddressPkeyObj
{
  public String                                 org_id;
  public String                                 customer_id;
  public String                                 address_type;
  public int                                  address_field_seq;
}