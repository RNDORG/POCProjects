package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;

public class EsmItemPkeyObj2 implements Serializable {

  private static final long serialVersionUID = 1L;
  
  @Column(name = "org_id")
  public String                                 org_id;
  
  @Column(name = "item_code")
  public String                                 item_code;
  
  public EsmItemPkeyObj2() {
  }

  public EsmItemPkeyObj2( String org_id, String item_code) {
	  this.org_id = org_id;
	  this.item_code = item_code;
  }

  public String getOrg_id() {	return org_id;}
  public String getItem_code() { return item_code;}

  //public void setItem_code(String item_code) { this.item_code = item_code;}
  //public void setOrg_id(String org_id) {	this.org_id = org_id;}

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof EsmItemPkeyObj2)) return false;
    EsmItemPkeyObj2 that = (EsmItemPkeyObj2) o;
    return Objects.equals(getOrg_id(), that.getOrg_id()) &&
            Objects.equals(getItem_code(), that.getItem_code());
  }

  @Override
  public int hashCode() {
	  return Objects.hash(getOrg_id(), getItem_code());
  }

}