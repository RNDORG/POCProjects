package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItemRate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="ESM_ITEM_RATE")
public class EsmItemRateTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="item_code")
  private String                  item_code;
  @Column(name="make_id")
  private String                   make_id;
  @Column(name="source_id")
  private String                  source_id;
  @Column(name="size_factor")
  private float                  size_factor;
  @Column(name="production_cost")
  private double               production_cost;
  @Column(name="domestic_sale_cost")
  private double              domestic_sale_cost;
  @Column(name="export_sale_cost")
  private double               export_sale_cost;
  @Column(name="domestic_buy_rate")
  private double              domestic_buy_rate;
  @Column(name="import_buy_rate")
  private double               import_buy_rate;
  @Column(name="make_rate")
  private double                  make_rate;
  @Column(name="effective_date")
  private String                effective_date;
  @Column(name="expiration_date")
  private String               expiration_date;



  public String getitem_code()                         { return item_code; }
  public String getmake_id()                          { return make_id; }
  public String getsource_id()                         { return source_id; }
  public float getsize_factor()                         { return size_factor; }
  public double getproduction_cost()                      { return production_cost; }
  public double getdomestic_sale_cost()                     { return domestic_sale_cost; }
  public double getexport_sale_cost()                      { return export_sale_cost; }
  public double getdomestic_buy_rate()                     { return domestic_buy_rate; }
  public double getimport_buy_rate()                      { return import_buy_rate; }
  public double getmake_rate()                         { return make_rate; }
  public String geteffective_date()                       { return effective_date; }
  public String getexpiration_date()                      { return expiration_date; }



  public void  setitem_code(String item_code )                 { this.item_code = item_code; }
  public void  setmake_id(String make_id )                   { this.make_id = make_id; }
  public void  setsource_id(String source_id )                 { this.source_id = source_id; }
  public void  setsize_factor(float size_factor )                { this.size_factor = size_factor; }
  public void  setproduction_cost(double production_cost )           { this.production_cost = production_cost; }
  public void  setdomestic_sale_cost(double domestic_sale_cost )        { this.domestic_sale_cost = domestic_sale_cost; }
  public void  setexport_sale_cost(double export_sale_cost )          { this.export_sale_cost = export_sale_cost; }
  public void  setdomestic_buy_rate(double domestic_buy_rate )         { this.domestic_buy_rate = domestic_buy_rate; }
  public void  setimport_buy_rate(double import_buy_rate )           { this.import_buy_rate = import_buy_rate; }
  public void  setmake_rate(double make_rate )                 { this.make_rate = make_rate; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
}