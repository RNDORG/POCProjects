package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmSupplierAddress;


public class EsmSupplierAddressPkeyObj
{
  public String                                 org_id;
  public String                                 supplier_id;
  public String                                 address_type;
  public int                                  address_field_seq;
}