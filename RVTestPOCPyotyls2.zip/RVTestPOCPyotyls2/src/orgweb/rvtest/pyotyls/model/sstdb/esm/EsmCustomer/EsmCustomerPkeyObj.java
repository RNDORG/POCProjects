package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer;

import java.io.Serializable;

public class EsmCustomerPkeyObj implements Serializable {
	
  private static final long serialVersionUID = 1L;

  public String                                 org_id;
  public Long                                   customer_id;
  
  public EsmCustomerPkeyObj() {}

  public EsmCustomerPkeyObj(String orgId, Long customerId) {
	// TODO Auto-generated constructor stub
	this.org_id = orgId;
	this.customer_id = customerId;
  }

}