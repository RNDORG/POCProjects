package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPoItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ESM_CUSTOMER_PO_ITEM")
public class EsmCustomerPoItemTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="oa_num")
  private String                    oa_num;
  @Column(name="item_code")
  private String                  item_code;
  @Column(name="make_id")
  private String                   make_id;
  @Column(name="qty")
  private int                       qty;
  @Column(name="rate")
  private double                     rate;
  @Column(name="delivery_date")
  private String                delivery_date;
  @Column(name="delivery_address_type")
  private String            delivery_address_type;
  @Column(name="destination_id")
  private String                destination_id;
  @Column(name="discount_percent")
  private float               discount_percent;
  @Column(name="discount_fix")
  private int                  discount_fix;
  @Column(name="status")
  private String                    status;
  @Column(name="qty_supplied")
  private int                  qty_supplied;
  @Column(name="qty_canceled")
  private int                  qty_canceled;
  @Column(name="cancel_date")
  private String                 cancel_date;
  @Column(name="cancel_remark")
  private String                cancel_remark;
  @Column(name="qty_rejected")
  private int                  qty_rejected;
  @Column(name="reject_date")
  private String                 reject_date;
  @Column(name="reject_remark")
  private String                reject_remark;
  @Column(name="qty_reverted")
  private int                  qty_reverted;
  @Column(name="revert_date")
  private String                 revert_date;
  @Column(name="revert_remark")
  private String                revert_remark;



  public String getoa_num()                           { return oa_num; }
  public String getitem_code()                         { return item_code; }
  public String getmake_id()                          { return make_id; }
  public int getqty()                              { return qty; }
  public double getrate()                            { return rate; }
  public String getdelivery_date()                       { return delivery_date; }
  public String getdelivery_address_type()                   { return delivery_address_type; }
  public String getdestination_id()                       { return destination_id; }
  public float getdiscount_percent()                      { return discount_percent; }
  public int getdiscount_fix()                         { return discount_fix; }
  public String getstatus()                           { return status; }
  public int getqty_supplied()                         { return qty_supplied; }
  public int getqty_canceled()                         { return qty_canceled; }
  public String getcancel_date()                        { return cancel_date; }
  public String getcancel_remark()                       { return cancel_remark; }
  public int getqty_rejected()                         { return qty_rejected; }
  public String getreject_date()                        { return reject_date; }
  public String getreject_remark()                       { return reject_remark; }
  public int getqty_reverted()                         { return qty_reverted; }
  public String getrevert_date()                        { return revert_date; }
  public String getrevert_remark()                       { return revert_remark; }



  public void  setoa_num(String oa_num )                    { this.oa_num = oa_num; }
  public void  setitem_code(String item_code )                 { this.item_code = item_code; }
  public void  setmake_id(String make_id )                   { this.make_id = make_id; }
  public void  setqty(int qty )                         { this.qty = qty; }
  public void  setrate(double rate )                      { this.rate = rate; }
  public void  setdelivery_date(String delivery_date )             { this.delivery_date = delivery_date; }
  public void  setdelivery_address_type(String delivery_address_type )     { this.delivery_address_type = delivery_address_type; }
  public void  setdestination_id(String destination_id )            { this.destination_id = destination_id; }
  public void  setdiscount_percent(float discount_percent )           { this.discount_percent = discount_percent; }
  public void  setdiscount_fix(int discount_fix )                { this.discount_fix = discount_fix; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setqty_supplied(int qty_supplied )                { this.qty_supplied = qty_supplied; }
  public void  setqty_canceled(int qty_canceled )                { this.qty_canceled = qty_canceled; }
  public void  setcancel_date(String cancel_date )               { this.cancel_date = cancel_date; }
  public void  setcancel_remark(String cancel_remark )             { this.cancel_remark = cancel_remark; }
  public void  setqty_rejected(int qty_rejected )                { this.qty_rejected = qty_rejected; }
  public void  setreject_date(String reject_date )               { this.reject_date = reject_date; }
  public void  setreject_remark(String reject_remark )             { this.reject_remark = reject_remark; }
  public void  setqty_reverted(int qty_reverted )                { this.qty_reverted = qty_reverted; }
  public void  setrevert_date(String revert_date )               { this.revert_date = revert_date; }
  public void  setrevert_remark(String revert_remark )             { this.revert_remark = revert_remark; }
}