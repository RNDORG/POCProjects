package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerContact;


public class EsmCustomerContactPkeyObj
{
  public String                                 org_id;
  public String                                 customer_id;
  public String                                 contact_person;
  public String                                 contact_num;
}