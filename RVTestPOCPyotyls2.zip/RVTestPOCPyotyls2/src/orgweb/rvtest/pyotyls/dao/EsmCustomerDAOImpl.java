package orgweb.rvtest.pyotyls.dao;

import java.util.List;

//import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer.*;

@Repository("esmCustomerDAO")
public class EsmCustomerDAOImpl implements EsmCustomerDAOIFace {

	private static final Logger logger = Logger.getLogger(EsmCustomerDAOImpl.class);

	private String ESM_CUSTOMER_INSERT_SAVE_CUSTOMER_REGISTER 
	= "INSERT INTO ESM_CUSTOMER (ORG_ID, CUSTOMER_ID, CUSTOMER_NAME, STATE_CODE, REGION_ID, COUNTRY_CODE "
	+ " , STATUS, EFFECTIVE_DATE, ADDRESS_1, ADDRESS_2, ADDRESS_3, EMAIL_ID, MOBILE_NUM, PSWD_0 ) "
	+ "VALUES (:orgId, :customerId, :customerName, :stateCode, :regionId, :countryCode "
	+ " , :status, :effectiveDate, :address1, :address2, :address3, :emailId, :mobileNum, :pswd0) ";

	private String ESM_CUSTOMER_UPDATE_SAVE_MANAGE_CUSTOMER_PROFILE 
	= "UPDATE ESM_CUSTOMER SET CUSTOMER_NAME = :customerName "
	+ ", STATE_CODE = :stateCode, REGION_ID = :regionId, COUNTRY_CODE = :countryCode "
	+ ", ADDRESS_1 = :address1, ADDRESS_2 = :address2, ADDRESS_3 = :address3 "
	+ ", EMAIL_ID = :emailId, MOBILE_NUM = :mobileNum "
	+ " WHERE ORG_ID = :orgId AND CUSTOMER_ID = :customerId ";
	
	private String ESM_CUSTOMER_QUERY_AUTHENTICATE 
    = "SELECT * FROM ESM_CUSTOMER "
	+ " WHERE ORG_ID = :orgId "
    + " AND MOBILE_NUM = :mobileNum "
    + " AND PSWD_0 = :pswd0 ";

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<EsmCustomerTabObjAnno> getList() {
		logger.info("getList : starts");
		EsmCustomerTabObjAnno esmCustomerTabObjAnno = new EsmCustomerTabObjAnno();
		return (List<EsmCustomerTabObjAnno>) sessionFactory.getCurrentSession().createCriteria(esmCustomerTabObjAnno.getClass()).list();
	}

	@Override
	public EsmCustomerTabObjAnno get(String orgId, Long customerId) {
		logger.info("get : starts");
		logger.info("get : ORG_ID = "+orgId+" AND CUSTOMER_ID="+customerId);
		return (EsmCustomerTabObjAnno) sessionFactory.getCurrentSession().get(EsmCustomerTabObjAnno.class, new EsmCustomerPkeyObj (orgId, customerId));
	}

	@Override
	public EsmCustomerTabObjAnno create(EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("create : starts");
		sessionFactory.getCurrentSession().saveOrUpdate(esmCustomerTabObjAnno);
		return esmCustomerTabObjAnno;
	}

	@Override
	public EsmCustomerTabObjAnno createOrEdit(EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("createOrEdit : starts");
		sessionFactory.getCurrentSession().saveOrUpdate(esmCustomerTabObjAnno);
		return esmCustomerTabObjAnno;
	}
	
	@Override
	public Long delete(String orgId, Long customerId) {
		logger.info("delete : starts");
		logger.info("delete : delete-query : "+"DELETE FROM ESM_CUSTOMER WHERE ORG_ID = '"+orgId+"' AND CUSTOMER_ID='"+customerId+"'");
		//sessionFactory.getCurrentSession().createQuery("DELETE FROM ESM_CUSTOMER WHERE ORG_ID = '"+orgId+"' AND CUSTOMER_ID='"+customerId+"'").executeUpdate();
		sessionFactory.getCurrentSession().createQuery("DELETE FROM EsmCustomerTabObjAnno WHERE ORG_ID = '"+orgId+"' AND CUSTOMER_ID='"+customerId+"'").executeUpdate();
		return customerId;
	}

	public Long getNextVal( String sequenceName ) {
		logger.info("getNextVal : starts");
		
		//================================================================
//		sessionFactory.getCurrentSession().createQuery("SELECT NEXTVAL('esm_customer_customer_id_seq') as seq").executeUpdate();
        //Session session = sessionFactory.openSession();
		//session.beginTransaction();
		//String sequenceName1 = "esm_customer_customer_id_seq";
		//================================================================

		//================================================================
//		Query query = (Query) sessionFactory.getCurrentSession().createQuery("SELECT NEXTVAL('"+sequenceName+"') as seq_val");
//		Integer nextVal = (Integer) (query).getSingleResult();
//		logger.info("getNextVal : ends "+nextVal.toString());
//		return nextVal;
		//================================================================
		Long random = (Double.valueOf(Math.random()*100000).longValue());
		Long millis = System.currentTimeMillis();
		logger.info("getNextVal : end : millis-random "+millis+"-"+random);
		return Long.valueOf(millis+""+random);
	}
	
	
	@Override
	public EsmCustomerTabObjAnno executeNativeSQL(EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("executeNativeSQL : starts");
		try {
	        Session session = sessionFactory.openSession();
			session.beginTransaction();
			logger.info("executeNativeSQL : before createQuery "+ESM_CUSTOMER_INSERT_SAVE_CUSTOMER_REGISTER);
			sessionFactory.getCurrentSession().createSQLQuery(ESM_CUSTOMER_INSERT_SAVE_CUSTOMER_REGISTER)
			.addEntity(EsmCustomerTabObjAnno.class)
			.setParameter("orgId", esmCustomerTabObjAnno.getorg_id())
			//TODO: sequence name in configuration
			.setParameter("customerId", getNextVal("esm_customer_customer_id_seq"))
			.setParameter("customerName", esmCustomerTabObjAnno.getcustomer_name())
			.setParameter("stateCode", esmCustomerTabObjAnno.getstate_code())
			.setParameter("regionId", esmCustomerTabObjAnno.getregion_id())
			.setParameter("countryCode", esmCustomerTabObjAnno.getcountry_code())
			.setParameter("status", esmCustomerTabObjAnno.getstatus())
			.setParameter("effectiveDate", esmCustomerTabObjAnno.geteffective_date())
			.setParameter("address1", esmCustomerTabObjAnno.getaddress_1())
			.setParameter("address2", esmCustomerTabObjAnno.getaddress_2())
			.setParameter("address3", esmCustomerTabObjAnno.getaddress_3())
			.setParameter("emailId", esmCustomerTabObjAnno.getemail_id())
			.setParameter("mobileNum", esmCustomerTabObjAnno.getmobile_num())
			.setParameter("pswd0", esmCustomerTabObjAnno.getpswd_0())
			.executeUpdate()
			;
			logger.info("executeNativeSQL : before commit");
			session.getTransaction().commit();
			logger.info("executeNativeSQL : ends");
			return esmCustomerTabObjAnno;
		}
		catch(Exception e){
			logger.info("executeNativeSQL : "+e.getMessage());
			e.printStackTrace();
		}
		return esmCustomerTabObjAnno;
	}

	public Long checkUniqueKey(String objectName, String fieldNameList, String fieldValueList) {
		logger.info("getNextVal : starts ");
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(" SELECT COUNT(1) as count FROM "+objectName+" WHERE "+fieldNameList+"='"+fieldValueList+"'");
		Long count = (Long) query.uniqueResult();
		logger.info("getNextVal : ends "+count.longValue());
		return count;
    }
	
	@SuppressWarnings("unchecked")
	@Override
	public EsmCustomerTabObjAnno executeNativeSQLAuthenticate(EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		// TODO Auto-generated method stub
		logger.info("executeNativeSQLAuthenticate : starts");
		logger.info("executeNativeSQLAuthenticate : esmCustomerTabObjAnno: "+esmCustomerTabObjAnno.getorg_id()+" - "+esmCustomerTabObjAnno.getmobile_num()+" - "+esmCustomerTabObjAnno.getpswd_0());
		Long count = new Long(0);
		List<EsmCustomerTabObjAnno> esmCustomerTabObjAnnoList = null;
		try {
			esmCustomerTabObjAnnoList = (List<EsmCustomerTabObjAnno>) sessionFactory.getCurrentSession()
					.createSQLQuery(ESM_CUSTOMER_QUERY_AUTHENTICATE)
					.addEntity(EsmCustomerTabObjAnno.class)
					.setParameter("orgId", esmCustomerTabObjAnno.getorg_id())
					//.setParameter("emailId", esmCustomerTabObjAnno.getemail_id())
					.setParameter("mobileNum", esmCustomerTabObjAnno.getmobile_num())
					.setParameter("pswd0", esmCustomerTabObjAnno.getpswd_0())
					.list();
			if ( esmCustomerTabObjAnnoList != null && esmCustomerTabObjAnnoList.size() > 0 ) {
				count = (long)esmCustomerTabObjAnnoList.size();
				esmCustomerTabObjAnno = esmCustomerTabObjAnnoList.get(0);
				logger.info("executeNativeSQLAuthenticate : esmCustomerTabObjAnnoList.size "+esmCustomerTabObjAnnoList.size());
			}
			else {
				throw new Exception("No record found for given mobile num and password");
			}
			logger.info("executeNativeSQLAuthenticate : ends "+count.longValue());
		}
		catch(Exception e){
			logger.info("executeNativeSQLAuthenticate : "+e.getMessage());
			e.printStackTrace();
		}
		return esmCustomerTabObjAnno;
	}

	@SuppressWarnings("unchecked")
	@Override
	public EsmCustomerTabObjAnno saveManageCustomerProfile(EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		// TODO Auto-generated method stub
		logger.info("executeNativeSQL : starts");
		try {
	        Session session = sessionFactory.openSession();
			session.beginTransaction();
			sessionFactory.getCurrentSession().createSQLQuery(ESM_CUSTOMER_UPDATE_SAVE_MANAGE_CUSTOMER_PROFILE)
			.addEntity(EsmCustomerTabObjAnno.class)
			.setParameter("orgId", esmCustomerTabObjAnno.getorg_id())
			.setParameter("customerId", esmCustomerTabObjAnno.getcustomer_id())
			.setParameter("customerName", esmCustomerTabObjAnno.getcustomer_name())
			.setParameter("stateCode", esmCustomerTabObjAnno.getstate_code())
			.setParameter("regionId", esmCustomerTabObjAnno.getregion_id())
			.setParameter("countryCode", esmCustomerTabObjAnno.getcountry_code())
			//.setParameter("status", esmCustomerTabObjAnno.getstatus())
			//.setParameter("effectiveDate", esmCustomerTabObjAnno.geteffective_date())
			.setParameter("address1", esmCustomerTabObjAnno.getaddress_1())
			.setParameter("address2", esmCustomerTabObjAnno.getaddress_2())
			.setParameter("address3", esmCustomerTabObjAnno.getaddress_3())
			.setParameter("emailId", esmCustomerTabObjAnno.getemail_id())
			.setParameter("mobileNum", esmCustomerTabObjAnno.getmobile_num())
			.executeUpdate()
			;
			logger.info("executeNativeSQL : before commit");
			session.getTransaction().commit();
			logger.info("executeNativeSQL : ends");
			return esmCustomerTabObjAnno;
		}
		catch(Exception e){
			logger.info("executeNativeSQL : "+e.getMessage());
			e.printStackTrace();
		}
		return esmCustomerTabObjAnno;
	}

	public static void main (String args[])	{
		Double rnd = Math.random() * 100000;
		logger.info("getNextVal : rnd "+rnd);
		Long randToLong = (Double.valueOf(rnd).longValue());
		Long millis = System.currentTimeMillis();
		logger.info("getNextVal : end : millis-random "+millis+"-"+randToLong);
	}

}