package orgweb.rvtest.pyotyls.dao;

import java.util.List;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer.EsmCustomerTabObjAnno;

public interface EsmCustomerDAOIFace {

	public List<EsmCustomerTabObjAnno> getList();

	public EsmCustomerTabObjAnno get(String orgId, Long customerId);
	
	public EsmCustomerTabObjAnno create(EsmCustomerTabObjAnno esmCustomerTabObjAnno);

	public EsmCustomerTabObjAnno createOrEdit(EsmCustomerTabObjAnno esmCustomerTabObjAnno);

	public Long delete(String orgId, Long customerId);

	public EsmCustomerTabObjAnno executeNativeSQL(EsmCustomerTabObjAnno esmCustomerTabObjAnno);

	public Long checkUniqueKey(String objectName, String fieldNameList, String fieldValueList);

	public EsmCustomerTabObjAnno executeNativeSQLAuthenticate(EsmCustomerTabObjAnno esmCustomerTabObjAnno);

	public EsmCustomerTabObjAnno saveManageCustomerProfile(EsmCustomerTabObjAnno esmCustomerTabObjAnno);
	
	//public EsmCustomerTabObjAnno update(String orgId, String customerId, EsmCustomerTabObjAnno esmCustomerTabObjAnno);
	
}
