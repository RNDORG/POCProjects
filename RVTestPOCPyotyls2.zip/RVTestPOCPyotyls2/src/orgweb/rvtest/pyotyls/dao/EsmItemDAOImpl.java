package orgweb.rvtest.pyotyls.dao;

//import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.*;

@Repository("esmItemDAO")
public class EsmItemDAOImpl implements EsmItemDAOIFace {

	private static final Logger logger = Logger.getLogger(EsmItemDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<EsmItemTabObjAnno> getList() {
		logger.info("getList : starts");
		return (List<EsmItemTabObjAnno>) sessionFactory.getCurrentSession().createCriteria(EsmItemTabObjAnno.class).list();
	}

	@Override
	public EsmItemTabObjAnno get(String orgId, String itemCode) {
		logger.info("get : starts");
		return (EsmItemTabObjAnno) sessionFactory.getCurrentSession().get(EsmItemTabObjAnno.class, new EsmItemPkeyObj (orgId, itemCode) );
	}

	@Override
	public EsmItemTabObjAnno create(EsmItemTabObjAnno esmItemTabObjAnno) {
		logger.info("create : starts");
		sessionFactory.getCurrentSession().saveOrUpdate(esmItemTabObjAnno);
		logger.info("create : ends");
		return esmItemTabObjAnno;
	}

	@Override
	public EsmItemTabObjAnno createOrEdit(EsmItemTabObjAnno esmItemTabObjAnno) {
		logger.info("createOrEdit : starts");
		sessionFactory.getCurrentSession().saveOrUpdate(esmItemTabObjAnno);
		logger.info("createOrEdit : ends");
		return esmItemTabObjAnno;
	}
	
	@Override
	public String delete(String orgId, String itemCode) {
		logger.info("delete : starts");
		logger.info("delete : delete-query : "+"DELETE FROM ESM_ITEM WHERE ORG_ID = '"+orgId+"' AND ITEM_CODE = '"+itemCode+"'");
		sessionFactory.getCurrentSession().createQuery("DELETE FROM EsmItemTabObjAnno WHERE ORG_ID = '"+orgId+"' AND ITEM_CODE = '"+itemCode+"'").executeUpdate();
		//sessionFactory.getCurrentSession().createQuery("delete from EsmItemTabObjAnno where org_id = '"+orgId+"' and item_code = '"+itemCode+"'").executeUpdate();
		logger.info("delete : ends");
		return itemCode;
	}

}