package orgweb.rvtest.pyotyls.dao;

public class SQLStatementConstant {

	String ESM_CUSTOMER_INSERT = "INSERT INTO ESM_CUSTOMER (ORG_ID, CUSTOMER_ID, CUSTOMER_NAME, STATE_CODE, REGION_ID "
	                           + " , COUNTRY_CODE, STATUS, EFFECTIVE_DATE, ADDRESS_1, ADDRESS_2, ADDRESS_3, EMAIL_ID "
			                   + " , MOBILE_NUM, PSWD_0 ) "
	                           + "VALUES (:orgId, :customerId, :customerName, :stateCode, :regionId "
			                   + " , :countryCode, :status, :effectiveDate, :address1, :address2, : address3, emailId "
	                           + " , :mobileNum, :pwsd0) ";

}
