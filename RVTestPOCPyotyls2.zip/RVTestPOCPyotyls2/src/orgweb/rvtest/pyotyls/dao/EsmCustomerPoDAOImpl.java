package orgweb.rvtest.pyotyls.dao;

//import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo.*;

@Repository("esmCustomerPoDAO")
public class EsmCustomerPoDAOImpl implements EsmCustomerPoDAOIFace {

	private static final Logger logger = Logger.getLogger(EsmCustomerPoDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<EsmCustomerPoTabObjAnno> getList() {
		logger.info("getList : starts");
		return (List<EsmCustomerPoTabObjAnno>) sessionFactory.getCurrentSession().createCriteria(EsmCustomerPoTabObjAnno.class).list();
	}

	@Override
	public EsmCustomerPoTabObjAnno get(String oaNum) {
		logger.info("get : starts : oaNum : "+oaNum);
		return (EsmCustomerPoTabObjAnno) sessionFactory.getCurrentSession().get(EsmCustomerPoTabObjAnno.class, oaNum);
	}

	@Override
	public EsmCustomerPoTabObjAnno create(EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno) {
		logger.info("create : starts");
		sessionFactory.getCurrentSession().saveOrUpdate(esmCustomerPoTabObjAnno);
		return esmCustomerPoTabObjAnno;
	}

	@Override
	public EsmCustomerPoTabObjAnno createOrEdit(EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno) {
		logger.info("createOrEdit : starts");
		sessionFactory.getCurrentSession().saveOrUpdate(esmCustomerPoTabObjAnno);
		return esmCustomerPoTabObjAnno;
	}
	
	@Override
	public String delete(String oaNum) {
		logger.info("delete : starts : oaNum : "+oaNum);
		logger.info("delete : delete-query : "+"DELETE FROM ESM_CUSTOMER_PO WHERE OA_NUM = '"+oaNum+"'");
		//sessionFactory.getCurrentSession().createQuery("DELETE FROM ESM_CUSTOMER_PO WHERE OA_NUM = '"+oaNum+"'").executeUpdate();
		sessionFactory.getCurrentSession().createQuery("DELETE FROM EsmCustomerPoTabObjAnno WHERE OA_NUM = '"+oaNum+"'").executeUpdate();
		return oaNum;
	}

}