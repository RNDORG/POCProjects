package orgweb.rvtest.pyotyls.controller;


import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer.EsmCustomerTabObjAnno;
import orgweb.rvtest.pyotyls.service.EsmCustomerServiceIFace;

@RestController
public class RestControllerCustomer {

	private static final Logger logger = Logger.getLogger(RestControllerCustomer.class);

	@Autowired
	private EsmCustomerServiceIFace esmCustomerService;

	@GetMapping("/manageCustomer/list")
	public List<EsmCustomerTabObjAnno> getCustomerList() {
		logger.info("getCustomerList : starts");
		return esmCustomerService.getList();
	}

	@GetMapping("/manageCustomer/get/{orgId}/{customerId}")
	public ResponseEntity getCustomer(@PathVariable("orgId") String orgId, @PathVariable("customerId") Long customerId) {
		logger.info("getCustomer : starts");
		EsmCustomerTabObjAnno esmCustomerTabObjAnno = esmCustomerService.get(orgId, customerId);
		if (esmCustomerTabObjAnno == null) {
			return new ResponseEntity("No Customer found for CUSTOMER_ID " + customerId, HttpStatus.NOT_FOUND);
		}
		logger.info("getCustomer : ends");
		return new ResponseEntity(esmCustomerTabObjAnno, HttpStatus.OK);
	}

	@PostMapping(value = "/manageCustomer/submit")
	public ResponseEntity submitCustomer(@RequestBody EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("submitCustomer : starts");
		try {
			sst.pyotyls.aq.Producer.sendMessage( esmCustomerTabObjAnno.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("submitCustomer : ends");
		return new ResponseEntity(esmCustomerTabObjAnno, HttpStatus.OK);
	}


	@PostMapping(value = "/manageCustomer/create")
	public ResponseEntity createCustomer(@RequestBody EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("createCustomer : starts");
		return new ResponseEntity(esmCustomerService.createOrEdit(esmCustomerTabObjAnno), HttpStatus.OK);
	}

	
	@DeleteMapping("/manageCustomer/delete/{orgId}/{customerId}")
	public ResponseEntity deleteCustomer(@PathVariable("orgId") String orgId, @PathVariable("customerId") Long customerId) {
		logger.info("deleteCustomer : starts");
		if (null == esmCustomerService.delete(orgId, customerId)) {
			return new ResponseEntity("No Customer found for CUSTOMER_ID " + customerId, HttpStatus.NOT_FOUND);
		}
		logger.info("deleteCustomer : ends");
		return new ResponseEntity(customerId, HttpStatus.OK);
	}

	@PutMapping("/manageCustomer/update/{orgId}/{customerId}")
	public ResponseEntity updateCustomer(@PathVariable("orgId") String orgId, @PathVariable("customerId") String customerId, @RequestBody EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("updateCustomer : starts");
		esmCustomerTabObjAnno = esmCustomerService.createOrEdit(esmCustomerTabObjAnno);
		if (null == esmCustomerTabObjAnno) {
			return new ResponseEntity("No Customer found for CUSTOMER_ID " + customerId, HttpStatus.NOT_FOUND);
		}
		logger.info("updateCustomer : ends");
		return new ResponseEntity(esmCustomerTabObjAnno, HttpStatus.OK);
	}

}