package orgweb.rvtest.pyotyls.controller.validation;

import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import orgweb.rvtest.pyotyls.controller.ServletControllerCustomer;
import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer.EsmCustomerTabObjAnno;

@Component
public class CustomerRegisterFormValidator implements Validator
{
	private static final Logger logger = Logger.getLogger(CustomerRegisterFormValidator.class);

	public boolean supports(Class clazz) {
        return EsmCustomerTabObjAnno.class.isAssignableFrom(clazz);
    }
 
	@Override
    public void validate(Object object, Errors errors) {
		logger.info("validate : starts");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "customer_name", "error.customer_name", "Customer name is required.");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mobile_num", "error.mobile_num", "Mobile number is required.");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email_id", "error.email_id", "Email is required.");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pswd_0", "error.pswd_0", "Password is required.");

        EsmCustomerTabObjAnno esmCustomerTabObjAnno = (EsmCustomerTabObjAnno) object;

        Pattern pattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
              Pattern.CASE_INSENSITIVE);
        if (!(pattern.matcher(esmCustomerTabObjAnno.getemail_id()).matches())) {
        	errors.rejectValue("email_id", "error.email_id.invalid","Invalid email id");
        }
        
        logger.info("validate : ends");
    }
}