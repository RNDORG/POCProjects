package orgweb.rvtest.pyotyls.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo.EsmCustomerPoTabObjAnno;
import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.EsmItemTabObjAnno;
import orgweb.rvtest.pyotyls.service.EsmCustomerPoServiceIFace;

@Controller
public class ServletControllerCustomerOrder {
	
	private static final Logger logger = Logger.getLogger(ServletControllerCustomerOrder.class);

	@Autowired
	private EsmCustomerPoServiceIFace esmCustomerPoService;

	@RequestMapping(value={"/manageCustomerOrderPage/new", "/manageCustomerOrderPage/list"}, method = RequestMethod.GET)
	public ModelAndView getCustomerOrderListMVC() {
		logger.info("getCustomerOrderListMVC : starts");
		ModelAndView modelAndView = new ModelAndView("manageCustomerOrder");
		modelAndView.addObject("esmCustomerPoTabObjAnno", new EsmCustomerPoTabObjAnno());
		modelAndView.addObject("esmCustomerPoTabObjAnnoList", (List<EsmCustomerPoTabObjAnno>) esmCustomerPoService.getList());
		logger.info("getCustomerOrderListMVC : ends");
		return modelAndView;
	}

	@RequestMapping(value={"/manageCustomerOrderPage/edit"}, method = RequestMethod.GET)
	public ModelAndView editCustomerOrderListMVC(@ModelAttribute("command")  EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno, BindingResult result) {
		logger.info("editCustomerOrderListMVC : starts");
		if (result.hasErrors()) {
			System.out.println("Binding result encountered");
	    }
		Map<String, Object> mapModel = new HashMap<String, Object>();
		mapModel.put("esmCustomerPoTabObjAnno",  esmCustomerPoService.get(esmCustomerPoTabObjAnno.getoa_num()));
		mapModel.put("esmCustomerPoTabObjAnnoList",  (List<EsmCustomerPoTabObjAnno>) esmCustomerPoService.getList());
		logger.info("editCustomerOrderListMVC : ends");
		return new ModelAndView("manageCustomerOrder", mapModel);
	}

	@RequestMapping(value = "/manageCustomerOrderPage/delete", method = RequestMethod.GET)
	public ModelAndView deleteCustomerOrderMVC(@ModelAttribute("command")  EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno, BindingResult result) {
		logger.info("deleteCustomerOrderMVC : starts");
		esmCustomerPoService.delete(esmCustomerPoTabObjAnno.getoa_num());
		Map<String, Object> mapModel = new HashMap<String, Object>();
		//mapModel.put("esmCustomerPoTabObjAnno",  esmCustomerPoService.get(esmCustomerPoTabObjAnno.getoa_num()));
		mapModel.put("esmCustomerPoTabObjAnno", new EsmCustomerPoTabObjAnno());
		mapModel.put("esmCustomerPoTabObjAnnoList",  (List<EsmCustomerPoTabObjAnno>) esmCustomerPoService.getList());
		logger.info("deleteCustomerOrderMVC : ends");
		return new ModelAndView("manageCustomerOrder", mapModel);
	}

	@RequestMapping(value = "/manageCustomerOrderPage/save", method = RequestMethod.POST)
	public ModelAndView saveCustomerOrderMVC(@ModelAttribute("command") EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno, BindingResult result) {
		logger.info("saveCustomerOrderMVC : starts");
		esmCustomerPoService.createOrEdit(esmCustomerPoTabObjAnno);
		Map<String, Object> mapModel = new HashMap<String, Object>();
		mapModel.put("esmCustomerPoTabObjAnno", new EsmCustomerPoTabObjAnno());
		mapModel.put("esmCustomerPoTabObjAnnoList",  (List<EsmCustomerPoTabObjAnno>) esmCustomerPoService.getList());
		logger.info("saveCustomerOrderMVC : ends");
		//return new ModelAndView("redirect:/views/manageCustomerOrder.html");
		return new ModelAndView("manageCustomerOrder", mapModel);
	}

}