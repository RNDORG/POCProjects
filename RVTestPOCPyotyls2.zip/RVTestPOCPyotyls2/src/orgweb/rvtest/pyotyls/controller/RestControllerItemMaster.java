package orgweb.rvtest.pyotyls.controller;


import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.EsmItemTabObjAnno;
import orgweb.rvtest.pyotyls.service.EsmItemServiceIFace;

@RestController
public class RestControllerItemMaster {

	private static final Logger logger = Logger.getLogger(RestControllerItemMaster.class);
	
	//@Autowired
	//private EsmCustomerPoDAO esmCustomerPoDAO;

	@Autowired
	private EsmItemServiceIFace esmItemService;

	@GetMapping("/manageItemMaster/list")
	public List<EsmItemTabObjAnno> getItemMasterList() {
		logger.info("getItemList : starts");
		return esmItemService.getList();
	}

	@GetMapping("/manageItemMaster/get/{itemCode}")
	public ResponseEntity getItemMaster(@PathVariable("orgId") String orgId, @PathVariable("itemCode") String itemCode) {
		logger.info("getItemMasterRecord : starts");
		EsmItemTabObjAnno esmItemTabObjAnno = esmItemService.get(orgId, itemCode);
		if (esmItemTabObjAnno == null) {
			return new ResponseEntity("No record found for ITEM_CODE " + itemCode, HttpStatus.NOT_FOUND);
		}
		logger.info("getItemMasterRecord : ends");
		return new ResponseEntity(esmItemTabObjAnno, HttpStatus.OK);
	}

	@PostMapping(value = "/manageItemMaster/submit")
	public ResponseEntity submitItemMaster(@RequestBody EsmItemTabObjAnno esmItemTabObjAnno) {
		logger.info("submitItemMaster : starts");
		try {
			sst.pyotyls.aq.Producer.sendMessage( esmItemTabObjAnno.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("submitItemMaster : ends");
		return new ResponseEntity(esmItemTabObjAnno, HttpStatus.OK);
	}


	@PostMapping(value = "/manageItemMaster/create")
	public ResponseEntity createItemMaster(@RequestBody EsmItemTabObjAnno esmItemTabObjAnno) {
		logger.info("createItemMaster : starts");
		return new ResponseEntity(esmItemService.createOrEdit(esmItemTabObjAnno), HttpStatus.OK);
	}

	@DeleteMapping("/manageItemMaster/delete/{itemCode}")
	public ResponseEntity deleteItemMaster(@PathVariable("orgId") String orgId, @PathVariable String itemCode) {
		logger.info("deleteItemMaster : starts");
		if (null == esmItemService.delete(orgId, itemCode)) {
			return new ResponseEntity("No records found for ITEM_CODE " + itemCode, HttpStatus.NOT_FOUND);
		}
		logger.info("deleteItemMaster : ends");
		return new ResponseEntity(itemCode, HttpStatus.OK);
	}

	@PutMapping("/manageItemMaster/update/{itemCode}")
	public ResponseEntity updateItemMaster(@PathVariable("orgId") String orgId, @PathVariable("itemCode") String itemCode, @RequestBody EsmItemTabObjAnno esmItemTabObjAnno) {
		logger.info("updateItemMaster : starts");
		esmItemTabObjAnno = esmItemService.createOrEdit(esmItemTabObjAnno);
		if (null == esmItemTabObjAnno) {
			return new ResponseEntity("No record found for ITEM_CODE " + itemCode, HttpStatus.NOT_FOUND);
		}
		logger.info("updateItemMaster : ends");
		return new ResponseEntity(esmItemTabObjAnno, HttpStatus.OK);
	}

}