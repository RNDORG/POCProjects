package orgweb.rvtest.pyotyls.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;

import orgweb.rvtest.pyotyls.controller.validation.CustomerRegisterFormValidator;
import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer.EsmCustomerTabObjAnno;
import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo.EsmCustomerPoTabObjAnno;
import orgweb.rvtest.pyotyls.service.EsmCustomerServiceIFace;

@Controller
public class ServletControllerCustomer {
	
	private static final Logger logger = Logger.getLogger(ServletControllerCustomer.class);

	@Autowired
	private EsmCustomerServiceIFace esmCustomerService;

	//======================================================================
	@Autowired
	CustomerRegisterFormValidator customerRegisterFormValidator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(customerRegisterFormValidator);
	}
	//======================================================================
	
	@RequestMapping(value={"/manageCustomerPage/register"}, method = RequestMethod.GET)
	public ModelAndView getCustomerRegisterMVC() {
		logger.info("getCustomerRegisterMVC : starts");
		ModelAndView modelAndView = new ModelAndView("manageCustomerRegister");
		modelAndView.addObject("esmCustomerTabObjAnno", new EsmCustomerTabObjAnno());
		logger.info("getCustomerRegisterMVC : ends");
		return modelAndView;
	}

	@RequestMapping(value = "/manageCustomerPage/save_register", method = RequestMethod.POST)
	public ModelAndView saveCustomerRegisterMVC(@ModelAttribute("command") @Validated EsmCustomerTabObjAnno esmCustomerTabObjAnno, BindingResult result) {
		logger.info("saveCustomerRegisterMVC : starts");
		
		//===========================================================
		Map<String, Object> mapModel = new HashMap<String, Object>();
		esmCustomerTabObjAnno.setorg_id("SST");
		esmCustomerTabObjAnno.setstatus("P");
		mapModel.put("esmCustomerTabObjAnno", esmCustomerTabObjAnno);
		//===========================================================

		//===========================================================
	    if (result.hasErrors()) {
			return new ModelAndView("manageCustomerRegister", mapModel);
	    }
		//===========================================================
	    
		//===========================================================
		esmCustomerService.manageCustomerSaveRegister(esmCustomerTabObjAnno);
		logger.info("saveCustomerRegisterMVC : ends");
		return new ModelAndView("manageCustomerRegister", mapModel);
		//===========================================================
	}

	@RequestMapping(value={"/manageCustomerPage/sign_in"}, method = RequestMethod.GET)
	public ModelAndView getCustomerSignInMVC() {
		logger.info("getCustomerSignInMVC : starts");
		ModelAndView modelAndView = new ModelAndView("manageCustomerSignIn");
		modelAndView.addObject("esmCustomerTabObjAnno", new EsmCustomerTabObjAnno());
		logger.info("getCustomerSignInMVC : ends");
		return modelAndView;
	}

	@RequestMapping(value={"/manageCustomerPage/user_auth"}, method = RequestMethod.POST)
	public ModelAndView getCustomerUserAuthMVC( @ModelAttribute("command")  EsmCustomerTabObjAnno esmCustomerTabObjAnno, BindingResult result) {
		logger.info("getCustomerUserAuthMVC : starts");
		ModelAndView modelAndView = new ModelAndView("index");
		esmCustomerTabObjAnno.setorg_id("SST");
		modelAndView.addObject("esmCustomerTabObjAnno", esmCustomerService.authenticateCustomer(esmCustomerTabObjAnno));
		logger.info("getCustomerUserAuthMVC : ends");
		return modelAndView;
	}

	@RequestMapping(value={"/manageCustomerPage/manage_customer_profile"}, method = RequestMethod.GET)
	public ModelAndView manageCustomerProfileMVC(@ModelAttribute("command")  EsmCustomerTabObjAnno esmCustomerTabObjAnno, BindingResult result) {
		logger.info("manageCustomerProfileMVC : starts");
		Map<String, Object> mapModel = new HashMap<String, Object>();
		mapModel.put("esmCustomerTabObjAnno",  esmCustomerService.get(esmCustomerTabObjAnno.getorg_id(),esmCustomerTabObjAnno.getcustomer_id()));
		mapModel.put("action",  "manage_customer_profile");
		logger.info("manageCustomerProfileMVC : ends");
		return new ModelAndView("manageCustomer", mapModel);
	}

	@RequestMapping(value = "/manageCustomerPage/save_manage_customer_profile", method = RequestMethod.POST)
	public ModelAndView saveManageCustomerProfileMVC(@ModelAttribute("command") EsmCustomerTabObjAnno esmCustomerTabObjAnno, BindingResult result) {
		logger.info("saveManageCustomerProfileMVC : starts");
		Map<String, Object> mapModel = new HashMap<String, Object>();
		esmCustomerTabObjAnno.setorg_id("SST");
		esmCustomerTabObjAnno.setstatus("P");
		mapModel.put("esmCustomerTabObjAnno", esmCustomerService.saveManageCustomerProfile(esmCustomerTabObjAnno));
		mapModel.put("esmCustomerTabObjAnnoList", null);
		logger.info("saveManageCustomerProfileMVC : ends");
		return new ModelAndView("manageCustomer", mapModel);
	}

	@RequestMapping(value={"/manageCustomerPage/new", "/manageCustomerPage/list"}, method = RequestMethod.GET)
	public ModelAndView getCustomerListMVC() {
		logger.info("getCustomerListMVC : starts");
		ModelAndView modelAndView = new ModelAndView("manageCustomer");
		modelAndView.addObject("esmCustomerTabObjAnno", new EsmCustomerTabObjAnno());
		modelAndView.addObject("esmCustomerTabObjAnnoList", (List<EsmCustomerTabObjAnno>) esmCustomerService.getList());
		logger.info("getCustomerListMVC : ends");
		return modelAndView;
	}

	@RequestMapping(value={"/manageCustomerPage/edit"}, method = RequestMethod.GET)
	public ModelAndView editCustomerListMVC(@ModelAttribute("command")  EsmCustomerTabObjAnno esmCustomerTabObjAnno, BindingResult result) {
		logger.info("editCustomerListMVC : starts");
		Map<String, Object> mapModel = new HashMap<String, Object>();
		mapModel.put("esmCustomerTabObjAnno",  esmCustomerService.get(esmCustomerTabObjAnno.getorg_id(),esmCustomerTabObjAnno.getcustomer_id()));
		mapModel.put("esmCustomerTabObjAnnoList",  (List<EsmCustomerTabObjAnno>) esmCustomerService.getList());
		logger.info("editCustomerListMVC : ends");
		return new ModelAndView("manageCustomer", mapModel);
	}

	@RequestMapping(value = "/manageCustomerPage/delete", method = RequestMethod.GET)
	public ModelAndView deleteCustomerMVC(@ModelAttribute("command")  EsmCustomerTabObjAnno esmCustomerTabObjAnno, BindingResult result) {
		logger.info("deleteCustomerMVC : starts");
		esmCustomerService.delete(esmCustomerTabObjAnno.getorg_id(),esmCustomerTabObjAnno.getcustomer_id());
		Map<String, Object> mapModel = new HashMap<String, Object>();
		mapModel.put("esmCustomerTabObjAnno", new EsmCustomerTabObjAnno());
		mapModel.put("esmCustomerTabObjAnnoList",  (List<EsmCustomerTabObjAnno>) esmCustomerService.getList());
		logger.info("deleteCustomerMVC : ends");
		return new ModelAndView("manageCustomer", mapModel);
	}

	@RequestMapping(value = "/manageCustomerPage/save", method = RequestMethod.POST)
	public ModelAndView saveCustomerMVC(@ModelAttribute("command") EsmCustomerTabObjAnno esmCustomerTabObjAnno, BindingResult result) {
		logger.info("saveCustomerMVC : starts");
		Map<String, Object> mapModel = new HashMap<String, Object>();
		//esmCustomerService.createOrEdit(esmCustomerTabObjAnno);
		esmCustomerService.manageCustomerSave(esmCustomerTabObjAnno);
		mapModel.put("esmCustomerTabObjAnno", new EsmCustomerTabObjAnno());
		mapModel.put("esmCustomerTabObjAnnoList",  (List<EsmCustomerTabObjAnno>) esmCustomerService.getList());
		logger.info("saveCustomerMVC : ends");
		return new ModelAndView("manageCustomer", mapModel);
	}

}
