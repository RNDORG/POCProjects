package orgweb.rvtest.pyotyls.service;

import java.util.List;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.EsmItemTabObjAnno;

public interface EsmItemServiceIFace {

	List<EsmItemTabObjAnno> getList();

	//EsmItemTabObjAnno get(String itemCode);

	EsmItemTabObjAnno get(String orgId, String itemCode);

	//String delete(String itemCode);

	String delete(String orgId, String itemCode);

	public EsmItemTabObjAnno createOrEdit (EsmItemTabObjAnno esmItemTabObjAnno);
	

}
