package orgweb.rvtest.pyotyls.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import orgweb.rvtest.pyotyls.dao.EsmItemDAOIFace;
//import orgweb.rvtest.pyotyls.dao.EsmItemDAOImpl;
import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmItem.EsmItemTabObjAnno;

@Service("esmItemService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class EsmItemServiceImpl implements EsmItemServiceIFace {
	
	private static final Logger logger = Logger.getLogger(EsmItemServiceImpl.class);

	@Autowired
	private EsmItemDAOIFace esmItemDAO;

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public EsmItemTabObjAnno createOrEdit (EsmItemTabObjAnno esmItemTabObjAnno) {
		logger.info("createOrEdit : starts");
		return esmItemDAO.createOrEdit(esmItemTabObjAnno);
	}

	@Override
	public List<EsmItemTabObjAnno> getList() {
		logger.info("getList : starts");
		return esmItemDAO.getList();
	}

	@Override
	public EsmItemTabObjAnno get (String orgId, String itemCode) {
		logger.info("get : starts");
		return esmItemDAO.get(orgId, itemCode);
	}

	@Override
	public String delete (String orgId, String itemCode) {
		logger.info("delete : starts");
		return esmItemDAO.delete(orgId, itemCode);
	}
}
