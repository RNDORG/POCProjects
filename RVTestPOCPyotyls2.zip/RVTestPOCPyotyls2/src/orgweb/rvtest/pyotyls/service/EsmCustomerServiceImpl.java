package orgweb.rvtest.pyotyls.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import orgweb.rvtest.pyotyls.dao.EsmCustomerDAOIFace;
import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer.EsmCustomerTabObjAnno;

@Service("EsmCustomerService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class EsmCustomerServiceImpl implements EsmCustomerServiceIFace {
	
	private static final Logger logger = Logger.getLogger(EsmCustomerServiceImpl.class);

	@Autowired
	private EsmCustomerDAOIFace esmCustomerDAO;

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public EsmCustomerTabObjAnno createOrEdit (EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("createOrEdit : starts");
		return esmCustomerDAO.createOrEdit(esmCustomerTabObjAnno);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public EsmCustomerTabObjAnno manageCustomerSave (EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("manageCustomerSave : starts");
		return esmCustomerDAO.createOrEdit(esmCustomerTabObjAnno);
	}

	@Override
	public EsmCustomerTabObjAnno manageCustomerSaveRegister (EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("manageCustomerSaveRegister : starts");
		
		if ( esmCustomerDAO.checkUniqueKey("EsmCustomerTabObjAnno", "EMAIL_ID", esmCustomerTabObjAnno.getemail_id()) >= 1L) {
			logger.info("createOrEdit : EMAIL_ID already exists");
			return null;
		}

		if ( esmCustomerDAO.checkUniqueKey("EsmCustomerTabObjAnno", "MOBILE_NUM", esmCustomerTabObjAnno.getmobile_num()) >= 1L) {
			logger.info("createOrEdit : MOBILE_NUM already exists");
			return null;
		}

		logger.info("manageCustomerSaveRegister : ends");
		return esmCustomerDAO.executeNativeSQL(esmCustomerTabObjAnno);
	}

	@Override
	public EsmCustomerTabObjAnno saveManageCustomerProfile(EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		logger.info("saveManageCustomerProfile : starts");

		// TODO : Apply validation that user does not update email id of other person
		// TODO : Apply validation that user does not update mobile of other person

		logger.info("saveManageCustomerProfile : ends");
		return esmCustomerDAO.saveManageCustomerProfile(esmCustomerTabObjAnno);
	}

	@Override
	public List<EsmCustomerTabObjAnno> getList() {
		logger.info("getList : starts");
		return esmCustomerDAO.getList();
	}

	@Override
	public EsmCustomerTabObjAnno get (String orgId, Long customerId) {
		logger.info("get : starts");
		return esmCustomerDAO.get(orgId, customerId);
	}

	@Override
	public Long delete (String orgId, Long customerId) {
		logger.info("delete : starts");
		return esmCustomerDAO.delete(orgId, customerId);
	}

	@Override
	public EsmCustomerTabObjAnno authenticateCustomer(EsmCustomerTabObjAnno esmCustomerTabObjAnno) {
		// TODO Auto-generated method stub
		logger.info("authenticateCustomer : starts");
		esmCustomerTabObjAnno = esmCustomerDAO.executeNativeSQLAuthenticate(esmCustomerTabObjAnno);

		if ( esmCustomerTabObjAnno != null && esmCustomerTabObjAnno.getstatus() != null && !esmCustomerTabObjAnno.getstatus().equals("A")) {
			logger.info("authenticateCustomer : authentication failed");
		}
		else {
			logger.info("authenticateCustomer : authentication success");
		}
		logger.info("authenticateCustomer : ends");
		return esmCustomerTabObjAnno;
	}

}
