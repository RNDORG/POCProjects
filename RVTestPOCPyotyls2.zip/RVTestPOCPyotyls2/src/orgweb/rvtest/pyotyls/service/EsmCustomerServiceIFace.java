package orgweb.rvtest.pyotyls.service;

import java.util.List;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomer.EsmCustomerTabObjAnno;

public interface EsmCustomerServiceIFace {

	public List<EsmCustomerTabObjAnno> getList();

	public EsmCustomerTabObjAnno get(String orgId, Long customerId);

	public Long delete(String orgId, Long customerId);

	public EsmCustomerTabObjAnno createOrEdit (EsmCustomerTabObjAnno esmCustomerTabObjAnno);

	public EsmCustomerTabObjAnno manageCustomerSave (EsmCustomerTabObjAnno esmCustomerTabObjAnno);

	public EsmCustomerTabObjAnno manageCustomerSaveRegister(EsmCustomerTabObjAnno esmCustomerTabObjAnno);

	public EsmCustomerTabObjAnno authenticateCustomer(EsmCustomerTabObjAnno esmCustomerTabObjAnno);

	public EsmCustomerTabObjAnno saveManageCustomerProfile(EsmCustomerTabObjAnno esmCustomerTabObjAnno);

}
