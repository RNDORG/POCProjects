CREATE TABLE ESM_SUPPLIER_CONTACT
(
  ORG_ID                                                                                              VARCHAR(10),
  SUPPLIER_ID                                                                                         VARCHAR(10),
  CONTACT_PERSON                                                                                      VARCHAR(30),
  CONTACT_NUM                                                                                         VARCHAR(60),
  SEQ_NUM                                                                                             NUMERIC(2),
  CONTACT_TYPE                                                                                        VARCHAR(10),
  CONTACT_PLACE                                                                                       VARCHAR(10)
)
 WITH OIDS;
