CREATE TABLE ESM_CUSTOMER_ADDRESS
(
  ORG_ID                                                                                              VARCHAR(10),
  CUSTOMER_ID                                                                                         VARCHAR(10),
  ADDRESS_TYPE                                                                                        VARCHAR(5),
  ADDRESS_FIELD_SEQ                                                                                   NUMERIC(9),
  ADDRESS_CTG                                                                                         VARCHAR(1),
  ADDRESS_FIELD_NAME                                                                                  VARCHAR(10),
  ADDRESS_FIELD_VALUE                                                                                 VARCHAR(50),
  EXPIRATION_DATE                                                                                     VARCHAR(8),
  EFFECTIVE_DATE                                                                                      VARCHAR(8)
)
 WITH OIDS;
