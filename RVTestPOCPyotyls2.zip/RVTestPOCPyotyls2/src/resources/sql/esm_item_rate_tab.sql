CREATE TABLE ESM_ITEM_RATE
(
  ITEM_CODE                                                                                           VARCHAR(66),
  MAKE_ID                                                                                             VARCHAR(10),
  SOURCE_ID                                                                                           VARCHAR(10),
  SIZE_FACTOR                                                                                         NUMERIC(5,3),
  PRODUCTION_COST                                                                                     NUMERIC(13,2),
  DOMESTIC_SALE_COST                                                                                  NUMERIC(13,2),
  EXPORT_SALE_COST                                                                                    NUMERIC(13,2),
  DOMESTIC_BUY_RATE                                                                                   NUMERIC(13,2),
  IMPORT_BUY_RATE                                                                                     NUMERIC(13,2),
  MAKE_RATE                                                                                           NUMERIC(13,2),
  EFFECTIVE_DATE                                                                                      VARCHAR(8),
  EXPIRATION_DATE                                                                                     VARCHAR(8)
)
 WITH OIDS;
