CREATE TABLE ESM_CUSTOMER_PO_IADDR
(
  OA_NUM                                                                                              VARCHAR(10),
  ITEM_CODE                                                                                           VARCHAR(66),
  MAKE_ID                                                                                             VARCHAR(10),
  DELIVERY_ADDRESS                                                                                    VARCHAR(100)
)
 WITH OIDS;
