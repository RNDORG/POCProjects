CREATE TABLE ESM_CUSTOMER_PO_ITEM
(
  OA_NUM                                                                                              VARCHAR(10),
  ITEM_CODE                                                                                           VARCHAR(66),
  MAKE_ID                                                                                             VARCHAR(10),
  QTY                                                                                                 NUMERIC(9),
  RATE                                                                                                NUMERIC(13,2),
  DELIVERY_DATE                                                                                       VARCHAR(8),
  DELIVERY_ADDRESS_TYPE                                                                               VARCHAR(5),
  DESTINATION_ID                                                                                      VARCHAR(10),
  DISCOUNT_PERCENT                                                                                    NUMERIC(5,2),
  DISCOUNT_FIX                                                                                        NUMERIC(9),
  STATUS                                                                                              VARCHAR(10),
  QTY_SUPPLIED                                                                                        NUMERIC(9),
  QTY_CANCELED                                                                                        NUMERIC(9),
  CANCEL_DATE                                                                                         VARCHAR(8),
  CANCEL_REMARK                                                                                       VARCHAR(100),
  QTY_REJECTED                                                                                        NUMERIC(9),
  REJECT_DATE                                                                                         VARCHAR(8),
  REJECT_REMARK                                                                                       VARCHAR(100),
  QTY_REVERTED                                                                                        NUMERIC(9),
  REVERT_DATE                                                                                         VARCHAR(8),
  REVERT_REMARK                                                                                       VARCHAR(100)
)
 WITH OIDS;
