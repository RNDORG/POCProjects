package orgweb.rvtest.pyotyls.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo.*;

@Component
public class EsmCustomerPoDAO implements EsmCustomerPoDAOIFace {

	// Dummy database. Initialize with some dummy values.
	private static List<EsmCustomerPoTabObjAnno> esmCustomerPoTabObjAnnoList;
	{
		esmCustomerPoTabObjAnnoList = new ArrayList<EsmCustomerPoTabObjAnno>();
		
		EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno = new EsmCustomerPoTabObjAnno();

		//Adding Record # 1
		esmCustomerPoTabObjAnno.setoa_num("OA-001");
		esmCustomerPoTabObjAnno.setoa_date("20170101");
		esmCustomerPoTabObjAnno.setorder_type("STD");
		esmCustomerPoTabObjAnno.setcustomer_id("CUST-001");
		esmCustomerPoTabObjAnno.setpo_num("PO-001");;
		esmCustomerPoTabObjAnno.setpo_date("20170101");
		esmCustomerPoTabObjAnno.setoa_entry_date("20170101");
		//esmCustomerPoTabObjAnno.setenq_num("NA");
		//esmCustomerPoTabObjAnno.setenq_version((short)0);
		//esmCustomerPoTabObjAnno.setenq_date(null);
		esmCustomerPoTabObjAnno.setdiscount_percent((float)0.00);
		esmCustomerPoTabObjAnno.setdiscount_fix((int)0);
		esmCustomerPoTabObjAnno.setpay_mode("CASH");
		esmCustomerPoTabObjAnno.settransport_mode("BYSHOP");
		esmCustomerPoTabObjAnno.setdelivery_date("20170102");
		esmCustomerPoTabObjAnno.setdelivery_address_type("CUSTHOME");
		esmCustomerPoTabObjAnno.setdelivery_address("1, Beena Tower, Sector-1, Avenue-1, Banglore");
		esmCustomerPoTabObjAnno.setdestination_id("DEST-001");
		esmCustomerPoTabObjAnno.setcurrency_id("INR");
		esmCustomerPoTabObjAnno.setstatus("PENDING");
		esmCustomerPoTabObjAnno.setspl_instruction("Rajma-1kg, Chawal-5kg, Sabun-Dove-4pcs, agarbatti-1pkt, Mung-1Kg, Arhar-2Kg, Aata-10kg");
		esmCustomerPoTabObjAnnoList.add(esmCustomerPoTabObjAnno);
		
		//Adding Record # 2
		esmCustomerPoTabObjAnno = new EsmCustomerPoTabObjAnno();
		esmCustomerPoTabObjAnno.setoa_num("OA-002");
		esmCustomerPoTabObjAnno.setoa_date("20170202");
		esmCustomerPoTabObjAnno.setorder_type("STD");
		esmCustomerPoTabObjAnno.setcustomer_id("CUST-002");
		esmCustomerPoTabObjAnno.setpo_num("PO-001");;
		esmCustomerPoTabObjAnno.setpo_date("20170101");
		esmCustomerPoTabObjAnno.setoa_entry_date("20170101");
		//esmCustomerPoTabObjAnno.setenq_num("NA");
		//esmCustomerPoTabObjAnno.setenq_version((short)0);
		//esmCustomerPoTabObjAnno.setenq_date(null);
		esmCustomerPoTabObjAnno.setdiscount_percent((float)0.00);
		esmCustomerPoTabObjAnno.setdiscount_fix((int)0);
		esmCustomerPoTabObjAnno.setpay_mode("CASH");
		esmCustomerPoTabObjAnno.settransport_mode("BYSHOP");
		esmCustomerPoTabObjAnno.setdelivery_date("20170102");
		esmCustomerPoTabObjAnno.setdelivery_address_type("CUSTHOME");
		esmCustomerPoTabObjAnno.setdelivery_address("1, Beena Tower, Sector-1, Avenue-1, Banglore");
		esmCustomerPoTabObjAnno.setdestination_id("DEST-001");
		esmCustomerPoTabObjAnno.setcurrency_id("INR");
		esmCustomerPoTabObjAnno.setstatus("PENDING");
		esmCustomerPoTabObjAnno.setspl_instruction("Rajma-2kg, Chawal-3kg, Sabun-Dove-4pcs, agarbatti-1pkt, Mung-1Kg, Arhar-2Kg, Aata-10kg");
		esmCustomerPoTabObjAnnoList.add(esmCustomerPoTabObjAnno);

		//Adding Record # 3
		esmCustomerPoTabObjAnno = new EsmCustomerPoTabObjAnno();
		esmCustomerPoTabObjAnno.setoa_num("OA-003");
		esmCustomerPoTabObjAnno.setoa_date("20170303");
		esmCustomerPoTabObjAnno.setorder_type("STD");
		esmCustomerPoTabObjAnno.setcustomer_id("CUST-003");
		esmCustomerPoTabObjAnno.setpo_num("PO-001");;
		esmCustomerPoTabObjAnno.setpo_date("20170101");
		esmCustomerPoTabObjAnno.setoa_entry_date("20170101");
		//esmCustomerPoTabObjAnno.setenq_num("NA");
		//esmCustomerPoTabObjAnno.setenq_version((short)0);
		//esmCustomerPoTabObjAnno.setenq_date(null);
		esmCustomerPoTabObjAnno.setdiscount_percent((float)0.00);
		esmCustomerPoTabObjAnno.setdiscount_fix((int)0);
		esmCustomerPoTabObjAnno.setpay_mode("CASH");
		esmCustomerPoTabObjAnno.settransport_mode("BYSHOP");
		esmCustomerPoTabObjAnno.setdelivery_date("20170102");
		esmCustomerPoTabObjAnno.setdelivery_address_type("CUSTHOME");
		esmCustomerPoTabObjAnno.setdelivery_address("1, Beena Tower, Sector-1, Avenue-1, Banglore");
		esmCustomerPoTabObjAnno.setdestination_id("DEST-001");
		esmCustomerPoTabObjAnno.setcurrency_id("INR");
		esmCustomerPoTabObjAnno.setstatus("PENDING");
		esmCustomerPoTabObjAnno.setspl_instruction("Rajma-2kg, Chawal-2kg, Sabun-Dove-5pcs, agarbatti-2pkt, Mung-1Kg, Arhar-2Kg, Aata-10kg");
		esmCustomerPoTabObjAnnoList.add(esmCustomerPoTabObjAnno);
	}

	/**
	 * Returns list of customers from dummy database.
	 * 
	 * @return list of customers
	 */
	public List<EsmCustomerPoTabObjAnno> getList() {
		return esmCustomerPoTabObjAnnoList;
	}

	/**
	 * Return customer object for given id from dummy database. If customer is
	 * not found for id, returns null.
	 * 
	 * @param id
	 *            customer id
	 * @return customer object for given id
	 */
	public EsmCustomerPoTabObjAnno get(String oaNum) {

		for (EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno : esmCustomerPoTabObjAnnoList) {
			if (esmCustomerPoTabObjAnno.getoa_num().equals(oaNum)) {
				return esmCustomerPoTabObjAnno;
			}
		}
		return null;
	}

	/**
	 * Create new customer in dummy database. Updates the id and insert new
	 * customer in list.
	 * 
	 * @param customer
	 *            Customer object
	 * @return customer object with updated id
	 */
	public EsmCustomerPoTabObjAnno create(EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno) {
		esmCustomerPoTabObjAnnoList.add(esmCustomerPoTabObjAnno);
		return esmCustomerPoTabObjAnno;
	}

	/**
	 * Delete the customer object from dummy database. If customer not found for
	 * given id, returns null.
	 * 
	 * @param id
	 *            the customer id
	 * @return id of deleted customer object
	 */
	public String delete(String oaNum) {

		for (EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno : esmCustomerPoTabObjAnnoList) {
			if (esmCustomerPoTabObjAnno.getoa_num().equals(oaNum)) {
				esmCustomerPoTabObjAnnoList.remove(esmCustomerPoTabObjAnno);
				return oaNum;
			}
		}
		return null;
	}


	/**
	 * Update the customer object for given id in dummy database. If customer
	 * not exists, returns null
	 * 
	 * @param id
	 * @param customer
	 * @return customer object with id
	 */
	public EsmCustomerPoTabObjAnno update(String oaNum, EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno) {

		for (EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnnoLocal : esmCustomerPoTabObjAnnoList) {
			if (esmCustomerPoTabObjAnnoLocal.getoa_num().equals(oaNum)) {
				esmCustomerPoTabObjAnnoList.remove(esmCustomerPoTabObjAnno);
				esmCustomerPoTabObjAnnoList.add(esmCustomerPoTabObjAnno);
				return esmCustomerPoTabObjAnno;
			}
		}
		return null;
	}

}