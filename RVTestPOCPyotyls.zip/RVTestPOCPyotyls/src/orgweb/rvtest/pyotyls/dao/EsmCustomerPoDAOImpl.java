package orgweb.rvtest.pyotyls.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo.*;

@Repository("esmCustomerPoDAO")
public class EsmCustomerPoDAOImpl implements EsmCustomerPoDAOIFace {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<EsmCustomerPoTabObjAnno> getList() {
		return (List<EsmCustomerPoTabObjAnno>) sessionFactory.getCurrentSession().createCriteria(EsmCustomerPoTabObjAnno.class).list();
	}

	@Override
	public EsmCustomerPoTabObjAnno get(String oaNum) {
		return (EsmCustomerPoTabObjAnno) sessionFactory.getCurrentSession().get(EsmCustomerPoTabObjAnno.class, oaNum);
	}

	@Override
	public EsmCustomerPoTabObjAnno create(EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno) {
		sessionFactory.getCurrentSession().saveOrUpdate(esmCustomerPoTabObjAnno);
		return esmCustomerPoTabObjAnno;
	}

	//@Override
	public EsmCustomerPoTabObjAnno createOrEdit(EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno) {
		sessionFactory.getCurrentSession().saveOrUpdate(esmCustomerPoTabObjAnno);
		return esmCustomerPoTabObjAnno;
	}
	
	@Override
	public String delete(String oaNum) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM ESB_CUSTOMER_PO WHERE OA_NUM = "+oaNum).executeUpdate();
		return oaNum;
	}

}