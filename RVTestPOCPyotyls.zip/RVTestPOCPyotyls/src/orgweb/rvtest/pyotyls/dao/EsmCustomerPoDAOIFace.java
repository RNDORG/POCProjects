package orgweb.rvtest.pyotyls.dao;

import java.util.List;

import orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo.EsmCustomerPoTabObjAnno;

public interface EsmCustomerPoDAOIFace {

	public List<EsmCustomerPoTabObjAnno> getList();

	public EsmCustomerPoTabObjAnno get(String oaNum);
	
	public EsmCustomerPoTabObjAnno create(EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno);
	
	public String delete(String oaNum);
	
	//public EsmCustomerPoTabObjAnno update(String oaNum, EsmCustomerPoTabObjAnno esmCustomerPoTabObjAnno);
	
}
