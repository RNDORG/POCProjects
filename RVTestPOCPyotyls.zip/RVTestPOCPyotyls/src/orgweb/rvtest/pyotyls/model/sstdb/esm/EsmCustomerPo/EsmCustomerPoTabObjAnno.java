package orgweb.rvtest.pyotyls.model.sstdb.esm.EsmCustomerPo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ESM_CUSTOMER_PO")
public class EsmCustomerPoTabObjAnno
{
  private String                                 tab_rowid;
  @Column(name="oa_num")
  private String                    oa_num;
  @Column(name="oa_date")
  private String                   oa_date;
  @Column(name="order_type")
  private String                  order_type;
  @Column(name="customer_id")
  private String                 customer_id;
  @Column(name="po_num")
  private String                    po_num;
  @Column(name="po_date")
  private String                   po_date;
  @Column(name="oa_entry_date")
  private String                oa_entry_date;
  @Column(name="enq_num")
  private String                   enq_num;
  @Column(name="enq_version")
  private short                  enq_version;
  @Column(name="enq_date")
  private String                   enq_date;
  @Column(name="discount_percent")
  private float               discount_percent;
  @Column(name="discount_fix")
  private int                  discount_fix;
  @Column(name="pay_term")
  private String                   pay_term;
  @Column(name="pay_mode")
  private String                   pay_mode;
  @Column(name="transport_mode")
  private String                transport_mode;
  @Column(name="delivery_date")
  private String                delivery_date;
  @Column(name="delivery_address_type")
  private String            delivery_address_type;
  @Column(name="delivery_address")
  private String               delivery_address;
  @Column(name="destination_id")
  private String                destination_id;
  @Column(name="currency_id")
  private String                 currency_id;
  @Column(name="exchange_rate")
  private float                 exchange_rate;
  @Column(name="cancel_flag")
  private String                 cancel_flag;
  @Column(name="cancel_date")
  private String                 cancel_date;
  @Column(name="cancel_remark")
  private String                cancel_remark;
  @Column(name="reject_flag")
  private String                 reject_flag;
  @Column(name="reject_date")
  private String                 reject_date;
  @Column(name="reject_remark")
  private String                reject_remark;
  @Column(name="status")
  private String                    status;
  @Column(name="ord_type_sts")
  private String                 ord_type_sts;
  @Column(name="booking_expiry_date")
  private String             booking_expiry_date;
  @Column(name="booking_confirm_date")
  private String             booking_confirm_date;
  @Column(name="spl_instruction")
  private String               spl_instruction;



  public String getoa_num()                           { return oa_num; }
  public String getoa_date()                          { return oa_date; }
  public String getorder_type()                         { return order_type; }
  public String getcustomer_id()                        { return customer_id; }
  public String getpo_num()                           { return po_num; }
  public String getpo_date()                          { return po_date; }
  public String getoa_entry_date()                       { return oa_entry_date; }
  public String getenq_num()                          { return enq_num; }
  public short getenq_version()                         { return enq_version; }
  public String getenq_date()                          { return enq_date; }
  public float getdiscount_percent()                      { return discount_percent; }
  public int getdiscount_fix()                         { return discount_fix; }
  public String getpay_term()                          { return pay_term; }
  public String getpay_mode()                          { return pay_mode; }
  public String gettransport_mode()                       { return transport_mode; }
  public String getdelivery_date()                       { return delivery_date; }
  public String getdelivery_address_type()                   { return delivery_address_type; }
  public String getdelivery_address()                      { return delivery_address; }
  public String getdestination_id()                       { return destination_id; }
  public String getcurrency_id()                        { return currency_id; }
  public float getexchange_rate()                        { return exchange_rate; }
  public String getcancel_flag()                        { return cancel_flag; }
  public String getcancel_date()                        { return cancel_date; }
  public String getcancel_remark()                       { return cancel_remark; }
  public String getreject_flag()                        { return reject_flag; }
  public String getreject_date()                        { return reject_date; }
  public String getreject_remark()                       { return reject_remark; }
  public String getstatus()                           { return status; }
  public String getord_type_sts()                        { return ord_type_sts; }
  public String getbooking_expiry_date()                    { return booking_expiry_date; }
  public String getbooking_confirm_date()                    { return booking_confirm_date; }
  public String getspl_instruction()                      { return spl_instruction; }



  public void  setoa_num(String oa_num )                    { this.oa_num = oa_num; }
  public void  setoa_date(String oa_date )                   { this.oa_date = oa_date; }
  public void  setorder_type(String order_type )                { this.order_type = order_type; }
  public void  setcustomer_id(String customer_id )               { this.customer_id = customer_id; }
  public void  setpo_num(String po_num )                    { this.po_num = po_num; }
  public void  setpo_date(String po_date )                   { this.po_date = po_date; }
  public void  setoa_entry_date(String oa_entry_date )             { this.oa_entry_date = oa_entry_date; }
  public void  setenq_num(String enq_num )                   { this.enq_num = enq_num; }
  public void  setenq_version(short enq_version )                { this.enq_version = enq_version; }
  public void  setenq_date(String enq_date )                  { this.enq_date = enq_date; }
  public void  setdiscount_percent(float discount_percent )           { this.discount_percent = discount_percent; }
  public void  setdiscount_fix(int discount_fix )                { this.discount_fix = discount_fix; }
  public void  setpay_term(String pay_term )                  { this.pay_term = pay_term; }
  public void  setpay_mode(String pay_mode )                  { this.pay_mode = pay_mode; }
  public void  settransport_mode(String transport_mode )            { this.transport_mode = transport_mode; }
  public void  setdelivery_date(String delivery_date )             { this.delivery_date = delivery_date; }
  public void  setdelivery_address_type(String delivery_address_type )     { this.delivery_address_type = delivery_address_type; }
  public void  setdelivery_address(String delivery_address )          { this.delivery_address = delivery_address; }
  public void  setdestination_id(String destination_id )            { this.destination_id = destination_id; }
  public void  setcurrency_id(String currency_id )               { this.currency_id = currency_id; }
  public void  setexchange_rate(float exchange_rate )              { this.exchange_rate = exchange_rate; }
  public void  setcancel_flag(String cancel_flag )               { this.cancel_flag = cancel_flag; }
  public void  setcancel_date(String cancel_date )               { this.cancel_date = cancel_date; }
  public void  setcancel_remark(String cancel_remark )             { this.cancel_remark = cancel_remark; }
  public void  setreject_flag(String reject_flag )               { this.reject_flag = reject_flag; }
  public void  setreject_date(String reject_date )               { this.reject_date = reject_date; }
  public void  setreject_remark(String reject_remark )             { this.reject_remark = reject_remark; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setord_type_sts(String ord_type_sts )              { this.ord_type_sts = ord_type_sts; }
  public void  setbooking_expiry_date(String booking_expiry_date )       { this.booking_expiry_date = booking_expiry_date; }
  public void  setbooking_confirm_date(String booking_confirm_date )      { this.booking_confirm_date = booking_confirm_date; }
  public void  setspl_instruction(String spl_instruction )           { this.spl_instruction = spl_instruction; }
}