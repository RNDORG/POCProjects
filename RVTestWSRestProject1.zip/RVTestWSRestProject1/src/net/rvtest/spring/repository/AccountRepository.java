package net.rvtest.spring.repository;

import org.springframework.data.repository.CrudRepository;

import net.rvtest.spring.bean.Account;

public interface AccountRepository extends CrudRepository<Account, Long> {

}
