package net.rvtest.spring.service;

import java.util.List;

import net.rvtest.spring.bean.Account;

public interface AccountServiceIface {
	
	Account create(Account account);
	Account get(Long accountId);
	List<Account> list();
	Account update(Account account, Long accountId);
	void delete(Long accountId);
}