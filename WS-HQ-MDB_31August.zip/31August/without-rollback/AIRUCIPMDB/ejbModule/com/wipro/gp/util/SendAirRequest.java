
package com.wipro.gp.util;

import java.util.concurrent.CountDownLatch;

import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

 /**
 * @author As-If
 */
public final class SendAirRequest implements Runnable
{
	private static final Logger logger 	= Logger.getLogger(com.wipro.gp.util.SendAirRequest.class);
	private static String urlInput 		= PropUtil.getInstance().getProperty("urlInput");
	
	private static int counter; 
	
	CountDownLatch doneSignal;
	
	String airRequestInput;	
	String parts[];	
	String origSrcSystem;
	String prevSrcSystem;
	String origTxnRefId;
	String lastSysTxnId;
	String messageType;
	String refillId;
	String refillProfileID;
	String subscriberNumber;
	String transactionCurrency;
	String adjustmentAmountRelative;
	String transactionAmount;
	String chargeRollbackFlag;
	String transactionType;
	String externalData1;
	String providerProductId;
	String chargeFlag;
	String refillFlag;
	
    public SendAirRequest() 
    {
    	
	}
    
    
    public SendAirRequest(CountDownLatch doneSignal, String message) 
    {
    	this.doneSignal 		= doneSignal;
    	this.airRequestInput 	=  message;
    	
	}
    
    public void run() 
    {
	    try
	    {	
	    	sendAirMessageReq();	    	
	    }
	    catch (Exception e) 
	    {	
	        logger.error("exception in thread, while sending request to AIR,  SendAirMessageReq() " + e.getMessage());
		}
    }
    
    
    public void sendAirMessageReq() throws Exception
    {
    	//logger.info("Entering info sendAirMessageReq() method of MDB Thread and orig id is : ");
    	CloseableHttpClient client 		= null;
    	CloseableHttpResponse response  = null;
    	
    	logger.info("Request Counter  ::::::: " + ++counter);
    	
    	try
    	{	
    		parts = airRequestInput.split("`:`");
	        origSrcSystem			 = parts[0];	        
	        prevSrcSystem			 = parts[1];
	        origTxnRefId			 = parts[2];
	        logger.info("Entering info sendAirMessageReq() method of MDB Thread and orig id is : " + origTxnRefId);
	        lastSysTxnId			 = parts[3];
	        messageType				 = parts[4];
	        refillId				 = parts[5];
	        refillProfileID			 = parts[6];
	        subscriberNumber		 = parts[7];
	        transactionCurrency		 = parts[8];
	        adjustmentAmountRelative = parts[9];
	        transactionAmount		 = parts[10];
	        chargeRollbackFlag		 = parts[11];
	        transactionType			 = parts[12];
	        externalData1			 = parts[13];
	        providerProductId		 = parts[14];
	        chargeFlag				 = parts[15];
	        refillFlag			     = parts[16];
    		
    		String responseQueueText = "";
    		client = Controller.getConnection();

    		//==========================================================
    		// Starting CHARGING UCIP section
    		//==========================================================
    		logger.debug(" In SendAirMessageReq(), Before getReChargeRequestText");
    		airRequestInput =  getReChargeRequestText();

    		logger.debug(" In SendAirMessageReq(), Before createHttpPostObject");
    		HttpPost httpPost  = createHttpPostObject(airRequestInput);
    		
    		StatusLine status   = null;
    		String content 		= null;
    		if(httpPost != null)
    		{
        		//AIR hit for RECHARGE, for not null http post request
    			try
    			{
    				logger.debug(" In SendAirMessageReq() Air Hit[BEFORE], for recharge : ");
        			response = client.execute(httpPost);
        			status   = response.getStatusLine();
        			logger.debug(" In SendAirMessageReq() Air Hit[AFTER], for recharge : ");
        			content  = EntityUtils.toString(response.getEntity());
        			responseQueueText = content;
    			}
    			catch(Exception ex)
    			{
    				logger.error(" [FAILURE-RECHARGE-NONFUNCTIONAL] for orig id : " + origTxnRefId);
    			}	
    		}
    		else
    		{
    			responseQueueText = "Issue while creating httpPost, while charging";
    			logger.error(responseQueueText);
    		}
    		if(status.getStatusCode() == 200 && (content != null && content.contains("<member><name>responseCode</name><value><i4>0</i4></value></member>")))
    		{
    			logger.info(" [SUCCESS-RECHARGE] for orig id : " + origTxnRefId);

    			//==========================================================
        		// Starting REFILL UCIP section
        		//==========================================================    		
        		logger.debug(" In SendAirMessageReq() before getRefillRequestText");
        		//Preparing Refill XML, request
    			airRequestInput =  getRefillRequestText();

    			logger.debug(" In SendAirMessageReq() before getRefillRequestText > createHttpPostObject");
    			//Preparing Post for Refill
    			httpPost = null;
    			httpPost  = createHttpPostObject(airRequestInput);
        		if(httpPost != null)
        		{
        			logger.debug(" In SendAirMessageReq() before getRefillRequestText > client.execute");
        			//AIR hit for Refill, for not null http post request
        			try
        			{
	        			response = client.execute(httpPost);
	        			status   = response.getStatusLine();
	        			content  = EntityUtils.toString(response.getEntity());
	        			responseQueueText = content;
        			}
        			catch(Exception ex)
        			{
        				logger.error(" [FAILURE-REFILL-NONFUNCTIONAL] for orig id : " + origTxnRefId);
        			}
        		}
        		else
        		{
        			responseQueueText = "Issue while creating httpPost, while REFILL";
        			logger.error(responseQueueText);
        		}
        		// Checking Refill response
        		if(status.getStatusCode() == 200 && (content != null && content.contains("<member><name>responseCode</name><value><i4>0</i4></value></member>")))
        		{
        			logger.info(" [SUCCESS-REFILL] for orig id : " + origTxnRefId);        			
        		}        			
    			else
        		{
    				logger.info(" [FAILURE-REFILL-FUNCTIONAL] for orig id : " + origTxnRefId);        			
        			responseQueueText = "<Fault> " + " <FaultCode></FaultCode>"
        					+ " <FaultDescription>Exception occured at AIR -REFILL for MSISDN: "+subscriberNumber+" origTxnRefId "+origTxnRefId
        					+ "</FaultDescription>"
        					+ " </Fault>";
        		}
    			//==========================================================
        		// Ends REFILL UCIP section
        		//==========================================================
    		}
    		else
    		{
    			logger.info(" [FAILURE-RECHARGE-FUNCTIONAL] for orig id : " + origTxnRefId);    			
    			responseQueueText = "<Fault> " + " <FaultCode></FaultCode>"
    					+ " <FaultDescription>Exception occured at AIR -UpdateBalanceAndDate for MSISDN: "+subscriberNumber+" origTxnRefId "+origTxnRefId
    					+ "</FaultDescription>"
    					+ " </Fault>";
    		}
    		
			writeToResponseQueue(responseQueueText);

        }
        catch(Exception ex)
        {	
        	logger.error("Error in Main, while sending request to AIR SendAirMessageReq() " + ex.getMessage());
        }
        finally
        {
          response.close();
    	  client.close();        	
        }
    	
    	logger.info("Extring from sendAirMessageReq() method of MDB Thread and orig id is : " + origTxnRefId);
    }
    
    
    public void writeToResponseQueue(String message) throws Exception
    {
    	logger.info("Going to write response received  for orig id : " + origTxnRefId);
    	
    	try
    	{
	    	String ConnectionFactory = "java:/ConnectionFactory";
		    String SmsQueue			 = "java:jboss/queue/AIR.RESPONSE.QUEUE.ONE";
			WriteResponseQueue wrq 	 = new WriteResponseQueue(SmsQueue, ConnectionFactory);
			wrq.sendMessage(message);
    	}
    	catch(Exception ex)
    	{
    		logger.error("Exception while writing in response queue(AIR.RESPONSE.QUEUE.ONE) for orig id: [" + origTxnRefId + "]");
    	}
    }   
    
    private HttpPost createHttpPostObject(String airRequestStr)
    {   
    	String inputStr = "";
		HttpPost httpPost 	= new HttpPost(urlInput);
		httpPost.addHeader("Content-Type", "text/xml");
		httpPost.addHeader("User-Agent", "IVR/5.0/1.0");
		//:TODO, need to change with host ip, 10.21.9.197
		httpPost.addHeader("Host", "10.10.23.191:7001");
		
		try
		{
			inputStr = airRequestStr.toString();
			logger.debug("inputStr : " + inputStr);
			inputStr = inputStr.substring(inputStr.indexOf("<methodCall>"), inputStr.indexOf("</methodCall>")) + "</methodCall>";
			logger.debug("substring inputStr " + inputStr);			
			
			StringEntity entity = new StringEntity(inputStr);
			httpPost.setEntity(entity);    		
			httpPost.addHeader("Authorization",	"Basic d2lwcm86d2lwcm9AMTIz");
		}
		catch (Exception e) 
		{	
			logger.error("Exception in substring inputStr " + e.getMessage());
			inputStr = airRequestStr.toString();
			httpPost = null;
		}
		
		return httpPost;
    }
    
    public String getRefillRequestText()
    {

    	String refillRequestText = "<methodCall><methodName>Refill</methodName><params><param><value><struct>"
    			+ "<member><name>originNodeType</name><value><string>"+prevSrcSystem+"</string></value></member>"
    			+ "<member><name>originHostName</name><value><string>"+origSrcSystem+"</string></value></member>"
    			+ "<member><name>originTimeStamp</name><value><dateTime.iso8601>20170827T17:37:15+0600</dateTime.iso8601></value></member>";
    			
    	if(origSrcSystem.equals("COMS")) origTxnRefId = lastSysTxnId;
    	if (origTxnRefId != null && origTxnRefId.length() > 20) origTxnRefId = origTxnRefId.substring(0, 19);
    	refillRequestText += "<member><name>originTransactionID</name><value><string>"+origTxnRefId+"</string></value></member>";

    	refillRequestText += "<member><name>subscriberNumber</name><value><string>"+subscriberNumber+"</string></value></member>";

    	if (( refillProfileID != null && refillProfileID.length() > 0 && refillProfileID.charAt(0) == 'T') && (externalData1 != null && externalData1.length()>0))
    	refillRequestText += "<member><name>externalData1</name><value><string>"+externalData1+"</string></value></member>";

    	if (transactionType != null && transactionType.length() > 0 )
    	refillRequestText += "<member><name>transactionType</name><value><string>"+transactionType+"</string></value></member>";
    	
    	int transactionAmountTmp = 0;
    	if ( transactionAmount != null && transactionAmount.length() > 0)
      	  transactionAmountTmp = Integer.parseInt(transactionAmount)*100;
    	float taxAmount = (float)transactionAmountTmp * (float)0.2175;
    	transactionAmountTmp += taxAmount;
    	//TOBE: TAX-LOGIC needs to be implemented
    	//if (( refillProfileID != null && refillProfileID.length() > 0 && refillProfileID.charAt(0) == 'T'))
    	refillRequestText += "<member><name>transactionAmount</name><value><string>"+transactionAmountTmp+"</string></value></member>";
    	refillRequestText += "<member><name>transactionCurrency</name><value><string>BDT</string></value></member>"
                + "<member><name>refillProfileID</name><value><string>"+refillProfileID+"</string></value></member>";
    	
       refillRequestText += "</struct></value></param></params></methodCall>";
    	
    	return refillRequestText;
    }
    
    
    public String getReChargeRequestText()
	{
    	
		String rechargeRequestText = "<methodCall><methodName>UpdateBalanceAndDate</methodName><params><param><value><struct>"
									 + "<member><name>originNodeType</name><value><string>"+prevSrcSystem+"</string></value></member>"
									 + "<member><name>originHostName</name><value><string>"+origSrcSystem+"</string></value></member>";

		if(origSrcSystem.equals("COMS")) origTxnRefId = lastSysTxnId;
    	if (origTxnRefId != null && origTxnRefId.length() > 20) origTxnRefId = origTxnRefId.substring(0, 19);
		rechargeRequestText += "<member><name>originTransactionID</name><value><string>"+origTxnRefId+"</string></value></member>";
		
		rechargeRequestText += "<member><name>originTimeStamp</name><value><dateTime.iso8601>20170622T10:00:01+0600</dateTime.iso8601></value></member>"
									 + "<member><name>subscriberNumberNAI</name><value><int>1</int></value></member>"
									 + "<member><name>subscriberNumber</name><value><string>880"+subscriberNumber+"</string></value></member>"
									 + "<member><name>transactionCurrency</name><value><string>BDT</string></value></member>";
		
    	int adjustmentAmountRelativeTmp = 0;
    	if ( adjustmentAmountRelative != null && adjustmentAmountRelative.length() > 0)
    		adjustmentAmountRelativeTmp = Integer.parseInt(adjustmentAmountRelative)*100;
    	float taxAmount = (float)adjustmentAmountRelativeTmp * (float)0.2175;
    	adjustmentAmountRelativeTmp += taxAmount;
    	//TOBE: TAX-LOGIC needs to be implemented
    	rechargeRequestText	 += "<member><name>adjustmentAmountRelative</name><value><string>-"+adjustmentAmountRelativeTmp+"</string></value></member>";

		if (transactionType != null && transactionType.length() > 0 )
			rechargeRequestText     += "<member><name>transactionType</name><value><string>"+transactionType+"</string></value></member>";
		
		rechargeRequestText			+= "<member><name>dedicatedAccountUpdateInformation</name><value>"
									 + "<array><data><value><struct>" 
									 +      "<member><name>dedicatedAccountID</name><value><i4>71</i4></value></member>"
									 + 		"<member><name>adjustmentAmountRelative</name><value><string>"+adjustmentAmountRelativeTmp+"</string></value></member>"
									 +		"<member><name>dedicatedAccountUnitType</name><value><i4>1</i4></value></member>"
									 + 		"</struct></value></data>"
									 + "</array></value></member></struct>"
									 + "</value></param></params></methodCall>";
	
		return rechargeRequestText;
	}
    
    public String getReChargeRequestTextRollback()
	{
    	if (origTxnRefId != null && origTxnRefId.length() > 20) origTxnRefId = origTxnRefId.substring(0, 19);

    	String rechargeRequestText = "<methodCall><methodName>UpdateBalanceAndDate</methodName><params><param><value><struct>"
									 + "<member><name>originNodeType</name><value><string>"+prevSrcSystem+"</string></value></member>"
									 + "<member><name>originHostName</name><value><string>"+origSrcSystem+"</string></value></member>"
									 + "<member><name>originTransactionID</name><value><string>"+origTxnRefId+"</string></value></member>"
									 + "<member><name>originTimeStamp</name><value><dateTime.iso8601>20170622T10:00:01+0600</dateTime.iso8601></value></member>"
									 + "<member><name>subscriberNumberNAI</name><value><int>1</int></value></member>"
									 + "<member><name>subscriberNumber</name><value><string>880"+subscriberNumber+"</string></value></member>"
									 + "<member><name>transactionCurrency</name><value><string>BDT</string></value></member>"
									 + "<member><name>adjustmentAmountRelative</name><value><string>"+adjustmentAmountRelative+"</string></value></member>"
									 + "<member><name>transactionType</name><value><string>"+transactionType+"</string></value></member>"
									 + "<member><name>dedicatedAccountUpdateInformation</name><value>"
									 + "<array><data><value><struct>" 
									 +      "<member><name>dedicatedAccountID</name><value><i4>71</i4></value></member>"
									 + 		"<member><name>adjustmentAmountRelative</name><value><string>-"+adjustmentAmountRelative+"</string></value></member>"
									 +		"<member><name>dedicatedAccountUnitType</name><value><i4>1</i4></value></member>"
									 + 		"</struct></value></data>"
									 + "</array></value></member></struct>"
									 + "</value></param></params></methodCall>";
	
		return rechargeRequestText;
	}
}