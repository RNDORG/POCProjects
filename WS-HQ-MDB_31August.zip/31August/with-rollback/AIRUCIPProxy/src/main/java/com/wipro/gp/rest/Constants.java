package com.wipro.gp.rest;

public class Constants {
	
	//PROD
	public static final String SMS_PROPERTY 				= "/sms/WebService/PROPS/AIR/AirPropertyFile.properties"; 
	

}
