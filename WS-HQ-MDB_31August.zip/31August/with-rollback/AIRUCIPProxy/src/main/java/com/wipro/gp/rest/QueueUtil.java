package com.wipro.gp.rest;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public class QueueUtil {
	
	
	private static int getCount(String url, String host, String port , String user, String pass){
        //String url=       "http://10.10.21.24:10090/management/subsystem/messaging/hornetq-server/default/jms-queue/ExpiryQueue?operation=resource&recursive&include-runtime&json.pretty";

        
        
        System.out.println("port:: "+port);
        HttpResponse response = null;
        HttpHost targetHost = new HttpHost(host, Integer.parseInt(port), "http");


		HttpParams httpparameters = new BasicHttpParams();
		int connectiontimeout = 10000; //1 second
		int sockettimeout = 10000;
		
		HttpConnectionParams.setConnectionTimeout(httpparameters, connectiontimeout);
		HttpConnectionParams.setSoTimeout(httpparameters, sockettimeout);


		DefaultHttpClient httpclient = new DefaultHttpClient(httpparameters);
		try 
		{
			httpclient.getCredentialsProvider().setCredentials(
					new AuthScope(targetHost.getHostName(), targetHost.getPort()), new UsernamePasswordCredentials(user, pass));
	
			HttpGet httpget = new HttpGet(url);
			httpget.addHeader("accept", "application/json");
			response = httpclient.execute(targetHost, 
			            httpget);
			// System.out.println("response:: "+response);
			
			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
	        String line = "";
	          while ((line = rd.readLine()) != null) 
	          {
	        	  ///  System.out.println(line);
	        	  if(line!=null && line.contains("message-count"))
	        	  {
	                ///  System.out.println("message-count:: "+line);
	                   String[] data= line.split(":");
	                  return Integer.parseInt(data[1].split(",")[0].trim());
	                                        
		           }
		          // System.out.println("Line: "+line);
	          }
	          
	          
		}
		catch (Exception exc) 
		{
		    exc.printStackTrace();
			System.out.println("Queue Exception digesting Authentication"+exc+" url "+url+" host "+host+" port  "+port);
			return -1;
			
		}
		finally 
		{
			httpclient.getConnectionManager().shutdown();
		}

		return 0;
	}
	
	
	public static void main(String args[])
	{
		String url= "http://10.21.9.197:10090/management/subsystem/messaging/hornetq-server/default/jms-queue/AIR.REQUEST.QUEUE.ONE?operation=resource&recursive&include-runtime&json.pretty";
		int messageCount = getCount(url, "10.21.9.196", "10090" , "admin", "Wipro@123");
		System.out.println("messageCount : " + messageCount);
		
	}


}
