package com.wipro.gp.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.wipro.gp.rest.AirUCIPService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
public class RSApplication extends Application {
	 private static Logger logger = LogManager.getLogger(RSApplication.class);
	
    public Set<Class<?>> getClasses()
    {
        Set<Class<?>> s = new HashSet<Class<?>>();
        s.add(AirUCIPService.class);
        return s;
    }
}