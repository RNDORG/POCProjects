package com.wipro.gp.rest;
 
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
 
@Path("/AirUCIPService")
public class AirUCIPService 
{
	private static Logger logger = LogManager.getLogger(AirUCIPService.class);
	
	private static final String ConnectionFactory 	= "java:/ConnectionFactory";
	private static final String SmsQueue		   	= "java:jboss/queue/AIR.REQUEST.QUEUE.ONE";
	private static final String SUCCESS_RESULT 		= "<result>success</result>"; 
	private static final String FAILURE_RESULT 		= "<result>failure</result>";
	private static final String FAILURE_THROTTLING 	= "<result>failure due to throttling limit exceeded</result>";
	private static final String FAILURE_PERMISSION 	= "<result>failure:permisssion denied</result>";
	private StringBuilder reqQueueString;
	private boolean result;
	private static final int tps = Integer.parseInt(PropUtil.getInstance().getProperty("REQ_TPS"));
	private static final String allowedUsers = PropUtil.getInstance().getProperty("ALLOWED_USERS");
	private static String[] allowedUsersArr;
	int totalCount;
	
	static
	{
		allowedUsersArr = allowedUsers.split(",");  
	}
   
   	@GET	
	@Path("/SendAirReq")	
	@Produces(MediaType.APPLICATION_XML)
	public String getMsg(@QueryParam("OrigSrcSystem") String origSrcSystem,
			@QueryParam("PrevSrcSystem") String prevSrcSystem,			
			@QueryParam("OrigTxnRefId") String origTxnRefId,
			@QueryParam("LastSysTxnId") String lastSysTxnId,
			@QueryParam("MessageType") String messageType,			
			@QueryParam("RefillId") String refillId,
			@QueryParam("refillProfileID") String refillProfileID,
			@QueryParam("subscriberNumber") String subscriberNumber,
			@QueryParam("transactionCurrency") String transactionCurrency,
			@QueryParam("adjustmentAmountRelative") String adjustmentAmountRelative,
			@QueryParam("transactionAmount") String transactionAmount,
			@QueryParam("chargeRollbackFlag") String chargeRollbackFlag,
			@QueryParam("transactionType") String transactionType,
			@QueryParam("externalData1") String externalData1,
			@QueryParam("ProviderProductId") String providerProductId,
			@QueryParam("ChargeFlag") String chargeFlag,
			@QueryParam("RefillFlag") String refillFlag
			)
	{	
   		logger.info("Entering into Air Webserice for orig id : " +  origTxnRefId);
   		
		TextMessageQueue tms = null;
		
		try 
		{
			tms 		= new TextMessageQueue(SmsQueue, ConnectionFactory);
			
			reqQueueString	= new StringBuilder();
			reqQueueString.append(origSrcSystem);
			reqQueueString.append("`:`");
			reqQueueString.append(prevSrcSystem);
			reqQueueString.append("`:`");
			reqQueueString.append(origTxnRefId);
			reqQueueString.append("`:`");
			reqQueueString.append(lastSysTxnId);
			reqQueueString.append("`:`");
			reqQueueString.append(messageType);
			reqQueueString.append("`:`");
			reqQueueString.append(refillId);
			reqQueueString.append("`:`");
			reqQueueString.append(refillProfileID);
			reqQueueString.append("`:`");
			reqQueueString.append(subscriberNumber);
			reqQueueString.append("`:`");
			reqQueueString.append(transactionCurrency);
			reqQueueString.append("`:`");
			reqQueueString.append(adjustmentAmountRelative);
			reqQueueString.append("`:`");
			reqQueueString.append(transactionAmount);
			reqQueueString.append("`:`");
			reqQueueString.append(chargeRollbackFlag);
			reqQueueString.append("`:`");
			reqQueueString.append(transactionType);
			reqQueueString.append("`:`");
			reqQueueString.append(externalData1);
			reqQueueString.append("`:`");
			reqQueueString.append(providerProductId);
			reqQueueString.append("`:`");
			reqQueueString.append(chargeFlag);
			reqQueueString.append("`:`");
			reqQueueString.append(refillFlag);
			
			logger.info(reqQueueString);
            
            result 		= tms.sendMessage(reqQueueString.toString());
            
		    return result?SUCCESS_RESULT:FAILURE_RESULT;		    
		} 
		catch (Exception e) 
		{				
			String output = "Execption in sendAirReq() webservice() " + e.getMessage() ;			
			logger.error(output);
			
			return FAILURE_RESULT;
		}
		finally		
		{	
			
			if(tms != null)		
			{		
				tms.cleanUp();		
				tms = null;
			}
			
			logger.info("Exting  from  Air webserice for orig id : " +  origTxnRefId);
		}
		
	}
   	
   	private String encodingString()
   	{
   		String msg = null;
//		if(msg.contains("%26"))
//		{
//			msg = msg.replace("%26", "&");
//		}
//		
//		if(msg.contains("%3A"))
//		{
//			msg = msg.replace("%3A", ":");
//		}
//		
//		if(msg.contains("%3C"))
//		{
//			msg = msg.replace("%3C", "<");
//		}
//		
//		if(msg.contains("%3E"))
//		{
//			msg = msg.replace("%3E", ">");
//		}
//		
//		if(msg.contains("%28"))
//		{
//			msg = msg.replace("%28", "(");
//		}
//		
//		if(msg.contains("%29"))
//		{
//			msg = msg.replace("%29", ")");
//		}
//		
//		if(msg.contains("%21"))
//		{
//			msg = msg.replace("%21", "!");	
//			
//		}
//		
//		if(msg.contains("%3B"))
//		{
//			msg = msg.replace("%3B", ";");	
//			
//		}
//		
//		if(msg.contains("%3F"))
//		{
//			msg = msg.replace("%3F", "?");	
//			
//		}
//		
//		if(msg.contains("%22"))
//		{
//			msg = msg.replace("%22", "\"");
//			
//		}
//		
//		if(msg.contains("%27"))
//		{
//			msg = msg.replace("%27", "'");
//			
//		}
//		
//		if(msg.contains("%23"))
//		{
//			msg = msg.replace("%23", "#");
//			
//		}
//		
//		if(msg.contains("%2A"))
//		{
//			msg = msg.replace("%2A", "*");
//			
//		}
//		
		//String output = "Success: MSISDN " +  msisdn + ", SMS text  : " +   msg + "Product Id :" +  prodID + " and  Destination : " + dest;
   		
   		return msg;

   	}
 
}