package com.wipro.gp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import org.apache.http.HeaderElement;
import org.apache.http.HeaderElementIterator;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
@Startup
@Singleton
public class Controller{
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.util.Controller.class);
	
	/***Configure number of workers here***/
	public final static int WORKERS 		= Integer.parseInt(PropUtil.getInstance().getProperty("workers.success"));
	public final static int MAX_CONNECTION  = Integer.parseInt(PropUtil.getInstance().getProperty("max.connection.per.ip"));
	
	//static public PoolingHttpClientConnectionManager connManager;
	
	public static PoolingHttpClientConnectionManager connManager;
	
	
	private static ConnectionKeepAliveStrategy myStrategy = new ConnectionKeepAliveStrategy() 
	{
		@Override
		public long getKeepAliveDuration(HttpResponse response, HttpContext context) 
		{
			HeaderElementIterator it = new BasicHeaderElementIterator(response.headerIterator(HTTP.CONN_KEEP_ALIVE));
			while (it.hasNext())
			{
				HeaderElement he 	= it.nextElement();
				String param 		= he.getName();
				String value 		= he.getValue();
				
				System.out.println("Param : " + param +  " Value : " + value );
				
				if (value != null && param.equalsIgnoreCase("timeout"))
				{
					//return Long.parseLong(value) * 1000;
					return 30 * 1000;
				}
			}
			return 30 * 1000;
			}
	};
	
	final static String hostt 	= "10.10.23.191:7001";
	final static  String port 	= "7001";
	final static  String userName	= "wipro";
	final static  String password = "wipro@123";
	
	
	//private final static int WORKERS = 4;	
	private static Properties properties;
	public static  int  portNo;
	public static  String systemId;
	public static String systemPwd;
	public static String systemType;
	public static int sourceTON;
	public static int sourceNPI;
	public static int destinationTON;
	public static int destinationNPI;
	public static String shortCode;        
    private static int maxConnectionsPerIP;
    
	
	
	/***************************************************************************
     * Step 1 : Load all configuration from the property file
     ***************************************************************************/
    static 
    {
    	System.out.println("--------------------------Start Loading........................................");

        // Load the property file
        logger.info("Start loading profile...");
        InputStream   propsInputStream = null;
        try
        {  
        	propsInputStream = new FileInputStream(Constants.SMS_PROPERTY);
            properties = new Properties();
            properties.load(propsInputStream);
            
            portNo          =   Integer.parseInt(properties.getProperty("port"));
            systemId        =   properties.getProperty("systemID");
            systemPwd       =   properties.getProperty("password");
            systemType      =   properties.getProperty("systemType");
            sourceTON       =   Integer.parseInt(properties.getProperty("sourceTON"));
            sourceNPI       =   Integer.parseInt(properties.getProperty("sourceNPI"));

            destinationTON  =   Integer.parseInt(properties.getProperty("destinationTON"));
            destinationNPI  =   Integer.parseInt(properties.getProperty("destinationNPI"));
            shortCode		=	properties.getProperty("shortCode");
           
        } 
        catch (Exception ex ) 
        {
        	logger.info("Exception in reading file or getting property " + ex.getMessage());
    		ex.printStackTrace();
    	} 
        finally 
        {
    		if (propsInputStream != null) 
    		{
    			try 
    			{
    				propsInputStream.close();
    			} catch (IOException e) 
    			{
    				logger.error("Exception in reading file or getting property" + e.getMessage());
    				e.printStackTrace();
    			}
    		}
    	}
        
       logger.info("Completed loading all properties" );
        
        try
        {
        	loadSMSCConnections();
        	logger.info("Loaded all connection Successfully");
        }
        catch(Exception ex)
        {
        	logger.error("Problem in loading connections......" + ex.getMessage());
        	System.exit(0);
        }
       
    
    	
    } 
	
	// Connecting Pool to connect with SMSC server
    private static void loadSMSCConnections() throws Exception
    {
    	connManager = new PoolingHttpClientConnectionManager();
    	connManager.setMaxTotal(150);
    	connManager.setDefaultMaxPerRoute(4);
    	HttpHost host = new HttpHost("http://10.199.33.22:10011/Air", 80);
    	connManager.setMaxPerRoute(new HttpRoute(host), 150);
    	
    	   
        logger.info("..................Connected with All SMSC hosts ...................");
        
    }	

	
	public static  CloseableHttpClient getConnection()
	{	
		
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
	    HttpHost targetHost = new HttpHost(hostt, Integer.parseInt(port), "http");
	    
	    credsProvider.setCredentials(new AuthScope(targetHost.getHostName(), targetHost.getPort()), new UsernamePasswordCredentials(userName, password));
	    
//		CloseableHttpClient client = HttpClients.custom().setKeepAliveStrategy(myStrategy)
//				  .setConnectionManager(connManager).setDefaultCredentialsProvider(credsProvider).build();
		CloseableHttpClient client = HttpClients.custom().setKeepAliveStrategy(myStrategy)
				  .setConnectionManager(connManager).setConnectionManagerShared(true).setDefaultCredentialsProvider(credsProvider).build();
		
				//HttpGet get = new HttpGet("http://google.com");
		
		return client;
	}
	
	public static void closeConnection(CloseableHttpResponse response)
	{
		try 
		{
			response.close();
			
		} catch (IOException e)
		{			
			e.printStackTrace();
		}
	}
	
		

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception 
	{	
		String air51Input 	= "<methodCall>refill</methodCall>";
		String inputStr = air51Input.toString();		
		String hostt 	= "10.10.23.191:7001";
		String port 	= "7001";
		String userName	= "wipro";
		String password = "wipro@123";		
		 
		CloseableHttpClient client = getConnection();		
		//HttpGet get = new HttpGet("http://google.com");
		
		String urlInput 	= "http://10.199.33.22:10011/Air"; 
		HttpPost httpPost 	= new HttpPost(urlInput);
		httpPost.addHeader("Content-Type", "text/xml");
		httpPost.addHeader("User-Agent", "IVR/5.0/1.0");
		httpPost.addHeader("Host", "10.10.23.191:7001");
		

		
		try {
			inputStr = air51Input.toString();
			inputStr = inputStr.substring(
					inputStr.indexOf("<methodCall>"),
					inputStr.indexOf("</methodCall>"))
					+ "</methodCall>";
		} catch (Exception e) {
			inputStr = air51Input.toString();
		}
		StringEntity entity = new StringEntity(inputStr);

		httpPost.setEntity(entity);
		
		httpPost.addHeader("Authorization",	"Basic d2lwcm86d2lwcm9AMTIz");
		
		CloseableHttpResponse response = client.execute(httpPost);
		
		//EntityUtils.consume(response.getEntity());
		
		
		StatusLine status = response.getStatusLine();			
		String content = EntityUtils.toString(response.getEntity());
		//JSONObject json = new JSONObject(content);	
		
		if(status.getStatusCode() == 200)
		{
			//write to response q with success
//			String ConnectionFactory = "java:/ConnectionFactory";
//		    String SmsQueue="java:jboss/queue/AIR.RESPONSE.QUEUE.ONE";
//			WriteResponseQueue wrq 		= new WriteResponseQueue(SmsQueue, ConnectionFactory);
//			wrq.sendMessage(content);
			
		}
		else
		{
			//write to response q with error
			
			String finalResponse = "<Fault> " + " <FaultCode></FaultCode>"
					+ " <FaultDescription>Exception occured at AIR - "
					+ "</FaultDescription>"
					+ " </Fault>";
		}			
		
		
		
		response.close();
		client.close();
		//connManager.close();
	}
	
	@PostConstruct 
    void atStartup() {
	}

    @PreDestroy
    void atShutdown() { }
	
	public void finalize()
	{
		
	}

}
