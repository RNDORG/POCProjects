package com.wipro.gp.util;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateUtil 
{
	private static final Logger logger = Logger.getLogger(com.wipro.gp.util.HibernateUtil.class);

	private static ServiceRegistryBuilder serviceRegistryBuilder; 
	private static SessionFactory sessionFactory;
	private static ServiceRegistry serviceRegistry;
	
	
	public static SessionFactory getSessionFactory() 
	{
		
		logger.info("In getSessionFactory() method.");
	     if(sessionFactory == null)
	     {
	    	 logger.info("SessionFactory null and going to creating sessionFactory");
	          createSessionFactory();
	      }
	     else
	     {
	    	 logger.info("Going to use already created sessionFactory");
	     }
	     
	      return sessionFactory;
	}
	
	
	private synchronized static void createSessionFactory()
	{
		
	    if(sessionFactory != null)
	    {
	    	return;
	    }	    
	    
	    try
	    {  
	            Configuration configuration = new Configuration().configure(HibernateUtil.class.getResource("/hibernate.cfg.xml"));
	            logger.debug("1. configuration done");
	            StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder();
	            logger.debug("2. serviceRegistryBuilder done");
	            serviceRegistryBuilder.applySettings(configuration.getProperties());
	            logger.debug("3. Apply setting  done");
	            ServiceRegistry serviceRegistry = serviceRegistryBuilder.build();
	            logger.debug("4. serviceRegistry  done");
	            sessionFactory = configuration.buildSessionFactory(serviceRegistry);
	            logger.debug(" -- sessionFactory  created -- ");	         
	         
	    } 
	    catch (Throwable ex)
	    {
	    	logger.info("Initial SessionFactory creation failed : " + ex.getMessage());
	    	
	        throw new ExceptionInInitializerError(ex);
	    }
	    
	 }  

}

