package com.wipro.gp.util;

public  class  Constants {
	//SIT with SMSC
	// public static final String SMS_PROPERTY 		= "/home/oracle/SMPPSIM/WebSMSConfiguration.properties";
	
	//SIT with Local simulator
	//public static final String SMS_PROPERTY 		= "/home/oracle/SMPPSIM/Local/WebSMSConfiguration.properties";
	
	//Prod
	//public static final String SMS_PROPERTY 		= "/home/stanveer/smsapp/WebSMSConfiguration.properties";	
	///public static final String SMS_PROPERTY 	    = (System.getProperty("user.dir") + "/configuration/PropertyFile.properties");
	                                                                       
	//public static final String SMS_PROPERTY 	    = "/sms/Jboss_SMS/standalone/standalone3/configuration/PropertyFile.properties";
	public static final String SMS_PROPERTY 			= "/sms/WebService/PROPS/AIR/AirPropertyFile3.properties";	
	
	public static final String STATUS_PENDING 			= "PENDING";
	public static final String STATUS_PUBLISHED 		= "PUBLISHED";
	public static final String SMS_APP 					= "ESB";
	public static final int  VALID_KEYWORD_LENGTH		= 40;
	public static final String  IGNORE_SHORT_CODE_1  	= "19221";
	public static final String  IGNORE_SHORT_CODE_2  	= "19240";
	public static final String  IGNORE_SHORT_CODE_3  	= "19226";	
	public static final String  IGNORE_SHORT_CODE_4  	= "19230";
	public static final String  IGNORE_SHORT_CODE_5  	= "19234";	
	public static final String COUNTRY_CODE				= "880";
	public static final int RTHROTTLED 					= 88;
	public final static int WORKERS_FOR_SEND_SMS 		= Integer.parseInt(PropUtil.getInstance().getProperty("workers.for.send.sms"));
	public final static int SMSC_THREADS		 		= Integer.parseInt(PropUtil.getInstance().getProperty("smsc.threads"));
	public final static int REQ_TPS	 					= Integer.parseInt(PropUtil.getInstance().getProperty("req.tps"));
	
	

}
