package com.wipro.gp.util;

import javax.jms.JMSException;

public interface JMSQueue {

    public boolean sendMessage(String textMessage) throws JMSException;

    public void cleanUp();
}
