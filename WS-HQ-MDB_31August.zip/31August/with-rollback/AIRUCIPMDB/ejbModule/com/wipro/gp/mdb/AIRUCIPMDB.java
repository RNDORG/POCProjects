package com.wipro.gp.mdb;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.wipro.gp.util.BoundedExecutor;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.SendAirRequest;




/**
 * Message-Driven Bean implementation class for: SMSMDB
 */

@MessageDriven(activationConfig = { @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
        @ActivationConfigProperty(propertyName = "maxSession", propertyValue = "150"), @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
        @ActivationConfigProperty(propertyName = "destination", propertyValue = "java:jboss/queue/AIR.REQUEST.QUEUE.ONE") })
@TransactionManagement(value = TransactionManagementType.BEAN)
public class AIRUCIPMDB implements MessageListener 
{
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.mdb.AIRUCIPMDB.class);
	
	String msisdn;
	String msg;
	String prodId;
	String shortCode;
	String[] parts;
	static int i = 1;
	static ExecutorService executor;
	static CountDownLatch doneSignal;
	static BoundedExecutor boundedExecutor;
	
	static
	{
		 
		executor  = Executors.newFixedThreadPool(Constants.WORKERS_FOR_SEND_SMS);
		doneSignal = new CountDownLatch(Constants.WORKERS_FOR_SEND_SMS);
		boundedExecutor = new BoundedExecutor(executor, Constants.REQ_TPS);
	}
	

    /**
     * Default constructor. 
     */
    public AIRUCIPMDB() {
        
    }
	
	/**
     * @see MessageListener#onMessage(Message)
     */
    public void onMessage(Message message) 
    {       
    	
    	logger.info("Entering into AIR MDB onMessage()");
    	
    	String mess = null;
    	SendAirRequest  sendAirRequest;
		
			try 
			{
				mess  = ((TextMessage)message).getText();
				
				logger.info("Message : " + mess);
        		
	        	sendAirRequest = new SendAirRequest(doneSignal, mess);
				boundedExecutor.submitTask(sendAirRequest);
			}
			catch (Exception e) 
			{	
				logger.error("Exception in AIR MDB onMessage()" + e.getMessage());				
			}
			finally
			{
				sendAirRequest = null;				
			}
			
			logger.info("Exiting from AIR MDB onMessage()");
    }
    

}
