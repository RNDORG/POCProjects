package com.wipro.gp.db;


import java.io.Serializable;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.wipro.gp.bean.ESBValidSms;
import com.wipro.gp.bean.ValidSms;
import com.wipro.gp.service.ReceiveMessageService;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.HibernateUtil;

public class ReceiveMessageDao {
	
//	private static final Logger logger = Logger.getLogger(com.wipro.gp.db.ReceiveMessageDao.class); 
	
	//private static final String STATUS = "PENDING"; 
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.db.ReceiveMessageDao.class);
	
	public long saveMessage(String smsText, String source_msisdn, String dest_shortCode, String prodId, String creationDate, boolean isValidSms)
	{
	
		logger.info("Entering into saveMessage...");
		
		SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();
		long id 					  =  0 ;
					
		if(sessionFactory == null)
		{			
			logger.info("SESSION IS NULL...");
		}
		
		Session session 	 = null;
		Transaction txUpdate = null;
	    Query q				 = null;;
	    
		try
		{
			// opens a new session from the session factory
			session  = sessionFactory.openSession();
			txUpdate = session.beginTransaction();
			
			
			if(isValidSms)
			{	
				logger.debug("Valid Sms length detected");
				
				ValidSms validSms = new  ValidSms(source_msisdn, dest_shortCode, smsText, Constants.STATUS_PENDING, prodId,
						null,creationDate, Constants.SMS_APP, "", "", null, null, null, null, null);
				 id = (Long) session.save(validSms);			
				logger.debug("created id: " + id);
			}
			else
			{	
				logger.debug("Going to Save message into ESBValidSms.");
								
				//:TODO Need to Move into map for performance
	            //q = session.createQuery("Update ThrottledManager set QCounter=QCounter-1");            
	            //q.executeUpdate();
				ESBValidSms esbValidSms = new  ESBValidSms(source_msisdn, dest_shortCode, smsText, Constants.STATUS_PENDING,Constants.STATUS_PENDING, prodId,
						null,creationDate, Constants.SMS_APP, "", "", null, null, null, null, null);
				
				//Serializable id = session.save(invalidSms);
				id = (Long) session.save(esbValidSms);
				logger.debug("created id for ESBValidSms : " + id);
			}
			
			txUpdate.commit();
		}
		catch(Exception ex)
		{
			logger.error("Exception in saveMessage() due to : " + ex.getMessage());
			
		}	
		finally
		{
			session.close();
		}
		
		
		return  id;
		
	}
	
	public static void main(String args[])
	{	
		ReceiveMessageService receiveMessageService = new ReceiveMessageService();
		receiveMessageService.receiveMessage("SUBS 1 GB", "9999359786", "1900", "P123");
	}
	
}
