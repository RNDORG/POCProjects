package com.wipro.gp.service;

import java.util.Date;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.wipro.gp.db.ReceiveMessageDao;
import com.wipro.gp.util.Constants;
import com.wipro.gp.util.DateUtil;
import com.wipro.gp.util.HibernateUtil;

public class ReceiveMessageService {
	
	private static final Logger logger = Logger.getLogger(com.wipro.gp.service.ReceiveMessageService.class);
	
	SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();
	Session session; 
    Transaction txUpdate;
    Query q;
    
    int totalCount;
	
	ReceiveMessageDao receiveMessageDao = new ReceiveMessageDao(); 
	
	
	public void receiveMessage(String smsText, String source_msisdn, String dest_shortCode, String prodId)	
	{	
		logger.info("Entering into receiveMessag method.");		
		
		Date currDate 		 		= new Date();
		String creationDate 		= DateUtil.parseDate(currDate, "yyyy-MM-dd HH:mm:ss");
		boolean isValidSms 			= false;
		dest_shortCode 				= dest_shortCode.trim();
		Pattern pattern 			= Pattern.compile("[0-9 ]+");
		boolean isExceptionalCase 	= pattern.matcher(smsText).matches(); // " 9999359786 9999359786   9999359786  "
		
		if(smsText.length() <= Constants.VALID_KEYWORD_LENGTH || isExceptionalCase || (smsText.toUpperCase()).startsWith("CF "))
		{	
			isValidSms = true;
			//tms 		= new TextMessageQueue(SmsQueue,ConnectionFactory);
			//smsInfo 	= msisdn + "`:`" + msg + "`:`" + prodID + "`:`" + dest;			
			//logger.info(smsInfo);
			session  = sessionFactory.openSession();
			//int totalCount = ((Integer)session.createQuery("select QCounter from ThrottledManager ").uniqueResult()).intValue();
			
			txUpdate = session.beginTransaction();
            q = session.createQuery("Update ThrottledManager set QCounter=QCounter-1");
            q.executeUpdate();
            txUpdate.commit();
           // logger.info("*************totalCount is**************" + totalCount);
		}
//		else if((Constants.IGNORE_SHORT_CODE_1).equals(dest_shortCode) || (Constants.IGNORE_SHORT_CODE_2).equals(dest_shortCode) 
//				|| (Constants.IGNORE_SHORT_CODE_3).equals(dest_shortCode)
//				|| (Constants.IGNORE_SHORT_CODE_4).equals(dest_shortCode)
//				|| (Constants.IGNORE_SHORT_CODE_5).equals(dest_shortCode))
//		{
//			isValidSms = true;
//		}		
		else
		{
			isValidSms = false;
		}
				
		receiveMessageDao.saveMessage(smsText,source_msisdn, dest_shortCode, creationDate, prodId,  isValidSms);	
				
		
		logger.info("Exiting from  insert...");
		
	}
	
	public static void main(String args[])
	{
		ReceiveMessageService dbInsert = new ReceiveMessageService();
		
		dbInsert.receiveMessage("Cf 7161 9718565538 8801700733750", "9999359786", "1900", "123");
	}
	
}
