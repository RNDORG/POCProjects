package com.wipro.gp.util;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.wipro.gp.util.JMSQueue;


public class WriteResponseQueue implements ExceptionListener, JMSQueue 
{
	
	private static Logger logger = LogManager.getLogger(WriteResponseQueue.class);
	
    private QueueConnection qc = null;
    private QueueSession qsess = null;
    private QueueSender qsndr = null;
    private String ConnectionFactory = "java:/ConnectionFactory";
    private String SmsQueue="java:jboss/queue/AIR.RESPONSE.QUEUE.ONE";
    /**
     * TextMessage Queue (Sends any type of text message)
     * 
     * @throws Exception
     */
    public WriteResponseQueue(String queueName, String queueConnectionFactory) throws Exception {

        try
        {          
            InitialContext ctx = new InitialContext();
            /*************** GP CRM Changes end here ***************/

            QueueConnectionFactory qcf = (QueueConnectionFactory) ctx.lookup(ConnectionFactory);

            qc = qcf.createQueueConnection();          

            qc.setExceptionListener(this);

            qsess = qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

            Queue queue = (Queue) ctx.lookup(queueName);

            qsndr = qsess.createSender(queue);
      
            ctx.close();

        } catch (Exception e)
        {
        	throw new Exception("Issue in writing in response exception" + e.getLocalizedMessage());
            
        }
    }

    /**
     * Sends text Message to destination queue
     * 
     * @param textMessage
     */
    @Override
    public boolean sendMessage(String textMessage) throws JMSException {
        boolean status = false;
        TextMessage message = null;
        try 
        {    
            logger.info("Inside SendMessage method");
        	message = qsess.createTextMessage();
            message.setText(textMessage);
            qsndr.send(message);
            status = true;

        }
        catch (JMSException jmse) 
        {          
        	logger.error(jmse.getMessage());
        }
        
        return status;
    }

    /**
     * Clear up all instance variables and closes queue connection
     */
    @Override
    public void cleanUp() 
    {
        try 
        {
            qsndr.close();
            qsndr = null;
            qsess.close();
            qsess = null;
            qc.close();
            qc = null;
        }
        catch (JMSException jmse) 
        {
           logger.error(jmse.getMessage());
        }
    }

    /**
     * @param JMSException
     */
    @Override
    public void onException(JMSException exception) 
    {       
    	logger.error(exception.getMessage());
    }
}
